# GDA Command Platform — S-164 Kickoff

**Last session:** S-163 — April 24, 2026
**Operator:** Shawn Seffernick, President EIS/GDA OU3
**Platform:** Retool — gdacommand.retool.com
**Editor:** https://gdacommand.retool.com/editor/9b2e8dbe-3f30-11f1-a98a-d30e2de07c9f/GDA%20Command%20Platform/dashboard

---

## Pre-Flight (Every Chat)
1. tool_search("n8n") — load MCP
2. Read this file
3. RR-38 and RR-28 are FROZEN — do not touch ever

---

## FIRST ACTION NEXT CHAT

**S-163-01 (Med) — getMegaDash returns { "message": "" }**

Root cause is unresolved. Execution 86025 confirmed Check Cache returns 0 rows (cache MISS occurring), but the workflow still completes in 31ms with empty payload. Suspect: Build Response code node silently errors on one of the $('Query All').first() calls.

**First 3 steps:**
1. Enable saveDataSuccessExecution: all on UYGJPu7N5YZblvEU
2. Run getMegaDash from Retool
3. Read execution via n8n_executions(action=get, mode=filtered, nodeNames=["Build Response","Respond","Respond Cached","Query All"]) to see what data each node produced

Then fix whatever is empty/erroring. After table is live, proceed to S-162-02 (E2E test).

---

## What Was Done S-163

- getMegaDash Advanced: Run on page load = ENABLED
- n8n credential fTrhOzBkjS1s67bm updated to gda-api-2026-8ced0b75
- Auth Check patched: accepts both gda-api-2026-secure and gda-api-2026-8ced0b75
- Query All patched: opps sub-query added (id, Opportunity, Agency, Est. value ($M), GDA score, PWin, Due date)
- dashboard-mega versionCounter: 83
- dashboard-mega restored to production state (TTL 60min, saveDataSuccessExecution: none)

---

## Open Debt

| ID | Sev | Summary |
|---|---|---|
| S-163-01 | Med | getMegaDash opps table — { message: '' } payload. Debug Build Response node next session. |
| S-162-02 | Low | E2E functional test all 25 Retool pages |
| RR-43 | Low | Bot dual-routing double-fire — fix when telegram-chat next touched |
| RR-36 | Med | Chrome MCP cross-origin — workaround in place |
| RR-44 | Low | Webhook headerAuth workaround documented |
| RR-38 | FROZEN | Do not touch |
| RR-28 | FROZEN | Do not touch |

---

## Platform State

Retool app: LIVE — gdacommand.retool.com
Total pages: 25
n8n backend: https://n8n.csr-llc.tech/webhook
Auth header: x-gda-key: gda-api-2026-8ced0b75
GDA Postgres: Connected as "GDA Postgres" in Retool
n8n active workflows: ~156
React source (VPS): /opt/gda-command/src/App.jsx — 415KB
n8n: https://n8n.csr-llc.tech (v2.37.1)
MCP: https://mcp.csr-llc.tech/mcp

---

## Key Credentials

VPS SSH cred: VqYFb1aRGJa8UfBc
GDA webhook auth cred: fTrhOzBkjS1s67bm (x-gda-key: gda-api-2026-8ced0b75)
Anthropic: direct HTTP with $env.ANTHROPIC_API_KEY (model: claude-sonnet-4-20250514)
LangChain cred d92MU0tRK7bEGV83: BROKEN — never use
GDA.bot.telegram-chat: 1ItrrFxGI3L43Pdv
GDA.dev.deploy: 8GnGxnBL9TJjj1i2
GDA.intel.morning-briefing-v1: YIvCdrOgF1LGmFNL
GDA.api.dashboard-mega: UYGJPu7N5YZblvEU

---

## Key Workflow IDs (unchanged from S-162)

| Workflow | ID |
|---|---|
| GDA.dev.deploy | 8GnGxnBL9TJjj1i2 |
| GDA.bot.telegram-chat | 1ItrrFxGI3L43Pdv |
| GDA.api.dashboard-mega | UYGJPu7N5YZblvEU |
| GDA.intel.morning-briefing-v1 | YIvCdrOgF1LGmFNL |
| GDA.api.capture-plan | QgperN6cuOpfnb09 |
| GDA.util.ssh-read-file | IcD4K740vpWSIuaZ |

---

## Rules

- Claude executes via MCP only. Never tell Shawn to manually do things.
- RR-38 and RR-28 are FROZEN. Do not touch.
- End every session: R-SR-09 (4 artifacts: Session Delta DOCX, DevOps Report DOCX, Master Build XLSX, Kickoff MD).
- Webhook auth workaround (RR-44): temp set to none, fire, restore headerAuth.
- n8n platform rules: never queryReplacement at typeVersion 2.5/2.6; Switch node broken — use IF; LangChain cred d92MU0tRK7bEGV83 broken.
