# S-182 SESSION KICKOFF
**GDA Command Platform | EIS / GDA OU3 | Shawn Seffernick**
**Generated: 2026-05-01 (S-181 Close)**

---

## MANDATORY FIRST ACTION
```
tool_search("n8n")   ← load MCP before ANY other action
```

---

## CARRY-FORWARD STATUS
- R-SR-09 artifacts from S-181: COMPLETE (Session Delta DOCX, DevOps Report DOCX, Master Build XLSX v4.181, this Kickoff MD)
- MCP-AUTH COMPLETE: GDA.mcp.proxy Auth Check updated to 2027 key; webhook cred fixed to 1pNPY36DDz49OtKL
- SSH-KEY COMPLETE: ed25519 keypair generated; cred NKOxLo5F81sRNPua active; all SSH nodes updated; VPS confirmed root@srv1397562

---

## S-182 PRIORITY QUEUE (Execute in Order)

| Rank | ID | Priority | Description |
|------|----|----------|-------------|
| 1 | **SSH-CLEANUP** | 🟡 MED | Delete orphan SSH creds: fiCbDZ3ahacK6FCA (failed key) and consider deprecating VqYFb1aRGJa8UfBc (password, wrong host). Verify no workflows still reference them. |
| 2 | **GIST-UPDATE** | 🟡 MED | Fire gist-update (PoOofuf0OgaYJCBN) to confirm it works with new 2027 key; update gist content with S-181 SITREP |
| 3 | **NEXT-FEATURE** | ⬜ LOW | Pull next feature/fix from platform backlog — confirm with Shawn |

---

## PLATFORM SNAPSHOT (entering S-182)

| Component | Status |
|-----------|--------|
| n8n | OPERATIONAL (2.49.0) |
| Frontend (gda.csr-llc.tech) | OPERATIONAL |
| Postgres | OPERATIONAL |
| Traefik | OPERATIONAL — rate limiting active |
| Gist-update (PoOofuf0OgaYJCBN) | OPERATIONAL (key status unverified post-rotation) |
| capture-plan AI agent | UPGRADED — EIS win themes + incumbent intel live (v404) |
| MCP Server | ✅ OPERATIONAL — 2027 key active |
| SSH auth | ✅ Key-based (ed25519, NKOxLo5F81sRNPua) |

---

## CANONICAL KEYS (post S-178 rotation)

```
x-gda-key:     gda-api-2027-AWqjhbxDYNcyV1mr
deploy-key:    gda-deploy-2027-a4zslQ79hn9A9UIi
GDA Webhook Auth cred ID: 1pNPY36DDz49OtKL
GitHub Gist PAT cred ID:  sKJFLNzetK86JnvO
VPS SSH Key cred ID:      NKOxLo5F81sRNPua
Postgres cred ID:         HwronxMmGY5XDGEt
```

---

## STANDING HARD RULES (never break)
- **Switch node** → broken platform-wide → use IF or Code nodes
- **LangChain cred `d92MU0tRK7bEGV83`** → permanently broken → use HTTP + `$env.ANTHROPIC_API_KEY`
- **Postgres typeVersion 2.5/2.6** → inline `{{ $json.field }}` in SQL only
- **App.jsx / GDALaunchpad.jsx source** → lives as base64 in gist → edit gist, redeploy
- **n8n container restart** → never `docker compose up -d n8n` from within n8n
- **N8N_ENCRYPTION_KEY** → must persist in `/root/n8n-envision/.env`
- **MCP test trigger** → does NOT pass x-gda-key → use temporary auth bypass pattern
- **RR-38, RR-28** → FROZEN
- **nginx.conf** → mounted volume, cannot docker cp — edit on host, restart container

---

## KEY IDs (quick reference)
```
Dashboard-Mega:    UYGJPu7N5YZblvEU
SSH Exec:          IcD4K740vpWSIuaZ
Deploy:            8GnGxnBL9TJjj1i2
Gist-update:       PoOofuf0OgaYJCBN
Morning Briefing:  YIvCdrOgF1LGmFNL
Briefing API:      0zVPgmYsvcqhyyo6
Capture-Plan:      QgperN6cuOpfnb09  ← v404, AN-1 complete
GDA Webhook Cred:  1pNPY36DDz49OtKL
GitHub Gist PAT:   sKJFLNzetK86JnvO
VPS SSH Key:       NKOxLo5F81sRNPua
Postgres:          HwronxMmGY5XDGEt
```

---

## SESSION PROTOCOL REMINDER
- Do not interrogate. Do not run in circles. Do not contradict prior sessions.
- If Shawn says "continue" / "go" / anything ambiguous → execute top item from queue above.
- Close every session with R-SR-09 (4 artifacts).
- AUTONOMY RULE: Claude executes everything via MCP. Never ask Shawn to manually edit files.

---
*S-182 Kickoff | GDA Command Platform | EIS / GDA OU3 | CONFIDENTIAL*
