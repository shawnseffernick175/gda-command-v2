# GDA Command — React Frontend

The primary GDA Command UI. Single-page Vite + React 19 app served from nginx behind a same-origin `/api` proxy. **Zero secrets in the frontend** — all API auth is performed server-side (nginx proxy today, GDA API Gateway next). React only ever calls relative `/api/<workflow-name>` paths.

## Live
- Production: https://gda.csr-llc.tech
- QA Center (new): https://gda.csr-llc.tech/#qa-center

## Stack
- Vite 7 + React 19
- recharts for visualizations
- Inline styles via `src/lib/gda.jsx` style helpers (no CSS framework)

## Quick start

```bash
git clone https://github.com/shawnseffernick175/gda-command.git
cd gda-command
npm install
npm run build
```

There's no dev server script today (`vite build` only). To run locally:
```bash
npx vite          # http://localhost:5173 — backend calls will 404 unless you proxy /api
```

## Deploy
The repo includes a GitHub Actions workflow at `.github/workflows/deploy.yml` that SSHes to the production VPS and runs `git pull && npm run build && docker restart gda-command` on push to `main`. Secrets required (configured in repo settings, not in code):
- `VPS_SSH_KEY`

The `deploy.sh` script in the repo root contains the same commands for manual VPS-side runs.

## Architecture

```
React UI  ─►  /api proxy (nginx)  ─►  n8n workflows  ─►  Postgres / external services
                                                 │
                                                 └─►  GDA API Gateway (next layer; v1 built separately)
```

- The `/api` proxy injects auth and forwards to n8n. The browser never sees `x-gda-key` or any other secret.
- Direct calls to `https://n8n.csr-llc.tech/webhook/...` from the browser are not allowed and are now stripped from `src/`.

## QA Center
A new sidebar page under PLATFORM that runs read-only health checks and dry-run probes against the same-origin `/api` routes — no PowerShell, no secrets.

- Source: `src/components/pages/QACenterPage.jsx`
- Buttons: **Run Health Check** (8 read-only probes), **Run Dry-Run Checks** (2 approved dry-run probes labeled “NO PRODUCTION WRITES”)
- Stable `data-testid` attributes for QA automation

## Code map
- `src/App.jsx` — sidebar config, router, and a handful of remaining inline pages (~5,300 lines, being migrated out per `CLAUDE.md`)
- `src/components/pages/*.jsx` — extracted page components (33 files including QA Center)
- `src/lib/gda.jsx` — `api` helper, styles, shared UI components
- `public/` — static assets
- `.github/workflows/deploy.yml` — CI deploy on push to `main`

## Conventions
See `CLAUDE.md` for the modularization plan, dependencies between components, and the rules that govern further extraction work.

## Repo hygiene
- `node_modules/` and `dist/` are git-ignored.
- `.env` and any `.env.*.local` are git-ignored.
- Backup snapshots of `App.jsx` (`*.bak*`, `*.pre-modularize`, etc.) are git-ignored.
