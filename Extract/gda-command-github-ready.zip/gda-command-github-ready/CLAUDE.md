# GDA Command — Claude Code Modularization Guide

## CRITICAL RULES
1. Source: `/opt/gda-command/src/App.jsx` (5,676 lines) — the monolith
2. NEVER touch `/root/gda-frontend/src/` — that's a dead stub
3. Build: `cd /opt/gda-command && node node_modules/.bin/vite build` (NOT npm run build)
4. Deploy: `cp -r dist/* /root/gda-frontend/dist/ && docker restart n8n-envision-gda-frontend-1`
5. Shared lib: `src/lib/gda.jsx` — exports api, styles, constants, ActionHistory, saveAction
6. Already-extracted pages live in `src/components/pages/*.jsx` (29 files)
7. App.jsx imports them at lines 8-31

## OBJECTIVE
Split the 5,676-line App.jsx into component files under `src/components/pages/`.
The goal is to move inline functions into their own files while keeping the app working.

## COMPONENT MAP (what to extract)

### Priority 1: Large inline components (500+ lines each)
| Component | Lines | Target File |
|---|---|---|
| `Launchpad()` | 528-1652 (~1,124 lines) | `src/components/pages/LaunchpadPage.jsx` |
| `OppTracker()` | 1832-2865 (~1,033 lines) | `src/components/pages/OppTrackerPage.jsx` |
| `CompIntel()` | 2948-3205 (~257 lines) | `src/components/pages/CompIntelPage.jsx` |
| `CapturePlan()` | 3510-4180 (~670 lines) | `src/components/pages/CapturePlanPage.jsx` |
| `AopTrackerPage` | 4516-5377 (~861 lines) | Already a var — move to `src/components/pages/AopTrackerPage.jsx` |

### Priority 2: Medium components (100-500 lines)
| Component | Lines | Target File |
|---|---|---|
| `PredictiveIntel()` | 3358-3505 (~147 lines) | `src/components/pages/PredictiveIntelPage.jsx` |
| `MeetingNotes()` | 4328-4457 (~129 lines) | Already exists — verify import |
| `PromptArchitect()` | 4181-4327 (~146 lines) | `src/components/pages/PromptArchitectPage.jsx` |
| `DocumentHub()` | 3207-3222 (~15 lines) | Keep inline or merge |

### Priority 3: Utility functions to extract to lib/
| Function | Lines | Target |
|---|---|---|
| `normalizeDept()` | 273-307 | `src/lib/department-utils.js` |
| `cleanBranch()` | 308-350 | `src/lib/department-utils.js` |
| `calculatePwin()` | 351-374 | `src/lib/scoring.js` |
| `calculateGDAScore()` | 375-417 | `src/lib/scoring.js` |
| `formatMarketVal()` | 1654-1662 | `src/lib/format.js` |
| `agencyToLevel2()` | 1663-1715 | `src/lib/department-utils.js` |
| `mapDepartment()` | 1716-1737 | `src/lib/department-utils.js` |
| `calculateEisBonus()` | 1738-1750 | `src/lib/scoring.js` |
| `calculateEisFitScore()` | 1751-1761 | `src/lib/scoring.js` |
| `renderMarkdown()` | 2866-2931 | `src/lib/markdown.js` |

## EXTRACTION PROCEDURE
For each component:
1. Copy the function and all its local helpers to the new file
2. Add `import React, { useState, useEffect, useRef, useMemo, useCallback, useReducer } from 'react';`
3. Add `import { api, ACCENT, NAVY, WHITE, BORDER, FONT, S, GDA_TEAL, GDA_GOLD, GDA_GREEN, GDA_BLUE, PageHeader, Spinner, Empty, Alert, GDAKpiBar, SourceTag, FreshnessTag, formatDollar, gdaNav, ActionHistory, saveAction, sanitizeExport } from '../../lib/gda';`
4. Add `export default ComponentName;`
5. In App.jsx, replace the function body with an import
6. Build and verify

## SHARED STATE
The following global state is used across components:
- `gdaNav` (imported from lib/gda.jsx) — navigation targets
- `window._gdaNavigate` — tab navigation function (set in App.jsx)
- `goToTab` — local alias for _gdaNavigate
- STAGE_MAP, STAGE_COLORS — constants defined in App.jsx around line 1770

Move STAGE_MAP and STAGE_COLORS to lib/gda.jsx before extracting OppTracker.

## DEPENDENCIES BETWEEN COMPONENTS
- Launchpad uses: `formatDollar`, `calculatePwin`, `GDAScoreBadge`, `GDASparkline`, `useTrendData`, `compositeScore`, `ScoreBadge`
- OppTracker uses: `normalizeStage`, `stageColor`, `suggestedStage`, `calculateEisBonus`, `calculateEisFitScore`, `OppSourceBadge`, `OppFitBar`, `getDeptForAgency`, `inferCommand`, `getGDACompany`, `renderOppDetailPanel`, `renderOppCard`, `renderMarkdown`
- CompIntel uses: `renderMarkdown`
- CapturePlan uses: `formatDollar`, `renderMarkdown`

Move shared helpers to lib/ FIRST, then extract components.

## VERIFICATION
After each extraction:
1. `node node_modules/.bin/vite build` — must succeed with zero errors
2. `cp -r dist/* /root/gda-frontend/dist/ && docker restart n8n-envision-gda-frontend-1`
3. Load gda.csr-llc.tech in browser
4. Navigate to the extracted tab — verify it renders
5. Click all action buttons — verify API calls work
6. Check browser console — zero errors

## DO NOT
- Do NOT extract the main App() function or the router/sidebar/header
- Do NOT change any API endpoint paths
- Do NOT modify lib/gda.jsx exports (only add new ones)
- Do NOT change the PAGES object structure at the bottom of App.jsx
- Do NOT rename any components — keep existing names
- Do NOT create new CSS files — all styles are inline

## MCP ACCESS
- n8n MCP: `claude mcp add --transport http n8n https://mcp.csr-llc.tech/mcp`
- SSH: VPS at 187.77.206.105
- Postgres: `gda_opportunity_tracker` database
