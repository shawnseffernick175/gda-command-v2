cd /opt/gda-command
GIT_SSH_COMMAND='ssh -i ~/.ssh/github_gda -o StrictHostKeyChecking=no' git pull origin main
npm run build
docker restart gda-command
echo "DEPLOYED at $(date)" >> /var/log/gda-deploy.log
