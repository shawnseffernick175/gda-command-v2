
import React from 'react';

const ACCENT = '#D14A2A';
const NAVY = '#1a2744';
const GREEN = '#2F5C1F';
const BLUE = '#32448A';
const ORANGE = '#B06D32';
const TEAL = '#5091A7';

const AOP = 44800000;
const FMT = (n) => n >= 1e9 ? '$' + (n/1e9).toFixed(1) + 'B' : n >= 1e6 ? '$' + (n/1e6).toFixed(1) + 'M' : n >= 1e3 ? '$' + (n/1e3).toFixed(0) + 'K' : '$' + n;

const KPI = ({label, value, sub, color, alert}) => React.createElement('div', {style:{flex:1, background:'#fff', border:'1px solid #e0e0e0', borderRadius:8, padding:'12px 16px', borderTop:'3px solid '+(color||NAVY)}},
  React.createElement('div', {style:{fontSize:9, fontWeight:700, color:'#888', letterSpacing:'0.5px', textTransform:'uppercase', marginBottom:3}}, label),
  React.createElement('div', {style:{fontSize:22, fontWeight:700, color:color||NAVY}}, value),
  sub ? React.createElement('div', {style:{fontSize:10, color: alert ? ACCENT : '#999', fontWeight: alert ? 600 : 400, marginTop:2}}, sub) : null
);

export default function ShipleyKPIBar({qualified, weighted, recompeteValue, mustWins}) {
  var q = qualified || 435000000;
  var w = weighted || 177000000;
  var rv = recompeteValue || 125000000;
  var mw = mustWins || 2;
  var coverage = (w / AOP).toFixed(1);
  var shipley5x = (q / AOP).toFixed(1);
  var recompetePct = Math.round((rv / w) * 100);
  var newBizGap = AOP * 0.12;

  return React.createElement('div', {style:{display:'flex', gap:10, marginBottom:16, flexWrap:'wrap'}},
    React.createElement(KPI, {label:'FY26 AOP (OU3)', value: FMT(AOP), sub:'12% YoY growth target', color: BLUE}),
    React.createElement(KPI, {label:'Qualified Pipeline', value: FMT(q), sub: shipley5x + 'x AOP (Shipley 5x = $224M)', color: parseFloat(shipley5x) >= 5 ? GREEN : TEAL}),
    React.createElement(KPI, {label:'Pwin-Weighted', value: FMT(w), sub: coverage + 'x coverage (need 1.0x min)', color: parseFloat(coverage) >= 1 ? GREEN : ACCENT}),
    React.createElement(KPI, {label:'Must-Win Recompetes', value: mw, sub: FMT(rv) + ' (' + recompetePct + '% of weighted)', color: ORANGE, alert: recompetePct > 60}),
    React.createElement(KPI, {label:'New Biz Gap', value: FMT(newBizGap), sub:'Annual growth delta to close', color: ACCENT})
  );
}
