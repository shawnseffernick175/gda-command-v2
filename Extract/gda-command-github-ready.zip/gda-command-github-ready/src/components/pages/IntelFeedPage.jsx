import React, { useState, useEffect, useCallback, useRef, useMemo } from 'react';
import { ACCENT, NAVY, BG, WHITE, BORDER, FONT, N8N, AUTH, api, S, css, gdaNav, NAV_ITEMS, Spinner, Empty, Alert, PageHeader, formatDollar, SourceTag, GDAKpiBar , saveAction, ActionHistory } from '../../lib/gda';
function IntelFeedPage() {
  const SOURCE_LABELS = {sam:'SAM.gov',govwin:'GovWin',govtribe:'GovTribe',fpds:'FPDS',tavily:'Tavily OSINT'};
  const URGENCY_COLORS = {critical:'#dc2626',high:'#ea580c',medium:'#d97706',low:'#16a34a',routine:'#6b7280'};
  const DEPT_OPTIONS = ['All Departments','Dept of Defense','Dept of Army','Dept of Navy','Dept of Air Force','DLA','DISA','SOCOM','CYBERCOM','TRADOC','Army Futures Command','INDOPACOM','INSCOM'];
  const [query, setQuery] = useState('');
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(false);
  const [feedStatus, setFeedStatus] = useState(null);
  const [kpiDetail, setKpiDetail] = useState(null);
  const [sources, setSources] = useState({sam:true,govwin:true,govtribe:true,fpds:true,tavily:true});
  const [recentSearches, setRecentSearches] = useState([]);
  const [urgencyFilter, setUrgencyFilter] = useState('all');
  const [deptFilter, setDeptFilter] = useState('All Departments');
  const [autoLoaded, setAutoLoaded] = useState(false);
  const [savedOpps, setSavedOpps] = useState({});

  const fetchIntel = async (q) => {
    const searchQ = q || query;
    setLoading(true);
    const activeSources = Object.entries(sources).filter(([k,v])=>v).map(([k])=>k);
    try {
      const d = await api.post('gda-intel-feed', {action:'get_intel', query:searchQ, sources:activeSources, limit:50});
      const items = d.results||d.intel||d.data||d.items||[];
      setResults(Array.isArray(items)?items:[]); if(d&&d.feed_status) setFeedStatus(d.feed_status); saveAction('intel-feed','search',searchQ||'Intel Search',{query:searchQ,sources:activeSources},{count:items.length});
      if(searchQ && searchQ.trim()) setRecentSearches(s=>[searchQ,...s.filter(x=>x!==searchQ)].slice(0,10));
    } catch(e) {
      try {
        const d2 = await api.post('gda-opp-tracker', {action:'search', query:searchQ||'defense', sources:activeSources});
        setResults(d2.results||d2.opportunities||d2.data||[]);
      } catch(e2) { setResults([]); }
    }
    setLoading(false);
  };

  useEffect(()=>{ if(!autoLoaded){setAutoLoaded(true);fetchIntel('defense acquisition');} },[]);

  const filtered = useMemo(()=>{
    let f = results;
    if(urgencyFilter!=='all') f=f.filter(r=>(r.urgency||'routine')===urgencyFilter);
    if(deptFilter!=='All Departments') f=f.filter(r=>(r.agency||r.department||'').toLowerCase().includes(deptFilter.toLowerCase()));
    return f;
  },[results,urgencyFilter,deptFilter]);

  return (
    <div>
      <PageHeader title="Intel Feed" sub="Unified intelligence across SAM.gov, GovWin, GovTribe, FPDS, Tavily OSINT" />
      <div style={{...S.card,marginBottom:14}}>
        <div style={{display:'flex',gap:10,alignItems:'center',marginBottom:10}}>
          <input style={{...S.input,flex:1}} placeholder="Search contracts, agencies, programs, keywords..." value={query} onChange={e=>setQuery(e.target.value)} onKeyDown={e=>e.key==='Enter'&&fetchIntel()} />
          <button style={S.btn()} onClick={()=>fetchIntel()} disabled={loading}>{loading?'Searching...':'Search Intel'}</button>
        </div>
        <div style={{display:'flex',gap:12,alignItems:'center',flexWrap:'wrap'}}>
          <span style={{fontSize:10,fontWeight:700,color:'#888'}}>SOURCES:</span>
          {Object.entries(sources).map(([k,v])=>(
            <label key={k} style={{display:'flex',alignItems:'center',gap:4,fontSize:11,color:v?NAVY:'#aaa',cursor:'pointer',padding:'2px 6px',borderRadius:4,background:v?ACCENT+'15':'transparent',border:'1px solid '+(v?ACCENT+'40':'#ddd')}}>
              <input type="checkbox" checked={v} onChange={()=>setSources(s=>({...s,[k]:!s[k]}))} style={{display:'none'}} />
              {SOURCE_LABELS[k]||k}
            </label>
          ))}
        </div>
        <div style={{display:'flex',gap:10,alignItems:'center',marginTop:10,flexWrap:'wrap'}}>
          <span style={{fontSize:10,fontWeight:700,color:'#888'}}>FILTERS:</span>
          <select value={urgencyFilter} onChange={e=>setUrgencyFilter(e.target.value)} style={{fontSize:11,padding:'3px 8px',borderRadius:4,border:'1px solid #ddd',color:NAVY}}>
            <option value="all">All Urgency</option>
            <option value="critical">Critical</option>
            <option value="high">High</option>
            <option value="medium">Medium</option>
            <option value="low">Low</option>
            <option value="routine">Routine</option>
          </select>
          <select value={deptFilter} onChange={e=>setDeptFilter(e.target.value)} style={{fontSize:11,padding:'3px 8px',borderRadius:4,border:'1px solid #ddd',color:NAVY}}>
            {DEPT_OPTIONS.map(d=><option key={d} value={d}>{d}</option>)}
          </select>
          <span style={{fontSize:10,color:'#999',marginLeft:'auto'}}>{filtered.length} of {results.length} items</span>
        </div>
        {recentSearches.length>0 && <div style={{marginTop:8,display:'flex',gap:6,flexWrap:'wrap'}}>
          <span style={{fontSize:10,color:'#888'}}>Recent:</span>
          {recentSearches.map((s,i)=><span key={i} onClick={()=>{setQuery(s);fetchIntel(s);}} style={{fontSize:10,color:ACCENT,cursor:'pointer',textDecoration:'underline'}}>{s}</span>)}
        </div>}
      </div>
      {!loading && results.length > 0 && <GDAKpiBar items={[
        {id:'items',label:'Intel Items',value:results.length,sub:'from all sources'},
        {id:'filtered',label:'Filtered',value:filtered.length,sub:'matching criteria'},
        {id:'saved',label:'Saved to Pipeline',value:Object.keys(savedOpps).filter(k=>savedOpps[k]===true).length,color:'#2F5C1F',sub:'opportunities saved'}
      ]} detail={kpiDetail} setDetail={setKpiDetail} />}
      {loading && <div style={{padding:30,textAlign:'center'}}><Spinner /><div style={{marginTop:8,fontSize:11,color:'#888'}}>{feedStatus&&feedStatus.status==='PROCESSING'?feedStatus.message:'Searching intelligence sources...'}</div></div>}
      {!loading && filtered.length===0 && <div style={{textAlign:'center',padding:'40px 20px',color:'#6b7280'}}><div style={{fontSize:13,marginBottom:12}}>{results.length>0?'No items match current filters.':(feedStatus&&feedStatus.status==='ERROR'?feedStatus.message:'Scan complete \u2014 0 results for current parameters')}</div>{results.length===0&&<div style={{display:'flex',gap:8,justifyContent:'center'}}>{feedStatus&&feedStatus.status==='ERROR'&&<div style={{background:'#FEF2F2',border:'1px solid #FCA5A5',borderRadius:8,padding:'8px 16px',color:'#DC2626',fontSize:12,fontWeight:600,marginBottom:8}}>{feedStatus.message}</div>}<button onClick={()=>fetchIntel(query||'')} style={{padding:'6px 18px',fontSize:12,borderRadius:6,border:'1px solid #d1d5db',background:'#fff',color:NAVY,cursor:'pointer',fontWeight:500}}>{'\u21bb Retry'}</button></div>}</div>}
      {!loading && filtered.length>0 && <div>
        {filtered.map((r,i)=>(
          <div key={i} style={{...S.card,marginBottom:10,borderLeft:'3px solid '+(URGENCY_COLORS[r.urgency]||'#6b7280'),transition:'box-shadow 0.2s',cursor:'default'}}>
            <div style={{display:'flex',justifyContent:'space-between',alignItems:'flex-start'}}>
              <div style={{flex:1}}>
                <div style={{display:'flex',alignItems:'center',gap:8,marginBottom:4,flexWrap:'wrap'}}>
                  <span style={{fontSize:13,fontWeight:700,color:NAVY}}>{r.title||r.name||'Untitled'}</span>
                  {r.source && <span style={{fontSize:9,padding:'1px 6px',borderRadius:3,background:ACCENT+'18',color:ACCENT,fontWeight:600,textTransform:'uppercase'}}>{SOURCE_LABELS[r.source]||r.source}</span>}
                  {r.urgency && <span style={{fontSize:9,padding:'1px 6px',borderRadius:3,background:(URGENCY_COLORS[r.urgency]||'#6b7280')+'20',color:URGENCY_COLORS[r.urgency]||'#6b7280',fontWeight:700,textTransform:'uppercase'}}>{r.urgency}</span>}
                </div>
                <div style={{fontSize:11,color:'#666',marginBottom:4}}>{r.agency||r.department||''} {r.solicitation_number?' | '+r.solicitation_number:''}</div>
                {r.description && <div style={{fontSize:11,color:'#555',lineHeight:1.6,maxHeight:44,overflow:'hidden'}}>{r.description}</div>}
              </div>
              <div style={{textAlign:'right',flexShrink:0,marginLeft:16}}>
                {(r.value||r.budget)>0 && <div style={{fontSize:14,fontWeight:700,color:NAVY}}>{formatDollar(r.value||r.budget)}</div>}
                {r.fit_score>0 && <span style={{fontSize:11,fontWeight:700,color:'#C65D21',marginLeft:4}}>Fit: {r.fit_score}</span>}
                {r.due_date && <div style={{fontSize:10,color:'#888',marginTop:4}}>Due: {r.due_date}</div>}
                {r.posted_date && <div style={{fontSize:10,color:'#aaa'}}>Posted: {r.posted_date}</div>}
              </div>
            </div>
            <div style={{display:'flex',alignItems:'center',gap:8,marginTop:6}}>
              {r.url && <SourceTag url={r.url} label={SOURCE_LABELS[r.source]||r.source||'Source'} />}
              <button onClick={()=>{if(savedOpps[i])return;api.post('gda-save-opp',{opp_title:r.title||r.name||'Untitled',agency:r.agency||r.source||'',dept:r.department||'',naics_code:r.naics||'',estimated_value:r.value||r.budget||0,source_url:r.url||r.source_url||'',solicitation_number:r.solicitation_number||r.solicitation||''}).then(()=>setSavedOpps(p=>({...p,[i]:true}))).catch(()=>setSavedOpps(p=>({...p,[i]:'error'})))}} style={{fontSize:10,padding:'3px 10px',borderRadius:4,border:'1px solid '+(savedOpps[i]===true?'#2F5C1F':savedOpps[i]==='error'?'#dc2626':'#d1d5db'),background:savedOpps[i]===true?'#2F5C1F12':savedOpps[i]==='error'?'#FEF2F2':'#fff',color:savedOpps[i]===true?'#2F5C1F':savedOpps[i]==='error'?'#dc2626':'#374151',cursor:savedOpps[i]===true?'default':'pointer',fontWeight:500}}>{savedOpps[i]===true?'✔ Saved to Opportunities':savedOpps[i]==='error'?'Save Failed - Retry':'Save to Opportunities'}</button>
            </div>
          </div>
        ))}
      </div>}
    </div>
  );
}
export default IntelFeedPage;