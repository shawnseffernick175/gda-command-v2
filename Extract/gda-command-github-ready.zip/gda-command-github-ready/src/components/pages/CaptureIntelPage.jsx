import React, { useState, useEffect, useCallback, useRef, useMemo } from 'react';
import { ACCENT, NAVY, BG, WHITE, BORDER, FONT, N8N, AUTH, api, S, css, gdaNav, NAV_ITEMS, Spinner, Empty, Alert, PageHeader , formatDollar , saveAction, ActionHistory } from '../../lib/gda';
function CaptureIntel() {
  const [target, setTarget] = useState('');
  const [agency, setAgency] = useState('');
  const [naics, setNaics] = useState('');
  const [result, setResult] = useState(null);
  const [activeAction, setActiveAction] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const AGENCY_OPTIONS = ['Department of Defense','U.S. Army','U.S. Navy','U.S. Air Force','U.S. Marine Corps','DLA','DISA','SOCOM','CYBERCOM','TRADOC','PEO STRI','INDOPACOM','INSCOM'];
  const ACTIONS = [
    {id:'incumbent', label:'Incumbent Analysis', icon:'🏛️', desc:'Current holder, recompete timeline, EIS pwin'},
    {id:'contacts',  label:'Contact Database',   icon:'👤', desc:'COs, PMs, decision makers, outreach'},
    {id:'vehicles',  label:'Vehicle Tracker',     icon:'🚗', desc:'Preferred vehicles, bid path, gaps'},
    {id:'teaming',   label:'Teaming Finder',      icon:'🤝', desc:'Primes, subs, JV candidates'},
    {id:'forecasts',  label:'Federal Forecasts',   icon:'📅', desc:'Upcoming forecasts, expiring contracts, budget signals'},
  ];

  const run = async (actionId) => {
    if (!target.trim()) { setError('Enter a target program or opportunity.'); return; }
    setActiveAction(actionId); setResult(null); setError(''); setLoading(true);
    try {
      const d = await api.post('gda-capture-intel', {action: actionId, target: target.trim(), agency, naics}, {signal: AbortSignal.timeout(60000)});
      setResult({action: actionId, data: d}); saveAction("capture-plan",actionId,actionId,{},d);
    } catch(e) { setError(e.name==='TimeoutError'?'Timed out (60s). Try again.':'Failed: '+e.message); }
    setLoading(false);
  };

  const renderForecasts = (d) => {
    const forecasts = d.upcoming_forecasts || [];
    const expiring = d.expiring_contracts || [];
    const preSol = d.pre_solicitation_signals || [];
    const budget = d.budget_signals || [];
    const ew = d.eis_early_warning || {};
    const sources = d.data_sources || [];

    const relColor = (r) => r==='High'?'#2F5C1F':r==='Medium'?'#D14A2A':'#6B7280';
    const relBg = (r) => r==='High'?'#2F5C1F15':r==='Medium'?'#B06D3212':'#F3F4F6';

    const isExpiringSoon = (dateStr) => {
      if (!dateStr) return false;
      try { return (new Date(dateStr) - new Date()) < 1000*60*60*24*180; } catch { return false; }
    };

    return (
      <div>
        {forecasts.length>0 && <div style={{marginBottom:16}}>
          <div style={{fontSize:11,fontWeight:700,color:'#1B2A4A',textTransform:'uppercase',letterSpacing:'1px',marginBottom:8}}>UPCOMING FORECASTS ({forecasts.length})</div>
          <div style={{overflowX:'auto'}}>
            <table style={{width:'100%',borderCollapse:'collapse',fontSize:12}}>
              <thead>
                <tr style={{background:'#F7F8FA'}}>
                  {['Name','Agency','Type','Est. Value','Release','EIS'].map(h => <th key={h} style={{padding:'8px 10px',textAlign:'left',borderBottom:'1px solid #E8ECF1',fontSize:11,fontWeight:600,color:'#6B7280',whiteSpace:'nowrap'}}>{h}</th>)}
                </tr>
              </thead>
              <tbody>
                {forecasts.map((f,i) => (
                  <tr key={i} style={{borderBottom:'1px solid #F0F0F0'}}>
                    <td style={{padding:'8px 10px',color:'#1B2A4A',fontWeight:500,maxWidth:200}}><div>{String(f.name||'')}</div>{f.eis_action&&<div style={{fontSize:10,color:'#D14A2A',marginTop:2}}>{String(f.eis_action)}</div>}</td>
                    <td style={{padding:'8px 10px',color:'#555'}}>{String(f.agency||'')}</td>
                    <td style={{padding:'8px 10px',color:'#555',whiteSpace:'nowrap'}}>{String(f.forecast_type||'')}</td>
                    <td style={{padding:'8px 10px',color:'#2F5C1F',fontWeight:600,whiteSpace:'nowrap'}}>{String(f.estimated_value||'—')}</td>
                    <td style={{padding:'8px 10px',color:'#555',whiteSpace:'nowrap'}}>{String(f.estimated_release||'—')}</td>
                    <td style={{padding:'8px 10px'}}>
                      <span style={{padding:'2px 8px',borderRadius:10,fontSize:10,fontWeight:600,background:relBg(f.eis_relevance),color:relColor(f.eis_relevance)}}>{String(f.eis_relevance||'—')}</span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>}

        {expiring.length>0 && <div style={{marginBottom:16}}>
          <div style={{fontSize:11,fontWeight:700,color:'#DC2626',textTransform:'uppercase',letterSpacing:'1px',marginBottom:8}}>EXPIRING CONTRACTS ({expiring.length})</div>
          <div style={{display:'grid',gridTemplateColumns:'repeat(auto-fill,minmax(280px,1fr))',gap:8}}>
            {expiring.map((c,i) => {
              const soon = isExpiringSoon(c.expiry_date);
              return (
                <div key={i} style={{padding:'10px 14px',background:'#fff',borderRadius:8,border:'1px solid '+(soon?'#FCA5A5':'#E8ECF1'),borderLeft:'3px solid '+(soon?'#DC2626':'#D14A2A')}}>
                  <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:4}}>
                    <span style={{fontSize:11,color:'#6B7280',fontFamily:'monospace'}}>{String(c.contract_number||'')}</span>
                    {c.recompete_likely && <span style={{fontSize:9,padding:'1px 6px',borderRadius:8,background:'#2F5C1F15',color:'#2F5C1F',fontWeight:600}}>Recompete</span>}
                  </div>
                  <div style={{fontSize:13,fontWeight:600,color:'#1B2A4A'}}>{String(c.incumbent||'')}</div>
                  <div style={{display:'flex',justifyContent:'space-between',marginTop:4,flexWrap:'wrap',gap:4}}>
                    <span style={{fontSize:11,color:'#2F5C1F',fontWeight:600}}>{String(c.value||'')}</span>
                    <span style={{fontSize:11,color:soon?'#DC2626':'#6B7280',fontWeight:soon?700:400}}>Exp: {String(c.expiry_date||'')}</span>
                  </div>
                  <div style={{fontSize:10,color:'#9CA3AF',marginTop:2}}>{String(c.agency||'')}</div>
                </div>
              );
            })}
          </div>
        </div>}

        {preSol.length>0 && <div style={{marginBottom:16}}>
          <div style={{fontSize:11,fontWeight:700,color:'#32448A',textTransform:'uppercase',letterSpacing:'1px',marginBottom:8}}>PRE-SOLICITATION SIGNALS ({preSol.length})</div>
          {preSol.map((p,i) => (
            <div key={i} style={{display:'flex',gap:12,padding:'8px 12px',background:'#F7F8FA',borderRadius:8,marginBottom:6,alignItems:'center',flexWrap:'wrap'}}>
              <span style={{padding:'2px 8px',borderRadius:6,background:'#EFF6FF',color:'#32448A',fontSize:10,fontWeight:600,whiteSpace:'nowrap'}}>{String(p.notice_type||'')}</span>
              <div style={{flex:1,minWidth:150}}>
                <div style={{fontSize:13,fontWeight:500,color:'#1B2A4A'}}>{String(p.title||'')}</div>
                <div style={{fontSize:11,color:'#6B7280'}}>{String(p.agency||'')} {p.posted_date?'· Posted: '+String(p.posted_date):''}</div>
              </div>
              {p.response_deadline && <span style={{fontSize:11,color:'#D14A2A',fontWeight:600,whiteSpace:'nowrap'}}>Due: {String(p.response_deadline)}</span>}
            </div>
          ))}
        </div>}

        {budget.length>0 && <div style={{marginBottom:16}}>
          <div style={{fontSize:11,fontWeight:700,color:'#32448A',textTransform:'uppercase',letterSpacing:'1px',marginBottom:8}}>BUDGET SIGNALS ({budget.length})</div>
          <table style={{width:'100%',borderCollapse:'collapse',fontSize:12}}>
            <thead>
              <tr style={{background:'#F7F8FA'}}>
                {['Program','FY','Amount','Change','New Start'].map(h => <th key={h} style={{padding:'8px 10px',textAlign:'left',borderBottom:'1px solid #E8ECF1',fontSize:11,fontWeight:600,color:'#6B7280'}}>{h}</th>)}
              </tr>
            </thead>
            <tbody>
              {budget.map((b,i) => {
                const chg = String(b.change_from_prior||'');
                const isPos = chg && !chg.startsWith('-') && chg!=='0';
                const isNeg = chg.startsWith('-');
                return (
                  <tr key={i} style={{borderBottom:'1px solid #F0F0F0'}}>
                    <td style={{padding:'8px 10px',color:'#1B2A4A',fontWeight:500}}>{String(b.program||'')}</td>
                    <td style={{padding:'8px 10px',color:'#555'}}>{String(b.fy||'')}</td>
                    <td style={{padding:'8px 10px',color:'#2F5C1F',fontWeight:600}}>{String(b.amount||'')}</td>
                    <td style={{padding:'8px 10px',color:isPos?'#2F5C1F':isNeg?'#DC2626':'#555',fontWeight:600}}>{isPos?'↑ ':isNeg?'↓ ':''}{chg}</td>
                    <td style={{padding:'8px 10px'}}>{b.new_start?<span style={{fontSize:10,padding:'2px 6px',borderRadius:6,background:'#2F5C1F15',color:'#2F5C1F',fontWeight:600}}>YES</span>:<span style={{fontSize:10,color:'#9CA3AF'}}>—</span>}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>}

        {(ew.immediate_actions||ew['30_day_deadlines']||ew['90_day_targets']||ew.strategic_positioning) && <div style={{marginBottom:16}}>
          <div style={{fontSize:11,fontWeight:700,color:'#DC2626',textTransform:'uppercase',letterSpacing:'1px',marginBottom:8}}>EIS EARLY WARNING</div>
          <div style={{display:'grid',gridTemplateColumns:'repeat(3,1fr)',gap:12,marginBottom:12}}>
            {[
              {label:'Immediate Actions', items:ew.immediate_actions||[], color:'#DC2626', bg:'#FEF2F2'},
              {label:'30-Day Deadlines', items:ew['30_day_deadlines']||[], color:'#D14A2A', bg:'#B06D3212'},
              {label:'90-Day Targets', items:ew['90_day_targets']||[], color:'#32448A', bg:'#EFF6FF'},
            ].map(col => (
              <div key={col.label} style={{padding:12,background:col.bg,borderRadius:8,borderLeft:'3px solid '+col.color}}>
                <div style={{fontSize:11,fontWeight:700,color:col.color,marginBottom:6,textTransform:'uppercase'}}>{col.label}</div>
                {col.items.length===0 && <div style={{fontSize:11,color:'#9CA3AF'}}>None</div>}
                {col.items.map((item,j) => <div key={j} style={{fontSize:12,color:'#1B2A4A',padding:'2px 0',lineHeight:1.4}}>• {typeof item==='string'?item:JSON.stringify(item)}</div>)}
              </div>
            ))}
          </div>
          {ew.strategic_positioning && <div style={{padding:12,background:'#F7F8FA',borderRadius:8,fontSize:13,color:'#1B2A4A',lineHeight:1.6}}><strong>Strategic Positioning:</strong> {String(ew.strategic_positioning)}</div>}
        </div>}

        {sources.length>0 && <div style={{fontSize:11,color:'#9CA3AF',marginTop:8}}>Sources: {sources.map((s,i) => <span key={i}>{i>0?', ':''}{String(s.name||s.url||'')}</span>)}</div>}
        {forecasts.length===0&&expiring.length===0&&budget.length===0&&<div style={{fontSize:12,color:'#9CA3AF',padding:'20px 0',textAlign:'center'}}>No forecast data returned</div>}
      </div>
    );
  };

  const renderGeneric = (d) => <div style={{fontSize:12,lineHeight:1.8,color:NAVY,whiteSpace:'pre-wrap',background:'#F8FAFC',padding:16,borderRadius:8,maxHeight:400,overflow:'auto'}}>{typeof d==='string'?d:JSON.stringify(d,null,2)}</div>;

  const renderIncumbent = (d) => {
    const inc=d.incumbent||d.current_incumbent||{}, rc=d.recompete||d.recompete_window||{}, eis=d.eis_assessment||d.assessment||{}, vendors=d.top_vendors||d.competitors||[];
    return (<div>
      {Object.keys(inc).length>0 && <div style={{...S.card,borderLeft:'4px solid '+NAVY,marginBottom:12}}><div style={{fontSize:12,fontWeight:700,color:NAVY,marginBottom:6}}>Current Incumbent</div>{inc.vendor&&<div style={{fontSize:13,fontWeight:600,color:NAVY}}>{inc.vendor}</div>}<div style={{display:'flex',gap:16,marginTop:6,flexWrap:'wrap'}}>{inc.contract_number&&<span style={{fontSize:11,color:'#6B7280'}}>Contract: {inc.contract_number}</span>}{inc.value&&<span style={{fontSize:11,color:'#2F5C1F',fontWeight:600}}>{formatDollar(inc.value)}</span>}{inc.expiry&&<span style={{fontSize:11,color:'#D14A2A'}}>Expires: {inc.expiry}</span>}</div></div>}
      {Object.keys(rc).length>0 && <div style={{...S.card,borderLeft:'4px solid #D14A2A',marginBottom:12}}><div style={{fontSize:12,fontWeight:700,color:NAVY,marginBottom:6}}>Recompete Window</div>{rc.estimated_dates&&<div style={{fontSize:12,color:NAVY}}>{typeof rc.estimated_dates==='string'?rc.estimated_dates:JSON.stringify(rc.estimated_dates)}</div>}{rc.bridge_risk&&<div style={{fontSize:11,color:'#D14A2A',marginTop:4}}>Bridge Risk: {rc.bridge_risk}</div>}</div>}
      {Object.keys(eis).length>0 && <div style={{...S.card,borderLeft:'4px solid #2F5C1F',marginBottom:12}}><div style={{fontSize:12,fontWeight:700,color:NAVY,marginBottom:6}}>EIS Assessment</div>{eis.pwin&&<div style={{fontSize:13,fontWeight:700,color:'#2F5C1F'}}>PWin: {eis.pwin}</div>}{eis.strategy&&<div style={{fontSize:12,color:NAVY,marginTop:4,lineHeight:1.6}}>{eis.strategy}</div>}{eis.teaming_suggestion&&<div style={{fontSize:11,color:'#32448A',marginTop:4}}>Teaming: {eis.teaming_suggestion}</div>}</div>}
      {vendors.length>0 && <div style={S.card}><div style={{fontSize:12,fontWeight:700,color:NAVY,marginBottom:8}}>Top Vendors</div>{vendors.map((v,i)=><div key={i} style={{display:'flex',justifyContent:'space-between',padding:'6px 0',borderBottom:'1px solid #f0f0f0',fontSize:12}}><span style={{color:NAVY,fontWeight:500}}>{typeof v==='string'?v:v.vendor||v.name||JSON.stringify(v)}</span>{v.value&&<span style={{color:'#2F5C1F',fontWeight:600}}>{formatDollar(v.value)}</span>}</div>)}</div>}
      {!Object.keys(inc).length&&!vendors.length&&renderGeneric(d)}
    </div>);
  };

  const renderContacts = (d) => {
    const cos=d.contracting_officers||d.cos||[], pms=d.program_managers||d.pms||[], kdm=d.key_decision_makers||d.decision_makers||[], events=d.upcoming_events||d.events||[], outreach=d.recommended_outreach||d.outreach||[];
    const renderC = (c,i) => <div key={i} style={{padding:'8px 12px',background:'#F8FAFC',borderRadius:6,marginBottom:6,border:'1px solid '+BORDER}}><div style={{fontSize:12,fontWeight:600,color:NAVY}}>{typeof c==='string'?c:c.name||'Contact'}</div>{c.title&&<div style={{fontSize:11,color:'#6B7280'}}>{c.title}</div>}<div style={{display:'flex',gap:12,marginTop:2,flexWrap:'wrap'}}>{c.email&&<a href={'mailto:'+c.email} style={{fontSize:10,color:ACCENT}}>{c.email}</a>}{c.phone&&<span style={{fontSize:10,color:'#6B7280'}}>{c.phone}</span>}</div></div>;
    return (<div>
      {cos.length>0&&<div style={{marginBottom:12}}><div style={{fontSize:11,fontWeight:700,color:NAVY,marginBottom:6}}>CONTRACTING OFFICERS ({cos.length})</div>{cos.map(renderC)}</div>}
      {pms.length>0&&<div style={{marginBottom:12}}><div style={{fontSize:11,fontWeight:700,color:NAVY,marginBottom:6}}>PROGRAM MANAGERS ({pms.length})</div>{pms.map(renderC)}</div>}
      {kdm.length>0&&<div style={{marginBottom:12}}><div style={{fontSize:11,fontWeight:700,color:'#DC2626',marginBottom:6}}>KEY DECISION MAKERS ({kdm.length})</div>{kdm.map(renderC)}</div>}
      {events.length>0&&<div style={{marginBottom:12}}><div style={{fontSize:11,fontWeight:700,color:'#32448A',marginBottom:6}}>UPCOMING EVENTS</div>{events.map((ev,i)=><div key={i} style={{fontSize:12,padding:'4px 0',borderBottom:'1px solid #f0f0f0',color:NAVY}}>{typeof ev==='string'?ev:ev.name||ev.event||JSON.stringify(ev)}</div>)}</div>}
      {outreach.length>0&&<div><div style={{fontSize:11,fontWeight:700,color:'#2F5C1F',marginBottom:6}}>RECOMMENDED OUTREACH</div>{outreach.map((r,i)=><div key={i} style={{fontSize:12,padding:'4px 0',borderBottom:'1px solid #f0f0f0',color:NAVY}}>• {typeof r==='string'?r:r.action||JSON.stringify(r)}</div>)}</div>}
      {!cos.length&&!pms.length&&!kdm.length&&renderGeneric(d)}
    </div>);
  };

  const renderVehicles = (d) => {
    const preferred=d.preferred_vehicles||d.vehicles||[], bid_paths=d.recommended_bid_path||d.bid_paths||[], gaps=d.eis_vehicle_gaps||d.gaps||[];
    return (<div>
      {preferred.length>0&&<div style={{marginBottom:12}}><div style={{fontSize:11,fontWeight:700,color:NAVY,marginBottom:6}}>AGENCY PREFERRED VEHICLES</div>{preferred.map((v,i)=><div key={i} style={{display:'flex',justifyContent:'space-between',padding:'8px 12px',background:'#F8FAFC',borderRadius:6,marginBottom:4,fontSize:12}}><span style={{color:NAVY,fontWeight:500}}>{typeof v==='string'?v:v.vehicle||v.name||JSON.stringify(v)}</span>{v.ceiling&&<span style={{color:'#2F5C1F',fontWeight:600}}>{formatDollar(v.ceiling)}</span>}</div>)}</div>}
      {bid_paths.length>0&&<div style={{marginBottom:12}}><div style={{fontSize:11,fontWeight:700,color:ACCENT,marginBottom:6}}>RECOMMENDED BID PATHS</div>{bid_paths.map((bp,i)=><div key={i} style={{padding:'8px 12px',background:'#B06D3212',borderRadius:6,marginBottom:6,borderLeft:'3px solid '+ACCENT}}><div style={{fontSize:12,fontWeight:600,color:NAVY}}>{typeof bp==='string'?bp:bp.path||bp.vehicle||JSON.stringify(bp)}</div>{bp.rationale&&<div style={{fontSize:11,color:'#6B7280',marginTop:2}}>{bp.rationale}</div>}</div>)}</div>}
      {gaps.length>0&&<div><div style={{fontSize:11,fontWeight:700,color:'#DC2626',marginBottom:6}}>EIS VEHICLE GAPS</div>{gaps.map((g,i)=><div key={i} style={{fontSize:12,padding:'4px 0',color:'#991B1B',borderBottom:'1px solid #f0f0f0'}}>• {typeof g==='string'?g:g.gap||JSON.stringify(g)}</div>)}</div>}
      {!preferred.length&&!bid_paths.length&&renderGeneric(d)}
    </div>);
  };

  const renderTeaming = (d) => {
    const primes=d.potential_primes||d.primes||[], subs=d.potential_subs||d.subs||[], recommended=d.recommended_team||d.recommended||{}, jv=d.jv_candidates||d.jv||[];
    const vc = (v,i,hl) => <div key={i} style={{padding:'8px 12px',background:hl?'#2F5C1F15':'#F8FAFC',borderRadius:6,marginBottom:6,border:'1px solid '+(hl?'#6EE7B7':BORDER)}}><div style={{fontSize:12,fontWeight:600,color:NAVY}}>{typeof v==='string'?v:v.vendor||v.name||JSON.stringify(v)}</div>{v.rationale&&<div style={{fontSize:11,color:'#6B7280',marginTop:2}}>{v.rationale}</div>}{v.certifications&&<div style={{fontSize:10,color:'#32448A',marginTop:2}}>{Array.isArray(v.certifications)?v.certifications.join(', '):v.certifications}</div>}</div>;
    return (<div>
      {Object.keys(recommended).length>0&&<div style={{...S.card,borderLeft:'4px solid #2F5C1F',marginBottom:12}}><div style={{fontSize:12,fontWeight:700,color:'#2F5C1F',marginBottom:8}}>★ RECOMMENDED TEAM</div>{typeof recommended==='string'?<div style={{fontSize:12,color:NAVY}}>{recommended}</div>:Object.entries(recommended).map(([k,v])=><div key={k} style={{fontSize:12,padding:'3px 0',color:NAVY}}><strong>{k}:</strong> {typeof v==='string'?v:JSON.stringify(v)}</div>)}</div>}
      {primes.length>0&&<div style={{marginBottom:12}}><div style={{fontSize:11,fontWeight:700,color:NAVY,marginBottom:6}}>POTENTIAL PRIMES ({primes.length})</div>{primes.map((v,i)=>vc(v,i,false))}</div>}
      {subs.length>0&&<div style={{marginBottom:12}}><div style={{fontSize:11,fontWeight:700,color:'#32448A',marginBottom:6}}>POTENTIAL SUBS ({subs.length})</div>{subs.map((v,i)=>vc(v,i,false))}</div>}
      {jv.length>0&&<div style={{marginBottom:12}}><div style={{fontSize:11,fontWeight:700,color:'#32448A',marginBottom:6}}>JV CANDIDATES ({jv.length})</div>{jv.map((v,i)=>vc(v,i,false))}</div>}
      {!primes.length&&!subs.length&&!Object.keys(recommended).length&&renderGeneric(d)}
    </div>);
  };

  return (
    <div>
      <PageHeader title="Capture Intel" sub="Incumbent analysis · contact database · vehicle tracker · teaming finder" />
      <div style={{...S.card,marginBottom:12}}>
        <div style={{display:'flex',gap:10,flexWrap:'wrap',marginBottom:12}}>
          <input style={{...S.input,flex:'1 1 200px'}} placeholder="Target program or opportunity (e.g. IEWS SETA, PEO STRI SBIR)" value={target} onChange={e=>setTarget(e.target.value)} onKeyDown={e=>e.key==='Enter'&&activeAction&&run(activeAction)} />
          <select style={{...S.select,flex:'0 0 180px'}} value={agency} onChange={e=>setAgency(e.target.value)}>
            <option value="">All Agencies</option>
            {AGENCY_OPTIONS.map(a=><option key={a} value={a}>{a}</option>)}
          </select>
          <input style={{...S.input,flex:'0 0 120px'}} placeholder="NAICS (opt)" value={naics} onChange={e=>setNaics(e.target.value)} />
        </div>
        <div style={{display:'flex',gap:8,flexWrap:'wrap'}}>
          {ACTIONS.map(a=>(
            <button key={a.id} onClick={()=>run(a.id)} disabled={loading} style={{...S.btn(activeAction===a.id&&result?'primary':'secondary'),display:'flex',flexDirection:'column',alignItems:'flex-start',padding:'10px 16px',gap:2,opacity:loading&&activeAction!==a.id?0.5:1,minWidth:150}}>
              <span style={{fontSize:12}}>{a.icon} {a.label}</span>
              <span style={{fontSize:10,opacity:0.65,fontWeight:400}}>{a.desc}</span>
            </button>
          ))}
        </div>
      </div>
      {error && <Alert type="error" msg={error} />}
      {loading && <div style={{...S.card,display:'flex',alignItems:'center',gap:10,padding:'14px 20px'}}><Spinner /><div><div style={{fontSize:12,fontWeight:600,color:NAVY}}>Running {ACTIONS.find(a=>a.id===activeAction)?.label}...</div><div style={{fontSize:11,color:'#888'}}>Searching SAM.gov, USASpending, GovWin, FPDS — 25-45 seconds.</div></div></div>}
      {result && !loading && (()=>{
        const {action, data} = result;
        const adef = ACTIONS.find(a=>a.id===action);
        return (
          <div style={S.card}>
            <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:14}}>
              <div style={{fontSize:14,fontWeight:700,color:NAVY}}>{adef?.icon} {adef?.label}: <span style={{color:ACCENT}}>{target}</span></div>
              <button style={S.btn('secondary',true)} onClick={()=>setResult(null)}>New Search</button>
            </div>
            {action==='incumbent'&&renderIncumbent(data)}
            {action==='contacts'&&renderContacts(data)}
            {action==='vehicles'&&renderVehicles(data)}
            {action==='teaming'&&renderTeaming(data)}
            {action==='forecasts'&&renderForecasts(data)}
          </div>
        );
      })()}
    </div>
  );
}
export default CaptureIntel;