import React, { useState, useEffect, useCallback, useRef, useMemo } from 'react';
import { ACCENT, NAVY, BG, WHITE, BORDER, FONT, N8N, AUTH, api, S, css, gdaNav, NAV_ITEMS, Spinner, Empty, Alert, PageHeader , GDAKpiBar , saveAction, ActionHistory } from '../../lib/gda';
function ComplianceMatrix() {
  const DEFAULT_CAPS = 'XR/AR/VR simulation, C5ISR, AI/ML, cybersecurity, DevSecOps, training systems, SOCOM/TRADOC experience';

  const [rfpTitle, setRfpTitle] = useState('');
  const [rfpText, setRfpText] = useState('');
  const [capabilities, setCapabilities] = useState(DEFAULT_CAPS);
  const [matrix, setMatrix] = useState(null);
  const [kpiDetail, setKpiDetail] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [sortBy, setSortBy] = useState('');
  const [sortDir, setSortDir] = useState('asc');
  const [filterStatus, setFilterStatus] = useState('all');
  const [filterRisk, setFilterRisk] = useState('all');
  const [filterUnit, setFilterUnit] = useState('all');
  const [expandedRow, setExpandedRow] = useState(null);
  const [editedRows, setEditedRows] = useState({});
  const [gapsOpen, setGapsOpen] = useState(false);
  const [toast, setToast] = useState('');
  const [cmStatus, setCmStatus] = useState('idle');
  const [cmApprovedAt, setCmApprovedAt] = useState(null);
  const [cmFiles, setCmFiles] = useState([]);
  const [cmDragOver, setCmDragOver] = useState(false);
  const [cmParsersReady, setCmParsersReady] = useState(false);

  useEffect(() => {
    let loaded = 0;
    const total = 3;
    const check = () => { loaded++; if (loaded >= total) setCmParsersReady(true); };
    const loadScript = (src, testKey, onReady) => {
      if (window[testKey]) { check(); return; }
      const sc = document.createElement('script');
      sc.src = src;
      sc.onload = () => { if (onReady) onReady(); check(); };
      sc.onerror = () => check();
      document.head.appendChild(sc);
    };
    loadScript('https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js', 'pdfjsLib', () => { if (window.pdfjsLib) window.pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js'; });
    loadScript('https://cdn.jsdelivr.net/npm/mammoth@1.6.0/mammoth.browser.min.js', 'mammoth');
    loadScript('https://cdn.jsdelivr.net/npm/xlsx@0.18.5/dist/xlsx.full.min.js', 'XLSX');
  }, []);

  const CM_ALLOWED = ['.pdf','.doc','.docx','.txt','.xlsx','.xls','.pptx','.csv'];
  const cmWaitForLib = (key, ms=5000) => new Promise((resolve) => {
    if (window[key]) return resolve(window[key]);
    const start = Date.now();
    const iv = setInterval(() => {
      if (window[key]) { clearInterval(iv); resolve(window[key]); }
      else if (Date.now() - start > ms) { clearInterval(iv); resolve(null); }
    }, 100);
  });
  const cmExtractText = async (file) => {
    const name = file.name.toLowerCase();
    if (name.endsWith('.txt') || name.endsWith('.csv') || name.endsWith('.tsv')) return await file.text();
    if (name.endsWith('.pdf')) { try { const lib = await cmWaitForLib('pdfjsLib'); if (!lib) return '[PDF parser not available - please retry]'; const buf = await file.arrayBuffer(); const pdf = await lib.getDocument({data:buf}).promise; let txt = ''; for (let i = 1; i <= pdf.numPages; i++) { const pg = await pdf.getPage(i); const tc = await pg.getTextContent(); txt += tc.items.map(it => it.str).join(' ') + '\n'; } return txt || '[PDF loaded but no extractable text]'; } catch(e) { return '[PDF extraction failed: ' + e.message + ']'; } }
    if (name.endsWith('.docx') || name.endsWith('.doc')) { try { const lib = await cmWaitForLib('mammoth'); if (!lib) return '[Word parser not available - please retry]'; const buf = await file.arrayBuffer(); const result = await lib.extractRawText({arrayBuffer:buf}); return result.value || '[Word doc loaded but no text extracted]'; } catch(e) { return '[Word extraction failed: ' + e.message + ']'; } }
    if (name.endsWith('.xlsx') || name.endsWith('.xls')) { try { const lib = await cmWaitForLib('XLSX'); if (!lib) return '[Excel parser not available]'; const buf = await file.arrayBuffer(); const wb = lib.read(buf); let txt = ''; wb.SheetNames.forEach(sn => { txt += '=== Sheet: ' + sn + ' ===\n'; txt += lib.utils.sheet_to_csv(wb.Sheets[sn]) + '\n\n'; }); return txt || '[Excel loaded but empty]'; } catch(e) { return '[Excel extraction failed: ' + e.message + ']'; } }
    if (name.endsWith('.pptx') || name.endsWith('.ppt')) { try { const JSZip = (await import('https://cdn.jsdelivr.net/npm/jszip@3.10.1/+esm')).default; const buf = await file.arrayBuffer(); const zip = await JSZip.loadAsync(buf); let txt = ''; const slideFiles = Object.keys(zip.files).filter(f => f.match(/ppt\/slides\/slide\d+\.xml/)).sort((a,b) => { const na = parseInt(a.match(/slide(\d+)/)[1]); const nb = parseInt(b.match(/slide(\d+)/)[1]); return na - nb; }); for (const sf of slideFiles) { const xml = await zip.files[sf].async('text'); const stripped = xml.replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim(); if (stripped) txt += '--- Slide ' + sf.match(/slide(\d+)/)[1] + ' ---\n' + stripped + '\n\n'; } return txt || '[PowerPoint loaded but no text extracted]'; } catch(e) { return '[PowerPoint extraction failed: ' + e.message + ']'; } }
    return await file.text();
  };
  const cmAddFiles = (nf) => {
    const valid = Array.from(nf).filter(f => CM_ALLOWED.some(e => f.name.toLowerCase().endsWith(e)));
    if (!valid.length) { setError('Supported: PDF, Word, Excel, PPT, CSV, TXT'); return; }
    if (!cmParsersReady) setError('Loading document parsers... files will process momentarily'); else setError('');
    valid.forEach(async (file) => {
      try {
        const extracted = await cmExtractText(file);
        setCmFiles(p => { if (p.find(x => x.name === file.name)) return p; return [...p, {name: file.name, content: extracted, size: file.size, type: file.type, extracted: true}]; });
      } catch(e) {
        setCmFiles(p => { if (p.find(x => x.name === file.name)) return p; return [...p, {name: file.name, content: '[Failed to extract: ' + e.message + ']', size: file.size, type: file.type, extracted: false}]; });
      }
    });
  };
  const cmRemoveFile = (n) => setCmFiles(p => p.filter(f => f.name !== n));
  const cmOnDrop = (e) => { e.preventDefault(); setCmDragOver(false); if (e.dataTransfer.files.length) cmAddFiles(e.dataTransfer.files); };
  const cmFmtSz = (b) => b > 1048576 ? (b/1048576).toFixed(1) + ' MB' : (b/1024).toFixed(0) + ' KB';

  const safeStr = (v) => {
    if (v === null || v === undefined) return '';
    if (typeof v === 'string') return v;
    if (typeof v === 'number' || typeof v === 'boolean') return String(v);
    return JSON.stringify(v);
  };

  const parseResponse = (text) => {
    try { return JSON.parse(text); } catch (_) {}
    const cb = text.match(/```(?:json)?\s*([\s\S]*?)```/);
    if (cb) { try { return JSON.parse(cb[1]); } catch (_) {} }
    const ob = text.match(/\{[\s\S]*\}/);
    if (ob) { try { return JSON.parse(ob[0]); } catch (_) {} }
    return null;
  };

  const generate = async () => {
    const fileText = cmFiles.map(f => '\n=== FILE: ' + f.name + ' ===\n' + f.content).join('\n');
    const combinedText = (rfpText.trim() + fileText).trim();
    if (!combinedText) { setError('Paste RFP requirements or upload documents first.'); return; }
    setLoading(true); setError(''); setMatrix(null); setExpandedRow(null); setEditedRows({});
    try {
      const msg = 'You are an expert proposal compliance analyst. Analyze this RFP and create a detailed compliance matrix. For EACH requirement found in the text, create a row with: requirement_id (L.1, L.2, etc.), requirement_text (exact text), section_reference (where in the RFP), compliance_status (COMPLIANT/PARTIALLY_COMPLIANT/NON_COMPLIANT/TBD), response_approach (2-3 sentences on how EIS would address this), evidence (what past performance or capability proves compliance), risk_level (LOW/MEDIUM/HIGH), and assigned_unit (EIS/PD Systems/Riverstone/Joint). Return ONLY JSON: {"matrix": [...], "summary": {"total": N, "compliant": N, "partial": N, "non_compliant": N, "tbd": N}, "gaps": ["list of capability gaps identified"], "recommendations": ["strategic recommendations"]}. RFP TITLE: ' + (rfpTitle || 'Untitled RFP') + '. EIS CAPABILITIES: ' + capabilities + '. RFP TEXT: ' + combinedText;
      const d = await api.post('gda-chat-v2', { message: msg, session_id: 'compliance-matrix-' + Date.now() });
      const text = safeStr(d.response || d.message || d.output || d);
      const parsed = parseResponse(text);
      if (!parsed || !parsed.matrix) {
        setError('Could not parse compliance matrix. Try again with cleaner RFP text.');
      } else {
        setMatrix(parsed); saveAction("compliance","generate","Compliance Matrix",{},parsed);
        setCmStatus('draft');
      }
    } catch (e) { setError('Generation failed: ' + e.message); }
    setLoading(false);
  };

  const getRows = () => {
    if (!matrix) return [];
    return (matrix.matrix || []).map((row, i) => ({ ...row, ...(editedRows[i] || {}), _idx: i }));
  };

  const displayRows = useMemo(() => {
    let rows = getRows();
    if (filterStatus !== 'all') rows = rows.filter(r => (r.compliance_status || '').toUpperCase().includes(filterStatus.toUpperCase()));
    if (filterRisk !== 'all') rows = rows.filter(r => (r.risk_level || '').toUpperCase() === filterRisk.toUpperCase());
    if (filterUnit !== 'all') rows = rows.filter(r => (r.assigned_unit || '').toLowerCase().includes(filterUnit.toLowerCase()));
    if (sortBy) {
      rows = rows.slice().sort((a, b) => {
        const av = (a[sortBy] || '').toString().toLowerCase();
        const bv = (b[sortBy] || '').toString().toLowerCase();
        return sortDir === 'asc' ? av.localeCompare(bv) : bv.localeCompare(av);
      });
    }
    return rows;
  }, [matrix, editedRows, filterStatus, filterRisk, filterUnit, sortBy, sortDir]);

  const handleSort = (col) => {
    if (sortBy === col) setSortDir(d => d === 'asc' ? 'desc' : 'asc');
    else { setSortBy(col); setSortDir('asc'); }
  };

  const setRowEdit = (idx, field, val) => setEditedRows(prev => ({ ...prev, [idx]: { ...(prev[idx] || {}), [field]: val } }));

  const statusBadge = (status) => {
    const s = (status || 'TBD').toUpperCase();
    const cfg = s === 'COMPLIANT' ? { bg: '#2F5C1F12', color: '#2F5C1F', border: '#86EFAC', label: 'COMPLIANT' }
      : s.includes('PARTIAL') ? { bg: '#B06D3212', color: '#CA8A04', border: '#FDE68A', label: 'PARTIAL' }
      : s.includes('NON') ? { bg: '#FEF2F2', color: '#DC2626', border: '#FCA5A5', label: 'NON-COMP' }
      : { bg: '#F8FAFC', color: '#64748B', border: '#CBD5E1', label: 'TBD' };
    return <span style={{ padding: '2px 8px', background: cfg.bg, color: cfg.color, border: '1px solid ' + cfg.border, borderRadius: 10, fontSize: 10, fontWeight: 700, whiteSpace: 'nowrap' }}>{cfg.label}</span>;
  };

  const riskBadge = (risk) => {
    const r = (risk || '').toUpperCase();
    const cfg = r === 'LOW' ? { bg: '#2F5C1F12', color: '#2F5C1F' }
      : r === 'MEDIUM' ? { bg: '#B06D3212', color: '#CA8A04' }
      : r === 'HIGH' ? { bg: '#FEF2F2', color: '#DC2626' }
      : { bg: '#F8FAFC', color: '#64748B' };
    return <span style={{ padding: '2px 7px', background: cfg.bg, color: cfg.color, borderRadius: 10, fontSize: 10, fontWeight: 700 }}>{r || '—'}</span>;
  };

  const unitPill = (unit) => {
    const u = (unit || '').trim();
    const cfg = u === 'EIS' ? { bg: '#EFF6FF', color: '#1D4ED8' }
      : u === 'PD Systems' ? { bg: '#32448A12', color: '#32448A' }
      : u === 'Riverstone' ? { bg: '#F0FDFA', color: '#0F766E' }
      : u === 'Joint' ? { bg: NAVY, color: WHITE }
      : { bg: '#F8FAFC', color: '#64748B' };
    return <span style={{ padding: '2px 8px', background: cfg.bg, color: cfg.color, borderRadius: 10, fontSize: 10, fontWeight: 600 }}>{u || '—'}</span>;
  };

  const copyCSV = () => {
    const rows = getRows();
    const esc = (v) => '"' + String(v || '').replace(/"/g, '""') + '"';
    const lines = [['#','Req ID','Requirement','Section','Status','Response Approach','Evidence','Risk','Unit'].map(esc).join(',')];
    rows.forEach((r, i) => lines.push([i+1, r.requirement_id, r.requirement_text, r.section_reference, r.compliance_status, r.response_approach, r.evidence, r.risk_level, r.assigned_unit].map(esc).join(',')));
    navigator.clipboard.writeText(lines.join('\n')).catch(() => {});
    setToast('CSV copied!'); setTimeout(() => setToast(''), 3000);
  };

  const copyMD = () => {
    const rows = getRows();
    const esc = (v) => String(v || '').replace(/\|/g, '\\|');
    const lines = ['| # | Req ID | Requirement | Status | Response Approach | Risk | Unit |', '|---|---|---|---|---|---|---|'];
    rows.forEach((r, i) => lines.push('| ' + [i+1, esc(r.requirement_id), esc(r.requirement_text), esc(r.compliance_status), esc(r.response_approach), esc(r.risk_level), esc(r.assigned_unit)].join(' | ') + ' |'));
    navigator.clipboard.writeText(lines.join('\n')).catch(() => {});
    setToast('Markdown copied!'); setTimeout(() => setToast(''), 3000);
  };

  const summary = matrix ? (matrix.summary || {}) : {};
  const total = summary.total || (matrix ? (matrix.matrix || []).length : 0);
  const compliant = summary.compliant || 0;
  const partial = summary.partial || 0;
  const nonTbd = (summary.non_compliant || 0) + (summary.tbd || 0);

  return (
    <div>
      <PageHeader title="Compliance Matrix Builder" sub="RFP Requirement Mapping & Response Planning" />

      {toast && (
        <div style={{ padding: '10px 16px', background: '#2F5C1F12', border: '1px solid #86EFAC', borderRadius: 8, marginBottom: 14, fontSize: 13, fontWeight: 600, color: '#2F5C1F' }}>{toast}</div>
      )}

      {/* Input card */}
      <div style={{ ...S.card, marginBottom: 16 }}>
        <div style={{ fontSize: 13, fontWeight: 700, color: NAVY, marginBottom: 14 }}>RFP Analysis Input</div>

        <div style={{ marginBottom: 10 }}>
          <div style={{ fontSize: 11, fontWeight: 600, color: '#666', marginBottom: 4 }}>RFP / SOW Title</div>
          <input style={S.input} placeholder="e.g. Georgetown Defense Analytics — Training & Simulation Support" value={rfpTitle} onChange={e => setRfpTitle(e.target.value)} />
        </div>

        <div style={{ marginBottom: 10 }}>
          <div style={{ fontSize: 11, fontWeight: 600, color: '#666', marginBottom: 4 }}>RFP Requirements / SOW / PWS</div>
          <textarea style={{ ...S.textarea, height: 160, resize: 'vertical' }} placeholder="Paste the RFP requirements section, SOW, or PWS here..." value={rfpText} onChange={e => setRfpText(e.target.value)} />
        </div>

        <div style={{ marginBottom: 14 }}>
          <div style={{ fontSize: 11, fontWeight: 600, color: '#666', marginBottom: 4 }}>EIS Capabilities Summary</div>
          <textarea style={{ ...S.textarea, height: 60, resize: 'none' }} value={capabilities} onChange={e => setCapabilities(e.target.value)} />
        </div>

        {/* Drop zone for RFP documents */}
        <div style={{ marginBottom: 14 }}>
          <div style={{ fontSize: 11, fontWeight: 600, color: '#666', marginBottom: 4 }}>Or Upload RFP Documents</div>
          <div onDrop={cmOnDrop} onDragOver={(e) => { e.preventDefault(); setCmDragOver(true); }} onDragLeave={() => setCmDragOver(false)}
            style={{ border: '2px dashed ' + (cmDragOver ? ACCENT : '#D1D5DB'), borderRadius: 10, padding: cmFiles.length > 0 ? '16px' : '40px 20px', textAlign: 'center', background: cmDragOver ? ACCENT + '08' : '#FAFBFC', transition: 'all 0.2s', cursor: 'pointer', marginBottom: 10 }}
            onClick={() => { const inp = document.createElement('input'); inp.type = 'file'; inp.multiple = true; inp.accept = CM_ALLOWED.join(','); inp.onchange = (e) => cmAddFiles(e.target.files); inp.click(); }}>
            {cmFiles.length === 0 ? (
              <div>
                <div style={{ fontSize: 32, marginBottom: 8 }}>📁</div>
                <div style={{ fontSize: 14, fontWeight: 700, color: NAVY, marginBottom: 4 }}>Drop RFP / SOW documents here</div>
                <div style={{ fontSize: 12, color: '#6B7280' }}>or click to browse. PDF, Word, Excel, PowerPoint, CSV, TXT</div>
                <div style={{ fontSize: 11, color: '#9CA3AF', marginTop: 6 }}>Upload the entire RFP package for automatic text extraction</div>
              </div>
            ) : (
              <div style={{ fontSize: 12, color: ACCENT, fontWeight: 600 }}>+ Drop more files or click to add</div>
            )}
          </div>
          {cmFiles.length > 0 && (
            <div style={{ marginBottom: 10 }}>
              <div style={{ fontSize: 12, fontWeight: 700, color: NAVY, marginBottom: 8 }}>{cmFiles.length} document{cmFiles.length > 1 ? 's' : ''} loaded</div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
                {cmFiles.map((f, i) => (
                  <div key={i} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '8px 12px', background: '#2F5C1F12', borderRadius: 6, border: '1px solid #BBF7D0' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                      <span style={{ fontSize: 14 }}>{f.name.endsWith('.pdf') ? '📄' : f.name.match(/\.docx?$/) ? '📘' : f.name.match(/\.xlsx?$/) ? '📊' : '📃'}</span>
                      <span style={{ fontSize: 12, fontWeight: 600, color: '#2F5C1F' }}>{f.name}</span>
                      <span style={{ fontSize: 11, color: '#6B7280' }}>{cmFmtSz(f.size)}</span>
                    </div>
                    <button onClick={(e) => { e.stopPropagation(); cmRemoveFile(f.name); }} style={{ background: 'none', border: 'none', color: '#DC2626', cursor: 'pointer', fontSize: 14, padding: '2px 6px' }}>x</button>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {error && <Alert msg={error} />}

        <button style={{ ...S.btn(), width: '100%', background: '#D14A2A', opacity: loading ? 0.6 : 1, fontSize: 14, padding: '10px 0' }} onClick={generate} disabled={loading}>
          {loading ? '⏳ Analyzing RFP requirements... (15-30s)' : '✅ Generate Compliance Matrix'}
        </button>
      </div>

      {/* Empty state */}
      {!matrix && !loading && (
        <div style={{ ...S.card, textAlign: 'center', padding: 60, color: '#aaa' }}>
          <div style={{ fontSize: 48, marginBottom: 12 }}>📋</div>
          <div style={{ fontSize: 14, fontWeight: 600, color: NAVY }}>Paste your RFP requirements or drop documents above</div>
          <div style={{ fontSize: 12, marginTop: 6 }}>The AI will extract every requirement and map it to EIS capabilities</div>
        </div>
      )}

      {/* Results */}
      {matrix && cmStatus === 'draft' && (
        <div style={{ background: '#B06D3212', border: '1px solid #FDE68A', borderRadius: 8, padding: '12px 16px', marginBottom: 14, display: 'flex', alignItems: 'center', gap: 12 }}>
          <span style={{ fontSize: 13, fontWeight: 700, color: '#B06D32' }}>⚠ AI Draft — Pending Your Review</span>
          <div style={{ flex: 1 }} />
          <button onClick={() => { setCmStatus('active'); setCmApprovedAt(new Date().toLocaleString()); api.post('gda-data-learn', {event:'draft_approved', context:'compliance-matrix', data:{rfpTitle}}).catch(function(){}); }} style={{ padding: '6px 16px', background: '#2F5C1F', color: '#fff', border: 'none', borderRadius: 6, fontSize: 12, fontWeight: 700, cursor: 'pointer' }}>✓ Approve</button>
          <button onClick={generate} style={{ padding: '6px 12px', background: '#6B7280', color: '#fff', border: 'none', borderRadius: 6, fontSize: 12, fontWeight: 600, cursor: 'pointer' }}>Revise</button>
        </div>
      )}
      {matrix && <GDAKpiBar items={[
        {id:'total',label:'Total Requirements',value:total,sub:'in matrix'},
        {id:'compliant',label:'Compliant',value:compliant,color:'#2F5C1F',sub:'requirements met'},
        {id:'partial',label:'Partial',value:partial,color:'#B06D32',sub:'needs work'},
        {id:'gap',label:'Gaps',value:nonTbd,color:nonTbd>0?'#DC2626':'#1B2A4A',sub:'not addressed'}
      ]} detail={kpiDetail} setDetail={setKpiDetail} />}
      {cmStatus === 'active' && cmApprovedAt && (
        <div style={{ background: '#2F5C1F12', border: '1px solid #86EFAC', borderRadius: 8, padding: '10px 16px', marginBottom: 14, fontSize: 12, fontWeight: 600, color: '#2F5C1F' }}>✓ Approved — {cmApprovedAt}</div>
      )}
      {matrix && (
        <div>
          {/* KPI summary bar */}
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr 1fr', gap: 10, marginBottom: 14 }}>
            {[
              { label: 'Total Requirements', value: total, color: NAVY, bg: WHITE },
              { label: 'Compliant', value: total ? compliant + ' (' + Math.round(compliant/total*100) + '%)' : compliant, color: '#2F5C1F', bg: '#2F5C1F12' },
              { label: 'Partially Compliant', value: total ? partial + ' (' + Math.round(partial/total*100) + '%)' : partial, color: '#CA8A04', bg: '#B06D3212' },
              { label: 'Non-Compliant / TBD', value: total ? nonTbd + ' (' + Math.round(nonTbd/total*100) + '%)' : nonTbd, color: '#DC2626', bg: '#FEF2F2' },
            ].map((kpi, i) => (
              <div key={i} style={{ background: kpi.bg, border: '1px solid ' + BORDER, borderRadius: 8, padding: '14px 16px', textAlign: 'center' }}>
                <div style={{ fontSize: 22, fontWeight: 800, color: kpi.color }}>{kpi.value}</div>
                <div style={{ fontSize: 11, color: '#666', marginTop: 3 }}>{kpi.label}</div>
              </div>
            ))}
          </div>

          {/* Action buttons */}
          <div style={{ display: 'flex', gap: 8, marginBottom: 12, alignItems: 'center', flexWrap: 'wrap' }}>
            <button onClick={copyCSV} style={{ ...S.btn('secondary', true), fontSize: 12 }}>📄 Copy as CSV</button>
            <button onClick={copyMD} style={{ ...S.btn('secondary', true), fontSize: 12 }}>📝 Copy as Markdown</button>
            <button disabled style={{ ...S.btn('secondary', true), fontSize: 12, opacity: 0.4, cursor: 'not-allowed' }} title="Coming soon">Export DOCX</button>
            <div style={{ flex: 1 }} />
            <button onClick={() => { setMatrix(null); setExpandedRow(null); setEditedRows({}); }} style={{ padding: '7px 14px', background: 'none', border: '1px solid #D14A2A', borderRadius: 6, color: '#D14A2A', fontSize: 12, fontWeight: 600, cursor: 'pointer' }}>↺ Re-analyze</button>
          </div>

          {/* Filter row */}
          <div style={{ display: 'flex', gap: 8, marginBottom: 10, alignItems: 'center' }}>
            <select style={{ ...S.select, fontSize: 11 }} value={filterStatus} onChange={e => setFilterStatus(e.target.value)}>
              <option value="all">All Statuses</option>
              <option value="COMPLIANT">Compliant</option>
              <option value="PARTIAL">Partially Compliant</option>
              <option value="NON">Non-Compliant</option>
              <option value="TBD">TBD</option>
            </select>
            <select style={{ ...S.select, fontSize: 11 }} value={filterRisk} onChange={e => setFilterRisk(e.target.value)}>
              <option value="all">All Risk Levels</option>
              <option value="LOW">Low Risk</option>
              <option value="MEDIUM">Medium Risk</option>
              <option value="HIGH">High Risk</option>
            </select>
            <select style={{ ...S.select, fontSize: 11 }} value={filterUnit} onChange={e => setFilterUnit(e.target.value)}>
              <option value="all">All Units</option>
              <option value="EIS">EIS</option>
              <option value="PD Systems">PD Systems</option>
              <option value="Riverstone">Riverstone</option>
              <option value="Joint">Joint</option>
            </select>
            <div style={{ fontSize: 11, color: '#888', marginLeft: 4 }}>{displayRows.length} row{displayRows.length !== 1 ? 's' : ''}</div>
          </div>

          {/* Matrix table */}
          <div style={{ ...S.card, padding: 0, overflowX: 'auto' }}>
            <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 12 }}>
              <thead>
                <tr style={{ background: NAVY }}>
                  <th style={{ ...S.th, color: WHITE, background: 'transparent', width: 32 }}>#</th>
                  <th style={{ ...S.th, color: WHITE, background: 'transparent', width: 60 }}>Req ID</th>
                  <th style={{ ...S.th, color: WHITE, background: 'transparent', minWidth: 180 }}>Requirement</th>
                  <th style={{ ...S.th, color: WHITE, background: 'transparent', width: 76 }}>Section</th>
                  <th onClick={() => handleSort('compliance_status')} style={{ ...S.th, color: WHITE, background: 'transparent', cursor: 'pointer', width: 100, userSelect: 'none' }}>
                    Status {sortBy === 'compliance_status' ? (sortDir === 'asc' ? '▲' : '▼') : '⇅'}
                  </th>
                  <th style={{ ...S.th, color: WHITE, background: 'transparent', minWidth: 160 }}>Response Approach</th>
                  <th style={{ ...S.th, color: WHITE, background: 'transparent', minWidth: 110 }}>Evidence</th>
                  <th onClick={() => handleSort('risk_level')} style={{ ...S.th, color: WHITE, background: 'transparent', cursor: 'pointer', width: 68, userSelect: 'none' }}>
                    Risk {sortBy === 'risk_level' ? (sortDir === 'asc' ? '▲' : '▼') : '⇅'}
                  </th>
                  <th onClick={() => handleSort('assigned_unit')} style={{ ...S.th, color: WHITE, background: 'transparent', cursor: 'pointer', width: 88, userSelect: 'none' }}>
                    Unit {sortBy === 'assigned_unit' ? (sortDir === 'asc' ? '▲' : '▼') : '⇅'}
                  </th>
                </tr>
              </thead>
              <tbody>
                {displayRows.length === 0 && (
                  <tr><td colSpan={9} style={{ textAlign: 'center', padding: 24, color: '#888', fontSize: 12 }}>No rows match current filters</td></tr>
                )}
                {displayRows.map((row, i) => {
                  const isOpen = expandedRow === row._idx;
                  return (
                    <React.Fragment key={row._idx}>
                      <tr
                        onClick={() => setExpandedRow(isOpen ? null : row._idx)}
                        style={{ borderBottom: '1px solid ' + BORDER, background: isOpen ? '#EFF6FF' : (i % 2 === 0 ? WHITE : '#fafafa'), cursor: 'pointer' }}
                      >
                        <td style={{ ...S.td, color: '#888', textAlign: 'center' }}>{i + 1}</td>
                        <td style={{ ...S.td, fontWeight: 700, color: ACCENT }}>{safeStr(row.requirement_id)}</td>
                        <td style={{ ...S.td, lineHeight: 1.5 }}>{safeStr(row.requirement_text)}</td>
                        <td style={{ ...S.td, color: '#666', fontSize: 11 }}>{safeStr(row.section_reference)}</td>
                        <td style={{ ...S.td, textAlign: 'center' }}>{statusBadge(row.compliance_status)}</td>
                        <td style={{ ...S.td, lineHeight: 1.5, color: '#555' }}>{safeStr(row.response_approach)}</td>
                        <td style={{ ...S.td, lineHeight: 1.5, color: '#666', fontSize: 11 }}>{safeStr(row.evidence)}</td>
                        <td style={{ ...S.td, textAlign: 'center' }}>{riskBadge(row.risk_level)}</td>
                        <td style={{ ...S.td, textAlign: 'center' }}>{unitPill(row.assigned_unit)}</td>
                      </tr>
                      {isOpen && (
                        <tr key={'edit-' + row._idx} style={{ background: '#EFF6FF', borderBottom: '2px solid ' + ACCENT }}>
                          <td colSpan={9} style={{ padding: '12px 16px' }}>
                            <div style={{ display: 'grid', gridTemplateColumns: '1fr 200px', gap: 12 }}>
                              <div>
                                <div style={{ fontSize: 11, fontWeight: 600, color: '#666', marginBottom: 4 }}>Response Approach</div>
                                <textarea
                                  style={{ ...S.textarea, height: 80, resize: 'vertical' }}
                                  value={safeStr(editedRows[row._idx] && editedRows[row._idx].response_approach !== undefined ? editedRows[row._idx].response_approach : row.response_approach)}
                                  onChange={e => setRowEdit(row._idx, 'response_approach', e.target.value)}
                                  onClick={e => e.stopPropagation()}
                                />
                              </div>
                              <div>
                                <div style={{ fontSize: 11, fontWeight: 600, color: '#666', marginBottom: 4 }}>Compliance Status</div>
                                <select
                                  style={S.select}
                                  value={safeStr(editedRows[row._idx] && editedRows[row._idx].compliance_status !== undefined ? editedRows[row._idx].compliance_status : row.compliance_status)}
                                  onChange={e => { e.stopPropagation(); setRowEdit(row._idx, 'compliance_status', e.target.value); }}
                                  onClick={e => e.stopPropagation()}
                                >
                                  <option value="COMPLIANT">COMPLIANT</option>
                                  <option value="PARTIALLY_COMPLIANT">PARTIALLY_COMPLIANT</option>
                                  <option value="NON_COMPLIANT">NON_COMPLIANT</option>
                                  <option value="TBD">TBD</option>
                                </select>
                              </div>
                            </div>
                          </td>
                        </tr>
                      )}
                    </React.Fragment>
                  );
                })}
              </tbody>
            </table>
          </div>

          {/* Gaps & Recommendations — collapsed by default */}
          <div style={{ ...S.card, padding: 0, marginTop: 14, overflow: 'hidden' }}>
            <div
              onClick={() => setGapsOpen(o => !o)}
              style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '12px 16px', background: NAVY, cursor: 'pointer', userSelect: 'none' }}
            >
              <div style={{ fontSize: 13, fontWeight: 700, color: WHITE }}>Gaps & Recommendations</div>
              <div style={{ color: WHITE, fontSize: 16, transition: 'transform 0.2s', transform: gapsOpen ? 'rotate(180deg)' : 'none' }}>▼</div>
            </div>
            {gapsOpen && (
              <div style={{ padding: 16, display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
                <div>
                  <div style={{ fontSize: 12, fontWeight: 700, color: NAVY, marginBottom: 8 }}>Capability Gaps</div>
                  {(matrix.gaps || []).length === 0
                    ? <div style={{ fontSize: 12, color: '#888' }}>None identified</div>
                    : <ol style={{ margin: 0, paddingLeft: 18 }}>{(matrix.gaps || []).map((g, i) => <li key={i} style={{ fontSize: 12, lineHeight: 1.6, color: '#333', marginBottom: 4 }}><span style={{ color: '#DC2626' }}>● </span>{safeStr(g)}</li>)}</ol>}
                </div>
                <div>
                  <div style={{ fontSize: 12, fontWeight: 700, color: NAVY, marginBottom: 8 }}>Strategic Recommendations</div>
                  {(matrix.recommendations || []).length === 0
                    ? <div style={{ fontSize: 12, color: '#888' }}>None</div>
                    : <ol style={{ margin: 0, paddingLeft: 18 }}>{(matrix.recommendations || []).map((r, i) => <li key={i} style={{ fontSize: 12, lineHeight: 1.6, color: '#333', marginBottom: 4 }}><span style={{ color: '#D14A2A' }}>● </span>{safeStr(r)}</li>)}</ol>}
                </div>
              </div>
            )}
          </div>
          <div style={{ fontSize: 10, color: '#9CA3AF', marginTop: 8 }}>Source: AI compliance analysis via GDA Agent</div>
        </div>
      )}
    </div>
  );
}
export default ComplianceMatrix;