import React, { useState, useEffect, useCallback, useRef, useMemo } from 'react';
import { ACCENT, NAVY, BG, WHITE, BORDER, FONT, N8N, AUTH, api, S, css, gdaNav, NAV_ITEMS, Spinner, Empty, Alert, PageHeader , saveAction, ActionHistory } from '../../lib/gda';
function Presentations() {
  const [form, setForm] = useState({ title: '', audience: '', topic: '', slide_count: 10, style: 'professional', output_format: 'pptx' });
  const [srcFiles, setSrcFiles] = useState([]);
  const [styleFile, setStyleFile] = useState(null);
  const [srcDragOver, setSrcDragOver] = useState(false);
  const [styleDragOver, setStyleDragOver] = useState(false);
  const [keyPts, setKeyPts] = useState([]);
  const [ptInput, setPtInput] = useState('');
  const [docFile, setDocFile] = useState(null);
  const [slides, setSlides] = useState(null);
  const [loading, setLoading] = useState(false);
  const [loadingDoc, setLoadingDoc] = useState(false);
  const [dragIdx, setDragIdx] = useState(null);
  const [error, setError] = useState('');

  const addPt = () => { if (ptInput.trim()) { setKeyPts(p => [...p, ptInput.trim()]); setPtInput(''); } };
  const rmPt = (i) => setKeyPts(p => p.filter((_, j) => j !== i));

  const handleDragStart = (i) => setDragIdx(i);
  const handleDrop = (i) => {
    if (dragIdx === null || dragIdx === i) return;
    setKeyPts(p => { const arr = p.slice(); const [removed] = arr.splice(dragIdx, 1); arr.splice(i, 0, removed); return arr; });
    setDragIdx(null);
  };
  const handleDragOver = (e) => e.preventDefault();

  const handleFile = async (e) => {
    const file = e.target.files[0]; if (!file) return;
    const reader = new FileReader();
    reader.onload = async () => {
      const b64 = reader.result.split(',')[1] || reader.result;
      setDocFile({ name: file.name, content: b64, size: file.size });
      setLoadingDoc(true);
      try {
        const d = await api.post('gda-pptx-gen', { action: 'extract_points', content: b64, filename: file.name });
        if (d && Array.isArray(d.points) && d.points.length > 0) {
          setKeyPts(p => [...p, ...d.points.map(pt => typeof pt === 'string' ? pt : JSON.stringify(pt))]);
        }
      } catch (_) {}
      setLoadingDoc(false);
    };
    reader.readAsDataURL(file);
  };

  const presWaitForLib = (key, ms=5000) => new Promise((resolve) => {
    if (window[key]) return resolve(window[key]);
    const start = Date.now();
    const iv = setInterval(() => {
      if (window[key]) { clearInterval(iv); resolve(window[key]); }
      else if (Date.now() - start > ms) { clearInterval(iv); resolve(null); }
    }, 100);
  });

  const presExtractText = async (file) => {
    const name = file.name.toLowerCase();
    if (name.endsWith('.txt') || name.endsWith('.csv')) return await file.text();
    if (name.endsWith('.pdf')) {
      try {
        const lib = await presWaitForLib('pdfjsLib');
        if (!lib) return '[PDF parser not loaded]';
        const buf = await file.arrayBuffer();
        const pdf = await lib.getDocument({data:buf}).promise;
        let txt = '';
        for (let i = 1; i <= pdf.numPages; i++) {
          const pg = await pdf.getPage(i);
          const tc = await pg.getTextContent();
          txt += tc.items.map(it => it.str).join(' ') + '\n';
        }
        return txt || '[PDF loaded but empty]';
      } catch(e) { return '[PDF failed: ' + e.message + ']'; }
    }
    if (name.endsWith('.docx') || name.endsWith('.doc')) {
      try {
        const lib = await presWaitForLib('mammoth');
        if (!lib) return '[Word parser not loaded]';
        const buf = await file.arrayBuffer();
        const result = await lib.extractRawText({arrayBuffer: buf});
        return result.value || '[Word doc empty]';
      } catch(e) { return '[Word failed: ' + e.message + ']'; }
    }
    if (name.endsWith('.xlsx') || name.endsWith('.xls')) {
      try {
        const lib = await presWaitForLib('XLSX');
        if (!lib) return '[Excel parser not loaded]';
        const buf = await file.arrayBuffer();
        const wb = lib.read(buf);
        let txt = '';
        wb.SheetNames.forEach(sn => { txt += '=== ' + sn + ' ===\n' + lib.utils.sheet_to_csv(wb.Sheets[sn]) + '\n\n'; });
        return txt || '[Excel empty]';
      } catch(e) { return '[Excel failed: ' + e.message + ']'; }
    }
    if (name.endsWith('.pptx')) {
      try {
        const JSZip = (await import('https://cdn.jsdelivr.net/npm/jszip@3.10.1/+esm')).default;
        const buf = await file.arrayBuffer();
        const zip = await JSZip.loadAsync(buf);
        let txt = '';
        const slideFiles = Object.keys(zip.files).filter(f => f.match(/ppt\/slides\/slide\d+\.xml/)).sort();
        for (const sf of slideFiles) {
          const xml = await zip.files[sf].async('text');
          txt += xml.replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim() + '\n\n';
        }
        return txt || '[PPTX empty]';
      } catch(e) { return '[PPTX failed: ' + e.message + ']'; }
    }
    return await file.text();
  };

  const ALLOWED_EXTS = ['.pdf','.doc','.docx','.txt','.xlsx','.xls','.pptx','.csv'];

  const addSrcFiles = (nf) => {
    const valid = Array.from(nf).filter(f => ALLOWED_EXTS.some(e => f.name.toLowerCase().endsWith(e)));
    if (!valid.length) return;
    valid.forEach(async (file) => {
      const extracted = await presExtractText(file);
      setSrcFiles(p => {
        if (p.find(x => x.name === file.name)) return p;
        return [...p, {name: file.name, content: extracted, size: file.size}];
      });
    });
  };

  const addStyleFile = async (nf) => {
    const file = Array.from(nf)[0];
    if (!file) return;
    const extracted = await presExtractText(file);
    setStyleFile({name: file.name, content: extracted, size: file.size});
  };


  const gen = async () => {
    if (!form.title.trim() && !form.topic.trim()) return;
    setLoading(true); setError(''); setSlides(null);
    try {
      const payload = { action: 'generate', ...form, topic: form.topic, slide_count: form.slide_count, key_points: keyPts, output_format: 'pptx' };
      if (docFile) { payload.doc_content = docFile.content; payload.filename = docFile.name; }
      if (srcFiles.length > 0) { payload.doc_content_text = srcFiles.map(f => '=== ' + f.name + ' ===\n' + f.content).join('\n\n'); }
      if (styleFile) { payload.style_template = styleFile.content; payload.style_filename = styleFile.name; }
      const d = await api.post('gda-pptx-gen', payload, {signal: AbortSignal.timeout(90000)});
      const arr = Array.isArray(d.slides) ? d.slides : (d.output ? [{ title: 'Output', bullets: [], speaker_notes: d.output }] : []);
      setSlides(arr); saveAction("doc-hub","generate",form.title||"Presentation",form,{slideCount:arr.length});
    } catch (e) { setError(e.message); }
    setLoading(false);
  };

  const copyAll = () => {
    if (!slides) return;
    const md = slides.map((s, i) =>
      `## Slide ${i + 1}: ${s.title || ''}\n${(s.bullets || []).map(b => `- ${b}`).join('\n')}${s.speaker_notes ? `\n\n_Notes: ${s.speaker_notes}_` : ''}`
    ).join('\n\n---\n\n');
    navigator.clipboard.writeText(md).catch(() => {});
  };

  const fmtSize = (bytes) => bytes < 1024 * 1024 ? (bytes / 1024).toFixed(1) + ' KB' : (bytes / (1024 * 1024)).toFixed(1) + ' MB';

  return (
    <div>
      {/* PageHeader removed - shown by DocumentHub parent */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
        <div>
          <div style={S.card}>
            <div style={S.cardTitle}>Generate Presentation</div>
            <div style={{ marginBottom: 12 }}>
              <div style={{ fontSize: 11, fontWeight: 600, color: '#666', marginBottom: 4 }}>Title</div>
              <input style={S.input} placeholder="e.g. EIS SOCOM Training Simulation Capability Brief" value={form.title} onChange={e => setForm(p => ({ ...p, title: e.target.value }))} />
            </div>
            <div style={{ marginBottom: 12 }}>
              <div style={{ fontSize: 11, fontWeight: 600, color: '#666', marginBottom: 4 }}>Target Audience</div>
              <input style={S.input} placeholder="e.g. SOCOM J7, contracting officer" value={form.audience} onChange={e => setForm(p => ({ ...p, audience: e.target.value }))} />
            </div>
            <div style={{ marginBottom: 12 }}>
              <div style={{ fontSize: 11, fontWeight: 600, color: '#666', marginBottom: 4 }}>Topic / What is this presentation about?</div>
              <textarea style={{ ...S.input, minHeight: 60, resize: 'vertical' }} placeholder="e.g., SBA Mentor-Protege Program requirements and process, IEW&S Recompete Strategy, Golden Dome Initiative overview..." value={form.topic} onChange={e => setForm(p => ({ ...p, topic: e.target.value }))} />
              <div style={{ fontSize: 11, color: '#9CA3AF', marginTop: 3 }}>This drives AI web research (Tavily) + slide generation (Claude)</div>
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginBottom: 12 }}>
              <div>
                <div style={{ fontSize: 11, fontWeight: 600, color: '#666', marginBottom: 4 }}>Slide Style</div>
                <select style={S.select} value={form.style} onChange={e => setForm(p => ({ ...p, style: e.target.value }))}>
                  <option value="professional">Professional - formal, structured bullets</option>
                  <option value="executive">Executive Brief - punchy, BLUF, decision-focused</option>
                  <option value="technical">Technical - data-heavy, specs and metrics</option>
                  <option value="storytelling">Storytelling - narrative, problem-solution</option>
                </select>
              </div>
              <div>
                <div style={{ fontSize: 11, fontWeight: 600, color: '#666', marginBottom: 4 }}>Number of Slides</div>
                <input type="number" min={3} max={30} style={S.input} value={form.slide_count} onChange={e => setForm(p => ({ ...p, slide_count: Math.max(3, Math.min(30, Number(e.target.value) || 10)) }))} />
              </div>
            </div>
            
            {/* PR-001: Key Points */}
            <div style={{ marginBottom: 12 }}>
              <div style={{ fontSize: 11, fontWeight: 600, color: '#666', marginBottom: 4 }}>Key Points</div>
              <div style={{ display: 'flex', gap: 6, marginBottom: 8 }}>
                <input style={{ ...S.input, flex: 1 }} placeholder="Type a key point and press Enter..." value={ptInput}
                  onChange={e => setPtInput(e.target.value)} onKeyDown={e => { if (e.key === 'Enter') { e.preventDefault(); addPt(); } }} />
                <button style={S.btn('secondary', true)} onClick={addPt}>Add</button>
              </div>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
                {keyPts.map((pt, i) => (
                  <span key={i} draggable onDragStart={() => handleDragStart(i)} onDrop={() => handleDrop(i)} onDragOver={handleDragOver}
                    style={{ display: 'inline-flex', alignItems: 'center', gap: 4, padding: '4px 10px', background: '#f0f7ff', border: '1px solid #d0e3f7', borderRadius: 14, fontSize: 11, color: NAVY, cursor: 'grab' }}>
                    <span style={{ color: '#aaa', fontSize: 10 }}>⋮⋮</span>
                    {pt}
                    <span onClick={() => rmPt(i)} style={{ cursor: 'pointer', color: '#999', fontWeight: 700, marginLeft: 2 }}>×</span>
                  </span>
                ))}
              </div>
            </div>
            {/* Source Documents Drop Zone */}
            <div style={{marginBottom:12}}>
              <div style={{fontSize:11,fontWeight:600,color:'#666',marginBottom:4}}>Source Documents <span style={{fontWeight:400,color:'#aaa'}}>(drop files to extract content)</span></div>
              <div onDragOver={e=>{e.preventDefault();setSrcDragOver(true);}} onDragLeave={()=>setSrcDragOver(false)} onDrop={e=>{e.preventDefault();setSrcDragOver(false);addSrcFiles(e.dataTransfer.files);}}
                onClick={()=>{const inp=document.createElement('input');inp.type='file';inp.multiple=true;inp.accept=ALLOWED_EXTS.join(',');inp.onchange=e=>addSrcFiles(e.target.files);inp.click();}}
                style={{minHeight:60,border:'2px dashed '+(srcDragOver?ACCENT:BORDER),borderRadius:8,cursor:'pointer',display:'flex',flexDirection:'column',alignItems:'center',justifyContent:'center',padding:12,background:srcDragOver?'#B06D3212':'#FAFBFC',transition:'all 0.2s'}}>
                <span style={{fontSize:12,color:'#6B7280'}}>Drop PDF, Word, Excel, PPT, CSV, TXT</span>
              </div>
              {srcFiles.length>0&&<div style={{marginTop:6}}>{srcFiles.map((f,i)=>(
                <div key={i} style={{display:'flex',alignItems:'center',justifyContent:'space-between',padding:'4px 8px',background:'#2F5C1F12',borderRadius:4,marginBottom:3,fontSize:11}}>
                  <span style={{color:NAVY,fontWeight:500}}>{f.name} <span style={{color:'#9CA3AF'}}>({fmtSize(f.size)})</span></span>
                  <span onClick={e=>{e.stopPropagation();setSrcFiles(p=>p.filter((_,j)=>j!==i));}} style={{cursor:'pointer',color:'#DC2626',fontWeight:700}}>x</span>
                </div>
              ))}</div>}
            </div>
            {/* Style Template Drop Zone */}
            <div style={{marginBottom:16}}>
              <div style={{fontSize:11,fontWeight:600,color:'#666',marginBottom:4}}>Style Template <span style={{fontWeight:400,color:'#aaa'}}>(optional — AI mimics format & tone)</span></div>
              {styleFile ? (
                <div style={{display:'flex',alignItems:'center',gap:8,padding:'6px 10px',background:'#EEF2FF',borderRadius:6,border:'1px solid #C7D2FE',fontSize:11}}>
                  <span style={{flex:1,color:NAVY,fontWeight:500}}>{styleFile.name} <span style={{color:'#9CA3AF'}}>({fmtSize(styleFile.size)})</span></span>
                  <span onClick={()=>setStyleFile(null)} style={{cursor:'pointer',color:'#DC2626',fontWeight:700}}>x</span>
                </div>
              ) : (
                <div onDragOver={e=>{e.preventDefault();setStyleDragOver(true);}} onDragLeave={()=>setStyleDragOver(false)} onDrop={e=>{e.preventDefault();setStyleDragOver(false);addStyleFile(e.dataTransfer.files);}}
                  onClick={()=>{const inp=document.createElement('input');inp.type='file';inp.accept='.pptx,.docx,.pdf,.txt';inp.onchange=e=>addStyleFile(e.target.files);inp.click();}}
                  style={{minHeight:40,border:'2px dashed '+(styleDragOver?'#32448A':BORDER),borderRadius:8,cursor:'pointer',display:'flex',alignItems:'center',justifyContent:'center',padding:8,background:styleDragOver?'#32448A12':'#FAFBFC'}}>
                  <span style={{fontSize:11,color:'#9CA3AF'}}>Drop style template (PPTX, DOCX, PDF)</span>
                </div>
              )}
            </div>
            {error && <Alert msg={error} />}            {error && <Alert msg={error} />}
            <button style={{ ...S.btn(), width: '100%', opacity: loading || !form.title.trim() ? 0.6 : 1 }} onClick={gen} disabled={loading || !form.title.trim()}>
              {loading ? 'Generating...' : form.output_format === 'pptx' ? 'Generate Presentation' : form.output_format === 'word' ? 'Generate Document' : form.output_format === 'brief' ? 'Generate Brief' : 'Generate Memo'}
            </button>
          </div>
        </div>
        {/* PR-003: Slide Preview */}
        <div>
          {slides ? (
            <div>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 }}>
                <div style={{ fontSize: 13, fontWeight: 700, color: NAVY }}>{slides.length} Slides Generated</div>
                <div style={{ display: 'flex', gap: 6 }}>
                  <button style={{ ...S.btn('secondary', true), fontSize: 11 }} onClick={copyAll}>Copy All</button>
                  <button style={{ ...S.btn('secondary', true), fontSize: 11, opacity: 0.5, cursor: 'not-allowed' }} disabled>Export</button>
                </div>
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                {slides.map((slide, i) => (
                  <div key={i} style={{ ...S.card, position: 'relative' }}>
                    <div style={{ position: 'absolute', top: 10, left: 10, width: 24, height: 24, borderRadius: 12, background: ACCENT, color: WHITE, fontSize: 11, fontWeight: 700, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>{i + 1}</div>
                    <div style={{ paddingLeft: 36 }}>
                      <div style={{ fontWeight: 700, fontSize: 15, color: NAVY, marginBottom: 6 }}>{slide.title || `Slide ${i + 1}`}</div>
                      {Array.isArray(slide.bullets) && slide.bullets.length > 0 && (
                        <ul style={{ margin: 0, paddingLeft: 16 }}>
                          {slide.bullets.map((b, j) => (
                            <li key={j} style={{ fontSize: 12, color: '#333', lineHeight: 1.6, marginBottom: 2 }}>
                              {typeof b === 'object' ? JSON.stringify(b) : String(b || '')}
                            </li>
                          ))}
                        </ul>
                      )}
                      {slide.speaker_notes && (
                        <details style={{ marginTop: 8 }}>
                          <summary style={{ fontSize: 11, color: '#888', cursor: 'pointer' }}>Speaker Notes</summary>
                          <div style={{ fontSize: 11, color: '#555', lineHeight: 1.6, marginTop: 4, paddingLeft: 8, borderLeft: '2px solid #e0e0e0' }}>
                            {typeof slide.speaker_notes === 'object' ? JSON.stringify(slide.speaker_notes) : String(slide.speaker_notes || '')}
                          </div>
                        </details>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <div style={{ ...S.card, textAlign: 'center', padding: 60, color: '#aaa' }}>
              <div style={{ fontSize: 40, marginBottom: 12 }}>▪</div>
              <div style={{ fontSize: 13, fontWeight: 600 }}>Slides will appear here</div>
              <div style={{ fontSize: 11, marginTop: 4 }}>Fill out the form and click Generate</div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
export default Presentations;