import React, { useState, useEffect, useCallback, useRef } from 'react';
import { ACCENT, NAVY, BG, WHITE, BORDER, FONT, N8N, AUTH, api, S, Spinner } from '../../lib/gda';

var TABS = ['source','win-strategy','risks','tech-volume','gate-review','calendar'];
var TAB_LABELS = {'source':'Source Material','win-strategy':'Win Strategy','risks':'Proposal Risks','tech-volume':'Tech Volume','gate-review':'Gate Reviews','calendar':'Proposal Calendar'};

var GATES = [
  {phase:'Interest', questions:['Does this opportunity align with OUR strategic plan?','Do we have relevant Past Performance?','Have we completed work similar with this customer?','Who is the incumbent?','Can we Prime this work?','Number of months until RFP released.']},
  {phase:'Qualify', questions:['Has the BD Team verified the Past Performance approach?','Do we know the organization and how well?','What type of program is this?','Is this New Business or Follow-on work?','Where are the delivery location(s)?','DD254 requirements?','Can we do the majority of the work?']},
  {phase:'Pursue', questions:['What is the status of the Capture Plan?','What is the Government acquisition strategy?','Which Past Performances will you use?','Have you built your team yet?','Does your team fill ALL the gaps in the requirements?','What is the business case to BID / ROI / Risk to Lose?','What is the status of the Technical Solutioning?','Can we get to a winning price point?','Have you developed Differentiators, Win Themes and Ghost Themes?','Have you done our risk assessment?','Is the incumbent well liked by the customer?','What are the customer major pain points?']},
  {phase:'Solicitation', questions:['Has the BD Team verified the Technical approach?','Has the BD/Technical Team verified the Management approach?','Has the Capture/BD/Technical Team verified the Pricing approach?','What is the status of the Black Hat process?','Is the (d)RFP completely different from what we expected?','Does our designed solution still fit the work?','Do we have the right key personnel?','Has a proposal calendar been developed including color reviews?']}
];

var COLOR_TEAMS = [
  {name:'Pink Team',desc:'Annotated outline + compliance',color:'#EC4899'},
  {name:'Red Team',desc:'Full draft scored by evaluators',color:'#DC2626'},
  {name:'Gold Team',desc:'Executive review + final pricing',color:'#D97706'},
  {name:'White Glove',desc:'Final production QC',color:'#6B7280'}
];

var TECH_SECTIONS = [
  {id:'understanding',title:'Understanding of the Requirement',prompt:'Draft a section demonstrating deep understanding of the customer mission, challenges, and objectives.'},
  {id:'approach',title:'Technical Approach',prompt:'Draft a technical approach addressing SOW requirements with specific methodologies, tools, and innovations.'},
  {id:'management',title:'Management Approach',prompt:'Draft a management approach covering org structure, PM methodology, risk management, quality assurance, and comms.'},
  {id:'transition',title:'Transition Plan',prompt:'Draft a transition-in plan covering knowledge transfer, staffing ramp, systems access, and minimal disruption.'},
  {id:'staffing',title:'Staffing & Key Personnel',prompt:'Draft a staffing approach covering key personnel qualifications, retention strategy, surge capacity, and succession.'},
  {id:'past-perf',title:'Past Performance Narratives',prompt:'Draft past performance narratives demonstrating relevant, recent, and successful contract execution.'}
];

export default function ProposalFactoryPage() {
  var h = React.createElement;
  var _tab = useState('source'); var tab = _tab[0]; var setTab = _tab[1];
  var _plans = useState([]); var plans = _plans[0]; var setPlans = _plans[1];
  var _sel = useState(null); var selectedPlan = _sel[0]; var setSelectedPlan = _sel[1];
  var _pd = useState({}); var propData = _pd[0]; var setPropData = _pd[1];
  var _loading = useState(true); var loading = _loading[0]; var setLoading = _loading[1];
  var _aiLoading = useState(false); var aiLoading = _aiLoading[0]; var setAiLoading = _aiLoading[1];
  var _toast = useState(''); var toast = _toast[0]; var setToast = _toast[1];
  var _saving = useState(false); var saving = _saving[0]; var setSaving = _saving[1];
  var _srcText = useState(''); var srcText = _srcText[0]; var setSrcText = _srcText[1];
  var _docs = useState([]); var docs = _docs[0]; var setDocs = _docs[1];
  var _dragOver = useState(false); var dragOver = _dragOver[0]; var setDragOver = _dragOver[1];
  var fileRef = useRef(null);

  var showToast = function(msg) { setToast(msg); setTimeout(function() { setToast(''); }, 3000); };

  useEffect(function() {
    fetch('/api/gda-capture-plan', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'list', limit: 50 })
    }).then(function(r) { return r.json(); }).then(function(d) {
      var rows = d.plans || d.data || [];
      var mapped = rows.map(function(r) {
        var pd = typeof r.plan_data === 'object' ? r.plan_data : {};
        try { if (typeof r.plan_data === 'string') pd = JSON.parse(r.plan_data); } catch (e) {}
        return { id: r.id, name: pd.codename || r.opportunity || 'Untitled', agency: r.agency || pd.agency || '', stage: pd.stage || 'Go/No-Go', pwin: parseInt(pd.pwin) || 0, tcv: pd.total_contract_value || '0', plan_data: pd };
      });
      setPlans(mapped);
      if (mapped.length > 0) { setSelectedPlan(mapped[0]); loadPropData(mapped[0]); }
      setLoading(false);
    }).catch(function() { setLoading(false); });
  }, []);

  var loadPropData = function(plan) {
    var pd = plan.plan_data || {};
    var pf = pd.proposal_factory || { win_themes: [], ghost_themes: [], discriminators: [], risks: [], tech_sections: {}, gate_answers: {}, calendar: {} };
    setPropData(pf);
    setSrcText(pf.source_text || '');
    setDocs(pf.source_docs || []);
  };

  var selectPlan = function(plan) { setSelectedPlan(plan); loadPropData(plan); };

  var savePropData = function(updated) {
    if (!selectedPlan) return;
    setSaving(true);
    var dataToSave = updated || propData;
    dataToSave.source_text = srcText;
    dataToSave.source_docs = docs;
    var newPd = Object.assign({}, selectedPlan.plan_data, { proposal_factory: dataToSave });
    fetch('/api/gda-capture-plan', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'save', id: selectedPlan.id, plan_data: newPd })
    }).then(function() { setSaving(false); showToast('Saved'); }).catch(function() { setSaving(false); showToast('Save failed'); });
  };

  var getSourceContext = function() {
    var txt = (srcText || '').trim();
    var docsTxt = docs.map(function(d) { return '--- ' + d.name + ' ---\n' + (d.content || ''); }).join('\n\n');
    var all = (txt + '\n\n' + docsTxt).trim();
    return all ? '\n\nSOURCE MATERIAL (use this as primary input):\n' + all.substring(0, 12000) : '';
  };

  var getOppContext = function() {
    var pd = selectedPlan ? selectedPlan.plan_data || {} : {};
    return 'Opportunity: ' + (pd.codename || (selectedPlan || {}).name || '') +
      '\nAgency: ' + (pd.agency || (selectedPlan || {}).agency || '') +
      '\nValue: $' + (pd.total_contract_value || 'TBD') +
      '\nNAICS: ' + (pd.naics_code || pd.naics || 'TBD') +
      '\nVehicle: ' + (pd.idiq_vehicle || 'TBD') +
      '\nStage: ' + (pd.stage || 'TBD') +
      '\nPwin: ' + (pd.pwin || 'TBD') + '%' +
      '\nCompetitors: ' + (pd.known_competitors || pd.competitors || 'Unknown') +
      '\nIncumbent: ' + (pd.incumbent || 'Unknown');
  };

  var aiGenerate = function(prompt, field, subfield) {
    setAiLoading(true);
    var fullPrompt = 'You are a Shipley-certified proposal strategist for Envision Innovative Solutions (defense contractor: M&S, SETA, simulation, C4ISR) under Georgetown Defense Analytics.\n\nContext:\n' + getOppContext() + getSourceContext() + '\n\nTask: ' + prompt + '\n\nProvide actionable, specific content. Reference the actual opportunity and source material. Federal proposal best practices.';
    fetch('/api/gda-ai-chat', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ message: fullPrompt })
    }).then(function(r) { return r.json(); }).then(function(d) {
      var text = d.response || d.text || d.message || '';
      if (field && subfield) {
        var u = Object.assign({}, propData);
        if (!u[field]) u[field] = {};
        u[field][subfield] = text;
        setPropData(u); savePropData(u);
      } else if (field === 'win_themes' || field === 'ghost_themes' || field === 'discriminators') {
        var items = text.split('\n').filter(function(l) { return l.trim().length > 5; }).map(function(l) { return l.replace(/^[\d\-\*\.\)]+\s*/, '').trim(); });
        var u2 = Object.assign({}, propData); u2[field] = items; setPropData(u2); savePropData(u2);
      }
      setAiLoading(false); showToast('AI generation complete');
    }).catch(function(e) { setAiLoading(false); showToast('AI error: ' + e.message); });
  };

  var processFiles = function(fileList) {
    Array.from(fileList).forEach(function(file) {
      var reader = new FileReader();
      reader.onload = function(ev) {
        var content = ev.target.result || '';
        setDocs(function(prev) {
          return prev.concat([{ name: file.name, size: file.size, content: content.substring(0, 50000), added: new Date().toISOString() }]);
        });
      };
      reader.readAsText(file);
    });
  };

  var handleDrop = function(e) {
    e.preventDefault(); e.stopPropagation(); setDragOver(false);
    if (e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      processFiles(e.dataTransfer.files);
    }
  };

  var card = function(children) { return h('div', { style: { background: '#fff', border: '1px solid ' + BORDER, borderRadius: 8, padding: '16px 20px', marginBottom: 14 } }, children); };
  var secTitle = function(icon, text) { return h('div', { style: { fontSize: 15, fontWeight: 700, color: NAVY, marginBottom: 12, display: 'flex', alignItems: 'center', gap: 8 } }, icon + ' ' + text); };
  var aiBtn = function(label, onClick) { return h('button', { onClick: onClick, disabled: aiLoading, style: { padding: '6px 14px', background: '#1B2A4A', color: '#fff', border: 'none', borderRadius: 6, fontSize: 11, fontWeight: 600, cursor: 'pointer', opacity: aiLoading ? 0.5 : 1 } }, aiLoading ? 'Generating...' : label); };
  var saveBtn = function() { return h('button', { onClick: function() { savePropData(); }, disabled: saving, style: { padding: '8px 20px', background: ACCENT, color: '#fff', border: 'none', borderRadius: 6, fontSize: 12, fontWeight: 700, cursor: 'pointer' } }, saving ? 'Saving...' : 'Save'); };
  var listItem = function(text, color, borderColor, i, field, arr) {
    return h('div', { key: i, style: { padding: '10px 14px', background: color, borderLeft: '3px solid ' + borderColor, borderRadius: '0 6px 6px 0', marginBottom: 8, fontSize: 13, display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' } },
      h('span', { style: { flex: 1 } }, text),
      h('button', { onClick: function() { var u = Object.assign({}, propData); u[field] = arr.filter(function(_, j) { return j !== i; }); setPropData(u); }, style: { background: 'none', border: 'none', color: '#DC2626', cursor: 'pointer', fontSize: 14, fontWeight: 700 } }, '\u00D7')
    );
  };
  var addManual = function(field, label) {
    return h('button', { onClick: function() { var t = prompt('Enter ' + label + ':'); if (t) { var u = Object.assign({}, propData); u[field] = (u[field] || []).concat([t]); setPropData(u); } }, style: { padding: '6px 14px', border: '1px solid ' + BORDER, borderRadius: 6, fontSize: 11, fontWeight: 600, cursor: 'pointer', background: '#fff', color: NAVY } }, '+ Add Manually');
  };

  var renderSource = function() {
    return h('div', null,
      card(h('div', null,
        secTitle('\uD83D\uDCCE', 'Source Material'),
        h('div', { style: { fontSize: 12, color: '#6B7280', marginBottom: 16 } }, 'Paste or drag-and-drop RFP sections, SOW language, competitor intel, customer quotes, evaluation criteria \u2014 anything the AI should use when generating proposal content.'),
        h('div', {
          onDragOver: function(e) { e.preventDefault(); setDragOver(true); },
          onDragLeave: function() { setDragOver(false); },
          onDrop: handleDrop,
          style: { border: '2px dashed ' + (dragOver ? ACCENT : BORDER), borderRadius: 10, padding: '20px', textAlign: 'center', background: dragOver ? ACCENT + '08' : '#FAFBFC', transition: 'all 0.2s', marginBottom: 16 }
        },
          h('div', { style: { fontSize: 28, marginBottom: 6 } }, '\uD83D\uDCC1'),
          h('div', { style: { fontSize: 13, fontWeight: 600, color: NAVY, marginBottom: 4 } }, 'Drag & Drop Files Here'),
          h('div', { style: { fontSize: 11, color: '#9CA3AF', marginBottom: 10 } }, 'Supports .txt, .md, .csv, .doc, .pdf (text extraction)'),
          h('button', { onClick: function() { if (fileRef.current) fileRef.current.click(); }, style: { padding: '6px 16px', background: '#fff', border: '1px solid ' + BORDER, borderRadius: 6, fontSize: 11, fontWeight: 600, cursor: 'pointer', color: NAVY } }, 'Or Click to Browse'),
          h('input', { ref: fileRef, type: 'file', accept: '.txt,.md,.csv,.pdf,.doc,.docx', multiple: true, style: { display: 'none' }, onChange: function(e) { if (e.target.files) processFiles(e.target.files); } })
        ),
        docs.length > 0 && h('div', { style: { marginBottom: 16 } },
          h('div', { style: { fontSize: 11, fontWeight: 700, color: '#777', marginBottom: 8, textTransform: 'uppercase', letterSpacing: '0.4px' } }, 'UPLOADED DOCUMENTS (' + docs.length + ')'),
          docs.map(function(d, i) {
            return h('div', { key: i, style: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '8px 12px', background: '#F9FAFB', borderRadius: 6, marginBottom: 4, border: '1px solid #F3F4F6' } },
              h('div', { style: { display: 'flex', alignItems: 'center', gap: 8 } },
                h('span', { style: { fontSize: 14 } }, '\uD83D\uDCC4'),
                h('span', { style: { fontSize: 12, fontWeight: 600, color: NAVY } }, d.name)
              ),
              h('div', { style: { display: 'flex', gap: 8, alignItems: 'center' } },
                h('span', { style: { fontSize: 10, color: '#9CA3AF' } }, (d.content || '').length.toLocaleString() + ' chars'),
                h('button', { onClick: function() { setDocs(function(p) { return p.filter(function(_, j) { return j !== i; }); }); }, style: { background: 'none', border: 'none', color: '#DC2626', cursor: 'pointer', fontSize: 14, fontWeight: 700 } }, '\u00D7')
              )
            );
          })
        ),
        h('div', { style: { fontSize: 11, fontWeight: 700, color: '#777', marginBottom: 6, textTransform: 'uppercase', letterSpacing: '0.4px' } }, 'FREE TEXT / PASTE CONTENT'),
        h('textarea', { value: srcText, onChange: function(e) { setSrcText(e.target.value); }, placeholder: 'Paste RFP Section C, PWS, SOW, evaluation criteria, intel notes, competitor capability statements, customer feedback...', style: { width: '100%', minHeight: 200, padding: '12px', border: '1px solid ' + BORDER, borderRadius: 6, fontSize: 12, fontFamily: FONT, lineHeight: 1.6, resize: 'vertical', boxSizing: 'border-box' } }),
        srcText && h('div', { style: { fontSize: 11, color: '#9CA3AF', marginTop: 4 } }, srcText.length.toLocaleString() + ' characters'),
        h('div', { style: { display: 'flex', justifyContent: 'space-between', marginTop: 12 } },
          h('div', { style: { fontSize: 11, color: '#6B7280' } }, (srcText || docs.length > 0) ? '\u2705 AI generation will use this source material as context' : '\u26A0\uFE0F No source material loaded \u2014 AI will use capture plan data only'),
          h('div', { style: { display: 'flex', gap: 8 } },
            srcText && h('button', { onClick: function() { setSrcText(''); }, style: { padding: '6px 14px', border: '1px solid #FCA5A5', borderRadius: 6, fontSize: 11, color: '#DC2626', cursor: 'pointer', background: '#fff' } }, 'Clear Text'),
            saveBtn()
          )
        )
      ))
    );
  };

  var renderWinStrategy = function() {
    var themes = propData.win_themes || [];
    var ghosts = propData.ghost_themes || [];
    var discs = propData.discriminators || [];
    return h('div', null,
      card(h('div', null,
        secTitle('\uD83C\uDFAF', 'Win Themes'),
        h('div', { style: { fontSize: 12, color: '#6B7280', marginBottom: 12 } }, 'What makes Envision the best choice? Each theme maps to a customer hot button.'),
        themes.length > 0 ? themes.map(function(t, i) { return listItem(t, '#F0F7FF', '#32448A', i, 'win_themes', themes); }) : h('div', { style: { padding: 20, textAlign: 'center', color: '#9CA3AF', fontSize: 12 } }, 'No win themes yet.'),
        h('div', { style: { display: 'flex', gap: 8, marginTop: 12 } },
          aiBtn('\uD83E\uDD16 AI Generate Win Themes', function() { aiGenerate('Generate 5-7 specific win themes. Each should address a customer pain point and highlight Envision competitive advantage. Numbered list, one per line.', 'win_themes'); }),
          addManual('win_themes', 'a win theme')
        )
      )),
      card(h('div', null,
        secTitle('\uD83D\uDC7B', 'Ghost Themes'),
        h('div', { style: { fontSize: 12, color: '#6B7280', marginBottom: 12 } }, 'Competitor weaknesses to highlight without naming them.'),
        ghosts.length > 0 ? ghosts.map(function(g, i) { return listItem(g, '#FEF2F2', '#DC2626', i, 'ghost_themes', ghosts); }) : h('div', { style: { padding: 20, textAlign: 'center', color: '#9CA3AF', fontSize: 12 } }, 'No ghost themes yet.'),
        h('div', { style: { display: 'flex', gap: 8, marginTop: 12 } },
          aiBtn('\uD83E\uDD16 AI Generate Ghost Themes', function() { aiGenerate('Generate 4-6 ghost themes highlighting competitor weaknesses. Never name competitors directly. One per line.', 'ghost_themes'); }),
          addManual('ghost_themes', 'a ghost theme')
        )
      )),
      card(h('div', null,
        secTitle('\u2B50', 'Discriminators'),
        h('div', { style: { fontSize: 12, color: '#6B7280', marginBottom: 12 } }, 'What can ONLY Envision bring? Must be provable and not easily replicated.'),
        discs.length > 0 ? discs.map(function(d, i) { return listItem(d, '#F0FDF4', '#2F5C1F', i, 'discriminators', discs); }) : h('div', { style: { padding: 20, textAlign: 'center', color: '#9CA3AF', fontSize: 12 } }, 'No discriminators yet.'),
        h('div', { style: { display: 'flex', gap: 8, marginTop: 12 } },
          aiBtn('\uD83E\uDD16 AI Generate Discriminators', function() { aiGenerate('Generate 4-5 unique discriminators for Envision. Must be provable, not easily replicated, and relevant to evaluation criteria. One per line.', 'discriminators'); }),
          addManual('discriminators', 'a discriminator')
        )
      )),
      h('div', { style: { display: 'flex', justifyContent: 'flex-end', marginTop: 8 } }, saveBtn())
    );
  };

  var renderRisks = function() {
    var risks = propData.risks || [];
    return card(h('div', null,
      secTitle('\u26A0\uFE0F', 'Proposal-Level Risks'),
      risks.length > 0 ? h('table', { style: { width: '100%', borderCollapse: 'collapse', fontSize: 12 } },
        h('thead', null, h('tr', null, ['#', 'Category', 'Risk', 'Likelihood', 'Impact', 'Mitigation'].map(function(hdr) {
          return h('th', { key: hdr, style: { padding: '8px 10px', textAlign: 'left', fontSize: 10, fontWeight: 700, color: '#777', letterSpacing: '0.4px', textTransform: 'uppercase', borderBottom: '1px solid ' + BORDER, background: '#fafafa' } }, hdr);
        }))),
        h('tbody', null, risks.map(function(r, i) {
          var lc = r.likelihood === 'High' ? '#DC2626' : r.likelihood === 'Medium' ? '#B06D32' : '#2F5C1F';
          var ic = r.impact === 'High' ? '#DC2626' : r.impact === 'Medium' ? '#B06D32' : '#2F5C1F';
          return h('tr', { key: i },
            h('td', { style: { padding: '8px 10px', borderBottom: '1px solid #f0f0f0', fontWeight: 600 } }, i + 1),
            h('td', { style: { padding: '8px 10px', borderBottom: '1px solid #f0f0f0' } }, h('span', { style: { padding: '2px 8px', borderRadius: 10, fontSize: 10, fontWeight: 600, background: '#f4f5f7', color: '#555' } }, r.category || 'General')),
            h('td', { style: { padding: '8px 10px', borderBottom: '1px solid #f0f0f0', maxWidth: 250 } }, r.risk),
            h('td', { style: { padding: '8px 10px', borderBottom: '1px solid #f0f0f0', fontWeight: 600, color: lc } }, r.likelihood),
            h('td', { style: { padding: '8px 10px', borderBottom: '1px solid #f0f0f0', fontWeight: 600, color: ic } }, r.impact),
            h('td', { style: { padding: '8px 10px', borderBottom: '1px solid #f0f0f0', maxWidth: 250 } }, r.mitigation)
          );
        }))
      ) : h('div', { style: { padding: 20, textAlign: 'center', color: '#9CA3AF', fontSize: 12 } }, 'No risks. Use AI to generate.'),
      h('div', { style: { display: 'flex', gap: 8, marginTop: 12 } },
        aiBtn('\uD83E\uDD16 AI Generate Risks', function() {
          setAiLoading(true);
          var p = 'Generate 8-10 proposal risks. For each return EXACTLY: CATEGORY|RISK|LIKELIHOOD|IMPACT|MITIGATION on one line. Categories: Technical, Management, Cost, Schedule, Performance. Likelihood/Impact: High, Medium, or Low.';
          fetch('/api/gda-ai-chat', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ message: 'Context:\n' + getOppContext() + getSourceContext() + '\n\n' + p }) })
            .then(function(r) { return r.json(); }).then(function(d) {
              var text = d.response || d.text || '';
              var parsed = text.split('\n').filter(function(l) { return l.indexOf('|') > 0; }).map(function(l) { var p = l.replace(/^[\d\-\*\.]+\s*/, '').split('|'); return { category: (p[0] || '').trim(), risk: (p[1] || '').trim(), likelihood: (p[2] || 'Medium').trim(), impact: (p[3] || 'Medium').trim(), mitigation: (p[4] || '').trim() }; }).filter(function(r) { return r.risk.length > 5; });
              var u = Object.assign({}, propData, { risks: parsed }); setPropData(u); savePropData(u); setAiLoading(false); showToast(parsed.length + ' risks generated');
            }).catch(function() { setAiLoading(false); showToast('AI error'); });
        })
      )
    ));
  };

  var renderTechVolume = function() {
    var sections = propData.tech_sections || {};
    return h('div', null,
      TECH_SECTIONS.map(function(sec) {
        var content = sections[sec.id] || '';
        return card(h('div', { key: sec.id },
          h('div', { style: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: content ? 12 : 0 } },
            h('div', null,
              h('div', { style: { fontSize: 14, fontWeight: 700, color: NAVY } }, sec.title),
              h('div', { style: { fontSize: 11, color: '#9CA3AF', marginTop: 2 } }, content ? content.length + ' chars' : 'Not yet drafted')
            ),
            h('div', { style: { display: 'flex', gap: 8 } },
              aiBtn('\uD83E\uDD16 AI Draft', function() { aiGenerate(sec.prompt + ' Write 400-600 words of proposal-ready content. Formal language, action verbs, reference Envision capabilities.', 'tech_sections', sec.id); }),
              content && h('button', { onClick: function() { var u = Object.assign({}, propData); u.tech_sections = Object.assign({}, sections); delete u.tech_sections[sec.id]; setPropData(u); }, style: { padding: '6px 14px', border: '1px solid #FCA5A5', borderRadius: 6, fontSize: 11, color: '#DC2626', cursor: 'pointer', background: '#fff' } }, 'Clear')
            )
          ),
          content && h('textarea', { defaultValue: content, onBlur: function(e) { var u = Object.assign({}, propData); u.tech_sections = Object.assign({}, sections); u.tech_sections[sec.id] = e.target.value; setPropData(u); }, style: { width: '100%', minHeight: 200, padding: 12, border: '1px solid ' + BORDER, borderRadius: 6, fontSize: 12, fontFamily: 'Georgia, serif', lineHeight: 1.7, resize: 'vertical', boxSizing: 'border-box' } })
        ));
      }),
      h('div', { style: { display: 'flex', justifyContent: 'flex-end', gap: 8, marginTop: 8 } }, saveBtn())
    );
  };

  var renderGateReview = function() {
    var answers = propData.gate_answers || {};
    var totalQ = 0; var answeredQ = 0;
    GATES.forEach(function(g) { g.questions.forEach(function(q) { totalQ++; if (answers[g.phase + '_' + q]) answeredQ++; }); });
    var pct = totalQ > 0 ? Math.round(answeredQ / totalQ * 100) : 0;
    return h('div', null,
      card(h('div', { style: { display: 'flex', alignItems: 'center', gap: 20 } },
        h('div', { style: { width: 60, height: 60, borderRadius: '50%', background: pct >= 80 ? '#2F5C1F15' : pct >= 50 ? '#B06D3215' : '#DC262615', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 20, fontWeight: 700, color: pct >= 80 ? '#2F5C1F' : pct >= 50 ? '#B06D32' : '#DC2626' } }, pct + '%'),
        h('div', null,
          h('div', { style: { fontSize: 15, fontWeight: 700, color: NAVY } }, 'Gate Review Progress'),
          h('div', { style: { fontSize: 12, color: '#6B7280' } }, answeredQ + ' of ' + totalQ + ' questions answered')
        )
      )),
      GATES.map(function(gate) {
        var ct = gate.questions.filter(function(q) { return answers[gate.phase + '_' + q]; }).length;
        return card(h('div', { key: gate.phase },
          h('div', { style: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 } },
            h('div', { style: { fontSize: 14, fontWeight: 700, color: NAVY } }, gate.phase + ' Phase'),
            h('span', { style: { fontSize: 11, fontWeight: 600, padding: '2px 10px', borderRadius: 10, background: ct === gate.questions.length ? '#2F5C1F15' : '#B06D3215', color: ct === gate.questions.length ? '#2F5C1F' : '#B06D32' } }, ct + '/' + gate.questions.length)
          ),
          gate.questions.map(function(q, qi) {
            var key = gate.phase + '_' + q;
            return h('div', { key: qi, style: { marginBottom: 10, padding: '10px 14px', background: answers[key] ? '#F9FAFB' : '#fff', border: '1px solid ' + (answers[key] ? '#E5E7EB' : '#F3F4F6'), borderRadius: 6 } },
              h('div', { style: { fontSize: 12, fontWeight: 600, color: NAVY, marginBottom: 4 } }, q),
              h('textarea', { defaultValue: answers[key] || '', placeholder: 'Answer...', onBlur: function(e) { var u = Object.assign({}, propData); if (!u.gate_answers) u.gate_answers = {}; u.gate_answers[key] = e.target.value; setPropData(u); }, style: { width: '100%', minHeight: 50, padding: '8px 10px', border: '1px solid ' + BORDER, borderRadius: 4, fontSize: 12, resize: 'vertical', boxSizing: 'border-box' } })
            );
          })
        ));
      }),
      h('div', { style: { display: 'flex', justifyContent: 'flex-end', marginTop: 8 } }, saveBtn())
    );
  };

  var renderCalendar = function() {
    var cal = propData.calendar || {};
    var daysLeft = cal.proposal_due ? Math.max(0, Math.ceil((new Date(cal.proposal_due) - new Date()) / 86400000)) : null;
    return h('div', null,
      card(h('div', null,
        secTitle('\uD83D\uDCC5', 'Key Dates'),
        h('div', { style: { display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, marginBottom: 16 } },
          ['rfp_release', 'questions_due', 'proposal_due', 'award_expected'].map(function(field) {
            var labels = { rfp_release: 'RFP Release', questions_due: 'Questions Due', proposal_due: 'Proposal Due', award_expected: 'Expected Award' };
            return h('div', { key: field },
              h('div', { style: { fontSize: 11, fontWeight: 700, color: '#777', textTransform: 'uppercase', marginBottom: 4 } }, labels[field]),
              h('input', { type: 'date', defaultValue: cal[field] || '', onBlur: function(e) { var u = Object.assign({}, propData); if (!u.calendar) u.calendar = {}; u.calendar[field] = e.target.value; setPropData(u); }, style: { width: '100%', padding: '8px 10px', border: '1px solid ' + BORDER, borderRadius: 6, fontSize: 12, boxSizing: 'border-box' } })
            );
          })
        ),
        daysLeft !== null && h('div', { style: { padding: '12px 16px', background: '#1B2A4A', borderRadius: 8, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 12 } },
          h('span', { style: { fontSize: 28, fontWeight: 700, color: '#fff' } }, daysLeft),
          h('span', { style: { fontSize: 13, color: '#94A3B8' } }, 'days until submission')
        )
      )),
      card(h('div', null,
        secTitle('\uD83C\uDFA8', 'Color Team Reviews'),
        h('div', { style: { display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: 12 } },
          COLOR_TEAMS.map(function(ct) {
            var k = ct.name.toLowerCase().replace(' ', '_');
            var status = (cal[k] || {});
            return h('div', { key: ct.name, style: { border: '1px solid ' + BORDER, borderRadius: 8, padding: 14, borderTop: '4px solid ' + ct.color } },
              h('div', { style: { fontSize: 13, fontWeight: 700, color: NAVY, marginBottom: 4 } }, ct.name),
              h('div', { style: { fontSize: 11, color: '#6B7280', marginBottom: 8 } }, ct.desc),
              h('input', { type: 'date', defaultValue: status.date || '', onBlur: function(e) { var u = Object.assign({}, propData); if (!u.calendar) u.calendar = {}; if (!u.calendar[k]) u.calendar[k] = {}; u.calendar[k].date = e.target.value; setPropData(u); }, style: { width: '100%', padding: '6px 8px', border: '1px solid ' + BORDER, borderRadius: 4, fontSize: 11, marginBottom: 6, boxSizing: 'border-box' } }),
              h('select', { defaultValue: status.status || 'not-started', onChange: function(e) { var u = Object.assign({}, propData); if (!u.calendar) u.calendar = {}; if (!u.calendar[k]) u.calendar[k] = {}; u.calendar[k].status = e.target.value; setPropData(u); }, style: { width: '100%', padding: '6px 8px', border: '1px solid ' + BORDER, borderRadius: 4, fontSize: 11, boxSizing: 'border-box' } },
                h('option', { value: 'not-started' }, 'Not Started'),
                h('option', { value: 'scheduled' }, 'Scheduled'),
                h('option', { value: 'in-progress' }, 'In Progress'),
                h('option', { value: 'complete' }, 'Complete')
              )
            );
          })
        )
      )),
      h('div', { style: { display: 'flex', justifyContent: 'flex-end', marginTop: 8 } }, saveBtn())
    );
  };

  if (loading) return h('div', { style: { textAlign: 'center', padding: 40, color: '#aaa' } }, 'Loading capture plans...');

  return h('div', null,
    h('div', { style: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 } },
      h('div', null,
        h('div', { style: { fontSize: 20, fontWeight: 700, color: NAVY, marginBottom: 4 } }, 'Proposal Factory'),
        h('div', { style: { fontSize: 12, color: '#666' } }, 'AI-powered proposal workbench \u2014 drag in source material, generate win themes, tech volumes, and gate reviews')
      ),
      h('div', { style: { display: 'flex', alignItems: 'center', gap: 12 } },
        h('select', { value: selectedPlan ? selectedPlan.id : '', onChange: function(e) { var p = plans.find(function(x) { return String(x.id) === e.target.value; }); if (p) selectPlan(p); }, style: { padding: '8px 14px', border: '1px solid ' + BORDER, borderRadius: 6, fontSize: 12, minWidth: 280, fontWeight: 600 } },
          plans.map(function(p) { return h('option', { key: p.id, value: p.id }, p.name + ' (' + p.agency + ') \u2014 ' + p.stage); })
        ),
        selectedPlan && h('span', { style: { padding: '4px 12px', borderRadius: 10, fontSize: 11, fontWeight: 700, background: selectedPlan.pwin >= 50 ? '#2F5C1F15' : selectedPlan.pwin >= 25 ? '#B06D3215' : '#DC262615', color: selectedPlan.pwin >= 50 ? '#2F5C1F' : selectedPlan.pwin >= 25 ? '#B06D32' : '#DC2626' } }, selectedPlan.pwin + '% Pwin')
      )
    ),
    h('div', { style: { display: 'flex', gap: 4, marginBottom: 20 } },
      TABS.map(function(t) { return h('button', { key: t, onClick: function() { setTab(t); }, style: { padding: '10px 20px', borderRadius: 8, border: '1px solid ' + (tab === t ? ACCENT : BORDER), background: tab === t ? ACCENT : '#fff', color: tab === t ? '#fff' : NAVY, cursor: 'pointer', fontWeight: 700, fontSize: 12 } }, TAB_LABELS[t]); })
    ),
    (srcText || docs.length > 0) && tab !== 'source' && h('div', { style: { padding: '8px 14px', background: '#2F5C1F08', border: '1px solid #86EFAC', borderRadius: 6, marginBottom: 14, fontSize: 11, color: '#2F5C1F', display: 'flex', alignItems: 'center', gap: 6 } }, '\u2705 Source material loaded (' + ((srcText ? 1 : 0) + docs.length) + ' sources, ' + ((srcText || '').length + docs.reduce(function(a, d) { return a + (d.content || '').length; }, 0)).toLocaleString() + ' chars). AI will use this context.'),
    tab === 'source' ? renderSource() :
    tab === 'win-strategy' ? renderWinStrategy() :
    tab === 'risks' ? renderRisks() :
    tab === 'tech-volume' ? renderTechVolume() :
    tab === 'gate-review' ? renderGateReview() :
    tab === 'calendar' ? renderCalendar() : null,
    toast && h('div', { style: { position: 'fixed', bottom: 24, right: 24, background: '#1B2A4A', color: '#fff', padding: '10px 20px', borderRadius: 8, fontSize: 13, fontWeight: 600, zIndex: 9999, boxShadow: '0 4px 12px rgba(0,0,0,0.3)' } }, toast)
  );
}
