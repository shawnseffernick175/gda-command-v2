import React, { useState, useEffect } from 'react';

const N8N = '/api';
const AUTH = { 'Content-Type': 'application/json' };
const api = { post: async (p, b={}) => { const r = await fetch(N8N+'/'+p, {method:'POST',headers:AUTH,body:JSON.stringify(b)}); if(!r.ok) throw new Error(r.status); const t = await r.text(); return t.trim() ? JSON.parse(t) : {}; }};
const ACCENT='#D14A2A', NAVY='#1a2744', WHITE='#ffffff', BORDER='#e0e0e0', BG='#f5f5f5';
const S = { card:{background:WHITE,border:'1px solid '+BORDER,borderRadius:8,padding:'16px 20px',marginBottom:14}, cardTitle:{fontSize:13,fontWeight:700,color:NAVY,marginBottom:10}, btn:(v='primary',s=false)=>({padding:s?'5px 10px':'8px 16px',borderRadius:6,border:'none',cursor:'pointer',fontSize:s?11:12,fontWeight:600,background:v==='primary'?ACCENT:v==='green'?'#22a06b':v==='blue'?'#32448A':'#eee',color:v==='secondary'?NAVY:'#fff'}), badge:(c='gray')=>({display:'inline-block',padding:'2px 8px',borderRadius:10,fontSize:10,fontWeight:600,background:c==='green'?'#2F5C1F15':c==='red'?'#ffebe6':c==='orange'?'#fff3e0':c==='blue'?'#e6f0ff':'#f4f5f7',color:c==='green'?'#2F5C1F':c==='red'?'#bf2600':c==='orange'?'#B06D32':c==='blue'?'#32448A':'#555'}), th:{padding:'8px 12px',textAlign:'left',fontSize:10,fontWeight:700,color:'#777',letterSpacing:'0.4px',textTransform:'uppercase',borderBottom:'1px solid '+BORDER,background:'#fafafa'}, td:{padding:'9px 12px',borderBottom:'1px solid #f0f0f0',verticalAlign:'middle',fontSize:12}, input:{width:'100%',padding:'8px 10px',border:'1px solid '+BORDER,borderRadius:6,fontSize:12,outline:'none',boxSizing:'border-box'} };

const formatDollar = v => { const n=parseFloat(v)||0; if(n>=1e9) return '$'+(n/1e9).toFixed(1)+'B'; if(n>=1e6) return '$'+(n/1e6).toFixed(1)+'M'; return '$'+n.toLocaleString(); };

export default function IdiqOnRamp() {
  const [vehicles, setVehicles] = useState([]);
  const [ndaa, setNdaa] = useState([]);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState('vehicles');
  const [expanded, setExpanded] = useState(null);

  useEffect(() => {
    Promise.all([
      api.post('gda-vehicle-tracker', {auth_key:'gda-api-2026-f584dae2', action:'list'}).catch(()=>({vehicles:[]})),
      api.post('gda-ndaa-ingest', {auth_key:'gda-api-2026-f584dae2'}).catch(()=>({}))
    ]).then(([vRes, nRes]) => {
      setVehicles(vRes.vehicles || []);
      const provisions = (nRes.ndaa_summary || nRes);
      if (provisions.provisions) setNdaa(provisions.provisions);
      else if (provisions.key_provisions_for_gda) setNdaa(provisions.key_provisions_for_gda);
      setLoading(false);
    });
  }, []);

  const posColor = p => p==='On Contract'||p==='On-Ramped'?'green':p==='Pursuing'?'orange':'gray';

  if (loading) return React.createElement('div',{style:{textAlign:'center',padding:40,color:'#aaa'}},'Loading IDIQ & NDAA data...');

  const TabBtn = ({id,label}) => React.createElement('button',{onClick:()=>setTab(id),style:{padding:'6px 14px',borderRadius:6,border:'1px solid '+(tab===id?ACCENT:BORDER),background:tab===id?ACCENT:WHITE,color:tab===id?'#fff':'#555',fontSize:11,fontWeight:tab===id?600:400,cursor:'pointer',marginRight:6}},label);

  return React.createElement('div',null,
    React.createElement('div',{style:{fontSize:20,fontWeight:700,color:NAVY,marginBottom:4}},'IDIQ & NDAA Intel'),
    React.createElement('div',{style:{fontSize:12,color:'#666',marginBottom:18}},'Contract vehicles, on-ramp monitoring, and NDAA intelligence'),
    React.createElement('div',{style:{display:'flex',gap:6,marginBottom:16}},
      React.createElement(TabBtn,{id:'vehicles',label:'Contract Vehicles ('+vehicles.length+')'}),
      React.createElement(TabBtn,{id:'ndaa',label:'NDAA Provisions'}),
      React.createElement(TabBtn,{id:'onramp',label:'On-Ramp Watch'})
    ),
    tab==='vehicles' && React.createElement('div',{style:S.card},
      React.createElement('div',{style:S.cardTitle},'GDA Contract Vehicles'),
      React.createElement('table',{style:{width:'100%',borderCollapse:'collapse'}},
        React.createElement('thead',null,React.createElement('tr',null,
          ['Vehicle','Contract #','Agency','Ceiling','Set-Aside','Position','Prime/Sub','Notes'].map(h=>React.createElement('th',{key:h,style:S.th},h))
        )),
        React.createElement('tbody',null,vehicles.map((v,i)=>React.createElement('tr',{key:v.id||i,style:{cursor:'pointer',background:expanded===i?'#f8f4f0':'transparent'},onClick:()=>setExpanded(expanded===i?null:i)},
          React.createElement('td',{style:{...S.td,fontWeight:600,color:NAVY}},v.vehicle_name),
          React.createElement('td',{style:{...S.td,fontFamily:'monospace',fontSize:11}},v.contract_number),
          React.createElement('td',{style:S.td},v.agency),
          React.createElement('td',{style:{...S.td,fontWeight:600}},formatDollar(v.ceiling_value)),
          React.createElement('td',{style:S.td},v.set_aside||'Unrestricted'),
          React.createElement('td',{style:S.td},React.createElement('span',{style:S.badge(posColor(v.gda_position))},v.gda_position)),
          React.createElement('td',{style:S.td},v.prime_or_sub),
          React.createElement('td',{style:{...S.td,fontSize:11,color:'#666',maxWidth:200}},v.notes)
        )))
      ),
      vehicles.length===0 && React.createElement('div',{style:{textAlign:'center',padding:20,color:'#aaa'}},'No vehicles tracked yet')
    ),
    tab==='ndaa' && React.createElement('div',{style:S.card},
      React.createElement('div',{style:S.cardTitle},'NDAA FY2026 Key Provisions for GDA'),
      React.createElement('div',{style:{fontSize:11,color:'#666',marginBottom:12}},'Source: P.L. 119-60 | Impacts on GDA target agencies and NAICS codes'),
      ndaa.length>0 ? ndaa.map((p,i)=>React.createElement('div',{key:i,style:{padding:'10px 14px',background:i%2===0?'#fafafa':'#fff',borderRadius:6,marginBottom:4,border:'1px solid #f0f0f0'}},
        React.createElement('div',{style:{display:'flex',justifyContent:'space-between',alignItems:'center'}},
          React.createElement('div',{style:{fontWeight:600,fontSize:12,color:NAVY}},p.section||p.title),
          React.createElement('span',{style:S.badge(p.category==='strategic'?'red':p.category==='capability'?'blue':'gray')},p.category||'general')
        ),
        React.createElement('div',{style:{fontSize:12,color:'#444',marginTop:4}},p.title||''),
        React.createElement('div',{style:{fontSize:11,color:'#666',marginTop:4,fontStyle:'italic'}},p.impact||'')
      )) : React.createElement('div',{style:{color:'#aaa',textAlign:'center',padding:20}},'No NDAA data loaded')
    ),
    tab==='onramp' && React.createElement('div',{style:S.card},
      React.createElement('div',{style:S.cardTitle},'IDIQ On-Ramp Watch'),
      React.createElement('div',{style:{fontSize:12,color:'#666',marginBottom:14}},'FAR 16.5 requires IDIQs to consider on-ramp every 5 years. Monitor target vehicles for Open Season announcements.'),
      React.createElement('div',{style:{background:'#fff3e0',border:'1px solid #ffe0b2',borderRadius:8,padding:'14px 18px',marginBottom:14}},
        React.createElement('div',{style:{fontWeight:700,fontSize:12,color:'#B06D32',marginBottom:6}},'What is an IDIQ On-Ramp?'),
        React.createElement('div',{style:{fontSize:12,color:'#555',lineHeight:1.6}},'The government reopens existing Multi-Award IDIQs to add new contractors. Triggers: FAR 16.5 5-year rule, underperforming incumbents, SB graduation gaps, technology evolution. Being on-ramped means same Master Contract terms + bid all future task orders. This is the white whale of acquisition.')
      ),
      vehicles.filter(v=>v.on_ramp_eligible).length>0 ?
        vehicles.filter(v=>v.on_ramp_eligible).map((v,i)=>React.createElement('div',{key:i,style:{padding:12,background:'#fff',border:'1px solid '+BORDER,borderRadius:8,marginBottom:8}},
          React.createElement('div',{style:{fontWeight:600,color:NAVY}},v.vehicle_name),
          React.createElement('div',{style:{fontSize:11,color:'#666',marginTop:4}},'On-ramp window: '+(v.on_ramp_window||'TBD')),
          React.createElement('div',{style:{fontSize:11,color:ACCENT,marginTop:4}},'Action required: Monitor SAM.gov for Open Season notice')
        ))
      : React.createElement('div',{style:{textAlign:'center',padding:20,color:'#aaa'}},'No on-ramp eligible vehicles detected. Monitoring SAM.gov daily.')
    )
  );
}
