import React, { useState, useEffect, useCallback, useRef, useMemo } from 'react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, LineChart, Line, AreaChart, Area, RadarChart, Radar, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Legend, CartesianGrid, ScatterChart, Scatter, ReferenceLine } from 'recharts';
import { ACCENT, NAVY, BG, WHITE, BORDER, FONT, N8N, AUTH, api, S, css, gdaNav, NAV_ITEMS, Spinner, Empty, Alert, PageHeader } from '../../lib/gda';
function SitrepTrends() {
  const today = new Date();
  const thirtyAgo = new Date(today - 30*24*60*60*1000);
  const fmtDate = (d) => d.toISOString().split('T')[0];

  const [startDate, setStartDate] = useState(fmtDate(thirtyAgo));
  const [endDate, setEndDate] = useState(fmtDate(today));
  const [chartType, setChartType] = useState('Defensive Sentiment');
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const CHART_TYPES = ['Defensive Sentiment','Threats & Opportunities'];

  const load = async () => {
    setLoading(true); setError('');
    try {
      const d = await api.post('gda-trends', {action:'query', start_date:startDate, end_date:endDate});
      const rows = d && (d.data || d.rows || d.trends || d.results || []);
      // Normalize to [{date, sentiment, threats, opportunities, sitrep_count, avg_threat_level}]
      const byDate = {};
      (Array.isArray(rows)?rows:[]).forEach(r => {
        const dt = r.date || r.created_at || '';
        if (!dt) return;
        if (!byDate[dt]) byDate[dt] = {date:dt, sentiment:0, threats:0, opportunities:0, sitrep_count:0, avg_threat_level:0};
        const mn = (r.metric_name||'').toLowerCase();
        const mv = parseFloat(r.metric_value||r.value||0);
        if (mn.includes('sentiment')) byDate[dt].sentiment = mv;
        else if (mn.includes('threat') && mn.includes('avg')) byDate[dt].avg_threat_level = mv;
        else if (mn.includes('threat')) byDate[dt].threats += mv;
        else if (mn.includes('opportunit') || mn.includes('active_opps')) byDate[dt].opportunities += mv;
        else if (mn.includes('sitrep')) byDate[dt].sitrep_count += mv;
        // If row already has all fields (flat shape)
        if (r.sentiment !== undefined) byDate[dt].sentiment = parseFloat(r.sentiment)||0;
        if (r.threats !== undefined) byDate[dt].threats = parseFloat(r.threats)||0;
        if (r.opportunities !== undefined) byDate[dt].opportunities = parseFloat(r.opportunities)||0;
        if (r.sitrep_count !== undefined) byDate[dt].sitrep_count = parseFloat(r.sitrep_count)||0;
        if (r.avg_threat_level !== undefined) byDate[dt].avg_threat_level = parseFloat(r.avg_threat_level)||0;
      });
      const sorted = Object.values(byDate).sort((a,b)=>a.date>b.date?1:-1);
      setData(sorted);
    } catch(e) { setError('Failed to load trends: '+e.message); setData([]); }
    setLoading(false);
  };

  useEffect(() => { load(); }, []);

  const totalSitreps = data.reduce((s,r)=>s+(r.sitrep_count||0),0);
  const avgThreat = data.length ? (data.reduce((s,r)=>s+(r.avg_threat_level||0),0)/data.length).toFixed(1) : 0;
  const totalOpps = data.reduce((s,r)=>s+(r.opportunities||0),0);
  const totalThreats = data.reduce((s,r)=>s+(r.threats||0),0);

  const chartData = data.map(r => ({
    date: r.date ? r.date.substring(5) : '', // MM-DD
    sentiment: r.sentiment||0,
    threats: r.threats||0,
    opportunities: r.opportunities||0 }));

  const threatColor = parseFloat(avgThreat) > 3 ? '#DC2626' : '#D14A2A';

  return (
    <div>
      <div style={{marginBottom:20}}>
        
        <div style={{fontSize:13,color:'#6B7280',marginTop:4}}>Visualize changes in key intelligence metrics over time</div>
      </div>

      {/* Controls */}
      <div style={{background:'#fff',border:'1px solid #E8ECF1',borderRadius:10,padding:16,marginBottom:16,display:'flex',gap:12,flexWrap:'wrap',alignItems:'flex-end'}}>
        <div>
          <div style={{fontSize:11,fontWeight:600,color:'#1B2A4A',marginBottom:4}}>Start Date</div>
          <input type="date" value={startDate} onChange={e=>setStartDate(e.target.value)} style={{padding:'8px 12px',border:'1px solid #E8ECF1',borderRadius:6,fontSize:13,color:'#1B2A4A'}} />
        </div>
        <div>
          <div style={{fontSize:11,fontWeight:600,color:'#1B2A4A',marginBottom:4}}>End Date</div>
          <input type="date" value={endDate} onChange={e=>setEndDate(e.target.value)} style={{padding:'8px 12px',border:'1px solid #E8ECF1',borderRadius:6,fontSize:13,color:'#1B2A4A'}} />
        </div>
        <div>
          <div style={{fontSize:11,fontWeight:600,color:'#1B2A4A',marginBottom:4}}>Chart Type</div>
          <select value={chartType} onChange={e=>setChartType(e.target.value)} style={{padding:'8px 12px',border:'1px solid #E8ECF1',borderRadius:6,fontSize:13,color:'#1B2A4A',background:'#fff'}}>
            {CHART_TYPES.map(t=><option key={t} value={t}>{t}</option>)}
          </select>
        </div>
        <button onClick={load} disabled={loading} style={{padding:'8px 20px',background:'#C65D21',color:'#fff',border:'none',borderRadius:6,fontSize:13,fontWeight:600,cursor:'pointer',opacity:loading?0.7:1,alignSelf:'flex-end'}}>{loading?'Loading...':'Refresh'}</button>
      </div>

      {error && <div style={{background:'#FEF2F2',border:'1px solid #FCA5A5',borderRadius:8,padding:12,marginBottom:12,color:'#991B1B',fontSize:13}}>{error}</div>}

      {/* KPI Cards */}
      <div style={{display:'grid',gridTemplateColumns:'repeat(3,1fr)',gap:12,marginBottom:16}}>
        <div style={{background:'#fff',border:'1px solid #E8ECF1',borderRadius:10,padding:16,textAlign:'center'}}>
          <div style={{fontSize:32,fontWeight:700,color:'#1B2A4A'}}>{String(Math.round(totalSitreps))}</div>
          <div style={{fontSize:12,fontWeight:600,color:'#6B7280',marginTop:4}}>TOTAL SITREPS</div>
        </div>
        <div style={{background:'#fff',border:'1px solid #E8ECF1',borderRadius:10,padding:16,textAlign:'center'}}>
          <div style={{fontSize:32,fontWeight:700,color:threatColor}}>{String(avgThreat)}</div>
          <div style={{fontSize:12,fontWeight:600,color:'#6B7280',marginTop:4}}>AVG THREAT LEVEL</div>
        </div>
        <div style={{background:'#fff',border:'1px solid #E8ECF1',borderRadius:10,padding:16,textAlign:'center'}}>
          <div style={{fontSize:32,fontWeight:700,color:'#2F5C1F'}}>{String(Math.round(totalOpps))}</div>
          <div style={{fontSize:12,fontWeight:600,color:'#6B7280',marginTop:4}}>TOTAL OPPORTUNITIES FOUND</div>
        </div>
      </div>

      {/* Chart + Summary */}
      <div style={{display:'grid',gridTemplateColumns:'2fr 1fr',gap:16,marginBottom:16,alignItems:'start'}}>
        <div style={{background:'#fff',border:'1px solid #E8ECF1',borderRadius:10,padding:16}}>
          <div style={{fontSize:14,fontWeight:700,color:'#1B2A4A',marginBottom:16}}>{chartType}</div>
          {loading && <div style={{height:250,display:'flex',alignItems:'center',justifyContent:'center',color:'#9CA3AF'}}><Spinner /></div>}
          {!loading && chartData.length===0 && <div style={{height:250,display:'flex',alignItems:'center',justifyContent:'center',color:'#9CA3AF',fontSize:13}}>No data for selected range</div>}
          {!loading && chartData.length>0 && (
            <ResponsiveContainer width="100%" height={250}>
              {chartType==='Defensive Sentiment' ? (
                <LineChart data={chartData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#F0F0F0" />
                  <XAxis dataKey="date" tick={{fontSize:10,fill:'#9CA3AF'}} />
                  <YAxis domain={[0,5]} tick={{fontSize:10,fill:'#9CA3AF'}} />
                  <Tooltip contentStyle={{fontSize:12,borderRadius:8,border:'1px solid #E8ECF1'}} />
                  <Line type="monotone" dataKey="sentiment" stroke="#D14A2A" strokeWidth={2} dot={false} name="Sentiment Score" />
                </LineChart>
              ) : (
                <BarChart data={chartData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#F0F0F0" />
                  <XAxis dataKey="date" tick={{fontSize:10,fill:'#9CA3AF'}} />
                  <YAxis tick={{fontSize:10,fill:'#9CA3AF'}} />
                  <Tooltip contentStyle={{fontSize:12,borderRadius:8,border:'1px solid #E8ECF1'}} />
                  <Legend wrapperStyle={{fontSize:11}} />
                  <Bar dataKey="threats" fill="#DC2626" name="Threats" stackId="a" />
                  <Bar dataKey="opportunities" fill="#2F5C1F" name="Opportunities" stackId="a" />
                </BarChart>
              )}
            </ResponsiveContainer>
          )}
        </div>
        <div style={{background:'#fff',border:'1px solid #E8ECF1',borderRadius:10,padding:16}}>
          <div style={{fontSize:14,fontWeight:700,color:'#1B2A4A',marginBottom:16}}>Summary</div>
          {[
            {label:'SITREPs in Range', val:Math.round(totalSitreps), color:'#1B2A4A'},
            {label:'Avg Threat Level', val:avgThreat, color:threatColor},
            {label:'Total Opportunities', val:Math.round(totalOpps), color:'#2F5C1F'},
            {label:'Total Threats Found', val:Math.round(totalThreats), color:'#DC2626'},
          ].map((row,i)=>(
            <div key={i} style={{display:'flex',justifyContent:'space-between',padding:'8px 0',borderBottom:'1px solid #F5F5F5',fontSize:13}}>
              <span style={{color:'#6B7280'}}>{row.label}</span>
              <span style={{fontWeight:700,color:row.color}}>{String(row.val)}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
export default SitrepTrends;