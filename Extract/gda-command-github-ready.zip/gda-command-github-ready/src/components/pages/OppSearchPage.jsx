import React, { useState, useEffect, useCallback, useRef, useMemo } from 'react';
import { ACCENT, NAVY, BG, WHITE, BORDER, FONT, N8N, AUTH, api, S, css, gdaNav, NAV_ITEMS, Spinner, Empty, Alert, PageHeader } from '../../lib/gda';
function OppSearch() {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState(null);
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState({});
  const [error, setError] = useState('');

  const search = async () => {
    if (!query.trim()) { setError('Enter a search term (e.g., Fort Bragg, SOCOM, USASOC, cybersecurity)'); return; }
    setError(''); setLoading(true); setResults(null);
    try {
      const d = await api.post('gda-opp-search', {query: query.trim()});
      setResults(d || {no_results: true});
    } catch(e) { setError('Search failed: ' + e.message); }
    setLoading(false);
  };

  const saveOpp = async (prog, agency) => {
    const key = (prog.title || '') + agency;
    setSaving(p => ({...p, [key]: true}));
    try {
      await api.post('gda-save-opp', {action: 'save', opportunity: {...prog, agency, source: 'opp-search'}});
      setSaving(p => ({...p, [key]: 'done'}));
    } catch(e) { setSaving(p => ({...p, [key]: 'error'})); }
  };

  return (
    <div>
      <PageHeader title="Opportunity Search" sub="Search federal opportunities across SAM.gov, GovTribe, GovWin, and the web. Type a location, agency, keyword, or solicitation number." />
      <div style={S.card}>
        <div style={{display:'flex',gap:10,marginBottom:16}}>
          <input style={{...S.input,flex:1,fontSize:14,padding:'12px 16px'}} placeholder="Search: Fort Bragg, SOCOM, cybersecurity, NAICS 541330, W15QKN..." value={query} onChange={e=>setQuery(e.target.value)} onKeyDown={e=>{if(e.key==='Enter')search();}} />
          <button style={{...S.btn(),padding:'12px 28px',fontSize:14,whiteSpace:'nowrap'}} onClick={search} disabled={loading}>
            {loading ? 'Searching...' : 'Search'}
          </button>
        </div>
        {error && <Alert type="error" msg={error} />}
      </div>
      {loading && <div style={{textAlign:'center',padding:30,color:'#6B7280'}}><Spinner /> Searching opportunities...</div>}
      {results && results.no_results && (
        <div style={{...S.card,textAlign:'center',padding:30}}>
          <div style={{fontSize:16,fontWeight:700,color:'#6B7280',marginBottom:8}}>No results for "{results.search_query || query}"</div>
          <div style={{fontSize:12,color:'#9CA3AF'}}>Try different keywords: agency name, location, NAICS code, program name, or solicitation number</div>
        </div>
      )}
      {results && !results.no_results && (
        <div>
          <div style={{...S.card,display:'flex',gap:16,flexWrap:'wrap',marginBottom:8}}>
            <div style={{fontSize:14,fontWeight:700,color:NAVY}}>Found: {results.total_programs} program{results.total_programs!==1?'s':''} across {results.total_agencies} agenc{results.total_agencies!==1?'ies':'y'}</div>
            <div style={{fontSize:12,color:'#6B7280'}}>Query: "{results.search_query}"</div>
          </div>
          {results.departments && results.departments.map((dept,di) => (
            <div key={di} style={{marginBottom:16}}>
              <div style={{fontSize:13,fontWeight:700,color:ACCENT,padding:'8px 0',borderBottom:'2px solid '+ACCENT+'33'}}>{dept.dept}</div>
              {dept.agencies && dept.agencies.map((ag,ai) => (
                <div key={ai} style={{marginLeft:8}}>
                  <div style={{fontSize:12,fontWeight:600,color:NAVY,padding:'6px 0'}}>{ag.agency} ({ag.program_count} match{ag.program_count!==1?'es':''})</div>
                  {ag.programs && ag.programs.map((prog,pi) => (
                    <div key={pi} style={{...S.card,marginLeft:8,marginBottom:6,padding:'10px 14px'}}>
                      <div style={{display:'flex',justifyContent:'space-between',alignItems:'flex-start',gap:12}}>
                        <div style={{flex:1}}>
                          <div style={{fontSize:13,fontWeight:700,color:NAVY,marginBottom:4}}>{prog.title || 'Untitled'}</div>
                          {prog.so_what && <div style={{fontSize:11,color:'#6B7280',marginBottom:4}}>{prog.so_what}</div>}
                          <div style={{display:'flex',gap:8,flexWrap:'wrap',fontSize:10}}>
                            {prog.solicitation && <span style={{background:'#EFF6FF',color:'#32448A',padding:'2px 8px',borderRadius:4,fontWeight:600}}>{prog.solicitation}</span>}
                            {prog.primary_fit && <span style={{background:'#2F5C1F12',color:'#2F5C1F',padding:'2px 8px',borderRadius:4}}>{prog.primary_fit}</span>}
                            {prog.source && <span style={{background:'#F8FAFC',color:'#6B7280',padding:'2px 8px',borderRadius:4}}>{prog.source}</span>}
                          </div>
                        </div>
                        <button onClick={()=>saveOpp(prog,ag.agency)} disabled={saving[(prog.title||'')+ag.agency]==='done'} style={{...S.btn(saving[(prog.title||'')+ag.agency]==='done'?'secondary':undefined),fontSize:11,padding:'6px 14px',whiteSpace:'nowrap'}}>
                          {saving[(prog.title||'')+ag.agency]==='done'?'Saved':saving[(prog.title||'')+ag.agency]===true?'Saving...':'+ Save to Opportunities'}
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              ))}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
export default OppSearch;