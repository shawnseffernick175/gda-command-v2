import React, { useState, useEffect, useCallback, useRef, useMemo } from 'react';
import { ACCENT, NAVY, BG, WHITE, BORDER, FONT, N8N, AUTH, api, S, css, gdaNav, NAV_ITEMS, Spinner, Empty, Alert, PageHeader, formatDollar, SourceTag, GDAKpiBar , saveAction, ActionHistory } from '../../lib/gda';
import SitrepTrends from './SitrepTrendsPage';

function DailySitrep(){
  var _opps=useState([]);var opps=_opps[0];var setOpps=_opps[1];
  var _risks=useState([]);var risks=_risks[0];var setRisks=_risks[1];
  var _aiSections=useState(null);var aiSections=_aiSections[0];var setAiSections=_aiSections[1];
  var _loading=useState(true);var loading=_loading[0];var setLoading=_loading[1];
  var _genTime=useState(null);var genTime=_genTime[0];var setGenTime=_genTime[1];
  var _openSec=useState({});var openSec=_openSec[0];var setOpenSec=_openSec[1];
  var _sitrepStatus=useState(function(){
    try{var last=localStorage.getItem('gda_sitrep_ack');if(last&&(Date.now()-parseInt(last))<86400000)return 'approved';}catch(e){}
    return 'loading';
  });var sitrepStatus=_sitrepStatus[0];var setSitrepStatus=_sitrepStatus[1];
  var _sitrepApprovedAt=useState(null);var sitrepApprovedAt=_sitrepApprovedAt[0];var setSitrepApprovedAt=_sitrepApprovedAt[1];
  var toggle=function(k){setOpenSec(function(p){var n=Object.assign({},p);n[k]=!p[k];return n;});};
  var nav=function(page){if(window._gdaNavigate)window._gdaNavigate(page);};

  var today=new Date().toLocaleDateString('en-US',{weekday:'long',year:'numeric',month:'long',day:'numeric'});

  function loadAll(){
    setLoading(true);setAiSections(null);
    Promise.all([
      api.post('gda-opp-tracker',{}).catch(function(){return {};}),
      api.post('gda-risk',{action:'list'}).catch(function(){return {};}),
      api.post('gda-dashboard-mega',{}).catch(function(){return null;})
    ]).then(function(results){
      var oppData=results[0];
      var items=[];
      if(oppData&&oppData.opportunities)items=oppData.opportunities;
      else if(oppData&&Array.isArray(oppData.departments)){oppData.departments.forEach(function(d){(d.agencies||[]).forEach(function(a){(a.programs||[]).forEach(function(p){items.push(p);});});});}
      else if(Array.isArray(oppData))items=oppData;
      setOpps(items);
      var riskItems=(results[1]&&results[1].data)||[];if(!Array.isArray(riskItems))riskItems=[];
      setRisks(riskItems);
      // gda-trade-control removed

      // Check if gda-daily-sitrep returned usable section data
      var sitrepData=results[2];
      if(sitrepData){
        var sd=(sitrepData&&sitrepData.sitrep)?sitrepData.sitrep:sitrepData;
        if(sd.world_news||sd.news||sd.top_news||sd.headlines||sd.market_signals||sd.market||sd.markets||sd.govt_intel||sd.government_intel||sd.gov_intel||sd.acquisition_news||sd.acquisitions||sd.contract_news||sd.exec_summary||sd.executive_summary||sd.bluf||sd.summary){
          var esFb={revenue_status:'yellow',key_development:(sd.bluf&&sd.bluf[0])||sd.summary||'See details below.',primary_risk:(sd.critical_actions&&sd.critical_actions[0])||'Review risk register.',pipeline_health:(sd.pipeline_status&&sd.pipeline_status.summary)||formatDollar(items.reduce(function(s,o){return s+(parseFloat(o.estimated_value)||0);},0))+' across '+items.length+' opps',decision_required:sd.decision_required||false,presidents_takeaway:(sd.bluf&&sd.bluf.join(' '))||sd.key_findings||sd.summary||'Review opportunities and upcoming deadlines.'};
          // Build market signals from strategic_landscape + defensive_watch
          var mktSigs = sd.market_signals || sd.market || [];
          if(mktSigs.length===0){
            if(sd.strategic_landscape){
              if(sd.strategic_landscape.doge_watch) mktSigs.push({indicator:'Budget & DOGE Watch',status:'yellow',update:sd.strategic_landscape.doge_watch,takeaway:'Monitor spending shifts.',source:sd.command_control&&sd.command_control.source||null});
              if(sd.strategic_landscape.indopacom) mktSigs.push({indicator:'INDOPACOM Posture',status:'green',update:sd.strategic_landscape.indopacom,takeaway:'Position for Pacific requirements.'});
            }
            if(sd.defensive_watch){
              if(sd.defensive_watch.market_pressure) mktSigs.push({indicator:'Market Pressure',status:'red',update:sd.defensive_watch.market_pressure,takeaway:'Differentiate capabilities.'});
              if(sd.defensive_watch.incumbency_threat) mktSigs.push({indicator:'Incumbency Threat',status:'red',update:sd.defensive_watch.incumbency_threat,takeaway:'Displace with next-gen solutions.'});
            }
          }
          // Build govt intel from department_coverage
          var govI = sd.govt_intel || sd.government_intel || {dod:[],ic:[],dhs:[]};
          if((!govI.dod||govI.dod.length===0) && sd.department_coverage){
            govI = {dod:(sd.department_coverage.active_departments||[]).map(function(d){return {topic:d,status:'green',update:'Active coverage',takeaway:'Continue monitoring'};}),ic:[],dhs:[],gaps:sd.department_coverage.gaps||[],recommendation:sd.department_coverage.recommendation||''};
          }
          // Build acquisition news from recommendations + critical_actions
          var acqNews = sd.acquisition_news || sd.acquisitions || [];
          if(acqNews.length===0){
            if(sd.recommendations) acqNews = sd.recommendations.map(function(r){return {item:r.action,status:r.deadline&&new Date(r.deadline)<new Date()?'red':'yellow',update:r.why||'',takeaway:'Owner: '+(r.owner||'TBD')+' | Due: '+(r.deadline||'TBD'),source:sd.command_control&&sd.command_control.source||null};});
            if(sd.critical_actions && acqNews.length===0) acqNews = sd.critical_actions.map(function(a){return {item:a,status:'red',update:'Critical action required',takeaway:'Execute immediately'};});
          }
          // Store html_body for full report view
          var htmlBody = (sitrepData&&sitrepData.html_body)||(sd&&sd.html_body)||null;
          setAiSections({
            exec_summary:sd.exec_summary||sd.executive_summary||esFb,
            world_news:(sd.world_news||sd.news||(sd.top_news||sd.headlines||[]).map(function(n){return {topic:n.title||n.topic||'News',status:n.status||'yellow',summary:n.summary||'',why_you_care:n.why_you_care||n.summary||'',source:n.url||n.source||''};})),
            market_signals:mktSigs,
            govt_intel:govI,
            acquisition_news:acqNews,
            threat_matrix:sd.threat_opportunity_matrix||[],
            pipeline_status:sd.pipeline_status||null,
            html_body:htmlBody
          });
          setGenTime(new Date().toLocaleString());
          saveAction("sitrep", "generate", "SITREP " + new Date().toLocaleDateString(), {}, sd);
          setSitrepStatus('draft');
          setLoading(false);
          return;
        }
      }

      // Build AI prompt with real data
      var totalVal=items.reduce(function(s,o){return s+(parseFloat(o.estimated_value)||0);},0);
      var stageCounts={};items.forEach(function(o){var st=o.stage||'Identified';stageCounts[st]=(stageCounts[st]||0)+1;});
      var topRisk=riskItems.sort(function(a,b){var o={CRITICAL:0,HIGH:1,MEDIUM:2,LOW:3};return(o[(a.severity||'').toUpperCase()]||4)-(o[(b.severity||'').toUpperCase()]||4);})[0];
      var urgent=items.filter(function(o){var d=new Date(o.response_deadline);return d>new Date()&&d<new Date(Date.now()+30*86400000);});

      var prompt='You are a defense intelligence analyst preparing the President\'s Daily Brief for Envision Innovative Solutions (EIS), a defense IT contractor targeting SOCOM, TRADOC, Army Futures Command, INSCOM, CYBERCOM, DISA, INDOPACOM.\n\nToday is '+today+'.\n\nPIPELINE DATA (REAL):\n- '+items.length+' active opportunities worth '+formatDollar(totalVal)+'\n- Stage distribution: '+JSON.stringify(stageCounts)+'\n- '+urgent.length+' bids due in 30 days\n- Top risk: '+(topRisk?topRisk.title+' ('+topRisk.severity+')':'None')+'\n\nGenerate a JSON object with these sections. Use CURRENT real-world events as of '+today+'. Return ONLY valid JSON, no markdown.\n\n{\n  "exec_summary": {\n    "revenue_status": "green|yellow|red",\n    "key_development": "...",\n    "primary_risk": "...",\n    "pipeline_health": "...",\n    "decision_required": true/false,\n    "presidents_takeaway": "..."\n  },\n  "world_news": [{"topic":"...","status":"green|yellow|red","summary":"...","why_you_care":"...","source":"..."}],\n  "market_signals": [{"indicator":"...","status":"green|yellow|red","update":"...","takeaway":"..."}],\n  "govt_intel": {"dod":[{"topic":"...","status":"green|yellow|red","update":"...","takeaway":"..."}],"ic":[...],"dhs":[...]},\n  "acquisition_news": [{"item":"...","status":"green|yellow|red","update":"...","takeaway":"..."}]\n}';

      api.post('gda-chat-v2',{ message:prompt,session_id:'sitrep_'+Date.now()})
        .then(function(r){
          var text=r.response||r.output||r.Summary||r.summary||'';
          try{
            var jsonMatch=text.match(/\{[\s\S]*\}/);
            if(jsonMatch)setAiSections(JSON.parse(jsonMatch[0]));
            else setAiSections({exec_summary:{revenue_status:'yellow',key_development:'AI analysis pending.',primary_risk:'Check risk register.',pipeline_health:formatDollar(totalVal)+' across '+items.length+' opps',decision_required:false,presidents_takeaway:'Review opportunities and upcoming deadlines.'},world_news:[{topic:'AI Analysis Pending',status:'yellow',summary:'The AI briefing could not generate structured data. Click Refresh to retry.',why_you_care:'Retry or check back later.'}],market_signals:[{indicator:'Pending',status:'yellow',update:'AI analysis did not return structured market data.',takeaway:'Click Refresh SITREP to regenerate.'}],govt_intel:{dod:[{topic:'Pending',status:'yellow',update:'AI analysis did not return structured government intel.',takeaway:'Click Refresh to retry.'}],ic:[],dhs:[]},acquisition_news:[{item:'Pending',status:'yellow',update:'AI analysis did not return structured acquisition data.',takeaway:'Click Refresh SITREP to regenerate.'}]});
          }catch(e){setAiSections({exec_summary:{revenue_status:'yellow',key_development:text.substring(0,200),primary_risk:topRisk?topRisk.title:'None',pipeline_health:formatDollar(totalVal),decision_required:false,presidents_takeaway:'See full analysis above.'},world_news:[{topic:'Parse Error',status:'yellow',summary:'AI returned data but it could not be parsed. Click Refresh to retry.',why_you_care:'Click Refresh to retry.'}],market_signals:[{indicator:'Unavailable',status:'yellow',update:'Could not parse AI response.',takeaway:'Refresh to retry.'}],govt_intel:{dod:[{topic:'Unavailable',status:'yellow',update:'Could not parse AI response.',takeaway:'Refresh to retry.'}],ic:[],dhs:[]},acquisition_news:[{item:'Unavailable',status:'yellow',update:'Could not parse AI response.',takeaway:'Refresh to retry.'}]});}
          setGenTime(new Date().toLocaleString());
          setSitrepStatus('draft');
        })
        .catch(function(){
          setAiSections({exec_summary:{revenue_status:'yellow',key_development:'AI briefing unavailable.',primary_risk:topRisk?topRisk.title:'None',pipeline_health:formatDollar(totalVal)+' opportunities',decision_required:false,presidents_takeaway:'Review opportunities manually.'},world_news:[{topic:'AI Unavailable',status:'red',summary:'The AI briefing service is currently unavailable. Click Refresh to retry.',why_you_care:'Manual review recommended.'}],market_signals:[{indicator:'Unavailable',status:'red',update:'AI briefing service unavailable.',takeaway:'Refresh to retry.'}],govt_intel:{dod:[{topic:'Unavailable',status:'red',update:'AI briefing service unavailable.',takeaway:'Refresh to retry.'}],ic:[],dhs:[]},acquisition_news:[{item:'Unavailable',status:'red',update:'AI briefing service unavailable.',takeaway:'Refresh to retry.'}]});
          setGenTime(new Date().toLocaleString());
          setSitrepStatus('draft');
        });
    }).finally(function(){setLoading(false);});
  }

  useEffect(function(){loadAll();},[]);

  // Computed pipeline stats
  var totalVal=opps.reduce(function(s,o){return s+(parseFloat(o.estimated_value)||0);},0);
  var stageCounts={};opps.forEach(function(o){var st=o.stage||'Identified';stageCounts[st]=(stageCounts[st]||0)+1;});
  var openRisks=risks.filter(function(r){return(r.status||'').toUpperCase()!=='RESOLVED';});
  var urgent30=opps.filter(function(o){var d=new Date(o.response_deadline);return d>new Date()&&d<new Date(Date.now()+30*86400000);});
  var topFit=opps.slice().sort(function(a,b){return(b.eis_fit_score||0)-(a.eis_fit_score||0);}).slice(0,5);

  var statusDot=function(s){var c=s==='green'?'#2F5C1F':s==='red'?'#DC2626':'#B06D32';var bg=s==='green'?'#2F5C1F15':s==='red'?'#DC262615':'#B06D3215';var label=s==='green'?'OK':s==='red'?'ALERT':'WATCH';return React.createElement('span',{style:{display:'inline-block',padding:'2px 8px',borderRadius:10,fontSize:11,fontWeight:700,background:bg,color:c,minWidth:45,textAlign:'center'}},label);};
  var SH=function(props){return React.createElement('div',{style:{display:'flex',alignItems:'center',justifyContent:'space-between',padding:'12px 16px',background:'#F9FAFB',marginBottom:openSec[props.id]?0:12,cursor:'pointer',userSelect:'none',border:'1px solid #E5E7EB',borderBottom:openSec[props.id]?'none':'1px solid #E5E7EB',borderRadius:openSec[props.id]?'8px 8px 0 0':'8px'},onClick:function(){toggle(props.id);}},React.createElement('span',{style:{fontSize:16,fontWeight:700,color:'#1B2A4A'}},props.icon+' '+props.title),React.createElement('span',{style:{fontSize:14,color:'#9CA3AF'}},openSec[props.id]?'\u25BC':'\u25B6'));};
  var SC=function(props){return openSec[props.id]?React.createElement('div',{style:{border:'1px solid #E5E7EB',borderTop:'none',borderRadius:'0 0 8px 8px',padding:16,marginBottom:12,background:'#fff'}},props.children):null;};
  var PTakeaway=function(props){return React.createElement('div',{style:{background:'#B06D3212',borderLeft:'3px solid #B06D32',padding:'10px 14px',marginTop:12,borderRadius:'0 6px 6px 0',fontSize:13,color:'#B06D32',fontStyle:'italic'}},'\ud83d\udc49 '+props.text);};
  var TH=function(props){return React.createElement('th',{style:{textAlign:'left',padding:'8px 10px',fontSize:10,fontWeight:700,color:'#6B7280',borderBottom:'2px solid #E5E7EB',textTransform:'uppercase',letterSpacing:'0.5px',background:'#FAFAFA'}},props.children);};
  var TD=function(props){return React.createElement('td',{style:Object.assign({padding:'8px 10px',fontSize:12,color:'#1B2A4A',borderBottom:'1px solid #F3F4F6',verticalAlign:'top'},props.style||{}),onClick:props.onClick},props.children);};

  if(loading&&!aiSections)return React.createElement('div',{style:{textAlign:'center',padding:'80px 20px'}},
    React.createElement('div',{style:{fontSize:32,marginBottom:12}},'\ud83e\udded'),
    React.createElement('div',{style:{fontSize:16,fontWeight:700,color:'#1B2A4A',marginBottom:8}},'Loading Daily Intelligence Briefing...'),
    React.createElement('div',{style:{fontSize:12,color:'#6B7280',lineHeight:1.6}},'Analyzing world events, market signals, acquisition news, and opportunity data.'),
    React.createElement('div',{style:{marginTop:16}}),React.createElement(Spinner,null)
  );

  var es=aiSections&&aiSections.exec_summary||{};

  return React.createElement('div',{style:{}},
    // HEADER
    React.createElement('div',{style:{textAlign:'center',marginBottom:24,borderBottom:'2px solid #1B2A4A',paddingBottom:16}},
      React.createElement('div',{style:{fontSize:24,fontWeight:800,color:'#1B2A4A',letterSpacing:1}},'\ud83e\udded DAILY SITREP'),
      React.createElement('div',{style:{fontSize:13,color:'#D14A2A',fontWeight:600,marginTop:4}},'Envision Innovative Solutions'),
      React.createElement('div',{style:{fontSize:12,color:'#6B7280',marginTop:4}},today),
      React.createElement('div',{style:{fontSize:10,color:'#9CA3AF',marginTop:4}},'Prepared by: GDA AI / President\'s Daily Brief'),
      React.createElement('div',{style:{fontSize:11,color:'#DC2626',fontWeight:700,letterSpacing:1,marginTop:6}},'INTERNAL \u2014 FOR OFFICIAL USE ONLY'),
      React.createElement('div',{style:{display:'flex',justifyContent:'center',gap:8,marginTop:12}},
        React.createElement('button',{onClick:function(){loadAll();},style:{padding:'5px 14px',fontSize:11,fontWeight:600,border:'1px solid #D1D5DB',borderRadius:6,background:'#fff',color:'#374151',cursor:'pointer'}},'\u21bb Refresh SITREP'),
        genTime&&React.createElement('span',{style:{fontSize:10,color:'#9CA3AF',alignSelf:'center'}},'Generated: '+genTime)
      )
    ),

    // SITREP ACKNOWLEDGMENT BANNER
    sitrepStatus==='draft'&&aiSections&&React.createElement('div',{style:{background:'#B06D3212',border:'1px solid #FDE68A',borderRadius:8,padding:'12px 16px',marginBottom:14,display:'flex',alignItems:'center',gap:12}},
      React.createElement('span',{style:{fontSize:13,fontWeight:700,color:'#B06D32'}},'\u26a0 AI Situation Report \u2014 Pending Acknowledgment'),
      React.createElement('div',{style:{flex:1}}),
      React.createElement('button',{onClick:function(){setSitrepStatus('approved');setSitrepApprovedAt(new Date().toLocaleString());try{localStorage.setItem('gda_sitrep_ack',String(Date.now()));}catch(e){}api.post('gda-data-learn',{event:'sitrep_acknowledged',context:'sitrep',data_type:'kpi_acknowledge',data:{date:new Date().toISOString(),pipeline_value:formatDollar(totalVal),opps_count:opps.length,risks_count:openRisks.length,urgent_count:urgent30.length}}).catch(function(){});},style:{padding:'6px 16px',background:'#32448A',color:'#fff',border:'none',borderRadius:6,fontSize:12,fontWeight:700,cursor:'pointer'}},'\u2713 Acknowledge')
    ),
    sitrepStatus==='approved'&&React.createElement('div',{style:{background:'#2F5C1F12',border:'1px solid #86EFAC',borderRadius:8,padding:'10px 16px',marginBottom:14,fontSize:12,fontWeight:600,color:'#2F5C1F'}},'\u2713 Acknowledged \u2014 '+sitrepApprovedAt),

    // KPI BAR
    React.createElement(GDAKpiBar, {
      items: [
        {id:'pipeline',label:'Pipeline',value:formatDollar(totalVal),color:'#2F5C1F',sub:'total tracked value'},
        {id:'opps',label:'Active Opps',value:String(opps.length),color:'#1B2A4A',sub:'across all depts'},
        {id:'risks',label:'Open Risks',value:String(openRisks.length),color:openRisks.length>0?'#DC2626':'#1B2A4A',sub:'requiring action'},
        {id:'urgent',label:'Due <30 Days',value:String(urgent30.length),color:'#B06D32',sub:'response deadlines'}
      ]
    }),

    // SECTION 1: EXECUTIVE SUMMARY
    React.createElement(SH,{id:'exec_summary',icon:'\ud83d\udd25',title:'EXECUTIVE SUMMARY'}),
    React.createElement(SC,{id:'exec_summary'},
      React.createElement('div',{style:{display:'flex',flexDirection:'column',gap:8}},
        React.createElement('div',{style:{display:'flex',alignItems:'flex-start',gap:8}},statusDot(es.revenue_status||'yellow'),React.createElement('div',null,React.createElement('strong',null,'Revenue Tracking: '),es.revenue_status==='green'?'On track':'Needs attention')),
        React.createElement('div',{style:{display:'flex',alignItems:'flex-start',gap:8}},statusDot('green'),React.createElement('div',null,React.createElement('strong',null,'Key Development: '),es.key_development||'—')),
        React.createElement('div',{style:{display:'flex',alignItems:'flex-start',gap:8}},statusDot('red'),React.createElement('div',null,React.createElement('strong',null,'Primary Risk: '),es.primary_risk||'None identified')),
        React.createElement('div',{style:{display:'flex',alignItems:'flex-start',gap:8}},statusDot('green'),React.createElement('div',null,React.createElement('strong',null,'Opportunity Health: '),es.pipeline_health||formatDollar(totalVal))),
        React.createElement('div',{style:{display:'flex',alignItems:'flex-start',gap:8}},statusDot(es.decision_required?'red':'green'),React.createElement('div',null,React.createElement('strong',null,'Immediate Decision Required: '),es.decision_required?'YES':'NO'))
      ),
      React.createElement(PTakeaway,{text:es.presidents_takeaway||'Review opportunities and upcoming deadlines.'})
    ),

    // SECTION 2: WORLD NEWS
    React.createElement(SH,{id:'world_news',icon:'\ud83c\udf0d',title:'WORLD NEWS (MISSION-RELEVANT)'}),
    React.createElement(SC,{id:'world_news'},
      (aiSections&&aiSections.world_news&&aiSections.world_news.length>0)?
        React.createElement('table',{style:{width:'100%',borderCollapse:'collapse'}},
          React.createElement('thead',null,React.createElement('tr',null,React.createElement(TH,null,'Title'),React.createElement(TH,null,'Summary'),React.createElement(TH,null,'Source'))),
          React.createElement('tbody',null,aiSections.world_news.map(function(n,i){
            return React.createElement('tr',{key:i,style:{background:i%2?'#FAFAFA':'#fff'}},
              React.createElement(TD,{style:{fontWeight:600,minWidth:100}},n.url?React.createElement('a',{href:n.url,target:'_blank',rel:'noopener',style:{color:'#1B2A4A',textDecoration:'none',fontWeight:600}},n.title||n.topic||'—'):React.createElement('span',null,n.title||n.topic||'—')),
              React.createElement(TD,null,statusDot(n.status||'green')),
              React.createElement(TD,null,n.summary||n.why_you_care||'—'),
              React.createElement(TD,null,n.url?React.createElement('a',{href:n.url,target:'_blank',rel:'noopener',style:{color:'#D14A2A',fontSize:11,textDecoration:'none',fontWeight:600}},'View Source \u2197'):React.createElement('span',{style:{color:'#9CA3AF',fontSize:11}},'No source'))
            );
          }))
        ):React.createElement('div',{style:{color:'#9CA3AF',fontSize:12,padding:12}},'No world news data available. Click Refresh SITREP to generate.'),
      React.createElement('div',{style:{fontSize:10,color:'#9CA3AF',marginTop:8,fontStyle:'italic'}},'Focus: Only news affecting defense spending, intel priorities, cyber/tech demand, or global instability.')
    ),

    // SECTION 3: MARKET SIGNALS
    React.createElement(SH,{id:'market_signals',icon:'\ud83d\udcc8',title:'DoD NEWS'}),
    React.createElement(SC,{id:'market_signals'},
      (aiSections&&aiSections.market_signals&&aiSections.market_signals.length>0)?
        React.createElement('table',{style:{width:'100%',borderCollapse:'collapse'}},
          React.createElement('thead',null,React.createElement('tr',null,React.createElement(TH,null,'Topic'),React.createElement(TH,null,'Summary'),React.createElement(TH,null,'Source'))),
          React.createElement('tbody',null,aiSections.market_signals.map(function(m,i){
            return React.createElement('tr',{key:i,style:{background:i%2?'#FAFAFA':'#fff'}},
              React.createElement(TD,{style:{fontWeight:600}},m.indicator||'—'),
              React.createElement(TD,null,m.update||'—'),
              React.createElement(TD,null,m.source?React.createElement('a',{href:m.source,target:'_blank',rel:'noopener',style:{color:'#D14A2A',fontSize:11,textDecoration:'none',fontWeight:600}},'Source \u2197'):React.createElement('span',{style:{color:'#B06D32',fontStyle:'italic'}},m.takeaway||'—'))
            );
          }))
        ):React.createElement('div',{style:{color:'#9CA3AF',fontSize:12,padding:12}},'No market signal data available. Click Refresh SITREP to generate.'),
      React.createElement(PTakeaway,{text:'Is the market telling us to be aggressive or defensive?'})
    ),

    // SECTION 4: GOVT DEPT INTEL
    React.createElement(SH,{id:'govt_intel',icon:'\ud83c\udfdb\ufe0f',title:'OTHER DEPARTMENT NEWS'}),
    React.createElement(SC,{id:'govt_intel'},
      (function(){
        var gi=aiSections&&aiSections.govt_intel||{};
        var sections=[{label:'Department of Defense',data:gi.dod||[]},{label:'Intelligence Community',data:gi.ic||[]},{label:'DHS / Cyber',data:gi.dhs||[]}];
        return React.createElement('div',null,sections.map(function(sec,si){
          if(!sec.data||sec.data.length===0)return null;
          return React.createElement('div',{key:si,style:{marginBottom:12}},
            React.createElement('div',{style:{fontSize:12,fontWeight:700,color:'#1B2A4A',marginBottom:6}},sec.label),
            React.createElement('table',{style:{width:'100%',borderCollapse:'collapse'}},
              React.createElement('thead',null,React.createElement('tr',null,React.createElement(TH,null,'Topic'),React.createElement(TH,null,'Summary'),React.createElement(TH,null,'Source'))),
              React.createElement('tbody',null,sec.data.map(function(d,di){
                return React.createElement('tr',{key:di,style:{background:di%2?'#FAFAFA':'#fff'}},
                  React.createElement(TD,{style:{fontWeight:600}},d.topic||'—'),
                  React.createElement(TD,null,(d.update||d.summary||'—').substring(0,150)),
                  React.createElement(TD,null,d.source?React.createElement('a',{href:d.source,target:'_blank',rel:'noopener',style:{color:'#D14A2A',fontSize:11,textDecoration:'none',fontWeight:600}},'Source ↗'):React.createElement('span',{style:{fontSize:11,color:'#9CA3AF'}},d.takeaway||'—'))
                );
              }))
            )
          );
        }),React.createElement('div',{style:{fontSize:10,color:'#9CA3AF',marginTop:4,fontStyle:'italic'}},'Rule: If it doesn\'t affect funding, mission, or contracts \u2014 cut it.'));
      })()
    ),

    // SECTION 5: ACQUISITION NEWS
    React.createElement(SH,{id:'acquisition_news',icon:'\ud83d\udcdc',title:'GOVERNMENT ACQUISITION NEWS'}),
    React.createElement(SC,{id:'acquisition_news'},
      (aiSections&&aiSections.acquisition_news&&aiSections.acquisition_news.length>0)?
        React.createElement('table',{style:{width:'100%',borderCollapse:'collapse'}},
          React.createElement('thead',null,React.createElement('tr',null,React.createElement(TH,null,'Topic'),React.createElement(TH,null,'Summary'),React.createElement(TH,null,'Source'))),
          React.createElement('tbody',null,aiSections.acquisition_news.map(function(a,i){
            return React.createElement('tr',{key:i,style:{background:i%2?'#FAFAFA':'#fff'}},
              React.createElement(TD,{style:{fontWeight:600}},a.item||a.topic||'—'),
              React.createElement(TD,null,(a.update||a.summary||'—').substring(0,150)),
              React.createElement(TD,null,a.source?React.createElement('a',{href:a.source,target:'_blank',rel:'noopener',style:{color:'#D14A2A',fontSize:11,textDecoration:'none',fontWeight:600}},'Source ↗'):React.createElement('span',{style:{fontSize:11,color:'#9CA3AF'}},a.takeaway||'—'))
            );
          }))
        ):React.createElement('div',{style:{color:'#9CA3AF',fontSize:12,padding:12}},'No acquisition news available. Click Refresh SITREP to generate.')
    ),

    // SECTION 6: CONTRACT PORTFOLIO — now linked to Financial Bible
    React.createElement(SH,{id:'contract_portfolio',icon:'\ud83d\udcca',title:'CONTRACT PORTFOLIO STATUS'}),
    React.createElement(SC,{id:'contract_portfolio'},
      React.createElement('div',{style:{display:'flex',justifyContent:'space-between',alignItems:'center',padding:'12px',background:'#F9FAFB',borderRadius:6}},
        React.createElement('div',null,
          React.createElement('div',{style:{fontSize:13,fontWeight:600,color:'#1B2A4A'}},'5 Active Contracts | $235.7M Total Ceiling'),
          React.createElement('div',{style:{fontSize:11,color:'#6B7280',marginTop:2}},'FY26 Projected: $18.3M from existing | $42.8M AOP Target | Gap: $24.5M')
        ),
        React.createElement('button',{onClick:function(){nav('aop-tracker');},style:{padding:'6px 14px',background:'#C65D21',color:'#fff',border:'none',borderRadius:6,fontSize:11,fontWeight:600,cursor:'pointer'}},'Open Financial Bible')
      )
    ),

    // SECTION 7: PIPELINE & GROWTH (REAL DATA)
    React.createElement(SH,{id:'pipeline',icon:'\ud83c\udfaf',title:'OPPORTUNITIES & GROWTH'}),
    React.createElement(SC,{id:'pipeline'},
      React.createElement('div',{style:{display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:8,marginBottom:12}},
        [{l:'Pipeline Value',v:formatDollar(totalVal),c:'#2F5C1F'},{l:'Investigating',v:String(stageCounts.Investigating||0),c:'#1B3A6B'},{l:'Pursuing',v:String(stageCounts.Pursuing||0),c:'#1B3A6B'},{l:'Proposal/Submitted',v:String((stageCounts.Proposal||0)+(stageCounts.Submitted||0)),c:'#1B3A6B'}].map(function(k,i){
          return React.createElement('div',{key:i,style:{textAlign:'center',padding:10,background:'#F9FAFB',borderRadius:6}},
            React.createElement('div',{style:{fontSize:16,fontWeight:700,color:k.c||'#1B2A4A'}},k.v),
            React.createElement('div',{style:{fontSize:9,color:'#6B7280',marginTop:2}},k.l)
          );
        })
      ),
      urgent30.length>0&&React.createElement('div',{style:{marginBottom:12}},
        React.createElement('div',{style:{fontSize:11,fontWeight:700,color:'#DC2626',marginBottom:6}},'NEAR-TERM BIDS (Due <30 days): '+urgent30.length),
        urgent30.slice(0,5).map(function(o,i){
          return React.createElement('div',{key:i,style:{display:'flex',justifyContent:'space-between',padding:'4px 0',fontSize:12,borderBottom:'1px solid #F3F4F6',cursor:'pointer'},onClick:function(){nav('opp-tracker');}},
            React.createElement('span',{style:{color:'#1B2A4A',fontWeight:500}},(o.opp_title||o.title||'Untitled').substring(0,50)),
            React.createElement('span',{style:{color:'#DC2626',fontSize:11}},new Date(o.response_deadline).toLocaleDateString())
          );
        })
      ),
      topFit.length>0&&React.createElement('div',null,
        React.createElement('div',{style:{fontSize:11,fontWeight:700,color:'#2F5C1F',marginBottom:6}},'STRATEGIC MUST-WINS (Top Fit Score)'),
        topFit.map(function(o,i){
          return React.createElement('div',{key:i,style:{display:'flex',justifyContent:'space-between',padding:'4px 0',fontSize:12,borderBottom:'1px solid #F3F4F6',cursor:'pointer'},onClick:function(){nav('opp-tracker');}},
            React.createElement('span',{style:{color:'#1B2A4A',fontWeight:500}},(o.opp_title||o.title||'Untitled').substring(0,50)),
            React.createElement('span',null,
              React.createElement('span',{style:{color:'#2F5C1F',fontWeight:700,marginRight:8}},'Fit: '+(o.eis_fit_score||0)),
              React.createElement('span',{style:{color:'#6B7280'}},formatDollar(o.estimated_value))
            )
          );
        })
      ),
      React.createElement(PTakeaway,{text:'Are we growing, flat, or shrinking?'})
    ),

    // SECTION 8: RISKS & DECISIONS (REAL DATA — TOP 3)
    React.createElement(SH,{id:'risks_decisions',icon:'\u26a0\ufe0f',title:'RISKS & DECISIONS'}),
    React.createElement(SC,{id:'risks_decisions'},
      openRisks.length>0?
        React.createElement('table',{style:{width:'100%',borderCollapse:'collapse'}},
          React.createElement('thead',null,React.createElement('tr',null,React.createElement(TH,null,'Issue'),React.createElement(TH,null,'Severity'),React.createElement(TH,null,'Description'),React.createElement(TH,null,'Action'))),
          React.createElement('tbody',null,openRisks.slice(0,3).map(function(r,i){
            var sc=r.severity==='CRITICAL'?'#DC2626':r.severity==='HIGH'?'#B06D32':'#6B7280';
            return React.createElement('tr',{key:i,style:{background:i%2?'#FAFAFA':'#fff',cursor:'pointer'},onClick:function(){nav('risk');}},
              React.createElement(TD,{style:{fontWeight:600}},r.title||'Risk '+(i+1)),
              React.createElement(TD,null,React.createElement('span',{style:{padding:'2px 8px',borderRadius:10,fontSize:10,fontWeight:700,background:sc+'15',color:sc}},r.severity||'MEDIUM')),
              React.createElement(TD,null,(r.description||'').substring(0,80)),
              React.createElement(TD,{style:{color:'#B06D32',fontStyle:'italic'}},r.mitigation||'Review required')
            );
          }))
        ):React.createElement('div',{style:{color:'#9CA3AF',fontSize:12,padding:12}},'No open risks. Click Refresh to generate from opportunity data.'),
      React.createElement('div',{style:{fontSize:10,color:'#9CA3AF',marginTop:8}},'Showing top 3 risks by severity. Full register has '+risks.length+' items.')
    ),

    // SOURCE CITATION
    React.createElement('div',{style:{fontSize:10,color:'#9CA3AF',marginTop:12,textAlign:'center'}},'Source: GDA AI analysis via Tavily + GovTribe opportunity data. Generated: '+(genTime||'—'))
    ,
    // TREND ANALYSIS (merged from SITREP Trends)
    React.createElement('div',{style:{borderTop:'2px solid #E8ECF1',marginTop:24,paddingTop:20}},
      React.createElement('div',{style:{fontSize:16,fontWeight:700,color:'#1B2A4A',marginBottom:4}},'TREND ANALYSIS'),
      React.createElement('div',{style:{fontSize:11,color:'#9CA3AF',marginBottom:16}},'Historical metrics and trajectory analysis'),
      React.createElement(SitrepTrends,null)
    )
  );
}
export default DailySitrep;