import React, { useState, useMemo } from 'react';
import { ACCENT, NAVY, WHITE, BORDER, FONT, PageHeader } from '../../lib/gda';

const CATEGORIES = [
  { id: 'intel', label: 'Intelligence & Analysis', icon: '🔎', color: '#1B2A4A', desc: 'Real-time defense market intelligence, competitor tracking, and strategic analysis.' },
  { id: 'pursuit', label: 'Pursuit & Capture', icon: '🎯', color: '#2F5C1F', desc: 'Opportunity pipeline, win probability, capture planning, and teaming strategy.' },
  { id: 'proposal', label: 'Proposal & Compliance', icon: '⚔️', color: '#D14A2A', desc: 'Proposal review, compliance matrices, risk management, and communications.' },
  { id: 'knowledge', label: 'Knowledge & Documents', icon: '📂', color: '#5091A7', desc: 'AI-powered document generation, search, meeting analysis, and RAG queries.' },
  { id: 'ops', label: 'Operations & Admin', icon: '⚙️', color: '#B06D32', desc: 'Dashboard, financials, platform health, and system configuration.' },
];

const TOOLS = [
  { id: 'sitrep', cat: 'intel', icon: '📋', name: 'Daily SITREP', nav: 'sitrep',
    tagline: 'AI-generated daily intelligence briefing with real-time market data.',
    desc: 'Combines Tavily web intelligence, SAM.gov opportunities, and pipeline analytics into a structured daily situation report. Includes executive summary, world news, market signals, government intel, acquisition news, and threat matrix.',
    components: ['Executive Summary with revenue status', 'World News (Tavily-powered)', 'Market Signals & Defensive Watch', 'Government Intel by department', 'Acquisition News & Contract Alerts', 'Trend Analysis with historical charts'],
    actions: ['Refresh SITREP — generates fresh intelligence', 'Acknowledge — marks SITREP as reviewed', 'Trend Analysis — visualize 30 days of metrics'],
    tips: ['SITREPs auto-save to history for 30 days', 'Trend Analysis charts improve with daily generation', 'Switch departments in Market Analysis dropdown'] },
  { id: 'intel-feed', cat: 'intel', icon: '📡', name: 'Intel Feed', nav: 'intel-feed',
    tagline: 'Search and monitor defense intelligence from multiple sources.',
    desc: 'Aggregates intelligence from Tavily, GovTribe, SAM.gov, and internal data. Filter by source, keyword, and date. Track articles and flag actionable intelligence.',
    components: ['Multi-source search (Tavily, GovTribe, SAM)', 'Source toggle filters', 'Article cards with relevance scoring', 'Feed status monitoring'],
    actions: ['Search Intel — query across all sources', 'Toggle sources — filter by data provider'],
    tips: ['Use specific keywords like agency names or NAICS codes', 'Combine sources for comprehensive coverage'] },
  { id: 'comp-intel', cat: 'intel', icon: '🔍', name: 'Competitive Intel', nav: 'comp-intel',
    tagline: '35-competitor watchlist with AI-powered deep dive analysis.',
    desc: 'Monitor competitors across the defense IT market. Track contract wins, teaming arrangements, hiring patterns, and strategic moves. AI deep dives generate comprehensive competitive profiles.',
    components: ['Competitor watchlist (35 tracked)', 'Regional groupings', 'Deep dive analysis cards', 'AI-powered competitive questions'],
    actions: ['Add competitor — add to watchlist', 'Deep Dive — full AI competitive analysis', 'Ask question — targeted competitive query'],
    tips: ['Deep dives take 20-30 seconds (calls AI)', 'Regional groups help identify local competitors', 'Use Ask feature for specific competitive questions'] },
  { id: 'incumbent', cat: 'intel', icon: '📊', name: 'Incumbent Analysis', nav: 'incumbent',
    tagline: 'Analyze incumbent contractors on target opportunities.',
    desc: 'Research incumbent performance, contract history, and vulnerabilities for displacement strategies. Pulls data from GovTribe and FPDS to build comprehensive incumbent profiles.',
    components: ['Contract search', 'Incumbent profile cards', 'Performance metrics', 'Displacement strategy recommendations'],
    actions: ['Analyze Incumbent — generate full incumbent profile'],
    tips: ['Works best with specific contract numbers', 'Results include recompete timeline data'] },
  { id: 'ooda', cat: 'intel', icon: '🔄', name: 'OODA Loop', nav: 'ooda',
    tagline: 'Observe-Orient-Decide-Act strategic analysis framework.',
    desc: 'Structured decision-making tool that walks through the OODA loop for any opportunity or strategic question. AI generates observations, orientation analysis, decision options, and recommended actions.',
    components: ['4-phase OODA workflow (Observe/Orient/Decide/Act)', 'AI-generated analysis per phase', 'Decision tracking with approval flow', 'OODA history for pattern analysis', 'Export to Excel'],
    actions: ['Run OODA — execute full 4-phase analysis', 'Export Excel — download analysis', 'Load History — review past OODA runs'],
    tips: ['Use for bid/no-bid decisions on major opportunities', 'History shows decision patterns over time', 'Each phase builds on the previous'] },

  { id: 'opp-tracker', cat: 'pursuit', icon: '🎯', name: 'Opportunity Tracker', nav: 'opp-tracker',
    tagline: '595+ opportunities from GovTribe and SAM.gov with GDA Priority Scoring.',
    desc: 'Central pipeline tracking all federal opportunities matching GDA NAICS codes. GDA Priority Score (0-100) ranks each opp across 4 tiers: NAICS fit, competitive position, urgency, and strategic value. Auto-stage progression moves opps through Identified → Qualified → Capture → Proposal → Award.',
    components: ['Department-grouped opportunity tree', 'GDA Priority Score badges (PURSUE/EVALUATE/MONITOR/PASS)', 'Stage progression tracking', 'Overdue deadline alerts', 'Source links to SAM.gov/GovTribe'],
    actions: ['Refresh from SAM.gov — pull latest opportunities', 'Filter by department, score, stage', 'Click any opp to see details + actions'],
    tips: ['PURSUE (75+) = invest BD resources', 'EVALUATE (60-74) = needs analysis', 'MONITOR (40-59) = watch list', 'PASS (<40) = archived'] },
  { id: 'pwin', cat: 'pursuit', icon: '🎲', name: 'Pwin Calculator', nav: 'pwin-calculator',
    tagline: 'Probability of win scoring with AI-powered recommendations.',
    desc: 'Calculate win probability for any opportunity using Shipley-aligned factors: customer relationship, solution fit, competitive position, price competitiveness, and past performance. AI generates specific improvement actions.',
    components: ['Multi-factor scoring form', 'Pwin score output with confidence level', 'AI recommendations for score improvement', 'Save and compare across opportunities'],
    actions: ['Calculate Pwin — score an opportunity', 'View saved calculations'],
    tips: ['Be honest with factor ratings for accurate scores', 'Pwin below 30% typically means no-bid'] },
  { id: 'capture-plan', cat: 'pursuit', icon: '📋', name: 'Capture Plan', nav: 'capture-plan',
    tagline: 'AI-generated Shipley-aligned capture plans.',
    desc: 'Generate comprehensive capture plans including win themes, competitive assessment, ghost strategy, customer analysis, solution strategy, teaming strategy, price strategy, risk assessment, and timeline.',
    components: ['13-section Shipley framework', 'Collapsible section editor', 'Draft → Approve workflow', 'Saved plans library', 'Import from Pwin Calculator'],
    actions: ['Generate Capture Plan — full AI generation', 'Approve Draft — lock plan', 'Saved Plans — view all saved plans'],
    tips: ['Import opportunity data from Pwin to pre-fill', 'Review and edit each section before approving', 'Plans auto-save to 30-day history'] },
  { id: 'teaming', cat: 'pursuit', icon: '🤝', name: 'Teaming Finder', nav: 'teaming',
    tagline: 'Find and evaluate potential teaming partners.',
    desc: 'Search for teaming partners based on capabilities, clearances, past performance, and set-aside status. AI recommends optimal teaming arrangements for target opportunities.',
    components: ['Partner search', 'Capability matching', 'Teaming arrangement builder'],
    actions: ['Add Partner — add to teaming database', 'Search — find matching partners'],
    tips: ['Filter by set-aside type for SB requirements'] },
  { id: 'wargame', cat: 'pursuit', icon: '♟️', name: 'Wargame', nav: 'wargame',
    tagline: 'Competitive wargaming simulations.',
    desc: 'Simulate competitive scenarios for major pursuits. Model competitor responses, pricing strategies, and solution approaches. Identify vulnerabilities and develop counter-strategies.',
    components: ['Scenario builder', 'Competitor modeling', 'Strategy simulation', 'Results analysis'],
    actions: ['Create wargame scenario', 'Run simulation'],
    tips: ['Most effective for must-win opportunities', 'Include all known competitors'] },

  { id: 'red-team', cat: 'proposal', icon: '⚔️', name: 'Proposal Review', nav: 'red-team',
    tagline: 'AI-powered proposal analysis and red team review.',
    desc: 'Upload proposal documents for automated red team review. AI analyzes compliance, strengths/weaknesses, win theme consistency, and scoring risk. Generates actionable feedback for improvement.',
    components: ['Document upload (PDF/DOCX)', 'AI analysis engine', 'Compliance scoring', 'Strength/weakness assessment', 'Improvement recommendations'],
    actions: ['Upload & Analyze — run red team review', 'White Hat — post-submittal check'],
    tips: ['Upload RFP first for compliance checking', 'Review generates in 20-40 seconds'] },
  { id: 'compliance', cat: 'proposal', icon: '✅', name: 'Compliance Matrix', nav: 'compliance-matrix',
    tagline: 'Parse RFP sections into structured compliance requirements.',
    desc: 'Upload an RFP and automatically extract all compliance requirements into a structured matrix. Track response status, assign owners, and ensure 100% compliance coverage.',
    components: ['RFP upload and parsing', 'Requirement extraction', 'Status tracking per requirement', 'Owner assignment', 'Compliance coverage percentage'],
    actions: ['Upload RFP — parse and extract requirements', 'Update status — mark requirements as addressed'],
    tips: ['Works best with text-based PDFs (not scanned)', 'Export to Excel for team distribution'] },
  { id: 'risk', cat: 'proposal', icon: '🛡️', name: 'Risk Register', nav: 'risk',
    tagline: 'Track, categorize, and mitigate risks across all pursuits.',
    desc: 'Comprehensive risk management with auto-population from opportunity analysis. Risks display in a compact 3-across grid with collapsed cards showing risk number, severity badge, and title. Click any card to expand full description, mitigation strategy, and action buttons (Add to Cube, Accept, Reject). Color-coded severity: Critical (red), High (orange), Medium (amber), Low (green).',
    components: ['Risk Assessment Matrix (5x5 heat map)', 'Collapsed 3-across card grid (R-number + severity + title)', 'Click-to-expand risk details with mitigation', 'Pending/Accepted/Rejected tabs', 'Add to Cube / Accept / Reject actions', '123 auto-generated risks from pipeline'],
    actions: ['Generate — auto-populate from opportunities', 'Refresh from Opps — update risk scores', 'Add to Cube — add risk to tracking cube', 'Accept/Reject — triage individual risks'],
    tips: ['63+ risks auto-generated daily from pipeline', 'Critical risks flagged in Launchpad KPIs'] },
  { id: 'email', cat: 'proposal', icon: '✉️', name: 'Email Drafter', nav: 'email',
    tagline: 'AI-powered professional email composition.',
    desc: 'Generate professional emails with AI assistance. Set context, tone, and key points. AI drafts polished emails ready for review and sending.',
    components: ['Context and audience selector', 'Tone control', 'Key points input', 'AI-generated draft', 'Copy to clipboard'],
    actions: ['Generate — create AI email draft'],
    tips: ['Be specific with context for better results', 'Drafts save to 30-day history'] },

  { id: 'doc-hub', cat: 'knowledge', icon: '📂', name: 'Document Hub & PPT', nav: 'doc-hub',
    tagline: 'Generate presentations and manage document library.',
    desc: 'Create professional slide decks from topics, outlines, or source documents. Upload reference materials and generate polished presentations. Supports PPTX generation with custom styling.',
    components: ['Topic-based slide generation', 'Source document upload', 'Style template selection', 'Key points editor', 'PPTX download'],
    actions: ['Generate — create presentation from inputs'],
    tips: ['Upload source docs for content extraction', 'Set audience and style for better output'] },
  { id: 'doc-rag', cat: 'knowledge', icon: '🔍', name: 'Doc RAG', nav: 'doc-rag',
    tagline: 'Query uploaded documents with AI-powered retrieval.',
    desc: 'Upload documents and ask questions against them. RAG (Retrieval-Augmented Generation) finds relevant passages and synthesizes answers. Compare documents side-by-side.',
    components: ['Document upload', 'Natural language query', 'Answer with source citations', 'Document comparison mode'],
    actions: ['Query — ask questions against uploaded docs', 'Compare — side-by-side document comparison'],
    tips: ['Upload multiple docs for cross-referencing', 'Compare mode works great for RFP amendments'] },
  { id: 'ai-agent', cat: 'knowledge', icon: '🤖', name: 'AI Agent Chat', nav: 'ai-agent',
    tagline: 'Conversational AI assistant with GDA context.',
    desc: 'Chat with an AI agent that has full context of GDA operations, pipeline, risks, and intelligence. Ask questions, get analysis, request actions. Supports file uploads for document analysis.',
    components: ['Chat interface', 'File upload', 'Context-aware responses', 'Quick prompt suggestions'],
    actions: ['Send — chat with the AI agent', 'Upload — attach files for analysis'],
    tips: ['Ask about specific opportunities by name', 'Upload RFPs for quick analysis', 'Agent knows your full pipeline'] },
  { id: 'meeting-notes', cat: 'knowledge', icon: '📝', name: 'Meeting Notes', nav: 'meeting-notes',
    tagline: 'AI-powered meeting analysis and action item extraction.',
    desc: 'Paste meeting transcripts or notes and get structured analysis. AI extracts key decisions, action items with owners, risks, follow-ups, and a brief summary.',
    components: ['Transcript input', 'Meeting type selector', 'Attendee tracking', 'AI analysis output', 'In-memory history'],
    actions: ['Analyze Meeting — extract structured insights'],
    tips: ['Include attendee names for better action item assignment', 'Works with both transcripts and handwritten notes'] },

  { id: 'launchpad', cat: 'ops', icon: '🚀', name: 'Launchpad', nav: 'launchpad',
    tagline: 'Command center dashboard with KPIs, charts, and intelligence.',
    desc: 'The main dashboard showing pipeline health, opportunity funnel, revenue vs target, market analysis (PAM/TAM/SAM/SOM), upcoming deadlines, latest intelligence, AI daily actions, and predictive intelligence.',
    components: ['6 KPI cards with sparklines', 'Pipeline Funnel chart', 'Revenue vs $100M Target pie', 'PAM/TAM/SAM/SOM market sizing', 'Upcoming Deadlines (4 time buckets)', 'AI Daily Actions', 'Latest Intelligence', 'Predictive Intelligence'],
    actions: ['Click KPIs for detail expansion', 'Switch department in Market Analysis', 'Expand/collapse intelligence sections'],
    tips: ['All sections default collapsed per platform convention', 'Deadlines show overdue PURSUE/EVALUATE alerts'] },
  { id: 'financial-bible', cat: 'ops', icon: '✚', name: 'Financial Bible', nav: 'financial-bible',
    tagline: 'Complete financial intelligence with P2 actuals, contract P&L, and AI analysis.',
    desc: 'Five-tab financial command center: P2 Financials shows live Period 2 (Feb 2026) actuals with contract-level P&L sorted by profitability, Income Statement summary, PM portfolio breakdown, and backlog analysis. AI Analyze button runs Claude on all financial data to identify money losers and recommend actions. Contract Waterfall, AOP Execution, AOP Capture, and Definitions tabs provide additional views.',
    components: ['P2 Financials tab (17 contracts, Income Statement, PM Summary, Backlog)', 'AI Analyze button (Claude-powered financial analysis)', 'Contract Waterfall tab', 'AOP Execution tab', 'AOP Capture tab', 'Definitions tab (81 terms, 7 categories)'],
    actions: ['AI Analyze — run Claude on all financial data', 'Switch between 5 financial tabs', 'View contract P&L sorted by profitability', 'Check PM portfolio performance'],
    tips: ['FY26 AOP target: $42.8M for OU3/Enable', 'P2 YTD: $5.2M revenue, -$468K gross profit, -9.0% margin', 'Biggest losers: MEG VR (-653%), BACNJ MR (-141%), F0209 OY3 (-33%)', 'Only profitable contract: Mega II OY5 (+23.5%)', '17 active contracts across 6 PMs'] },
  { id: 'platform-health', cat: 'ops', icon: '💡', name: 'Platform Health', nav: 'platform-health',
    tagline: 'System diagnostics, workflow status, and API health.',
    desc: 'Monitor GDA Command platform health including n8n workflow status, API endpoint connectivity, database metrics, and execution error rates.',
    components: ['Workflow status dashboard', 'API endpoint health', 'Error rate monitoring', 'System metrics'],
    actions: ['Run health check — test all systems'],
    tips: ['Check after any infrastructure changes', 'Error rates should be < 5/day'] },
  { id: 'prompt-architect', cat: 'ops', icon: '🧪', name: 'Prompt Architect', nav: 'prompt-architect',
    tagline: 'Design and test prompts for GDA AI workflows.',
    desc: 'Build, test, and iterate on prompts used across GDA Command. Compare outputs, save versions, and deploy optimized prompts to production workflows.',
    components: ['Prompt editor', 'Test execution', 'Output comparison', 'Version history'],
    actions: ['Generate — test a prompt', 'Save — store prompt version'],
    tips: ['Test prompts before deploying to workflows', 'Compare outputs across prompt versions'] },
];

function PlatformGuide() {
  const [search, setSearch] = useState('');
  const [activeCat, setActiveCat] = useState(null);
  const [expandedTool, setExpandedTool] = useState(null);

  const filtered = useMemo(() => {
    let tools = TOOLS;
    if (activeCat) tools = tools.filter(t => t.cat === activeCat);
    if (search.trim()) {
      const q = search.toLowerCase();
      tools = tools.filter(t => t.name.toLowerCase().includes(q) || t.tagline.toLowerCase().includes(q) || t.desc.toLowerCase().includes(q) || (t.components||[]).some(c => c.toLowerCase().includes(q)));
    }
    return tools;
  }, [search, activeCat]);

  const navigate = (tabId) => { if (window._gdaNavigate) window._gdaNavigate(tabId); };

  return (
    <div style={{ margin: 0, fontFamily: FONT }}>
      <div style={{ marginBottom: 32 }}>
        <h1 style={{ fontSize: 28, fontWeight: 800, color: NAVY, margin: '0 0 6px' }}>GDA Command — Help Center</h1>
        <p style={{ fontSize: 14, color: '#6B7280', margin: '0 0 20px' }}>22 integrated tools for federal acquisition intelligence. Search or browse by category.</p>
        <input
          value={search} onChange={e => setSearch(e.target.value)}
          placeholder="Search tools, features, or keywords..."
          style={{ width: '100%', maxWidth: 500, padding: '12px 16px', fontSize: 14, border: '2px solid ' + BORDER, borderRadius: 10, outline: 'none', fontFamily: FONT, transition: 'border-color 0.2s' }}
          onFocus={e => e.target.style.borderColor = ACCENT}
          onBlur={e => e.target.style.borderColor = BORDER}
        />
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: 16, marginBottom: 28, padding: '20px', background: '#F0F7FF', borderRadius: 12, border: '1px solid #D0E0F0' }}>
        <div style={{ textAlign: 'center', padding: '16px' }}>
          <div style={{ fontSize: 32, marginBottom: 8 }}>1️⃣</div>
          <div style={{ fontSize: 14, fontWeight: 700, color: NAVY, marginBottom: 4 }}>Check Your SITREP</div>
          <div style={{ fontSize: 12, color: '#6B7280', lineHeight: 1.5 }}>Start each day with the Daily SITREP for market intel, pipeline status, and recommended actions.</div>
          <button onClick={() => navigate('sitrep')} style={{ marginTop: 10, padding: '6px 14px', background: ACCENT, color: '#fff', border: 'none', borderRadius: 6, fontSize: 11, fontWeight: 600, cursor: 'pointer', fontFamily: FONT }}>Open SITREP →</button>
        </div>
        <div style={{ textAlign: 'center', padding: '16px' }}>
          <div style={{ fontSize: 32, marginBottom: 8 }}>2️⃣</div>
          <div style={{ fontSize: 14, fontWeight: 700, color: NAVY, marginBottom: 4 }}>Review Pipeline</div>
          <div style={{ fontSize: 12, color: '#6B7280', lineHeight: 1.5 }}>Check the Opportunity Tracker for new opps, score changes, and approaching deadlines.</div>
          <button onClick={() => navigate('opp-tracker')} style={{ marginTop: 10, padding: '6px 14px', background: ACCENT, color: '#fff', border: 'none', borderRadius: 6, fontSize: 11, fontWeight: 600, cursor: 'pointer', fontFamily: FONT }}>Open Tracker →</button>
        </div>
        <div style={{ textAlign: 'center', padding: '16px' }}>
          <div style={{ fontSize: 32, marginBottom: 8 }}>3️⃣</div>
          <div style={{ fontSize: 14, fontWeight: 700, color: NAVY, marginBottom: 4 }}>Execute Actions</div>
          <div style={{ fontSize: 12, color: '#6B7280', lineHeight: 1.5 }}>Use Capture Plans, OODA Loop, and Competitive Intel to advance your top opportunities.</div>
          <button onClick={() => navigate('capture-plan')} style={{ marginTop: 10, padding: '6px 14px', background: ACCENT, color: '#fff', border: 'none', borderRadius: 6, fontSize: 11, fontWeight: 600, cursor: 'pointer', fontFamily: FONT }}>Capture Plan →</button>
        </div>
      </div>

      <div style={{ marginBottom: 28, padding: '16px 20px', background: '#FFFBF0', borderRadius: 10, border: '1px solid #F0E6D0' }}>
        <div style={{ fontSize: 13, fontWeight: 700, color: NAVY, marginBottom: 10, display: 'flex', alignItems: 'center', gap: 8 }}>⌨️ Keyboard Shortcuts</div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(220px, 1fr))', gap: 8 }}>
          {[['/', 'Focus search bar'], ['Esc', 'Close expanded panels'], ['↑ ↓', 'Navigate sidebar tabs'], ['Ctrl+S', 'Browser save (no action)']].map(([k, d], i) => (
            <div key={i} style={{ display: 'flex', gap: 10, alignItems: 'center', fontSize: 12 }}>
              <kbd style={{ padding: '2px 8px', background: '#F3F4F6', border: '1px solid #D1D5DB', borderRadius: 4, fontSize: 11, fontWeight: 600, color: NAVY, fontFamily: 'monospace', minWidth: 36, textAlign: 'center' }}>{k}</kbd>
              <span style={{ color: '#6B7280' }}>{d}</span>
            </div>
          ))}
        </div>
      </div>

      <div style={{ display: 'flex', gap: 10, marginBottom: 28, flexWrap: 'wrap' }}>
        <button onClick={() => setActiveCat(null)} style={{ padding: '8px 16px', borderRadius: 20, border: '1px solid ' + (!activeCat ? NAVY : BORDER), background: !activeCat ? NAVY : '#fff', color: !activeCat ? '#fff' : NAVY, fontSize: 12, fontWeight: 600, cursor: 'pointer', fontFamily: FONT }}>All Tools</button>
        {CATEGORIES.map(c => (
          <button key={c.id} onClick={() => setActiveCat(activeCat === c.id ? null : c.id)} style={{ padding: '8px 16px', borderRadius: 20, border: '1px solid ' + (activeCat === c.id ? c.color : BORDER), background: activeCat === c.id ? c.color : '#fff', color: activeCat === c.id ? '#fff' : c.color, fontSize: 12, fontWeight: 600, cursor: 'pointer', fontFamily: FONT }}>{c.icon} {c.label}</button>
        ))}
      </div>

      {activeCat && (() => {
        const cat = CATEGORIES.find(c => c.id === activeCat);
        return <div style={{ padding: '16px 20px', background: cat.color + '08', borderLeft: '4px solid ' + cat.color, borderRadius: 8, marginBottom: 20, fontSize: 13, color: '#374151' }}>{cat.desc}</div>;
      })()}

      <div style={{ fontSize: 12, color: '#9CA3AF', marginBottom: 16 }}>{filtered.length} tool{filtered.length !== 1 ? 's' : ''}{search ? ' matching "' + search + '"' : ''}</div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(320px, 1fr))', gap: 16 }}>
        {filtered.map(tool => {
          const cat = CATEGORIES.find(c => c.id === tool.cat);
          const isExpanded = expandedTool === tool.id;
          return (
            <div key={tool.id} style={{ background: '#fff', border: '1px solid ' + (isExpanded ? cat.color : BORDER), borderRadius: 12, overflow: 'hidden', transition: 'all 0.2s', boxShadow: isExpanded ? '0 4px 20px rgba(0,0,0,0.08)' : '0 1px 3px rgba(0,0,0,0.04)' }}>
              <div onClick={() => setExpandedTool(isExpanded ? null : tool.id)} style={{ padding: '18px 20px', cursor: 'pointer' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 8 }}>
                  <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
                    <span style={{ fontSize: 24 }}>{tool.icon}</span>
                    <div>
                      <div style={{ fontSize: 15, fontWeight: 700, color: NAVY }}>{tool.name}</div>
                      <div style={{ fontSize: 10, color: cat.color, fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.5px' }}>{cat.label}</div>
                    </div>
                  </div>
                  <span style={{ fontSize: 11, color: '#9CA3AF' }}>{isExpanded ? '\u25BC' : '\u25B6'}</span>
                </div>
                <p style={{ fontSize: 13, color: '#374151', margin: 0, lineHeight: 1.5 }}>{tool.tagline}</p>
              </div>

              {isExpanded && (
                <div style={{ padding: '0 20px 20px', borderTop: '1px solid #F3F4F6' }}>
                  <p style={{ fontSize: 13, color: '#374151', lineHeight: 1.7, margin: '14px 0' }}>{tool.desc}</p>

                  {tool.components && tool.components.length > 0 && (
                    <div style={{ marginBottom: 14 }}>
                      <div style={{ fontSize: 11, fontWeight: 700, color: NAVY, textTransform: 'uppercase', letterSpacing: '0.5px', marginBottom: 8 }}>Components</div>
                      <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
                        {tool.components.map((c, i) => (
                          <span key={i} style={{ fontSize: 11, padding: '4px 10px', background: cat.color + '10', color: cat.color, borderRadius: 12, fontWeight: 500 }}>{c}</span>
                        ))}
                      </div>
                    </div>
                  )}

                  {tool.actions && tool.actions.length > 0 && (
                    <div style={{ marginBottom: 14 }}>
                      <div style={{ fontSize: 11, fontWeight: 700, color: NAVY, textTransform: 'uppercase', letterSpacing: '0.5px', marginBottom: 8 }}>Actions</div>
                      {tool.actions.map((a, i) => (
                        <div key={i} style={{ fontSize: 12, color: '#374151', padding: '3px 0', display: 'flex', alignItems: 'center', gap: 6 }}>
                          <span style={{ color: ACCENT, fontWeight: 700 }}>\u203A</span> {a}
                        </div>
                      ))}
                    </div>
                  )}

                  {tool.tips && tool.tips.length > 0 && (
                    <div style={{ marginBottom: 14 }}>
                      <div style={{ fontSize: 11, fontWeight: 700, color: NAVY, textTransform: 'uppercase', letterSpacing: '0.5px', marginBottom: 8 }}>Tips</div>
                      {tool.tips.map((t, i) => (
                        <div key={i} style={{ fontSize: 12, color: '#6B7280', padding: '2px 0' }}>\u25B8 {t}</div>
                      ))}
                    </div>
                  )}

                  <button onClick={() => navigate(tool.nav)} style={{ padding: '8px 18px', background: cat.color, color: '#fff', border: 'none', borderRadius: 6, fontSize: 12, fontWeight: 600, cursor: 'pointer', fontFamily: FONT }}>Open {tool.name} \u2192</button>
                </div>
              )}
            </div>
          );
        })}
      </div>

      <div style={{ marginTop: 40, padding: '20px', background: '#FAFBFC', borderRadius: 12, border: '1px solid ' + BORDER }}>
        <h3 style={{ fontSize: 15, fontWeight: 700, color: NAVY, margin: '0 0 8px' }}>Platform Architecture</h3>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 16, fontSize: 12, color: '#374151' }}>
          <div><div style={{ fontWeight: 700, color: NAVY, marginBottom: 4 }}>Frontend</div>React SPA \u00b7 Vite \u00b7 Recharts \u00b7 Inter font</div>
          <div><div style={{ fontWeight: 700, color: NAVY, marginBottom: 4 }}>Backend</div>n8n (120+ workflows) \u00b7 Postgres \u00b7 Pinecone</div>
          <div><div style={{ fontWeight: 700, color: NAVY, marginBottom: 4 }}>Intelligence</div>Anthropic Claude \u00b7 Tavily \u00b7 GovTribe MCP \u00b7 SAM.gov</div>
        </div>
      </div>
    </div>
  );
}

export default PlatformGuide;
