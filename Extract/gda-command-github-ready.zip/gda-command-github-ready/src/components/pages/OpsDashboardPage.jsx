import React, { useState, useEffect, useCallback, useRef, useMemo } from 'react';
import { ACCENT, NAVY, BG, WHITE, BORDER, FONT, N8N, AUTH, api, S, css, gdaNav, NAV_ITEMS, Spinner, Empty, Alert, PageHeader } from '../../lib/gda';
function OpsDashboard() {
  const [opsData, setOpsData] = useState(null);
  const [opsLoad, setOpsLoad] = useState(false);
  const [opsTab, setOpsTab] = useState('health');
  const OPS_TABS = [{id:'health',l:'System Health'},{id:'workflows',l:'Workflows'},{id:'deploys',l:'Deploy History'},{id:'ai',l:'AI Diagnostics'}];
  const [aiQ, setAiQ] = useState('');
  const [aiA, setAiA] = useState('');
  const [aiLoad, setAiLoad] = useState(false);
  useEffect(()=>{setOpsLoad(true);api.post('gda-ops-dashboard-data',{}).then(d=>setOpsData(d)).catch(()=>{}).finally(()=>setOpsLoad(false));},[]);
  const askAI = async () => { if(!aiQ.trim()) return; setAiLoad(true); try { const d = await api.post('gda-chat-v2',{message:'Operations diagnostic: '+aiQ}); setAiA(d.response||d.output||JSON.stringify(d)); } catch(e){ setAiA('Error: '+e.message); } setAiLoad(false); };
  const d = opsData || {};
  const health = d.health || [];
  const wfs = d.workflows || [];
  const deploys = d.deploys || [];
  const opsEmpty = health.length === 0 && wfs.length === 0 && deploys.length === 0 && !opsLoad;
  return (
    <div>
      <PageHeader title="Operations Dashboard" sub="System health, workflow stats, deploy history, and AI diagnostics" />
      <div style={{display:'flex',gap:4,marginBottom:14,flexWrap:'wrap',borderBottom:'1px solid '+BORDER,paddingBottom:6}}>
        {OPS_TABS.map(t=><button key={t.id} onClick={()=>setOpsTab(t.id)} style={{...S.nav(opsTab===t.id)}}>{t.l}</button>)}
      </div>
      {opsLoad && <div style={{color:ACCENT,fontSize:12}}>Loading ops data...</div>}
      {opsEmpty && opsTab!=='ai' && <div style={{...S.card,textAlign:'center',padding:40}}><div style={{fontSize:14,fontWeight:600,color:NAVY,marginBottom:8}}>No operational data available</div><div style={{fontSize:12,color:'#888',marginBottom:14}}>Connect the ops monitoring pipeline or refresh to retry.</div><button style={S.btn()} onClick={()=>{setOpsLoad(true);api.post('gda-ops-dashboard-data',{}).then(function(r){setOpsData(r);}).catch(function(){}).finally(function(){setOpsLoad(false);});}}>Refresh</button></div>}
      {opsTab==='health' && !opsEmpty && <div style={S.card}><div style={S.cardTitle}>System Health</div><table style={{width:'100%',borderCollapse:'collapse',fontSize:12}}><thead><tr><th style={S.th}>Service</th><th style={S.th}>Status</th><th style={S.th}>Uptime</th><th style={S.th}>Last Check</th></tr></thead><tbody>{health.map((h,i)=><tr key={i} style={{borderBottom:'1px solid #f0f0f0'}}><td style={{...S.td,fontWeight:600,color:NAVY}}>{h.name}</td><td style={S.td}>{h.status}</td><td style={S.td}>{h.uptime}</td><td style={{...S.td,color:'#888'}}>{h.last}</td></tr>)}</tbody></table><SourceTag url="https://n8n.csr-llc.tech" label="n8n" /></div>}
      {opsTab==='workflows' && !opsEmpty && <div style={S.card}><div style={S.cardTitle}>Top Workflows by Execution Count</div><table style={{width:'100%',borderCollapse:'collapse',fontSize:12}}><thead><tr><th style={S.th}>Workflow</th><th style={S.th}>Runs</th><th style={S.th}>Last Run</th><th style={S.th}>Status</th></tr></thead><tbody>{wfs.map((w,i)=><tr key={i} style={{borderBottom:'1px solid #f0f0f0'}}><td style={{...S.td,fontWeight:600,color:ACCENT}}>{w.name}</td><td style={{...S.td,fontWeight:700}}>{w.runs}</td><td style={{...S.td,color:'#888'}}>{w.last}</td><td style={S.td}>{w.status}</td></tr>)}</tbody></table><SourceTag url="https://n8n.csr-llc.tech" label="n8n" /></div>}
      {opsTab==='deploys' && !opsEmpty && <div style={S.card}><div style={S.cardTitle}>Recent Deploys (S-070)</div><table style={{width:'100%',borderCollapse:'collapse',fontSize:12}}><thead><tr><th style={S.th}>#</th><th style={S.th}>Commit</th><th style={S.th}>Description</th><th style={S.th}>Lines</th><th style={S.th}>Time</th><th style={S.th}>Status</th></tr></thead><tbody>{deploys.map((d,i)=><tr key={i} style={{borderBottom:'1px solid #f0f0f0'}}><td style={S.td}>{d.n}</td><td style={{...S.td,fontFamily:'monospace',color:ACCENT}}>{d.commit}</td><td style={{...S.td,maxWidth:200}}>{d.msg}</td><td style={S.td}>{d.lines}</td><td style={S.td}>{d.time}</td><td style={{...S.td,color:'#1a7a3a',fontWeight:600}}>{d.status}</td></tr>)}</tbody></table><SourceTag url="https://github.com/shawnseffernick175/gda-command" label="GitHub" /></div>}
      {opsTab==='ai' && <div style={S.card}><div style={S.cardTitle}>AI Diagnostics</div><div style={{...S.row(),gap:6,marginBottom:12}}><input style={S.input} value={aiQ} onChange={e=>setAiQ(e.target.value)} onKeyDown={e=>e.key==='Enter'&&askAI()} placeholder="Ask about system health, performance, errors..." /><button style={S.btn()} onClick={askAI} disabled={aiLoad}>{aiLoad?'...':'Diagnose'}</button></div>{aiA && <div style={{padding:12,background:'#f8f6f3',borderRadius:6,fontSize:12,lineHeight:1.7,whiteSpace:'pre-wrap',color:NAVY}}>{aiA}</div>}</div>}
    </div>
  );
}
export default OpsDashboard;