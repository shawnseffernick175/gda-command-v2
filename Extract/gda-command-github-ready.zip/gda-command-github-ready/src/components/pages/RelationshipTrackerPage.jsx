import React, { useState, useEffect, useCallback, useRef, useMemo } from 'react';
import { ACCENT, NAVY, BG, WHITE, BORDER, FONT, N8N, AUTH, api, S, css, gdaNav, NAV_ITEMS, Spinner, Empty, Alert, PageHeader } from '../../lib/gda';

function RelationshipTracker() {
  var _tab = useState('contacts'); var tab = _tab[0]; var setTab = _tab[1];
  var _contacts = useState([]); var contacts = _contacts[0]; var setContacts = _contacts[1];
  var _gaps = useState([]); var gaps = _gaps[0]; var setGaps = _gaps[1];
  var _loading = useState(true); var loading = _loading[0]; var setLoading = _loading[1];
  var _error = useState(''); var error = _error[0]; var setError = _error[1];
  var _expanded = useState(null); var expanded = _expanded[0]; var setExpanded = _expanded[1];
  var _showForm = useState(false); var showForm = _showForm[0]; var setShowForm = _showForm[1];
  var _form = useState({name:'',title:'',organization:'',agency:'',email:'',phone:'',relationship_strength:5,contact_frequency_days:30,notes:'',tags:'',gda_unit:'EIS'});
  var form = _form[0]; var setForm = _form[1];
  var _tpForm = useState({contact_id:'',contact_type:'meeting',summary:'',next_action:'',next_action_date:''});
  var tpForm = _tpForm[0]; var setTpForm = _tpForm[1];
  var _saving = useState(false); var saving = _saving[0]; var setSaving = _saving[1];
  var _toast = useState(''); var toast = _toast[0]; var setToast = _toast[1];

  function load() {
    setLoading(true);
    api.post('gda-relationship-tracker',{action:'list'}).then(function(r){
      setContacts(r.contacts||r.data||[]);setLoading(false);
    }).catch(function(e){setError('Failed: '+e.message);setLoading(false);});
  }
  function loadGaps() {
    api.post('gda-relationship-tracker',{action:'gaps'}).then(function(r){setGaps(r.gaps||r.data||[]);}).catch(function(){});
  }
  useEffect(function(){load();loadGaps();},[]);

  var overdue = contacts.filter(function(c){return c.status==='OVERDUE';}).length;
  var dueSoon = contacts.filter(function(c){return c.status==='DUE_SOON';}).length;
  var avgStrength = contacts.length > 0 ? Math.round(contacts.reduce(function(s,c){return s+(c.relationship_strength||0);},0)/contacts.length*10)/10 : 0;

  function submitContact() {
    setSaving(true);
    api.post('gda-relationship-tracker',Object.assign({action:'upsert'},form)).then(function(){
      setShowForm(false);setForm({name:'',title:'',organization:'',agency:'',email:'',phone:'',relationship_strength:5,contact_frequency_days:30,notes:'',tags:'',gda_unit:'EIS'});
      load();setToast('Contact saved');setTimeout(function(){setToast('');},3000);
    }).catch(function(e){setToast('Error: '+e.message);}).finally(function(){setSaving(false);});
  }
  function submitTouchpoint() {
    setSaving(true);
    api.post('gda-relationship-tracker',Object.assign({action:'touchpoint'},tpForm)).then(function(){
      setTpForm({contact_id:'',contact_type:'meeting',summary:'',next_action:'',next_action_date:''});
      load();loadGaps();setToast('Touchpoint logged');setTimeout(function(){setToast('');},3000);
    }).catch(function(e){setToast('Error: '+e.message);}).finally(function(){setSaving(false);});
  }

  var strengthColor = function(s){return s>=8?'#2F5C1F':s>=5?'#B06D32':'#DC2626';};
  var TABS = [{id:'contacts',label:'Contacts'},{id:'touchpoint',label:'Log Touchpoint'},{id:'gaps',label:'Gap Alerts'}];

  return React.createElement('div', null,
    React.createElement(PageHeader, {title:'Relationship Tracker', sub:'Contact management, touchpoint logging, and relationship health'}),
    toast && React.createElement('div',{style:{padding:'8px 16px',background:'#2F5C1F12',border:'1px solid #86EFAC',borderRadius:8,marginBottom:12,fontSize:12,color:'#2F5C1F',fontWeight:600}},toast),
    React.createElement('div',{style:{display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:10,marginBottom:16}},
      React.createElement('div',{style:{background:'#fff',border:'1px solid #E8ECF1',borderRadius:10,padding:'12px',textAlign:'center',borderTop:'3px solid '+NAVY}},
        React.createElement('div',{style:{fontSize:11,color:'#6B7280'}}, 'Total Contacts'),
        React.createElement('div',{style:{fontSize:24,fontWeight:700,color:NAVY}}, contacts.length)
      ),
      React.createElement('div',{style:{background:'#fff',border:'1px solid #E8ECF1',borderRadius:10,padding:'12px',textAlign:'center',borderTop:'3px solid #DC2626'}},
        React.createElement('div',{style:{fontSize:11,color:'#6B7280'}}, 'Overdue'),
        React.createElement('div',{style:{fontSize:24,fontWeight:700,color:'#DC2626'}}, overdue)
      ),
      React.createElement('div',{style:{background:'#fff',border:'1px solid #E8ECF1',borderRadius:10,padding:'12px',textAlign:'center',borderTop:'3px solid #B06D32'}},
        React.createElement('div',{style:{fontSize:11,color:'#6B7280'}}, 'Due Soon'),
        React.createElement('div',{style:{fontSize:24,fontWeight:700,color:'#B06D32'}}, dueSoon)
      ),
      React.createElement('div',{style:{background:'#fff',border:'1px solid #E8ECF1',borderRadius:10,padding:'12px',textAlign:'center',borderTop:'3px solid #2F5C1F'}},
        React.createElement('div',{style:{fontSize:11,color:'#6B7280'}}, 'Avg Strength'),
        React.createElement('div',{style:{fontSize:24,fontWeight:700,color:'#2F5C1F'}}, avgStrength+'/10')
      )
    ),
    React.createElement('div',{style:{display:'flex',gap:0,marginBottom:16}},
      TABS.map(function(t,ti){return React.createElement('button',{key:t.id,onClick:function(){setTab(t.id);},style:{padding:'9px 22px',fontSize:12,fontWeight:tab===t.id?700:400,color:tab===t.id?'#fff':NAVY,background:tab===t.id?ACCENT:'#fff',border:'1px solid '+(tab===t.id?ACCENT:BORDER),cursor:'pointer',borderRadius:ti===0?'6px 0 0 6px':ti===TABS.length-1?'0 6px 6px 0':'0'}},t.label);})
    ),
    tab==='contacts' && React.createElement('div',null,
      React.createElement('div',{style:{display:'flex',justifyContent:'flex-end',marginBottom:12}},
        React.createElement('button',{onClick:function(){setShowForm(true);},style:{background:ACCENT,color:'#fff',border:'none',borderRadius:6,padding:'8px 16px',fontSize:12,fontWeight:600,cursor:'pointer'}}, '+ Add Contact')
      ),
      loading && React.createElement('div',{style:{textAlign:'center',padding:20}},React.createElement(Spinner)),
      !loading && contacts.length===0 && React.createElement(Empty,{msg:'No contacts yet. Add your first contact.'}),
      !loading && React.createElement('div',{style:{display:'grid',gridTemplateColumns:'repeat(auto-fill,minmax(280px,1fr))',gap:10}},
        contacts.map(function(c,i){
          var isOpen = expanded === c.id;
          return React.createElement('div',{key:c.id||i,style:{background:'#fff',border:'1px solid #E8ECF1',borderRadius:8,padding:'12px',cursor:'pointer',borderLeft:'4px solid '+strengthColor(c.relationship_strength||0)},onClick:function(){setExpanded(isOpen?null:c.id);}},
            React.createElement('div',{style:{display:'flex',justifyContent:'space-between',alignItems:'center'}},
              React.createElement('div',null,
                React.createElement('div',{style:{fontSize:14,fontWeight:700,color:NAVY}},c.name||'Unknown'),
                React.createElement('div',{style:{fontSize:11,color:'#6B7280'}},c.title||''),
                React.createElement('div',{style:{fontSize:11,color:'#9CA3AF'}},(c.organization||'')+(c.agency?' - '+c.agency:''))
              ),
              React.createElement('div',{style:{textAlign:'right'}},
                React.createElement('div',{style:{fontSize:18,fontWeight:700,color:strengthColor(c.relationship_strength||0)}},(c.relationship_strength||0)+'/10'),
                React.createElement('div',{style:{fontSize:10,color:'#9CA3AF'}},c.last_contact_date?'Last: '+new Date(c.last_contact_date).toLocaleDateString():'No contact logged')
              )
            ),
            isOpen && React.createElement('div',{style:{marginTop:10,paddingTop:10,borderTop:'1px solid #E8ECF1',fontSize:12}},
              c.email && React.createElement('div',null,'Email: '+c.email),
              c.phone && React.createElement('div',null,'Phone: '+c.phone),
              c.gda_unit && React.createElement('div',null,'Unit: '+c.gda_unit),
              c.touchpoint_count!=null && React.createElement('div',null,'Touchpoints: '+c.touchpoint_count),
              c.notes && React.createElement('div',{style:{marginTop:6,color:'#6B7280',fontStyle:'italic'}},c.notes)
            )
          );
        })
      )
    ),
    tab==='touchpoint' && React.createElement('div',{style:{maxWidth:600}},
      React.createElement('div',{style:{background:'#fff',border:'1px solid #E8ECF1',borderRadius:10,padding:20}},
        React.createElement('div',{style:{fontSize:14,fontWeight:700,color:NAVY,marginBottom:12}}, 'Log Touchpoint'),
        React.createElement('select',{style:Object.assign({},S.input,{marginBottom:8}),value:tpForm.contact_id,onChange:function(e){setTpForm(Object.assign({},tpForm,{contact_id:e.target.value}));}},
          React.createElement('option',{value:''},'Select contact...'),
          contacts.map(function(c){return React.createElement('option',{key:c.id,value:c.id},c.name+' - '+c.organization);})
        ),
        React.createElement('select',{style:Object.assign({},S.input,{marginBottom:8}),value:tpForm.contact_type,onChange:function(e){setTpForm(Object.assign({},tpForm,{contact_type:e.target.value}));}},
          ['meeting','call','email','conference','other'].map(function(t){return React.createElement('option',{key:t,value:t},t.charAt(0).toUpperCase()+t.slice(1));})
        ),
        React.createElement('textarea',{style:Object.assign({},S.input,{marginBottom:8,minHeight:80}),placeholder:'Summary of interaction...',value:tpForm.summary,onChange:function(e){setTpForm(Object.assign({},tpForm,{summary:e.target.value}));}}),
        React.createElement('input',{style:Object.assign({},S.input,{marginBottom:8}),placeholder:'Next action...',value:tpForm.next_action,onChange:function(e){setTpForm(Object.assign({},tpForm,{next_action:e.target.value}));}}),
        React.createElement('input',{type:'date',style:Object.assign({},S.input,{marginBottom:12}),value:tpForm.next_action_date,onChange:function(e){setTpForm(Object.assign({},tpForm,{next_action_date:e.target.value}));}}),
        React.createElement('button',{onClick:submitTouchpoint,disabled:saving||!tpForm.contact_id,style:{background:ACCENT,color:'#fff',border:'none',borderRadius:6,padding:'10px 20px',fontSize:12,fontWeight:600,cursor:'pointer',opacity:saving||!tpForm.contact_id?0.5:1}},saving?'Saving...':'Log Touchpoint')
      )
    ),
    tab==='gaps' && React.createElement('div',null,
      gaps.length===0 && React.createElement(Empty,{msg:'No overdue or due-soon contacts. Relationships healthy.'}),
      gaps.map(function(g,i){
        var color = g.status==='OVERDUE'?'#DC2626':'#B06D32';
        return React.createElement('div',{key:i,style:{background:'#fff',border:'1px solid #E8ECF1',borderRadius:8,padding:'12px',marginBottom:8,borderLeft:'4px solid '+color}},
          React.createElement('div',{style:{display:'flex',justifyContent:'space-between',alignItems:'center'}},
            React.createElement('div',null,
              React.createElement('span',{style:{fontSize:10,fontWeight:700,color:color,textTransform:'uppercase'}},g.status||''),
              React.createElement('div',{style:{fontSize:14,fontWeight:600,color:NAVY}},g.name||'Unknown'),
              React.createElement('div',{style:{fontSize:11,color:'#6B7280'}},g.organization||'')
            ),
            React.createElement('div',{style:{textAlign:'right'}},
              React.createElement('div',{style:{fontSize:11,color:'#6B7280'}},g.days_since_contact!=null?g.days_since_contact+' days since contact':'Never contacted'),
              React.createElement('button',{onClick:function(){setTab('touchpoint');setTpForm(Object.assign({},tpForm,{contact_id:String(g.id||'')}));},style:{marginTop:4,fontSize:11,padding:'4px 10px',background:ACCENT,color:'#fff',border:'none',borderRadius:4,cursor:'pointer',fontWeight:600}},'Log Contact')
            )
          )
        );
      })
    ),
    showForm && React.createElement('div',{style:{position:'fixed',inset:0,background:'rgba(27,42,74,0.5)',zIndex:10000,display:'flex',alignItems:'center',justifyContent:'center'},onClick:function(e){if(e.target===e.currentTarget)setShowForm(false);}},
      React.createElement('div',{style:{background:'#fff',padding:24,borderRadius:12,maxWidth:480,width:'90%',maxHeight:'80vh',overflow:'auto'}},
        React.createElement('div',{style:{fontSize:16,fontWeight:700,color:NAVY,marginBottom:12}},'Add Contact'),
        [{k:'name',l:'Name',p:'Full name'},{k:'title',l:'Title',p:'Job title'},{k:'organization',l:'Organization',p:'Company or agency'},{k:'agency',l:'Agency',p:'Target agency'},{k:'email',l:'Email',p:'Email'},{k:'phone',l:'Phone',p:'Phone'}].map(function(f){
          return React.createElement('div',{key:f.k,style:{marginBottom:8}},
            React.createElement('div',{style:{fontSize:11,fontWeight:600,color:'#666',marginBottom:3}},f.l),
            React.createElement('input',{style:Object.assign({},S.input),placeholder:f.p,value:form[f.k],onChange:function(e){var n=Object.assign({},form);n[f.k]=e.target.value;setForm(n);}})
          );
        }),
        React.createElement('div',{style:{marginBottom:8}},
          React.createElement('div',{style:{fontSize:11,fontWeight:600,color:'#666',marginBottom:3}},'Strength (1-10): '+form.relationship_strength),
          React.createElement('input',{type:'range',min:1,max:10,value:form.relationship_strength,onChange:function(e){setForm(Object.assign({},form,{relationship_strength:parseInt(e.target.value)}));},style:{width:'100%'}})
        ),
        React.createElement('div',{style:{marginBottom:8}},
          React.createElement('div',{style:{fontSize:11,fontWeight:600,color:'#666',marginBottom:3}},'GDA Unit'),
          React.createElement('select',{style:S.input,value:form.gda_unit,onChange:function(e){setForm(Object.assign({},form,{gda_unit:e.target.value}));}},
            ['EIS','PD Systems','Riverstone'].map(function(u){return React.createElement('option',{key:u,value:u},u);})
          )
        ),
        React.createElement('textarea',{style:Object.assign({},S.input,{marginBottom:12,minHeight:60}),placeholder:'Notes...',value:form.notes,onChange:function(e){setForm(Object.assign({},form,{notes:e.target.value}));}}),
        React.createElement('div',{style:{display:'flex',gap:8}},
          React.createElement('button',{onClick:submitContact,disabled:saving||!form.name,style:{background:ACCENT,color:'#fff',border:'none',borderRadius:6,padding:'8px 20px',fontSize:12,fontWeight:600,cursor:'pointer'}},saving?'Saving...':'Save Contact'),
          React.createElement('button',{onClick:function(){setShowForm(false);},style:{background:'none',border:'1px solid #D1D5DB',borderRadius:6,padding:'8px 16px',fontSize:12,cursor:'pointer',color:'#6B7280'}},'Cancel')
        )
      )
    )
  );
}

export default RelationshipTracker;
