import React, { useState, useEffect, useCallback, useRef, useMemo } from 'react';
import { ACCENT, NAVY, BG, WHITE, BORDER, FONT, N8N, AUTH, api, S, css, gdaNav, NAV_ITEMS, Spinner, Empty, Alert, PageHeader } from '../../lib/gda';
function TradingChallenge() {
  const [account, setAccount] = React.useState({balance:100,peak_balance:100,total_trades:0,winning_trades:0,losing_trades:0,total_pnl:0,scorecard_count:0});
  const [trades, setTrades] = React.useState([]);
  const [ledger, setLedger] = React.useState([]);
  const [loading, setLoading] = React.useState(true);
  const [killing, setKilling] = React.useState(false);
  const [killMsg, setKillMsg] = React.useState('');
  const [activeTab, setActiveTab] = React.useState('scorecard');
  const [scanHistory, setScanHistory] = React.useState(null);
  const [scanLoading, setScanLoading] = React.useState(false);
  const [selectedDay, setSelectedDay] = React.useState('');

  const load = async () => {
    setLoading(true);
    try {
      const [acctRes, tradesRes, ledgerRes] = await Promise.all([
        api.post('gda-trade-account', {action:'get'}).catch(() => ({})),
        api.post('gda-trade-book', {action:'list'}).catch(() => []),
        api.post('gda-challenge-ledger', {action:'list'}).catch(() => [])
      ]);
      setAccount(acctRes.data || acctRes || {});
      var tb = tradesRes.data || tradesRes || [];
      setTrades(Array.isArray(tb) ? tb : []);
      var lb = ledgerRes.data || ledgerRes || [];
      setLedger(Array.isArray(lb) ? lb : []);
    } catch(e) { console.error(e); }
    setLoading(false);
  };

  React.useEffect(() => { load(); }, []);

  const fetchScanHistory = async () => {
    setScanLoading(true);
    try {
      const res = await api.post('gda-scan-history', {action:'get'});
      const d = res.data || res || {};
      setScanHistory(d);
      if (d.days && d.days.length > 0) setSelectedDay(d.days[0].date);
    } catch(e) { console.error('Scan history error:', e); }
    setScanLoading(false);
  };

  const killSwitch = async () => {
    if (!window.confirm('KILL SWITCH: Liquidate active position and halt engine?')) return;
    setKilling(true);
    try {
      await api.post('gda-challenge-ledger', {action:'kill'});
      setKillMsg('Kill switch executed.');
      await load();
    } catch(e) { setKillMsg('Error: ' + e.message); }
    setKilling(false);
  };

  const activeTrade = trades.find(t => t.status === 'Active');
  const closedTrades = trades.filter(t => t.status === 'Closed_Win' || t.status === 'Closed_Loss');
  const winRate = account.total_trades > 0 ? ((account.winning_trades / account.total_trades) * 100).toFixed(1) : '0.0';
  const closedWins = closedTrades.filter(t => t.status === 'Closed_Win');
  const closedLosses = closedTrades.filter(t => t.status === 'Closed_Loss');
  const avgWin = closedWins.length > 0
    ? (closedWins.reduce((a,t) => a + parseFloat(t.realized_pnl||0), 0) / closedWins.length).toFixed(2)
    : '0.00';
  const avgLoss = closedLosses.length > 0
    ? Math.abs(closedLosses.reduce((a,t) => a + parseFloat(t.realized_pnl||0), 0) / closedLosses.length).toFixed(2)
    : '0.00';
  const expectancy = account.total_trades > 0
    ? ((parseFloat(winRate)/100 * parseFloat(avgWin)) - ((1 - parseFloat(winRate)/100) * parseFloat(avgLoss))).toFixed(2)
    : '0.00';
  const drawdown = account.peak_balance > 0
    ? (((account.peak_balance - account.balance) / account.peak_balance) * 100).toFixed(1)
    : '0.0';
  const scorecardDone = trades.filter(t => t.scorecard_trade_num && (t.status === 'Closed_Win' || t.status === 'Closed_Loss')).length;

  const statusColor = s => ({Active:'#32448A',Closed_Win:'#2F5C1F',Closed_Loss:'#DC2626',Pending:'#9CA3AF'}[s] || '#9CA3AF');
  const statusBg = s => ({Active:'#EFF6FF',Closed_Win:'#2F5C1F12',Closed_Loss:'#FEF2F2',Pending:'#F9FAFB'}[s] || '#F9FAFB');
  const fmtPrice = v => v ? '$' + parseFloat(v).toFixed(2) : '—';

  if (loading) return <div style={{padding:40,textAlign:'center',color:'#6B7280'}}>Loading trading data...</div>;

  return (
    <div style={{padding:16,margin:0}}>
      {/* Header */}
      <div style={{display:'flex',justifyContent:'space-between',alignItems:'flex-start',marginBottom:20}}>
        <div>
          <div style={{fontSize:22,fontWeight:800,color:'#1B2A4A'}}>{'📈 GDA Trade Engine'}</div>
          <div style={{fontSize:12,color:'#6B7280',marginTop:2}}>{'Fixed Fractional Risk · 1% per trade · 1:2 min RR · 28-Trade Scorecard'}</div>
        </div>
        <div style={{display:'flex',gap:8}}>
          <button onClick={load} style={{padding:'8px 16px',background:'#1B2A4A',color:'#fff',border:'none',borderRadius:6,fontSize:12,fontWeight:600,cursor:'pointer'}}>Refresh</button>
          <button onClick={() => { if(!scanHistory) fetchScanHistory(); setActiveTab(activeTab==='scans'?'scorecard':'scans'); }} style={{padding:'8px 16px',background:activeTab==='scans'?'#32448A':'#4B5563',color:'#fff',border:'none',borderRadius:6,fontSize:12,fontWeight:600,cursor:'pointer'}}>{activeTab==='scans'?'Back':'Scan History'}</button>
          {activeTrade && <button onClick={killSwitch} disabled={killing} style={{padding:'8px 16px',background:'#DC2626',color:'#fff',border:'none',borderRadius:6,fontSize:12,fontWeight:700,cursor:'pointer'}}>{killing ? 'Executing...' : '🔴 KILL SWITCH'}</button>}
        </div>
      </div>

      {killMsg && <div style={{background:'#FEF2F2',border:'1px solid #DC2626',borderRadius:8,padding:'10px 16px',marginBottom:16,fontSize:13,color:'#DC2626'}}>{killMsg}</div>}

      {/* KPI Bar */}
      <div style={{display:'grid',gridTemplateColumns:'repeat(7,1fr)',gap:8,marginBottom:20}}>
        {[
          {l:'Balance',v:'$'+parseFloat(account.balance||100).toFixed(2),c:'#1B2A4A'},
          {l:'Total P&L',v:(parseFloat(account.total_pnl||0)>=0?'+':'')+'$'+parseFloat(Math.abs(account.total_pnl||0)).toFixed(2),c:parseFloat(account.total_pnl||0)>=0?'#2F5C1F':'#DC2626'},
          {l:'Win Rate',v:winRate+'%',c:'#1B2A4A'},
          {l:'Expectancy',v:'$'+expectancy,c:parseFloat(expectancy)>=0?'#2F5C1F':'#DC2626'},
          {l:'Drawdown',v:drawdown+'%',c:parseFloat(drawdown)>10?'#DC2626':'#6B7280'},
          {l:'Trades',v:account.total_trades||0,c:'#1B2A4A'},
          {l:'Scorecard',v:scorecardDone+'/28',c:'#D14A2A'}
        ].map((k,i) => (
          <div key={i} style={{background:'#fff',border:'1px solid #E5E7EB',borderRadius:8,padding:'10px 8px',textAlign:'center'}}>
            <div style={{fontSize:16,fontWeight:800,color:k.c}}>{k.v}</div>
            <div style={{fontSize:9,color:'#6B7280',fontWeight:600,textTransform:'uppercase',marginTop:2}}>{k.l}</div>
          </div>
        ))}
      </div>

      {/* Active Trade Banner */}
      {activeTrade && (
        <div style={{background:'#EFF6FF',border:'2px solid #32448A',borderRadius:10,padding:'16px 20px',marginBottom:20}}>
          <div style={{fontSize:13,fontWeight:700,color:'#32448A',marginBottom:10}}>{'🔵 ACTIVE — '}{activeTrade.symbol}{activeTrade.scorecard_trade_num ? ' · Scorecard #'+activeTrade.scorecard_trade_num : ''}</div>
          <div style={{display:'grid',gridTemplateColumns:'repeat(6,1fr)',gap:12,marginBottom:8}}>
            {[
              {l:'Entry',v:fmtPrice(activeTrade.entry_price)},
              {l:'Stop Loss',v:fmtPrice(activeTrade.stop_loss_price)},
              {l:'Take Profit',v:fmtPrice(activeTrade.take_profit_price)},
              {l:'Shares',v:activeTrade.shares||'—'},
              {l:'Risk',v:activeTrade.risk_amount_usd ? '$'+parseFloat(activeTrade.risk_amount_usd).toFixed(2) : '—'},
              {l:'R:R',v:activeTrade.target_rr ? activeTrade.target_rr+'x' : '—'}
            ].map((f,i) => (
              <div key={i}>
                <div style={{fontSize:10,color:'#6B7280',textTransform:'uppercase',fontWeight:600}}>{f.l}</div>
                <div style={{fontSize:15,fontWeight:700,color:'#1B2A4A',marginTop:2}}>{f.v}</div>
              </div>
            ))}
          </div>
          {activeTrade.ai_stop_rationale && <div style={{fontSize:11,color:'#374151',fontStyle:'italic',marginBottom:4}}>{'Stop rationale: '}{activeTrade.ai_stop_rationale}</div>}
          {activeTrade.ai_reasoning && <div style={{fontSize:11,color:'#374151',fontStyle:'italic'}}>{'"'}{activeTrade.ai_reasoning}{'"'}</div>}
        </div>
      )}

      {/* Tabs */}
      <div style={{display:'flex',gap:0,marginBottom:16}}>
        {['scorecard','history','stats'].map((t,i) => (
          <button key={t} onClick={() => setActiveTab(t)} style={{padding:'8px 20px',fontSize:12,fontWeight:activeTab===t?700:400,color:activeTab===t?'#fff':'#1B2A4A',background:activeTab===t?'#1B2A4A':'#fff',border:'1px solid #E5E7EB',cursor:'pointer',borderRadius:i===0?'6px 0 0 6px':i===2?'0 6px 6px 0':'0'}}>
            {t==='scorecard'?'28-Trade Scorecard':t==='history'?'Trade History':'Performance Stats'}
          </button>
        ))}
      </div>

      {/* Scorecard Tab */}
      {activeTab==='scorecard' && (
        <div>
          <div style={{marginBottom:12}}>
            <div style={{background:'#F3F4F6',borderRadius:999,height:10,overflow:'hidden'}}>
              <div style={{background:'#2F5C1F',width:(scorecardDone/28*100)+'%',height:'100%',borderRadius:999}} />
            </div>
            <div style={{fontSize:11,color:'#6B7280',marginTop:4}}>{scorecardDone} of 28 scorecard trades complete</div>
          </div>
          <div style={{background:'#fff',border:'1px solid #E5E7EB',borderRadius:10,overflow:'hidden'}}>
            <table style={{width:'100%',borderCollapse:'collapse'}}>
              <thead>
                <tr style={{background:'#F9FAFB'}}>
                  {['#','Symbol','Entry','SL','TP','Shares','Risk','R:R','Fill','P&L','Status'].map(h => (
                    <th key={h} style={{padding:'9px 10px',fontSize:10,fontWeight:700,color:'#6B7280',textAlign:'left',textTransform:'uppercase',borderBottom:'1px solid #E5E7EB'}}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {trades.filter(t => t.scorecard_trade_num).sort((a,b) => a.scorecard_trade_num - b.scorecard_trade_num).map((t,i) => (
                  <tr key={i} style={{borderBottom:'1px solid #F3F4F6',background:statusBg(t.status)}}>
                    <td style={{padding:'8px 10px',fontSize:12,fontWeight:700,color:'#1B2A4A'}}>#{t.scorecard_trade_num}</td>
                    <td style={{padding:'8px 10px',fontSize:12,fontWeight:600}}>{t.symbol||'—'}</td>
                    <td style={{padding:'8px 10px',fontSize:12}}>{fmtPrice(t.entry_price)}</td>
                    <td style={{padding:'8px 10px',fontSize:12,color:'#DC2626'}}>{fmtPrice(t.stop_loss_price)}</td>
                    <td style={{padding:'8px 10px',fontSize:12,color:'#2F5C1F'}}>{fmtPrice(t.take_profit_price)}</td>
                    <td style={{padding:'8px 10px',fontSize:12}}>{t.shares||'—'}</td>
                    <td style={{padding:'8px 10px',fontSize:12}}>{t.risk_amount_usd ? '$'+parseFloat(t.risk_amount_usd).toFixed(2) : '—'}</td>
                    <td style={{padding:'8px 10px',fontSize:12}}>{t.target_rr ? t.target_rr+'x' : '—'}</td>
                    <td style={{padding:'8px 10px',fontSize:12}}>{fmtPrice(t.fill_price)}</td>
                    <td style={{padding:'8px 10px',fontSize:12,fontWeight:600,color:parseFloat(t.realized_pnl||0)>=0?'#2F5C1F':'#DC2626'}}>{t.realized_pnl ? (parseFloat(t.realized_pnl)>=0?'+':'') + parseFloat(t.realized_pnl).toFixed(2) : '—'}</td>
                    <td style={{padding:'8px 10px'}}><span style={{padding:'2px 8px',borderRadius:10,fontSize:10,fontWeight:700,background:statusBg(t.status),color:statusColor(t.status)}}>{t.status}</span></td>
                  </tr>
                ))}
                {trades.filter(t => t.scorecard_trade_num).length === 0 && (
                  <tr><td colSpan={11} style={{padding:'30px',textAlign:'center',color:'#9CA3AF',fontSize:13}}>No scorecard trades yet. Engine fires next market open.</td></tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* History Tab */}
      {activeTab==='history' && (
        <div style={{background:'#fff',border:'1px solid #E5E7EB',borderRadius:10,overflow:'hidden'}}>
          <table style={{width:'100%',borderCollapse:'collapse'}}>
            <thead>
              <tr style={{background:'#F9FAFB'}}>
                {['Symbol','Entry','SL','TP','Shares','Risk','R:R','Fill','P&L','Opened','Status'].map(h => (
                  <th key={h} style={{padding:'9px 10px',fontSize:10,fontWeight:700,color:'#6B7280',textAlign:'left',textTransform:'uppercase',borderBottom:'1px solid #E5E7EB'}}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {[...trades].sort((a,b) => new Date(b.created_at||0) - new Date(a.created_at||0)).map((t,i) => (
                <tr key={i} style={{borderBottom:'1px solid #F3F4F6',background:statusBg(t.status)}}>
                  <td style={{padding:'8px 10px',fontSize:12,fontWeight:600}}>{t.symbol||'—'}</td>
                  <td style={{padding:'8px 10px',fontSize:12}}>{fmtPrice(t.entry_price)}</td>
                  <td style={{padding:'8px 10px',fontSize:12,color:'#DC2626'}}>{fmtPrice(t.stop_loss_price)}</td>
                  <td style={{padding:'8px 10px',fontSize:12,color:'#2F5C1F'}}>{fmtPrice(t.take_profit_price)}</td>
                  <td style={{padding:'8px 10px',fontSize:12}}>{t.shares||'—'}</td>
                  <td style={{padding:'8px 10px',fontSize:12}}>{t.risk_amount_usd ? '$'+parseFloat(t.risk_amount_usd).toFixed(2) : '—'}</td>
                  <td style={{padding:'8px 10px',fontSize:12}}>{t.target_rr ? t.target_rr+'x' : '—'}</td>
                  <td style={{padding:'8px 10px',fontSize:12}}>{fmtPrice(t.fill_price)}</td>
                  <td style={{padding:'8px 10px',fontSize:12,fontWeight:600,color:parseFloat(t.realized_pnl||0)>=0?'#2F5C1F':'#DC2626'}}>{t.realized_pnl ? (parseFloat(t.realized_pnl)>=0?'+':'') + parseFloat(t.realized_pnl).toFixed(2) : '—'}</td>
                  <td style={{padding:'8px 10px',fontSize:11,color:'#6B7280'}}>{t.opened_at ? new Date(t.opened_at).toLocaleDateString() : '—'}</td>
                  <td style={{padding:'8px 10px'}}><span style={{padding:'2px 8px',borderRadius:10,fontSize:10,fontWeight:700,background:statusBg(t.status),color:statusColor(t.status)}}>{t.status}</span></td>
                </tr>
              ))}
              {trades.length === 0 && <tr><td colSpan={11} style={{padding:'30px',textAlign:'center',color:'#9CA3AF',fontSize:13}}>No trades recorded yet.</td></tr>}
            </tbody>
          </table>
        </div>
      )}

      {/* Stats Tab */}
      {activeTab==='stats' && (
        <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:16}}>
          <div style={{background:'#fff',border:'1px solid #E5E7EB',borderRadius:10,padding:20}}>
            <div style={{fontSize:14,fontWeight:700,color:'#1B2A4A',marginBottom:16}}>Performance Metrics</div>
            {[
              {l:'Total Trades',v:account.total_trades||0},
              {l:'Winning Trades',v:account.winning_trades||0},
              {l:'Losing Trades',v:account.losing_trades||0},
              {l:'Win Rate',v:winRate+'%'},
              {l:'Avg Win',v:'$'+avgWin},
              {l:'Avg Loss',v:'$'+avgLoss},
              {l:'Expectancy per Trade',v:'$'+expectancy},
              {l:'Total P&L',v:(parseFloat(account.total_pnl||0)>=0?'+':'')+'$'+parseFloat(Math.abs(account.total_pnl||0)).toFixed(2)},
              {l:'Max Drawdown',v:drawdown+'%'},
              {l:'Peak Balance',v:'$'+parseFloat(account.peak_balance||100).toFixed(2)},
              {l:'Current Balance',v:'$'+parseFloat(account.balance||100).toFixed(2)},
            ].map((r,i) => (
              <div key={i} style={{display:'flex',justifyContent:'space-between',padding:'8px 0',borderBottom:'1px solid #F3F4F6'}}>
                <span style={{fontSize:12,color:'#6B7280'}}>{r.l}</span>
                <span style={{fontSize:12,fontWeight:700,color:'#1B2A4A'}}>{r.v}</span>
              </div>
            ))}
          </div>
          <div style={{background:'#fff',border:'1px solid #E5E7EB',borderRadius:10,padding:20}}>
            <div style={{fontSize:14,fontWeight:700,color:'#1B2A4A',marginBottom:16}}>System Rules</div>
            {[
              {l:'Risk per trade',v:'1% of balance'},
              {l:'Min R:R ratio',v:'2.0x'},
              {l:'Confidence threshold',v:'80%'},
              {l:'Gap requirement',v:'8%+'},
              {l:'Rel volume requirement',v:'2.5x+'},
              {l:'VWAP condition',v:'Above VWAP'},
              {l:'Overnight holds',v:'Not allowed'},
              {l:'EOD force close',v:'3:45 PM ET'},
              {l:'Stop type',v:'Structural (not %)'},
              {l:'Position sizing',v:'Fixed fractional'},
              {l:'Exchange',v:'Schwab (NYSE/NASDAQ)'},
              {l:'Scorecard length',v:'28 trades'},
            ].map((r,i) => (
              <div key={i} style={{display:'flex',justifyContent:'space-between',padding:'8px 0',borderBottom:'1px solid #F3F4F6'}}>
                <span style={{fontSize:12,color:'#6B7280'}}>{r.l}</span>
                <span style={{fontSize:12,fontWeight:700,color:'#1B2A4A'}}>{r.v}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Scan History Panel */}
      {activeTab==='scans' && (
        <div style={{marginTop:16}}>
          <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:12}}>
            <div style={{fontSize:16,fontWeight:700,color:'#1B2A4A'}}>Engine Scan History</div>
            <div style={{display:'flex',gap:8,alignItems:'center'}}>
              <select value={selectedDay} onChange={e=>setSelectedDay(e.target.value)} style={{padding:'6px 12px',borderRadius:6,border:'1px solid #D1D5DB',fontSize:12,fontWeight:600}}>
                {scanHistory && scanHistory.days && scanHistory.days.map(d => <option key={d.date} value={d.date}>{d.date} ({d.scans.length} scans, {d.signal_count} signals)</option>)}
              </select>
              <button onClick={fetchScanHistory} style={{padding:'6px 12px',background:'#1B2A4A',color:'#fff',border:'none',borderRadius:6,fontSize:11,cursor:'pointer'}}>{scanLoading?'Loading...':'Refresh'}</button>
            </div>
          </div>
          {scanLoading && <div style={{padding:20,textAlign:'center',color:'#6B7280'}}>Loading scan history...</div>}
          {scanHistory && scanHistory.days && scanHistory.days.filter(d=>d.date===selectedDay).map(day => (
            <div key={day.date}>
              <div style={{display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:8,marginBottom:12}}>
                <div style={{background:'#F3F4F6',borderRadius:8,padding:'10px 14px',textAlign:'center'}}><div style={{fontSize:20,fontWeight:800,color:'#1B2A4A'}}>{day.scans.length}</div><div style={{fontSize:10,color:'#6B7280'}}>SCANS</div></div>
                <div style={{background:'#2F5C1F12',borderRadius:8,padding:'10px 14px',textAlign:'center'}}><div style={{fontSize:20,fontWeight:800,color:'#2F5C1F'}}>{day.go_count}</div><div style={{fontSize:10,color:'#6B7280'}}>GREEN</div></div>
                <div style={{background:'#FEF2F2',borderRadius:8,padding:'10px 14px',textAlign:'center'}}><div style={{fontSize:20,fontWeight:800,color:'#DC2626'}}>{day.nogo_count}</div><div style={{fontSize:10,color:'#6B7280'}}>NO-GO</div></div>
                <div style={{background:'#EFF6FF',borderRadius:8,padding:'10px 14px',textAlign:'center'}}><div style={{fontSize:20,fontWeight:800,color:'#32448A'}}>{day.signal_count}</div><div style={{fontSize:10,color:'#6B7280'}}>SIGNALS</div></div>
              </div>
              {day.scans.map((scan,si) => (
                <div key={si} style={{background:'#fff',border:'1px solid #E5E7EB',borderRadius:8,padding:'12px 16px',marginBottom:8}}>
                  <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:8}}>
                    <div style={{fontSize:12,fontWeight:700,color:'#1B2A4A'}}>Scan #{si+1} - {new Date(scan.time).toLocaleTimeString('en-US',{hour:'2-digit',minute:'2-digit',hour12:true})}</div>
                    <div style={{fontSize:11,color:'#6B7280'}}>{scan.signal_count} signal{scan.signal_count!==1?'s':''} found</div>
                  </div>
                  {scan.engine_result && <div style={{fontSize:11,color:scan.engine_result.symbol==='NO_GO'?'#DC2626':'#2F5C1F',background:scan.engine_result.symbol==='NO_GO'?'#FEF2F2':'#2F5C1F12',padding:'6px 10px',borderRadius:4,marginBottom:8}}>{scan.engine_result.symbol==='NO_GO'?'NO-GO: ':'GO: '}{scan.engine_result.reason||''}</div>}
                  {scan.top_signals.length>0 && <div style={{display:'flex',flexWrap:'wrap',gap:6}}>{scan.top_signals.map((sig,j)=>(
                    <div key={j} style={{background:sig.tier==='GREEN'?'#2F5C1F12':sig.tier==='YELLOW'?'#B06D3212':'#FEF2F2',border:'1px solid '+(sig.tier==='GREEN'?'#BBF7D0':sig.tier==='YELLOW'?'#FDE68A':'#FECACA'),borderRadius:6,padding:'4px 10px',fontSize:11}}>
                      <span style={{fontWeight:700}}>{sig.symbol}</span> <span style={{color:'#6B7280'}}>{sig.confidence}%</span> <span style={{color:sig.tier==='GREEN'?'#2F5C1F':sig.tier==='YELLOW'?'#B06D32':'#DC2626',fontWeight:600}}>{sig.tier}</span>
                    </div>
                  ))}</div>}
                  {scan.top_signals.length===0 && <div style={{fontSize:11,color:'#9CA3AF',fontStyle:'italic'}}>No setups met criteria (gap 8%+, rel vol 2.5x+, above VWAP)</div>}
                </div>
              ))}
            </div>
          ))}
          {!scanHistory && !scanLoading && <div style={{padding:20,textAlign:'center',color:'#9CA3AF'}}>Click Refresh to load scan history</div>}
        </div>
      )}
    </div>
  );
}
export default TradingChallenge;