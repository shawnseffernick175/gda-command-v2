import React, { useState, useEffect } from 'react';
const N8N='/api', AUTH={'Content-Type':'application/json'}, ACCENT='#D14A2A', NAVY='#1a2744', WHITE='#ffffff', BORDER='#e0e0e0';
const api={post:async(p,b={})=>{const r=await fetch(N8N+'/'+p,{method:'POST',headers:AUTH,body:JSON.stringify(b)});if(!r.ok)throw new Error(r.status);const t=await r.text();return t.trim()?JSON.parse(t):{}}};
const S={card:{background:WHITE,border:'1px solid '+BORDER,borderRadius:8,padding:'16px 20px',marginBottom:14},th:{padding:'8px 12px',textAlign:'left',fontSize:10,fontWeight:700,color:'#777',letterSpacing:'0.4px',textTransform:'uppercase',borderBottom:'1px solid '+BORDER,background:'#fafafa'},td:{padding:'9px 12px',borderBottom:'1px solid #f0f0f0',fontSize:12},btn:(v='primary')=>({padding:'8px 16px',borderRadius:6,border:'none',cursor:'pointer',fontSize:12,fontWeight:600,background:v==='primary'?ACCENT:'#eee',color:v==='primary'?'#fff':NAVY}),badge:(c='gray')=>({display:'inline-block',padding:'2px 8px',borderRadius:10,fontSize:10,fontWeight:600,background:c==='green'?'#2F5C1F15':c==='red'?'#ffebe6':c==='blue'?'#e6f0ff':'#f4f5f7',color:c==='green'?'#2F5C1F':c==='red'?'#bf2600':c==='blue'?'#32448A':'#555'}),input:{width:'100%',padding:'8px 10px',border:'1px solid '+BORDER,borderRadius:6,fontSize:12,outline:'none',boxSizing:'border-box'}};

export default function TeamingFinder() {
  const [partners, setPartners] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showAdd, setShowAdd] = useState(false);
  const [form, setForm] = useState({company_name:'',uei:'',size_status:'Small',naics_codes:'',core_capabilities:'',relationship_strength:'New',nda_status:'None',notes:''});

  const load = () => api.post('gda-teaming',{auth_key:'gda-api-2026-f584dae2',action:'list'}).then(r=>{setPartners(r.partners||[]);setLoading(false)}).catch(()=>setLoading(false));
  useEffect(()=>{load()},[]);

  const save = async () => {
    await api.post('gda-teaming',{auth_key:'gda-api-2026-f584dae2',action:'upsert',...form});
    setShowAdd(false); setForm({company_name:'',uei:'',size_status:'Small',naics_codes:'',core_capabilities:'',relationship_strength:'New',nda_status:'None',notes:''}); load();
  };

  const relColor = r => r==='Strong'?'green':r==='Active'?'blue':r==='Warm'?'orange':'gray';

  if(loading) return React.createElement('div',{style:{padding:40,textAlign:'center',color:'#aaa'}},'Loading...');
  return React.createElement('div',null,
    React.createElement('div',{style:{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:18}},
      React.createElement('div',null,
        React.createElement('div',{style:{fontSize:20,fontWeight:700,color:NAVY}},'Teaming Partner Finder'),
        React.createElement('div',{style:{fontSize:12,color:'#666',marginTop:4}},'Identify, qualify, and track teaming partners for capture campaigns')
      ),
      React.createElement('button',{onClick:()=>setShowAdd(!showAdd),style:S.btn()},showAdd?'Cancel':'+ Add Partner')
    ),
    showAdd && React.createElement('div',{style:{...S.card,background:'#fafafa'}},
      React.createElement('div',{style:{display:'grid',gridTemplateColumns:'1fr 1fr 1fr',gap:10}},
        ['company_name','uei','naics_codes','core_capabilities','notes'].map(k=>
          React.createElement('div',{key:k},React.createElement('label',{style:{fontSize:10,color:'#777',display:'block',marginBottom:2}},k.replace(/_/g,' ')),
            React.createElement('input',{style:S.input,value:form[k],onChange:e=>setForm({...form,[k]:e.target.value})})))
      ),
      React.createElement('button',{onClick:save,style:{...S.btn(),marginTop:10}},'Save Partner')
    ),
    React.createElement('div',{style:S.card},
      React.createElement('table',{style:{width:'100%',borderCollapse:'collapse'}},
        React.createElement('thead',null,React.createElement('tr',null,
          ['Company','UEI','Size','NAICS','Capabilities','Strength','NDA','Notes'].map(h=>React.createElement('th',{key:h,style:S.th},h)))),
        React.createElement('tbody',null,partners.map((p,i)=>React.createElement('tr',{key:p.id||i},
          React.createElement('td',{style:{...S.td,fontWeight:600,color:NAVY}},p.company_name),
          React.createElement('td',{style:{...S.td,fontFamily:'monospace',fontSize:10}},p.uei),
          React.createElement('td',{style:S.td},React.createElement('span',{style:S.badge(p.size_status==='Small'?'green':'gray')},p.size_status)),
          React.createElement('td',{style:{...S.td,fontSize:10}},p.naics_codes),
          React.createElement('td',{style:{...S.td,fontSize:11,maxWidth:160}},p.core_capabilities),
          React.createElement('td',{style:S.td},React.createElement('span',{style:S.badge(relColor(p.relationship_strength))},p.relationship_strength)),
          React.createElement('td',{style:S.td},React.createElement('span',{style:S.badge(p.nda_status==='Executed'?'green':'gray')},p.nda_status)),
          React.createElement('td',{style:{...S.td,fontSize:11,color:'#666',maxWidth:180}},p.notes)
        )))
      ),
      partners.length===0&&React.createElement('div',{style:{padding:20,textAlign:'center',color:'#aaa'}},'No teaming partners tracked yet')
    )
  );
}
