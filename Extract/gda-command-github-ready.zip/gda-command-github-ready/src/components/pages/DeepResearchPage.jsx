import React, { useState, useEffect } from 'react';
import { ACCENT, NAVY, BG, WHITE, BORDER, FONT, api, S, Spinner, saveAction } from '../../lib/gda';

var ENDPOINT = '/api/gda-deep-research';
var HISTORY_ENDPOINT = '/api/gda-deep-research-history';
var TYPES = ['competitor','program','agency','opportunity'];

function Section(props) {
  var _s = useState(false); var open = _s[0]; var setOpen = _s[1];
  var h = React.createElement;
  return h('div', { style: { marginBottom: 10 } },
    h('button', {
      onClick: function() { setOpen(!open); },
      style: { width: '100%', display: 'flex', alignItems: 'center', justifyContent: 'space-between', background: '#fff', border: '1px solid ' + BORDER, borderRadius: open ? '8px 8px 0 0' : 8, padding: '10px 14px', cursor: 'pointer', fontFamily: FONT, color: NAVY, fontSize: 13, fontWeight: 600 }
    }, props.title, h('span', { style: { fontSize: 10, color: '#9CA3AF' } }, open ? '\u25BC' : '\u25B6')),
    open && h('div', { style: { background: '#fff', border: '1px solid ' + BORDER, borderTop: 'none', borderRadius: '0 0 8px 8px', padding: 14 } }, props.children)
  );
}

export default function DeepResearchPage() {
  var h = React.createElement;
  var _target = useState(''); var target = _target[0]; var setTarget = _target[1];
  var _type = useState('competitor'); var rType = _type[0]; var setType = _type[1];
  var _oppId = useState(''); var oppId = _oppId[0]; var setOppId = _oppId[1];
  var _loading = useState(false); var loading = _loading[0]; var setLoading = _loading[1];
  var _result = useState(null); var result = _result[0]; var setResult = _result[1];
  var _report = useState(null); var report = _report[0]; var setReport = _report[1];
  var _error = useState(''); var error = _error[0]; var setError = _error[1];
  var _history = useState([]); var history = _history[0]; var setHistory = _history[1];
  var _histLoading = useState(true); var histLoading = _histLoading[0]; var setHistLoading = _histLoading[1];

  useEffect(function() {
    fetch(HISTORY_ENDPOINT, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{}' })
      .then(function(r) { return r.json(); })
      .then(function(d) { setHistory(Array.isArray(d) ? d : []); setHistLoading(false); })
      .catch(function() { setHistLoading(false); });
  }, []);

  var runResearch = function() {
    if (!target.trim()) return;
    setLoading(true); setError(''); setResult(null); setReport(null);
    var payload = { target: target.trim(), type: rType };
    if (oppId.trim()) payload.opp_id = oppId.trim();
    fetch(ENDPOINT, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) })
      .then(function(r) { return r.json(); })
      .then(function(d) {
        setResult(d);
        if (d.report) setReport(d.report);
        setLoading(false);
        saveAction('deep-research', 'research', target.trim(), {target: target.trim(), depth: rType, focus: rType}, {summary: (d.report || d.executive_summary || '').substring(0, 2000)});
        // Refresh history
        fetch(HISTORY_ENDPOINT, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{}' })
          .then(function(r) { return r.json(); })
          .then(function(d2) { setHistory(Array.isArray(d2) ? d2 : []); });
      })
      .catch(function(e) { setError(e.message || 'Research failed'); setLoading(false); });
  };

  var confColor = function(c) { return c === 'HIGH' ? '#2F5C1F' : c === 'MEDIUM' ? '#B06D32' : '#DC2626'; };
  var fmtDate = function(d) { if (!d) return ''; var dt = new Date(d); return dt.toLocaleDateString() + ' ' + dt.toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'}); };

  // Render report sections
  var renderReport = function() {
    if (!result) return null;
    var rpt = report || {};
    var exec_summary = result.executive_summary || rpt.executive_summary || '';
    var confidence = result.confidence || rpt.confidence || 'UNKNOWN';
    var sources = result.sources_used || rpt.sources_used || 0;
    var followUp = result.follow_up_queries || rpt.follow_up_queries || [];
    var ci = rpt.competitive_intel || {};
    var capture = rpt.capture_implications || {};
    var findings = rpt.key_findings || [];

    return h('div', { style: { marginTop: 20 } },
      // Executive Summary
      h('div', { style: { background: '#fff', border: '1px solid ' + BORDER, borderRadius: 10, padding: 20, marginBottom: 14, borderLeft: '4px solid ' + ACCENT } },
        h('div', { style: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 } },
          h('div', { style: { fontSize: 16, fontWeight: 700, color: NAVY } }, 'Executive Summary'),
          h('div', { style: { display: 'flex', gap: 8 } },
            h('span', { style: { padding: '3px 10px', borderRadius: 10, fontSize: 10, fontWeight: 700, background: confColor(confidence) + '15', color: confColor(confidence) } }, confidence + ' confidence'),
            h('span', { style: { padding: '3px 10px', borderRadius: 10, fontSize: 10, fontWeight: 600, background: '#3B82F615', color: '#3B82F6' } }, sources + ' sources')
          )
        ),
        h('div', { style: { fontSize: 13, color: '#374151', lineHeight: 1.7 } }, exec_summary)
      ),

      // Key Findings
      findings.length > 0 && h(Section, { title: 'Key Findings (' + findings.length + ')' },
        findings.map(function(f, i) {
          return h('div', { key: i, style: { padding: '10px 12px', background: '#FAFBFC', borderRadius: 6, marginBottom: 6, borderLeft: '3px solid ' + ACCENT } },
            typeof f === 'string' ? h('div', { style: { fontSize: 12, color: '#374151' } }, f)
            : h('div', null,
                h('div', { style: { fontSize: 12, fontWeight: 600, color: NAVY } }, f.finding || f.title || ''),
                f.detail && h('div', { style: { fontSize: 11, color: '#6B7280', marginTop: 2 } }, f.detail),
                f.source && h('div', { style: { fontSize: 10, color: '#9CA3AF', marginTop: 2 } }, 'Source: ' + f.source)
              )
          );
        })
      ),

      // Competitive Intel
      (ci.strengths || ci.weaknesses || ci.recent_wins || ci.teaming || ci.hiring) && h(Section, { title: 'Competitive Intelligence' },
        h('div', { style: { display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 } },
          ci.strengths && ci.strengths.length > 0 && h('div', null,
            h('div', { style: { fontSize: 11, fontWeight: 700, color: '#2F5C1F', marginBottom: 6, textTransform: 'uppercase' } }, 'Strengths'),
            ci.strengths.map(function(s, i) { return h('div', { key: i, style: { fontSize: 12, color: '#374151', marginBottom: 4, paddingLeft: 10, borderLeft: '2px solid #86EFAC' } }, s); })
          ),
          ci.weaknesses && ci.weaknesses.length > 0 && h('div', null,
            h('div', { style: { fontSize: 11, fontWeight: 700, color: '#DC2626', marginBottom: 6, textTransform: 'uppercase' } }, 'Weaknesses'),
            ci.weaknesses.map(function(w, i) { return h('div', { key: i, style: { fontSize: 12, color: '#374151', marginBottom: 4, paddingLeft: 10, borderLeft: '2px solid #FCA5A5' } }, w); })
          ),
          ci.recent_wins && ci.recent_wins.length > 0 && h('div', null,
            h('div', { style: { fontSize: 11, fontWeight: 700, color: '#3B82F6', marginBottom: 6, textTransform: 'uppercase' } }, 'Recent Wins'),
            ci.recent_wins.map(function(w, i) { return h('div', { key: i, style: { fontSize: 12, color: '#374151', marginBottom: 4, paddingLeft: 10, borderLeft: '2px solid #93C5FD' } }, typeof w === 'string' ? w : (w.title || w.contract || '') + (w.value ? ' ($' + w.value + ')' : '')); })
          ),
          ci.teaming && ci.teaming.length > 0 && h('div', null,
            h('div', { style: { fontSize: 11, fontWeight: 700, color: '#8B5CF6', marginBottom: 6, textTransform: 'uppercase' } }, 'Teaming Partners'),
            ci.teaming.map(function(t, i) { return h('div', { key: i, style: { fontSize: 12, color: '#374151', marginBottom: 4, paddingLeft: 10, borderLeft: '2px solid #C4B5FD' } }, typeof t === 'string' ? t : t.partner || ''); })
          )
        ),
        ci.hiring && ci.hiring.length > 0 && h('div', { style: { marginTop: 12 } },
          h('div', { style: { fontSize: 11, fontWeight: 700, color: '#B06D32', marginBottom: 6, textTransform: 'uppercase' } }, 'Hiring Signals'),
          ci.hiring.map(function(hh, i) { return h('div', { key: i, style: { fontSize: 12, color: '#374151', marginBottom: 4, paddingLeft: 10, borderLeft: '2px solid #FED7AA' } }, typeof hh === 'string' ? hh : hh.role || ''); })
        )
      ),

      // Capture Implications
      (capture.threats || capture.opportunities || capture.recommended_actions) && h(Section, { title: 'Capture Implications' },
        capture.threats && capture.threats.length > 0 && h('div', { style: { marginBottom: 12 } },
          h('div', { style: { fontSize: 11, fontWeight: 700, color: '#DC2626', marginBottom: 6, textTransform: 'uppercase' } }, 'Threats'),
          capture.threats.map(function(t, i) { return h('div', { key: i, style: { fontSize: 12, color: '#374151', marginBottom: 4, paddingLeft: 10, borderLeft: '2px solid #FCA5A5' } }, t); })
        ),
        capture.opportunities && capture.opportunities.length > 0 && h('div', { style: { marginBottom: 12 } },
          h('div', { style: { fontSize: 11, fontWeight: 700, color: '#2F5C1F', marginBottom: 6, textTransform: 'uppercase' } }, 'Opportunities'),
          capture.opportunities.map(function(o, i) { return h('div', { key: i, style: { fontSize: 12, color: '#374151', marginBottom: 4, paddingLeft: 10, borderLeft: '2px solid #86EFAC' } }, o); })
        ),
        capture.recommended_actions && capture.recommended_actions.length > 0 && h('div', null,
          h('div', { style: { fontSize: 11, fontWeight: 700, color: NAVY, marginBottom: 6, textTransform: 'uppercase' } }, 'Recommended Actions'),
          capture.recommended_actions.map(function(a, i) { return h('div', { key: i, style: { fontSize: 12, color: '#374151', marginBottom: 6, padding: '8px 12px', background: '#F0F7FF', borderRadius: 6, borderLeft: '3px solid #32448A' } }, typeof a === 'string' ? a : (a.action || '') + (a.priority ? ' [' + a.priority + ']' : '')); })
        )
      ),

      // Follow-up Queries
      followUp.length > 0 && h(Section, { title: 'Follow-up Research Queries (' + followUp.length + ')' },
        followUp.map(function(q, i) {
          var qText = typeof q === 'string' ? q : q.query || q.question || '';
          return h('div', { key: i, style: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '8px 12px', background: '#FAFBFC', borderRadius: 6, marginBottom: 4 } },
            h('span', { style: { fontSize: 12, color: '#374151', flex: 1 } }, qText),
            h('button', { onClick: function() { setTarget(qText.substring(0, 100)); setType('competitor'); }, style: { padding: '4px 10px', fontSize: 10, border: '1px solid ' + BORDER, borderRadius: 4, background: '#fff', color: NAVY, cursor: 'pointer', fontWeight: 600, whiteSpace: 'nowrap', marginLeft: 8 } }, 'Research')
          );
        })
      )
    );
  };

  return h('div', null,
    h('div', { style: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 } },
      h('div', null,
        h('div', { style: { fontSize: 20, fontWeight: 700, color: NAVY, marginBottom: 4 } }, '\uD83D\uDD2C Deep Research Agent'),
        h('div', { style: { fontSize: 12, color: '#666' } }, 'AI-powered competitive intelligence \u2014 multi-source research with GovTribe, FPDS, SAM.gov, and OSINT')
      )
    ),

    // Research Launcher
    h('div', { style: { background: '#fff', border: '1px solid ' + BORDER, borderRadius: 10, padding: 20, marginBottom: 20 } },
      h('div', { style: { display: 'flex', gap: 12, alignItems: 'flex-end', flexWrap: 'wrap' } },
        h('div', { style: { flex: 2, minWidth: 200 } },
          h('div', { style: { fontSize: 11, fontWeight: 700, color: '#777', marginBottom: 4, textTransform: 'uppercase' } }, 'Research Target'),
          h('input', { value: target, onChange: function(e) { setTarget(e.target.value); }, placeholder: 'e.g. Leidos, OASIS+ TO, Army CECOM, RS3...', onKeyDown: function(e) { if (e.key === 'Enter') runResearch(); }, style: { width: '100%', padding: '10px 14px', border: '1px solid ' + BORDER, borderRadius: 6, fontSize: 13, fontWeight: 600, boxSizing: 'border-box' } })
        ),
        h('div', { style: { flex: 1, minWidth: 140 } },
          h('div', { style: { fontSize: 11, fontWeight: 700, color: '#777', marginBottom: 4, textTransform: 'uppercase' } }, 'Research Type'),
          h('select', { value: rType, onChange: function(e) { setType(e.target.value); }, style: { width: '100%', padding: '10px 14px', border: '1px solid ' + BORDER, borderRadius: 6, fontSize: 13, boxSizing: 'border-box' } },
            TYPES.map(function(t) { return h('option', { key: t, value: t }, t.charAt(0).toUpperCase() + t.slice(1)); })
          )
        ),
        rType === 'opportunity' && h('div', { style: { flex: 1, minWidth: 120 } },
          h('div', { style: { fontSize: 11, fontWeight: 700, color: '#777', marginBottom: 4, textTransform: 'uppercase' } }, 'Opp ID (optional)'),
          h('input', { value: oppId, onChange: function(e) { setOppId(e.target.value); }, placeholder: 'SAM.gov ID...', style: { width: '100%', padding: '10px 14px', border: '1px solid ' + BORDER, borderRadius: 6, fontSize: 13, boxSizing: 'border-box' } })
        ),
        h('button', { onClick: runResearch, disabled: loading || !target.trim(), style: { padding: '10px 24px', background: loading ? '#9CA3AF' : '#1B2A4A', color: '#fff', border: 'none', borderRadius: 6, fontSize: 13, fontWeight: 700, cursor: loading ? 'default' : 'pointer', whiteSpace: 'nowrap' } }, loading ? '\u23F3 Researching...' : '\uD83D\uDD2C Run Deep Research')
      ),
      loading && h('div', { style: { marginTop: 16, textAlign: 'center', padding: 20 } },
        h('div', { style: { fontSize: 13, color: '#6B7280', marginBottom: 8 } }, 'Running multi-source intelligence collection...'),
        h('div', { style: { fontSize: 11, color: '#9CA3AF' } }, 'Querying GovTribe, FPDS, SAM.gov, financial data, news, and job postings. This takes ~30 seconds.')
      ),
      error && h('div', { style: { marginTop: 12, padding: '10px 14px', background: '#FEF2F2', border: '1px solid #FCA5A5', borderRadius: 6, color: '#DC2626', fontSize: 12 } }, 'Error: ' + error)
    ),

    // Results
    renderReport(),

    // Research History
    h('div', { style: { marginTop: 24 } },
      h(Section, { title: 'Research History (' + history.length + ')' },
        histLoading ? h('div', { style: { textAlign: 'center', padding: 20, color: '#9CA3AF', fontSize: 12 } }, 'Loading history...')
        : history.length === 0 ? h('div', { style: { textAlign: 'center', padding: 20, color: '#9CA3AF', fontSize: 12 } }, 'No research history yet.')
        : h('table', { style: { width: '100%', borderCollapse: 'collapse', fontSize: 12 } },
            h('thead', null, h('tr', null,
              ['Target', 'Type', 'Confidence', 'Sources', 'Summary', 'Date'].map(function(hdr) {
                return h('th', { key: hdr, style: { padding: '8px 10px', textAlign: 'left', fontSize: 10, fontWeight: 700, color: '#777', textTransform: 'uppercase', borderBottom: '1px solid ' + BORDER, background: '#fafafa' } }, hdr);
              })
            )),
            h('tbody', null, history.map(function(r) {
              return h('tr', { key: r.id, style: { cursor: 'pointer' }, onClick: function() { setTarget(r.target); setType(r.research_type); } },
                h('td', { style: { padding: '8px 10px', borderBottom: '1px solid #f0f0f0', fontWeight: 600, color: NAVY } }, r.target),
                h('td', { style: { padding: '8px 10px', borderBottom: '1px solid #f0f0f0' } }, h('span', { style: { padding: '2px 8px', borderRadius: 10, fontSize: 10, fontWeight: 600, background: '#f4f5f7', color: '#555' } }, r.research_type)),
                h('td', { style: { padding: '8px 10px', borderBottom: '1px solid #f0f0f0', fontWeight: 600, color: confColor(r.confidence) } }, r.confidence),
                h('td', { style: { padding: '8px 10px', borderBottom: '1px solid #f0f0f0' } }, r.sources_used),
                h('td', { style: { padding: '8px 10px', borderBottom: '1px solid #f0f0f0', color: '#6B7280', maxWidth: 300, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' } }, r.summary || ''),
                h('td', { style: { padding: '8px 10px', borderBottom: '1px solid #f0f0f0', color: '#9CA3AF', whiteSpace: 'nowrap' } }, fmtDate(r.created_at))
              );
            }))
          )
      )
    )
  );
}
