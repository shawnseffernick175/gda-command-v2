import React, { useState, useEffect, useCallback, useRef, useMemo } from 'react';
import { ACCENT, NAVY, BG, WHITE, BORDER, FONT, N8N, AUTH, api, S, css, gdaNav, NAV_ITEMS, Spinner, Empty, Alert, PageHeader } from '../../lib/gda';
function AIAgent() {
  const [messages, setMessages] = useState([{role:'assistant',content:'GDA AI Agent online. Ask about defense acquisition, BD strategy, your opportunities, or upload a document for analysis.'}]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [docName, setDocName] = useState('');
  const [docB64, setDocB64] = useState('');
  const [savedChats, setSavedChats] = useState([]);
  const [showHistory, setShowHistory] = useState(false);
  const [mode, setMode] = useState('General');
  const sessionId = useRef('chat_' + Date.now());
  const bottomRef = useRef(null);
  useEffect(() => { bottomRef.current?.scrollIntoView({behavior:'smooth'}); }, [messages]);
  useEffect(() => { api.post('gda-discussions',{action:'list'}).then(d=>{ const chats = d.discussions||d.data||[]; setSavedChats(Array.isArray(chats)?chats:[]); }).catch(()=>{}); }, []);
  const MODE_PREFIXES = { 'General': '', 'BD Intel': 'Acting as a BD intelligence analyst for EIS (government defense IT services): ', 'Capture': 'Acting as a capture manager pursuing government defense contracts: ', 'Technical': 'Acting as a technical architect for defense IT and C5ISR systems: ' };
  const handleFile = (e) => { const file = e.target.files[0]; if(!file) return; setDocName(file.name); const reader = new FileReader(); reader.onload = () => { const b64=reader.result.split(',')[1]||reader.result; setDocB64(b64); setMessages(m=>[...m,{role:'system',content:'Document uploaded: '+file.name+' ('+(file.size/1024).toFixed(1)+' KB). Ask questions about it.'}]); }; reader.readAsDataURL(file); };
  const formatResponse = (d) => { const summary = d.reply || d.Summary || d.summary || d.response || d.output || ''; const structured = {}; if (Array.isArray(d.Key_Points) && d.Key_Points.length && d.Key_Points[0] !== 'N/A') structured.key_points = d.Key_Points; if (Array.isArray(d.Recommendations) && d.Recommendations.length && d.Recommendations[0] !== 'N/A') structured.recommendations = d.Recommendations; if (Array.isArray(d.Next_Steps) && d.Next_Steps.length && d.Next_Steps[0] !== 'N/A') structured.next_steps = d.Next_Steps; if (Array.isArray(d.Risks) && d.Risks.length && d.Risks[0] !== 'N/A') structured.risks = d.Risks; if (Array.isArray(d.Sources) && d.Sources.length && d.Sources[0] !== 'N/A') structured.sources = d.Sources; return {content: summary || JSON.stringify(d), structured: Object.keys(structured).length ? structured : null}; };
  const send = async () => { const msg = input.trim(); if(!msg) return; setInput(''); const prefix = MODE_PREFIXES[mode] || ''; setMessages(m=>[...m,{role:'user',content:msg,mode:mode!=='General'?mode:null}]); setLoading(true); try { const safeMessages = Array.isArray(messages) ? messages : []; const payload = {message: prefix+msg, session_id: sessionId.current, today: new Date().toISOString().split('T')[0], history: safeMessages.slice(-10).map(m=>({role:m.role,content:m.content}))}; if(docB64){payload.document_b64=docB64;payload.document_name=docName;} const d = await api.post('gda-chat-v2', payload, {signal: AbortSignal.timeout(90000)}); const {content, structured} = formatResponse(d); setMessages(m=>[...m,{role:'assistant',content,structured}]); } catch(e) { setMessages(m=>[...m,{role:'assistant',content:'Error: '+e.message}]); } setLoading(false); };
  const saveChat = async () => { const title = 'Chat '+new Date().toLocaleDateString(); try { await api.post('gda-discussions',{action:'save',title,messages}); const d=await api.post('gda-discussions',{action:'list'}); const chats=d.discussions||d.data||[]; setSavedChats(Array.isArray(chats)?chats:[]); } catch {} };
  const loadChat = (chat) => { const msgs = Array.isArray(chat.messages) ? chat.messages : []; setMessages(msgs); setShowHistory(false); };
  const deleteChat = async (id) => { try { await api.post('gda-discussions',{action:'delete',id}); setSavedChats(s=>(Array.isArray(s)?s:[]).filter(c=>c.id!==id)); } catch {} };
  const refresh = () => { setMessages([{role:'assistant',content:'New session started.'}]); setDocName(''); setDocB64(''); sessionId.current='chat_'+Date.now(); };
  const StructuredSection = ({label, items, color}) => { const [open, setOpen] = useState(false); if (!items || !items.length) return null; return ( <div style={{marginTop:6,paddingTop:6,borderTop:'1px solid rgba(0,0,0,0.08)'}}> <div style={{display:'flex',alignItems:'center',gap:5,cursor:'pointer',userSelect:'none'}} onClick={()=>setOpen(o=>!o)}> <span style={{fontSize:9,color}}>{open?'▼':'▶'}</span> <span style={{fontSize:9,fontWeight:700,color,letterSpacing:'0.4px'}}>{label} ({items.length})</span> </div> {open && <div style={{marginTop:4}}>{items.map((item,i)=><div key={i} style={{fontSize:11,color:NAVY,padding:'2px 0 2px 10px',borderLeft:'2px solid '+color+'44',marginBottom:2,lineHeight:1.5}}>{typeof item==='string'?item:JSON.stringify(item)}</div>)}</div>} </div> ); };
  const safeChats = Array.isArray(savedChats) ? savedChats : [];
  const MODES = ['General','BD Intel','Capture','Technical'];
  return (
    <div style={{display:'flex',flexDirection:'column',height:'calc(100vh - 120px)'}}>
      <PageHeader title='AI Agent Chat' sub='Structured BD intelligence — Key Points, Recommendations, Next Steps' action={
        <div style={{display:'flex',gap:6,alignItems:'center',flexWrap:'wrap'}}>
          <div style={{display:'flex',gap:2,background:'#f5f5f5',borderRadius:6,padding:2}}>
            {MODES.map(m=>(<button key={m} onClick={()=>setMode(m)} style={{padding:'4px 10px',borderRadius:4,border:'none',background:mode===m?NAVY:'transparent',color:mode===m?WHITE:'#555',fontSize:10,fontWeight:600,cursor:'pointer'}}>{m}</button>))}
          </div>
          <label style={{padding:'6px 12px',borderRadius:6,background:NAVY,color:WHITE,fontSize:11,fontWeight:600,cursor:'pointer'}}>📎 Doc<input type='file' accept='.pdf,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.txt' onChange={handleFile} style={{display:'none'}} /></label>
          <button style={S.btn('secondary',true)} onClick={()=>setShowHistory(!showHistory)}>{showHistory?'Chat':'History'}</button>
          <button style={S.btn('secondary',true)} onClick={refresh}>New</button>
        </div>
      } />
      <div style={{display:'flex',gap:10,alignItems:'center',marginBottom:8,fontSize:10,color:'#888'}}>
        <span style={{padding:'2px 8px',borderRadius:10,background:'#2F5C1F15',color:'#2F5C1F',fontWeight:600}}>● Active</span>
        <span>{(Array.isArray(messages)?messages:[]).filter(m=>m.role!=='system').length} msgs</span>
        {docName && <span style={{color:ACCENT}}>📎 {docName}</span>}
        {mode!=='General' && <span style={{padding:'2px 8px',borderRadius:10,background:ACCENT+'22',color:ACCENT,fontWeight:600}}>{mode}</span>}
      </div>
      {showHistory ? (
        <div style={{flex:1,overflow:'auto'}}>
          <div style={S.card}><div style={S.cardTitle}>Saved Conversations ({safeChats.length})</div>
            {safeChats.length===0 && <div style={{color:'#999',fontSize:12}}>No saved chats yet.</div>}
            {safeChats.map((ch,i)=>(
              <div key={i} style={{display:'flex',justifyContent:'space-between',alignItems:'center',padding:'10px 0',borderBottom:'1px solid #f0f0f0'}}>
                <div style={{cursor:'pointer',flex:1}} onClick={()=>loadChat(ch)}>
                  <div style={{fontSize:13,fontWeight:600,color:NAVY}}>{ch.title||'Untitled'}</div>
                  <div style={{fontSize:10,color:'#999'}}>{ch.created_at?new Date(ch.created_at).toLocaleString():'Unknown'} · {(Array.isArray(ch.messages)?ch.messages:[]).length} msgs</div>
                </div>
                <button onClick={()=>deleteChat(ch.id)} style={{background:'none',border:'none',color:'#e53935',cursor:'pointer',fontSize:16,padding:'4px 8px'}}>×</button>
              </div>
            ))}
          </div>
        </div>
      ) : (
        <div style={{flex:1,overflow:'auto',display:'flex',flexDirection:'column',gap:8,paddingBottom:16}}>
          {(Array.isArray(messages)?messages:[]).map((m,i)=>(
            <div key={i} style={{display:'flex',justifyContent:m.role==='user'?'flex-end':m.role==='system'?'center':'flex-start'}}>
              {m.role==='system'
                ? <div style={{fontSize:10,color:'#888',fontStyle:'italic',padding:'2px 10px',background:'#f5f5f5',borderRadius:10}}>{m.content}</div>
                : <div style={{maxWidth:'76%',padding:'10px 14px',borderRadius:m.role==='user'?'16px 16px 4px 16px':'16px 16px 16px 4px',background:m.role==='user'?NAVY:WHITE,color:m.role==='user'?WHITE:NAVY,border:m.role==='assistant'?'1px solid '+BORDER:'none',fontSize:13,lineHeight:1.6}}>
                    {m.mode && <div style={{fontSize:9,fontWeight:700,color:m.role==='user'?'rgba(255,255,255,0.55)':'#aaa',marginBottom:3,letterSpacing:'0.5px'}}>{m.mode.toUpperCase()}</div>}
                    <div style={{whiteSpace:'pre-wrap'}}>{m.content}</div>
                    {m.structured && (
                      <div style={{marginTop:8}}>
                        <StructuredSection label="KEY POINTS" items={m.structured.key_points} color="#32448A" />
                        <StructuredSection label="RECOMMENDATIONS" items={m.structured.recommendations} color="#2F5C1F" />
                        <StructuredSection label="NEXT STEPS" items={m.structured.next_steps} color={ACCENT} />
                        <StructuredSection label="RISKS" items={m.structured.risks} color="#DC2626" />
                        <StructuredSection label="SOURCES" items={m.structured.sources} color="#32448A" />
                      </div>
                    )}
                  </div>
              }
            </div>
          ))}
          {loading && <div style={{display:'flex'}}><div style={{padding:'10px 14px',background:WHITE,border:'1px solid '+BORDER,borderRadius:'16px 16px 16px 4px',display:'flex',alignItems:'center',gap:8}}><Spinner /><span style={{fontSize:12,color:'#888',fontStyle:'italic'}}>GDA Agent is thinking...</span></div></div>}
          <div ref={bottomRef} />
        </div>
      )}
      <div style={{display:'flex',gap:8,background:WHITE,border:'1px solid '+BORDER,borderRadius:10,padding:'8px 12px',marginTop:8}}>
        <input style={{...S.input,border:'none',outline:'none',flex:1}} placeholder={mode==='General'?'Message GDA AI...':mode+' — ask your question...'} value={input} onChange={e=>setInput(e.target.value)} onKeyDown={e=>{if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();send();}}} />
        <button style={{...S.btn('green',true)}} onClick={saveChat} title='Save conversation'>Save</button>
        <button style={S.btn()} onClick={send} disabled={loading||!input.trim()}>Send</button>
      </div>
    </div>
  );
}
export default AIAgent;
