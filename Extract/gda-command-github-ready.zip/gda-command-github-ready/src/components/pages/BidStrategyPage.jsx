import React, { useState } from 'react';
import Wargame from './WargamePage';
import IncumbentAnalysis from './IncumbentAnalysisPage';
import TeamingFinder from './TeamingFinderPage';

const NAVY = '#1a2744', ACCENT = '#D14A2A', BORDER = '#e0e0e0', WHITE = '#ffffff';

const TABS = [
  { id: 'wargame',   label: 'Wargame',            icon: '\u265f\ufe0f' },
  { id: 'incumbent', label: 'Incumbent Analysis', icon: '\ud83d\udcca' },
  { id: 'teaming',   label: 'Teaming Finder',     icon: '\ud83e\udd1d' },
];

export default function BidStrategy() {
  const [active, setActive] = useState('wargame');
  return React.createElement('div', { style: { height: '100%' } },
    React.createElement('div', { style: { marginBottom: 16 } },
      React.createElement('div', { style: { fontSize: 20, fontWeight: 700, color: NAVY, marginBottom: 2 } }, 'Bid Strategy'),
      React.createElement('div', { style: { fontSize: 12, color: '#666' } }, 'Wargame competitors \u00b7 Analyze incumbents \u00b7 Build your team')
    ),
    React.createElement('div', {
      style: { display: 'flex', gap: 4, borderBottom: '2px solid ' + BORDER, marginBottom: 20 }
    },
      TABS.map(t => React.createElement('button', {
        key: t.id,
        onClick: () => setActive(t.id),
        style: {
          display: 'flex', alignItems: 'center', gap: 6,
          padding: '10px 20px', background: 'none', border: 'none', cursor: 'pointer',
          borderBottom: active === t.id ? '2px solid ' + ACCENT : '2px solid transparent',
          marginBottom: -2,
          color: active === t.id ? ACCENT : '#555',
          fontWeight: active === t.id ? 700 : 500,
          fontSize: 13,
        }
      }, t.icon + ' ' + t.label))
    ),
    React.createElement('div', { style: { display: active === 'wargame'   ? 'block' : 'none' } }, React.createElement(Wargame, null)),
    React.createElement('div', { style: { display: active === 'incumbent' ? 'block' : 'none' } }, React.createElement(IncumbentAnalysis, null)),
    React.createElement('div', { style: { display: active === 'teaming'   ? 'block' : 'none' } }, React.createElement(TeamingFinder, null))
  );
}
