import { saveAction, ActionHistory } from '../../lib/gda';
import React, { useState, useEffect } from 'react';
const N8N='/api', AUTH={'Content-Type':'application/json'}, ACCENT='#D14A2A', NAVY='#1a2744', WHITE='#ffffff', BORDER='#e0e0e0';
const api={post:async(p,b={})=>{const r=await fetch(N8N+'/'+p,{method:'POST',headers:AUTH,body:JSON.stringify(b)});if(!r.ok)throw new Error(r.status);const t=await r.text();return t.trim()?JSON.parse(t):{}}};
const S={card:{background:WHITE,border:'1px solid '+BORDER,borderRadius:8,padding:'16px 20px',marginBottom:14},th:{padding:'8px 12px',textAlign:'left',fontSize:10,fontWeight:700,color:'#777',letterSpacing:'0.4px',textTransform:'uppercase',borderBottom:'1px solid '+BORDER,background:'#fafafa'},td:{padding:'9px 12px',borderBottom:'1px solid #f0f0f0',fontSize:12},btn:(v='primary')=>({padding:'8px 16px',borderRadius:6,border:'none',cursor:'pointer',fontSize:12,fontWeight:600,background:v==='primary'?ACCENT:'#eee',color:v==='primary'?'#fff':NAVY}),badge:(c='gray')=>({display:'inline-block',padding:'2px 8px',borderRadius:10,fontSize:10,fontWeight:600,background:c==='green'?'#2F5C1F15':c==='red'?'#ffebe6':c==='blue'?'#e6f0ff':'#f4f5f7',color:c==='green'?'#2F5C1F':c==='red'?'#bf2600':c==='blue'?'#32448A':'#555'}),input:{width:'100%',padding:'8px 10px',border:'1px solid '+BORDER,borderRadius:6,fontSize:12,outline:'none',boxSizing:'border-box'}};

export default function Wargame() {
  const [games, setGames] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selected, setSelected] = useState(null);

  useEffect(()=>{
    api.post('gda-wargame',{auth_key:'gda-api-2026-f584dae2',action:'list'}).then(r=>{setGames(r.wargames||[]);setLoading(false)}).catch(()=>setLoading(false));
  },[]);

  if(loading) return React.createElement('div',{style:{padding:40,textAlign:'center',color:'#aaa'}},'Loading...');
  return React.createElement('div',null,
    React.createElement('div',{style:{fontSize:20,fontWeight:700,color:NAVY,marginBottom:4}},'Competitive Wargame'),
    React.createElement('div',{style:{fontSize:12,color:'#666',marginBottom:18}},'Simulate competitive scenarios to sharpen win strategy and ghost competitors'),
    games.map((g,i)=>React.createElement('div',{key:g.id||i,style:{...S.card,cursor:'pointer',borderLeft:g.status==='Active'?'3px solid '+ACCENT:'3px solid '+BORDER},onClick:()=>setSelected(selected===i?null:i)},
      React.createElement('div',{style:{display:'flex',justifyContent:'space-between'}},
        React.createElement('div',null,
          React.createElement('div',{style:{fontWeight:700,color:NAVY,fontSize:14}},g.scenario_name),
          React.createElement('div',{style:{fontSize:11,color:'#666',marginTop:2}},g.opp_title||g.solicitation_number||'')
        ),
        React.createElement('div',{style:{display:'flex',gap:8,alignItems:'center'}},
          g.pwin_before>0&&React.createElement('span',{style:{fontSize:11,color:'#888'}},'Pwin: '+g.pwin_before+'%'),
          React.createElement('span',{style:S.badge(g.status==='Active'?'red':'gray')},g.status)
        )
      ),
      selected===i&&React.createElement('div',{style:{marginTop:12,paddingTop:12,borderTop:'1px solid #f0f0f0'}},
        React.createElement('div',{style:{display:'grid',gridTemplateColumns:'1fr 1fr',gap:12}},
          React.createElement('div',null,
            React.createElement('div',{style:{fontSize:10,fontWeight:700,color:'#888',textTransform:'uppercase',marginBottom:4}},'Our Strategy'),
            React.createElement('div',{style:{fontSize:12,color:'#444'}},g.our_strategy||'Not defined')
          ),
          React.createElement('div',null,
            React.createElement('div',{style:{fontSize:10,fontWeight:700,color:'#888',textTransform:'uppercase',marginBottom:4}},'Competitor 1'),
            React.createElement('div',{style:{fontSize:12,fontWeight:600,color:NAVY}},g.competitor_1_name||'TBD'),
            React.createElement('div',{style:{fontSize:11,color:'#666'}},g.competitor_1_strategy||'')
          )
        ),
        g.ghost_themes&&React.createElement('div',{style:{marginTop:8}},
          React.createElement('div',{style:{fontSize:10,fontWeight:700,color:ACCENT,textTransform:'uppercase',marginBottom:4}},'Ghost Themes'),
          React.createElement('div',{style:{fontSize:12,color:'#444'}},g.ghost_themes)
        )
      )
    )),
    games.length===0&&React.createElement('div',{style:{...S.card,textAlign:'center',color:'#aaa',padding:30}},'No wargames yet. Create one from Capture Plan.')
  );
}
