import React, { useState, useEffect, useCallback, useRef, useMemo } from 'react';
import { ACCENT, NAVY, BG, WHITE, BORDER, FONT, N8N, AUTH, api, S, css, gdaNav, NAV_ITEMS, Spinner, Empty, Alert, PageHeader, sanitizeExport , saveAction, ActionHistory } from '../../lib/gda';
function EmailDrafter(){
  const [tab,setTab]=useState('compose');
  const [history, setHistory] = useState([]);
  const [hist,setHist]=useState([]);
  const [loading,setLoading]=useState(false);
  const [result,setResult]=useState(null);
  const [copied,setCopied]=useState(false);
  const [form,setForm]=useState({to:'',subject:'',tone:'professional',length:'concise',bluf:false,persona:'EIS President',opening:'',urgency:'',attachments:'',closing:'professional',classification:'',incoming:''});
  const [kps,setKps]=useState([]);
  const [kpIn,setKpIn]=useState('');
  const sf=k=>e=>setForm(p=>({...p,[k]:e.target.value}));
  const sc=k=>e=>setForm(p=>({...p,[k]:e.target.checked}));
  const addKp=()=>{if(!kpIn.trim())return;setKps(k=>[...k,kpIn.trim()]);setKpIn('');};
  const rmKp=idx=>setKps(k=>k.filter((_,j)=>j!==idx));
  const draft=async()=>{
    setLoading(true);setResult(null);
    try{const d=await api.post('gda-email-drafter',{...form,key_points:kps});setResult(d);
      saveAction("email", "draft", form.subject || form.context || "Email Draft", form, d);
      if(d.response||d.email||d.draft||d.output)setHistory&&null;setHist(h=>[{...form,kps,result:d,ts:new Date().toLocaleString()},...h.slice(0,9)]);
    }catch(e){setResult({error:e.message});}setLoading(false);};
  const copy=()=>{navigator.clipboard.writeText(sanitizeExport(result?.response||result?.email||result?.draft||result?.output||''));setCopied(true);setTimeout(()=>setCopied(false),2000);};
  const fl=(label,ch,opt=false)=>(<div style={{marginBottom:10}}><div style={{fontSize:11,fontWeight:600,color:'#666',marginBottom:3}}>{label}{opt&&<span style={{color:'#aaa',marginLeft:4,fontWeight:400}}>(optional)</span>}</div>{ch}</div>);
  const sec=(title,ch)=>(<div style={{...S.card,marginBottom:12}}><div style={{fontSize:11,fontWeight:700,color:ACCENT,letterSpacing:'0.5px',textTransform:'uppercase',marginBottom:10}}>{title}</div>{ch}</div>);
  return(<div>
    <PageHeader title="Email Drafter" sub="AI-crafted professional emails for BD outreach and correspondence"/>
    <div style={{display:'inline-flex',gap:0,marginBottom:16,background:WHITE,border:`1px solid ${BORDER}`,borderRadius:8,overflow:'hidden'}}>
      {['compose','history'].map(t=>(<button key={t} onClick={()=>setTab(t)} style={{padding:'8px 20px',border:'none',cursor:'pointer',fontSize:12,fontWeight:t===tab?700:400,background:t===tab?NAVY:WHITE,color:t===tab?WHITE:'#666'}}>
        {t==='history'?<>History{hist.length>0&&<span style={{marginLeft:5,fontSize:10,background:ACCENT,color:WHITE,padding:'1px 5px',borderRadius:8}}>{hist.length}</span>}</>:'Compose'}
      </button>))}
    </div>
    {tab==='compose'&&(<div style={S.grid(2,16)}>
      <div>
        {sec('Basic Info',<>
          {fl('To (Name / Title / Agency)',<input style={S.input} placeholder="e.g. John Smith, PM SOCOM J7" value={form.to} onChange={sf('to')}/>,true)}
          {fl('Subject',<input style={S.input} placeholder="e.g. EIS Capability Brief" value={form.subject} onChange={sf('subject')}/>,true)}
          <div style={S.grid(2,10)}>
            {fl('Tone',<select style={{...S.select,width:'100%'}} value={form.tone} onChange={sf('tone')}>{['professional','concise','formal','warm','direct'].map(t=><option key={t}>{t.charAt(0).toUpperCase()+t.slice(1)}</option>)}</select>)}
            {fl('Length',<select style={{...S.select,width:'100%'}} value={form.length} onChange={sf('length')}>{['brief','concise','standard','detailed'].map(t=><option key={t}>{t.charAt(0).toUpperCase()+t.slice(1)}</option>)}</select>)}
          </div>
        </>)}
        {sec('Style',<>
          <div style={{display:'flex',alignItems:'center',gap:10,marginBottom:8}}>
            <input type="checkbox" id="bluf" checked={form.bluf} onChange={sc('bluf')} style={{accentColor:ACCENT,width:14,height:14}}/>
            <label htmlFor="bluf" style={{fontSize:12,color:NAVY,cursor:'pointer'}}>BLUF format (Bottom Line Up Front)</label>
          </div>
          {fl('Persona / From',<input style={S.input} value={form.persona} onChange={sf('persona')} placeholder="e.g. EIS President"/>)}
        </>)}
        {sec('Email Elements',<>
          {fl('Opening context',<input style={S.input} placeholder="e.g. Following our meeting at SOFIC..." value={form.opening} onChange={sf('opening')}/>,true)}
          {fl('Urgency / Deadline',<input style={S.input} placeholder="e.g. Response needed by Mar 20" value={form.urgency} onChange={sf('urgency')}/>,true)}
          {fl('Attachments to mention',<input style={S.input} placeholder="e.g. Capability one-pager, past performance" value={form.attachments} onChange={sf('attachments')}/>,true)}
          <div style={S.grid(2,10)}>
            {fl('Closing style',<select style={{...S.select,width:'100%'}} value={form.closing} onChange={sf('closing')}>{['professional','warm','formal','action-oriented'].map(t=><option key={t}>{t.charAt(0).toUpperCase()+t.slice(1)}</option>)}</select>)}
            {fl('Classification',<input style={S.input} placeholder="UNCLASSIFIED//FOUO" value={form.classification} onChange={sf('classification')}/>,true)}
          </div>
        </>)}
        {sec('Key Points',<>
          <div style={{...S.row(),marginBottom:8}}><input style={S.input} placeholder="Add a key point, press Enter..." value={kpIn} onChange={e=>setKpIn(e.target.value)} onKeyDown={e=>e.key==='Enter'&&addKp()}/><button style={S.btn('primary',true)} onClick={addKp}>+</button></div>
          {kps.map((kp,i)=>(<div key={i} style={{display:'flex',alignItems:'center',gap:6,padding:'5px 0',borderBottom:'1px solid #f0f0f0'}}><span style={{fontSize:11,color:'#888',minWidth:16,fontWeight:600}}>{i+1}.</span><span style={{flex:1,fontSize:12}}>{kp}</span><button onClick={()=>rmKp(i)} style={{...S.btn('secondary',true),padding:'2px 6px',fontSize:10}}>x</button></div>))}
          {kps.length===0&&<div style={{fontSize:11,color:'#aaa',fontStyle:'italic'}}>No points added</div>}
        </>)}
        {sec('Respond to Incoming Email',fl('Paste received email',<textarea style={{...S.textarea,minHeight:80}} placeholder="Paste an email you received — AI drafts a contextual response..." value={form.incoming} onChange={sf('incoming')}/>,true))}
        <button style={{...S.btn(),width:'100%',padding:'10px'}} onClick={draft} disabled={loading}>{loading?'Drafting...':'Draft Email'}</button>
      </div>
      <div>
        {result&&(<div style={S.card}>{result.error?<Alert msg={result.error}/>:(<><div style={{...S.row(),justifyContent:'space-between',marginBottom:10}}><div style={S.cardTitle}>Draft</div><button style={S.btn('secondary',true)} onClick={copy}>{copied?'Copied':'Copy'}</button></div><div style={{fontSize:12,lineHeight:1.8,whiteSpace:'pre-wrap',fontFamily:'monospace',background:'#fafafa',padding:12,borderRadius:6}}>{result.response||result.email||result.draft||result.output||typeof result === "string" ? result : Object.entries(result).map(function(e){return e[0]+": "+e[1]}).join("\n")}</div></>)}</div>)}
        {!result&&!loading&&(<div style={{...S.card,background:'#fafafa',border:`1px dashed ${BORDER}`}}><div style={{textAlign:'center',padding:'40px 20px',color:'#aaa'}}><div style={{fontSize:28,marginBottom:8}}>E</div><div style={{fontSize:13,fontWeight:600}}>AI Email Drafter</div><div style={{fontSize:11,marginTop:4}}>All fields optional — fill what you need</div></div></div>)}
      </div>
    </div>)}
    {tab==='history'&&(<div>{hist.length===0?<Empty msg="No drafts generated yet"/>:hist.map((h,i)=>(<div key={i} style={{...S.card,marginBottom:10}}><div style={{...S.row(),justifyContent:'space-between',marginBottom:8}}><div><div style={{fontSize:13,fontWeight:700,color:NAVY}}>{h.subject||h.to||('Draft #'+(hist.length-i))}</div><div style={{fontSize:11,color:'#888'}}>{h.ts} · {h.tone} · {h.length}</div></div><button style={S.btn('secondary',true)} onClick={()=>{setTab('compose');setForm({to:h.to,subject:h.subject,tone:h.tone,length:h.length,bluf:h.bluf,persona:h.persona,opening:h.opening,urgency:h.urgency,attachments:h.attachments,closing:h.closing,classification:h.classification,incoming:h.incoming});setKps(h.kps||[]);setResult(h.result);}}>Reload</button></div>{(h.result?.response||h.result?.email||h.result?.draft||h.result?.output)&&(<div style={{fontSize:11,color:'#666',lineHeight:1.5,background:'#fafafa',padding:'6px 10px',borderRadius:4,maxHeight:50,overflow:'hidden'}}>{(h.result.response||h.result.email||h.result.draft||h.result.output).slice(0,200)}...</div>)}</div>))}</div>)}
  </div>);}
export default EmailDrafter;