import React, { useState, useEffect, useCallback, useRef, useMemo } from 'react';
import { ACCENT, NAVY, BG, WHITE, BORDER, FONT, N8N, AUTH, api, S, css, gdaNav, NAV_ITEMS, Spinner, Empty, Alert, PageHeader , saveAction, ActionHistory } from '../../lib/gda';
function PwinCalculator() {
  const FACTORS = [
    { key: 'customer_relationship', label: 'Customer Relationship', weight: 0.25, desc: 'Do we know the customer? Have we shaped requirements?' },
    { key: 'technical_solution',    label: 'Technical Solution',    weight: 0.20, desc: 'Can we deliver? Do we have the right capabilities?' },
    { key: 'past_performance',      label: 'Past Performance',      weight: 0.20, desc: 'Relevant CPARS, similar contract experience?' },
    { key: 'price_competitiveness', label: 'Price Competitiveness', weight: 0.15, desc: 'Can we win on price? LPTA vs Best Value?' },
    { key: 'team_composition',      label: 'Team Composition',      weight: 0.10, desc: 'Prime/sub team strength, key personnel identified?' },
    { key: 'contract_vehicle',      label: 'Contract Vehicle',      weight: 0.10, desc: 'Do we have the right vehicle? GSA/OASIS/SEWP?' },
  ];
  const AGENCIES = ['SOCOM','TRADOC','PEO STRI','CYBERCOM','INSCOM','DISA','Army Futures Command','Other'];

  const [opportunity, setOpportunity] = useState('');
  const [agency, setAgency] = useState('SOCOM');
  const [notes, setNotes] = useState('');
  const [scores, setScores] = useState(() => Object.fromEntries(FACTORS.map(f => [f.key, 5])));
  const [saving, setSaving] = useState(false);
  const [toast, setToast] = useState('');
  const [showHistory, setShowHistory] = useState(false);
  const [history, setHistory] = useState([]);
  const [histLoading, setHistLoading] = useState(false);
  const [pwinStatus, setPwinStatus] = useState('idle');
  const [pwinApprovedAt, setPwinApprovedAt] = useState(null);

  // Live pwin calculation
  const pwin = useMemo(() => {
    const weighted = FACTORS.reduce((sum, f) => sum + scores[f.key] * f.weight, 0);
    return Math.round(weighted * 10);
  }, [scores]);

  const weightedScore = useMemo(() => FACTORS.reduce((s, f) => s + scores[f.key] * f.weight, 0).toFixed(2), [scores]);

  const recommendation = useMemo(() => {
    if (pwin >= 70) return { label: 'BID', color: '#2F5C1F', bg: '#2F5C1F12' };
    if (pwin >= 50) return { label: 'CONDITIONAL BID', color: '#CA8A04', bg: '#FEFCE8' };
    if (pwin >= 35) return { label: 'BID WITH TEAMING', color: '#EA580C', bg: '#B06D3212' };
    return { label: 'NO-BID', color: '#DC2626', bg: '#FEF2F2' };
  }, [pwin]);

  const gates = useMemo(() => [
    { label: 'Gate 1 — Pursue',      pass: pwin >= 25 },
    { label: 'Gate 2 — Bid',         pass: pwin >= 40 },
    { label: 'Gate 3 — Submit',      pass: pwin >= 50 },
    { label: 'Gate 4 — Best & Final',pass: pwin >= 60 },
  ], [pwin]);

  const scoreColor = (s) => s >= 7 ? '#2F5C1F' : s >= 4 ? '#CA8A04' : '#DC2626';

  const pwinColor = pwin >= 70 ? '#2F5C1F' : pwin >= 50 ? '#CA8A04' : pwin >= 35 ? '#EA580C' : '#DC2626';

  const save = async () => {
    if (!opportunity.trim()) { setToast('Enter an opportunity name first'); setTimeout(() => setToast(''), 3000); return; }
    setSaving(true);
    try {
      await api.post('gda-pwin-calculator', { action: 'calculate', opportunity, agency, notes, ...scores });
      setPwinStatus('draft'); saveAction('pwin','calculate',form.opportunity||'Pwin Calculation',form,d);
      setToast(`Pwin saved: ${opportunity} — ${pwin}%`);
      setTimeout(() => setToast(''), 4000);
    } catch (e) { setToast('Save failed: ' + e.message); setTimeout(() => setToast(''), 4000); }
    setSaving(false);
  };

  const approvePwin = () => {
    setPwinStatus('approved');
    setPwinApprovedAt(new Date().toLocaleString());
    api.post('gda-data-learn', {event:'pwin_approved', context:'pwin-calculator', data:{opportunity, pwin}}).catch(function(){});
  };

  const loadHistory = async () => {
    setShowHistory(true); setHistLoading(true);
    try {
      const d = await api.post('gda-pwin-calculator', { action: 'list', limit: 20 });
      setHistory(d.scores || []);
    } catch (_) { setHistory([]); }
    setHistLoading(false);
  };

  const loadFromHistory = (row) => {
    if (row.scores) setScores(row.scores);
    else {
      const s = {};
      FACTORS.forEach(f => { if (row[f.key] !== undefined) s[f.key] = row[f.key]; });
      if (Object.keys(s).length) setScores(prev => ({ ...prev, ...s }));
    }
    if (row.opportunity) setOpportunity(row.opportunity);
    if (row.agency) setAgency(row.agency);
    if (row.notes) setNotes(row.notes);
    setShowHistory(false);
  };

  // SVG semicircle gauge
  const gaugeAngle = (pwin / 100) * 180;
  const r = 70, cx = 90, cy = 90;
  const toRad = (deg) => (deg - 180) * Math.PI / 180;
  const arcX = (deg) => cx + r * Math.cos(toRad(deg));
  const arcY = (deg) => cy + r * Math.sin(toRad(deg));
  const arcPath = (end) => {
    const x = arcX(end); const y = arcY(end);
    const large = end > 90 ? 1 : 0;
    return `M ${arcX(0)} ${arcY(0)} A ${r} ${r} 0 ${large} 1 ${x} ${y}`;
  };

  return (
    <div>
      <PageHeader
        title="Pwin Calculator"
        sub="Shipley Weighted Scorecard — Probability of Win Assessment"
        action={
          <button onClick={loadHistory} style={{ padding: '7px 16px', background: WHITE, border: '1px solid ' + BORDER, borderRadius: 6, fontSize: 12, fontWeight: 600, cursor: 'pointer', color: NAVY }}>
            📋 History
          </button>
        }
      />

      {toast && (
        <div style={{ padding: '10px 16px', background: pwin >= 50 ? '#2F5C1F12' : '#FEF2F2', border: '1px solid ' + (pwin >= 50 ? '#86EFAC' : '#FCA5A5'), borderRadius: 8, marginBottom: 14, fontSize: 13, fontWeight: 600, color: pwin >= 50 ? '#2F5C1F' : '#DC2626' }}>
          {toast}
        </div>
      )}

      {pwinStatus === 'draft' && (
        <div style={{ background: '#B06D3212', border: '1px solid #FDE68A', borderRadius: 8, padding: '12px 16px', marginBottom: 14, display: 'flex', alignItems: 'center', gap: 12 }}>
          <span style={{ fontSize: 13, fontWeight: 700, color: '#B06D32' }}>⚠ AI Assessment — Pending Your Review</span>
          <div style={{ flex: 1 }} />
          <button onClick={approvePwin} style={{ padding: '6px 16px', background: '#2F5C1F', color: '#fff', border: 'none', borderRadius: 6, fontSize: 12, fontWeight: 700, cursor: 'pointer' }}>✓ Approve</button>
        </div>
      )}
      {pwinStatus === 'approved' && pwinApprovedAt && (
        <div style={{ background: '#2F5C1F12', border: '1px solid #86EFAC', borderRadius: 8, padding: '10px 16px', marginBottom: 14, fontSize: 12, fontWeight: 600, color: '#2F5C1F' }}>✓ Approved — {pwinApprovedAt}</div>
      )}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 320px', gap: 16, alignItems: 'start' }}>
        {/* LEFT: Inputs + Sliders */}
        <div>
          {/* Opportunity + Agency */}
          <div style={{ ...S.card, marginBottom: 14 }}>
            <div style={{ display: 'flex', gap: 10, marginBottom: 10 }}>
              <input
                style={{ ...S.input, flex: 1 }}
                placeholder="Opportunity name (e.g. Georgetown Defense Analytics)"
                value={opportunity}
                onChange={e => setOpportunity(e.target.value)}
              />
              <select style={{ ...S.select, width: 200 }} value={agency} onChange={e => setAgency(e.target.value)}>
                {AGENCIES.map(a => <option key={a} value={a}>{a}</option>)}
              </select>
            </div>
            <textarea
              style={{ ...S.textarea, height: 52, resize: 'none' }}
              placeholder="Assessment notes..."
              value={notes}
              onChange={e => setNotes(e.target.value)}
            />
          </div>

          {/* Factor Sliders */}
          <div style={S.card}>
            <div style={{ fontSize: 12, fontWeight: 700, color: NAVY, marginBottom: 14 }}>Score Each Factor (1–10)</div>
            {FACTORS.map(f => {
              const s = scores[f.key];
              const c = scoreColor(s);
              return (
                <div key={f.key} style={{ marginBottom: 18 }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 4 }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                      <span style={{ fontSize: 13, fontWeight: 700, color: NAVY }}>{f.label}</span>
                      <span style={{ padding: '1px 7px', borderRadius: 10, fontSize: 10, fontWeight: 600, background: '#f0f0f0', color: '#666' }}>{Math.round(f.weight * 100)}%</span>
                    </div>
                    <span style={{ fontSize: 22, fontWeight: 800, color: c, minWidth: 28, textAlign: 'right' }}>{s}</span>
                  </div>
                  <input
                    type="range" min="1" max="10" value={s}
                    onChange={e => setScores(p => ({ ...p, [f.key]: Number(e.target.value) }))}
                    style={{ width: '100%', accentColor: c, height: 4, cursor: 'pointer' }}
                  />
                  <div style={{ fontSize: 11, color: '#888', marginTop: 3 }}>{f.desc}</div>
                </div>
              );
            })}

            <button
              style={{ ...S.btn(), width: '100%', marginTop: 8, background: '#D14A2A', opacity: saving ? 0.6 : 1 }}
              onClick={save} disabled={saving}
            >
              {saving ? 'Saving...' : 'Save Assessment'}
            </button>
          </div>
        </div>

        {/* RIGHT: Live Gauge + Breakdown + Gates */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
          {/* Gauge Card */}
          <div style={{ ...S.card, textAlign: 'center' }}>
            <svg width="180" height="100" viewBox="0 0 180 100" style={{ display: 'block', margin: '0 auto 8px' }}>
              {/* Background arc */}
              <path d={arcPath(180)} fill="none" stroke="#e0e0e0" strokeWidth="12" strokeLinecap="round" />
              {/* Filled arc */}
              {pwin > 0 && <path d={arcPath(gaugeAngle)} fill="none" stroke={pwinColor} strokeWidth="12" strokeLinecap="round" />}
              {/* Center text */}
              <text x={cx} y={cy - 8} textAnchor="middle" fontSize="28" fontWeight="800" fill={pwinColor}>{pwin}%</text>
              <text x={cx} y={cy + 10} textAnchor="middle" fontSize="10" fill="#888">PWIN</text>
            </svg>
            <div style={{ fontSize: 11, color: '#888', marginBottom: 8 }}>Weighted Score: {weightedScore} / 10</div>
            <div style={{ display: 'inline-block', padding: '5px 18px', borderRadius: 20, background: recommendation.bg, color: recommendation.color, fontWeight: 700, fontSize: 13 }}>
              {recommendation.label}
            </div>
            <div style={{ fontSize: 10, color: '#9CA3AF', marginTop: 8 }}>Source: Shipley-weighted assessment</div>
          </div>

          {/* Breakdown Table */}
          <div style={S.card}>
            <div style={{ fontSize: 12, fontWeight: 700, color: NAVY, marginBottom: 10 }}>Score Breakdown</div>
            <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 11 }}>
              <thead>
                <tr style={{ borderBottom: '1px solid ' + BORDER }}>
                  <th style={{ textAlign: 'left', padding: '4px 4px', color: '#888', fontWeight: 600 }}>Factor</th>
                  <th style={{ textAlign: 'center', padding: '4px 4px', color: '#888', fontWeight: 600 }}>Score</th>
                  <th style={{ textAlign: 'center', padding: '4px 4px', color: '#888', fontWeight: 600 }}>Wt</th>
                  <th style={{ textAlign: 'right', padding: '4px 4px', color: '#888', fontWeight: 600 }}>Contrib</th>
                </tr>
              </thead>
              <tbody>
                {FACTORS.map(f => {
                  const s = scores[f.key];
                  const contrib = (s * f.weight).toFixed(2);
                  return (
                    <tr key={f.key} style={{ borderBottom: '1px solid #f5f5f5' }}>
                      <td style={{ padding: '5px 4px', fontSize: 10, color: NAVY }}>{f.label}</td>
                      <td style={{ padding: '5px 4px', textAlign: 'center', fontWeight: 700, color: scoreColor(s) }}>{s}</td>
                      <td style={{ padding: '5px 4px', textAlign: 'center', color: '#888' }}>{Math.round(f.weight * 100)}%</td>
                      <td style={{ padding: '5px 4px', textAlign: 'right', fontWeight: 600 }}>{contrib}</td>
                    </tr>
                  );
                })}
                <tr style={{ borderTop: '2px solid ' + BORDER, background: '#fafafa' }}>
                  <td colSpan="3" style={{ padding: '6px 4px', fontWeight: 700, fontSize: 11, color: NAVY }}>Pwin</td>
                  <td style={{ padding: '6px 4px', textAlign: 'right', fontWeight: 800, fontSize: 14, color: pwinColor }}>{pwin}%</td>
                </tr>
              </tbody>
            </table>
          </div>

          {/* Gate Review */}
          <div style={S.card}>
            <div style={{ fontSize: 12, fontWeight: 700, color: NAVY, marginBottom: 12 }}>Shipley Gate Review</div>
            {gates.map((g, i) => (
              <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 10 }}>
                <div style={{
                  width: 28, height: 28, borderRadius: 14, border: '2px solid ' + (g.pass ? '#2F5C1F' : '#DC2626'),
                  background: g.pass ? '#2F5C1F' : WHITE, color: g.pass ? WHITE : '#DC2626',
                  display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 14, fontWeight: 700, flexShrink: 0 }}>
                  {g.pass ? '✓' : '✗'}
                </div>
                <div>
                  <div style={{ fontSize: 12, fontWeight: 600, color: g.pass ? '#2F5C1F' : '#888' }}>{g.label}</div>
                  <div style={{ fontSize: 10, color: '#aaa' }}>
                    {g.pass ? 'PASSED' : `Requires ${[25,40,50,60][i]}%+ Pwin`}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* History Modal */}
      {showHistory && (
        <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.5)', zIndex: 1000, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <div style={{ background: WHITE, borderRadius: 12, padding: 24, width: 680, maxWidth: '95vw', maxHeight: '80vh', overflow: 'auto' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
              <div style={{ fontSize: 16, fontWeight: 700, color: NAVY }}>Pwin Assessment History</div>
              <button onClick={() => setShowHistory(false)} style={{ background: 'none', border: 'none', fontSize: 20, cursor: 'pointer', color: '#888' }}>×</button>
            </div>
            {histLoading ? <div style={{ textAlign: 'center', padding: 40 }}><Spinner /></div> : history.length === 0 ? (
              <Empty msg="No saved assessments yet" />
            ) : (
              <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 12 }}>
                <thead>
                  <tr style={{ borderBottom: '2px solid ' + BORDER }}>
                    <th style={S.th}>Opportunity</th>
                    <th style={S.th}>Agency</th>
                    <th style={{ ...S.th, textAlign: 'center' }}>Pwin</th>
                    <th style={S.th}>Recommendation</th>
                    <th style={S.th}>Date</th>
                  </tr>
                </thead>
                <tbody>
                  {history.map((row, i) => {
                    const p = row.pwin || 0;
                    const pc = p >= 70 ? '#2F5C1F' : p >= 50 ? '#CA8A04' : p >= 35 ? '#EA580C' : '#DC2626';
                    return (
                      <tr key={i} style={{ borderBottom: '1px solid #f0f0f0', cursor: 'pointer' }} onClick={() => loadFromHistory(row)}>
                        <td style={{ ...S.td, fontWeight: 600, color: NAVY }}>{row.opportunity || '—'}</td>
                        <td style={S.td}>{row.agency || '—'}</td>
                        <td style={{ ...S.td, textAlign: 'center', fontWeight: 800, color: pc }}>{p}%</td>
                        <td style={S.td}>{row.recommendation || '—'}</td>
                        <td style={{ ...S.td, color: '#888', fontSize: 11 }}>{row.assessed_at ? new Date(row.assessed_at).toLocaleDateString() : '—'}</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            )}
            <div style={{ fontSize: 11, color: '#aaa', marginTop: 12 }}>Click a row to load scores into the calculator</div>
          </div>
        </div>
      )}
    </div>
  );
}
export default PwinCalculator;