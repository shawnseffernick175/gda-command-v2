import React, { useState, useEffect, useCallback, useRef, useMemo } from 'react';
import { ACCENT, NAVY, BG, WHITE, BORDER, FONT, N8N, AUTH, api, S, css, gdaNav, NAV_ITEMS, Spinner, Empty, Alert, PageHeader } from '../../lib/gda';

function WinLossDB() {
  var _tab = useState('record'); var tab = _tab[0]; var setTab = _tab[1];
  var _records = useState([]); var records = _records[0]; var setRecords = _records[1];
  var _loading = useState(false); var loading = _loading[0]; var setLoading = _loading[1];
  var _analysis = useState(null); var analysis = _analysis[0]; var setAnalysis = _analysis[1];
  var _analysisLoading = useState(false); var analysisLoading = _analysisLoading[0]; var setAnalysisLoading = _analysisLoading[1];
  var _expanded = useState(null); var expanded = _expanded[0]; var setExpanded = _expanded[1];
  var _toast = useState(''); var toast = _toast[0]; var setToast = _toast[1];
  var _saving = useState(false); var saving = _saving[0]; var setSaving = _saving[1];

  var defaultForm = {opportunity_title:'',solicitation_number:'',agency:'',naics_code:'',set_aside:'',contract_value:'',decision_outcome:'WIN',decision_date:new Date().toISOString().split('T')[0],winner:'',winning_price:'',our_price:'',debrief_summary:'',strengths:'',weaknesses:'',lessons_learned:'',competitor_names:'',teaming_partners:'',gda_unit:'EIS',capture_manager:'',proposal_lead:'',pwin_at_submission:50};
  var _form = useState(defaultForm); var form = _form[0]; var setForm = _form[1];

  function loadRecords() {
    setLoading(true);
    api.post('gda-win-loss',{action:'list'}).then(function(r){setRecords(r.records||r.data||[]);}).catch(function(){}).finally(function(){setLoading(false);});
  }
  useEffect(function(){loadRecords();},[]);

  var wins = records.filter(function(r){return r.decision_outcome==='WIN';}).length;
  var losses = records.filter(function(r){return r.decision_outcome==='LOSS';}).length;
  var noBids = records.filter(function(r){return r.decision_outcome==='NO_BID';}).length;
  var winRate = (wins+losses)>0?Math.round(wins/(wins+losses)*100):0;

  function submitRecord() {
    setSaving(true);
    var payload = Object.assign({action:'record'},form);
    payload.strengths = form.strengths.split(',').map(function(s){return s.trim();}).filter(Boolean);
    payload.weaknesses = form.weaknesses.split(',').map(function(s){return s.trim();}).filter(Boolean);
    payload.lessons_learned = form.lessons_learned.split(',').map(function(s){return s.trim();}).filter(Boolean);
    payload.competitor_names = form.competitor_names.split(',').map(function(s){return s.trim();}).filter(Boolean);
    payload.teaming_partners = form.teaming_partners.split(',').map(function(s){return s.trim();}).filter(Boolean);
    api.post('gda-win-loss',payload).then(function(){
      setForm(defaultForm);loadRecords();setToast('Decision recorded');setTimeout(function(){setToast('');},3000);
    }).catch(function(e){setToast('Error: '+e.message);}).finally(function(){setSaving(false);});
  }

  function runAnalysis() {
    setAnalysisLoading(true);setAnalysis(null);
    api.post('gda-win-loss',{action:'analyze'},{signal:AbortSignal.timeout(60000)}).then(function(r){setAnalysis(r);}).catch(function(e){setAnalysis({error:e.message});}).finally(function(){setAnalysisLoading(false);});
  }

  var outcomeBadge = function(o){var c={WIN:'#2F5C1F',LOSS:'#DC2626',NO_BID:'#6B7280',PROTEST:'#32448A',WITHDRAWN:'#B06D32'};var bg={WIN:'#2F5C1F15',LOSS:'#FEE2E2',NO_BID:'#F3F4F6',PROTEST:'#32448A12',WITHDRAWN:'#B06D3218'};return React.createElement('span',{style:{fontSize:10,fontWeight:700,padding:'2px 8px',borderRadius:10,color:c[o]||'#6B7280',background:bg[o]||'#F3F4F6'}},o||'UNKNOWN');};
  var TABS = [{id:'record',label:'Record'},{id:'history',label:'History'},{id:'analysis',label:'Analysis'}];

  return React.createElement('div', null,
    React.createElement(PageHeader, {title:'Win/Loss Database', sub:'Track bid outcomes, debrief insights, and competitive patterns'}),
    toast && React.createElement('div',{style:{padding:'8px 16px',background:'#2F5C1F12',border:'1px solid #86EFAC',borderRadius:8,marginBottom:12,fontSize:12,color:'#2F5C1F',fontWeight:600}},toast),
    React.createElement('div',{style:{display:'grid',gridTemplateColumns:'repeat(5,1fr)',gap:10,marginBottom:16}},
      React.createElement('div',{style:{background:'#fff',border:'1px solid #E8ECF1',borderRadius:10,padding:'12px',textAlign:'center',borderTop:'3px solid '+NAVY}},React.createElement('div',{style:{fontSize:11,color:'#6B7280'}},'Total'),React.createElement('div',{style:{fontSize:24,fontWeight:700,color:NAVY}},records.length)),
      React.createElement('div',{style:{background:'#fff',border:'1px solid #E8ECF1',borderRadius:10,padding:'12px',textAlign:'center',borderTop:'3px solid #2F5C1F'}},React.createElement('div',{style:{fontSize:11,color:'#6B7280'}},'Win Rate'),React.createElement('div',{style:{fontSize:24,fontWeight:700,color:'#2F5C1F'}},winRate+'%')),
      React.createElement('div',{style:{background:'#fff',border:'1px solid #E8ECF1',borderRadius:10,padding:'12px',textAlign:'center',borderTop:'3px solid #2F5C1F'}},React.createElement('div',{style:{fontSize:11,color:'#6B7280'}},'Wins'),React.createElement('div',{style:{fontSize:24,fontWeight:700,color:'#2F5C1F'}},wins)),
      React.createElement('div',{style:{background:'#fff',border:'1px solid #E8ECF1',borderRadius:10,padding:'12px',textAlign:'center',borderTop:'3px solid #DC2626'}},React.createElement('div',{style:{fontSize:11,color:'#6B7280'}},'Losses'),React.createElement('div',{style:{fontSize:24,fontWeight:700,color:'#DC2626'}},losses)),
      React.createElement('div',{style:{background:'#fff',border:'1px solid #E8ECF1',borderRadius:10,padding:'12px',textAlign:'center',borderTop:'3px solid #6B7280'}},React.createElement('div',{style:{fontSize:11,color:'#6B7280'}},'No-Bids'),React.createElement('div',{style:{fontSize:24,fontWeight:700,color:'#6B7280'}},noBids))
    ),
    React.createElement('div',{style:{display:'flex',gap:0,marginBottom:16}},
      TABS.map(function(t,ti){return React.createElement('button',{key:t.id,onClick:function(){setTab(t.id);},style:{padding:'9px 22px',fontSize:12,fontWeight:tab===t.id?700:400,color:tab===t.id?'#fff':NAVY,background:tab===t.id?ACCENT:'#fff',border:'1px solid '+(tab===t.id?ACCENT:BORDER),cursor:'pointer',borderRadius:ti===0?'6px 0 0 6px':ti===TABS.length-1?'0 6px 6px 0':'0'}},t.label);})
    ),
    tab==='record' && React.createElement('div',{style:{maxWidth:700}},
      React.createElement('div',{style:{background:'#fff',border:'1px solid #E8ECF1',borderRadius:10,padding:20}},
        React.createElement('div',{style:{fontSize:14,fontWeight:700,color:NAVY,marginBottom:14}},'Record Bid Decision'),
        React.createElement('div',{style:{display:'grid',gridTemplateColumns:'1fr 1fr',gap:10,marginBottom:12}},
          [{k:'opportunity_title',l:'Opportunity',p:'Opportunity name'},{k:'solicitation_number',l:'Solicitation #',p:'Sol number'},{k:'agency',l:'Agency',p:'Contracting agency'},{k:'naics_code',l:'NAICS',p:'NAICS code'},{k:'set_aside',l:'Set-Aside',p:'SB, 8(a), etc.'},{k:'contract_value',l:'Contract Value',p:'$X,XXX,XXX'},{k:'winner',l:'Winner (if loss)',p:'Winning company'},{k:'winning_price',l:'Winning Price',p:'$X,XXX,XXX'},{k:'our_price',l:'Our Price',p:'$X,XXX,XXX'},{k:'capture_manager',l:'Capture Mgr',p:'Name'},{k:'proposal_lead',l:'Proposal Lead',p:'Name'}].map(function(f){
            return React.createElement('div',{key:f.k},
              React.createElement('div',{style:{fontSize:11,fontWeight:600,color:'#666',marginBottom:3}},f.l),
              React.createElement('input',{style:S.input,placeholder:f.p,value:form[f.k],onChange:function(e){var n=Object.assign({},form);n[f.k]=e.target.value;setForm(n);}})
            );
          })
        ),
        React.createElement('div',{style:{display:'grid',gridTemplateColumns:'1fr 1fr 1fr',gap:10,marginBottom:12}},
          React.createElement('div',null,
            React.createElement('div',{style:{fontSize:11,fontWeight:600,color:'#666',marginBottom:3}},'Outcome'),
            React.createElement('select',{style:S.input,value:form.decision_outcome,onChange:function(e){setForm(Object.assign({},form,{decision_outcome:e.target.value}));}},
              ['WIN','LOSS','NO_BID','PROTEST','WITHDRAWN'].map(function(o){return React.createElement('option',{key:o,value:o},o);})
            )
          ),
          React.createElement('div',null,
            React.createElement('div',{style:{fontSize:11,fontWeight:600,color:'#666',marginBottom:3}},'Date'),
            React.createElement('input',{type:'date',style:S.input,value:form.decision_date,onChange:function(e){setForm(Object.assign({},form,{decision_date:e.target.value}));}})
          ),
          React.createElement('div',null,
            React.createElement('div',{style:{fontSize:11,fontWeight:600,color:'#666',marginBottom:3}},'GDA Unit'),
            React.createElement('select',{style:S.input,value:form.gda_unit,onChange:function(e){setForm(Object.assign({},form,{gda_unit:e.target.value}));}},
              ['EIS','PD Systems','Riverstone'].map(function(u){return React.createElement('option',{key:u,value:u},u);})
            )
          )
        ),
        React.createElement('div',{style:{marginBottom:12}},
          React.createElement('div',{style:{fontSize:11,fontWeight:600,color:'#666',marginBottom:3}},'Pwin at Submission: '+form.pwin_at_submission+'%'),
          React.createElement('input',{type:'range',min:0,max:100,value:form.pwin_at_submission,onChange:function(e){setForm(Object.assign({},form,{pwin_at_submission:parseInt(e.target.value)}));},style:{width:'100%'}})
        ),
        React.createElement('textarea',{style:Object.assign({},S.input,{marginBottom:8,minHeight:80}),placeholder:'Debrief summary...',value:form.debrief_summary,onChange:function(e){setForm(Object.assign({},form,{debrief_summary:e.target.value}));}}),
        [{k:'strengths',l:'Strengths (comma-separated)'},{k:'weaknesses',l:'Weaknesses'},{k:'lessons_learned',l:'Lessons Learned'},{k:'competitor_names',l:'Competitors'},{k:'teaming_partners',l:'Teaming Partners'}].map(function(f){
          return React.createElement('input',{key:f.k,style:Object.assign({},S.input,{marginBottom:8}),placeholder:f.l,value:form[f.k],onChange:function(e){var n=Object.assign({},form);n[f.k]=e.target.value;setForm(n);}});
        }),
        React.createElement('button',{onClick:submitRecord,disabled:saving||!form.opportunity_title,style:{background:ACCENT,color:'#fff',border:'none',borderRadius:6,padding:'10px 20px',fontSize:12,fontWeight:600,cursor:'pointer',opacity:saving||!form.opportunity_title?0.5:1}},saving?'Saving...':'Record Decision')
      )
    ),
    tab==='history' && React.createElement('div',null,
      loading && React.createElement('div',{style:{textAlign:'center',padding:20}},React.createElement(Spinner)),
      !loading && records.length===0 && React.createElement(Empty,{msg:'No bid decisions recorded yet.'}),
      !loading && records.map(function(r,i){
        var isOpen = expanded===r.id;
        return React.createElement('div',{key:r.id||i,style:{background:'#fff',border:'1px solid #E8ECF1',borderRadius:8,padding:'12px',marginBottom:8,cursor:'pointer'},onClick:function(){setExpanded(isOpen?null:r.id);}},
          React.createElement('div',{style:{display:'flex',justifyContent:'space-between',alignItems:'center'}},
            React.createElement('div',{style:{display:'flex',alignItems:'center',gap:10}},
              outcomeBadge(r.decision_outcome),
              React.createElement('span',{style:{fontSize:13,fontWeight:600,color:NAVY}},r.opportunity_title||'Untitled'),
              React.createElement('span',{style:{fontSize:11,color:'#6B7280'}},r.agency||'')
            ),
            React.createElement('div',{style:{display:'flex',alignItems:'center',gap:12}},
              r.contract_value && React.createElement('span',{style:{fontSize:12,fontWeight:600,color:'#2F5C1F'}},r.contract_value),
              r.decision_date && React.createElement('span',{style:{fontSize:11,color:'#9CA3AF'}},new Date(r.decision_date).toLocaleDateString()),
              r.pwin_at_submission!=null && React.createElement('span',{style:{fontSize:10,color:'#6B7280'}},'Pwin:'+r.pwin_at_submission+'%')
            )
          ),
          isOpen && React.createElement('div',{style:{marginTop:10,paddingTop:10,borderTop:'1px solid #E8ECF1',fontSize:12,lineHeight:1.7}},
            r.debrief_summary && React.createElement('div',{style:{marginBottom:6}},React.createElement('strong',null,'Debrief: '),r.debrief_summary),
            r.winner && React.createElement('div',null,React.createElement('strong',null,'Winner: '),r.winner),
            r.winning_price && React.createElement('div',null,React.createElement('strong',null,'Winning price: '),r.winning_price),
            r.our_price && React.createElement('div',null,React.createElement('strong',null,'Our price: '),r.our_price),
            Array.isArray(r.strengths)&&r.strengths.length>0 && React.createElement('div',null,React.createElement('strong',null,'Strengths: '),r.strengths.join(', ')),
            Array.isArray(r.weaknesses)&&r.weaknesses.length>0 && React.createElement('div',null,React.createElement('strong',null,'Weaknesses: '),r.weaknesses.join(', ')),
            Array.isArray(r.lessons_learned)&&r.lessons_learned.length>0 && React.createElement('div',null,React.createElement('strong',null,'Lessons: '),r.lessons_learned.join(', '))
          )
        );
      })
    ),
    tab==='analysis' && React.createElement('div',null,
      React.createElement('button',{onClick:runAnalysis,disabled:analysisLoading,style:{background:ACCENT,color:'#fff',border:'none',borderRadius:6,padding:'10px 20px',fontSize:12,fontWeight:600,cursor:'pointer',marginBottom:16,opacity:analysisLoading?0.5:1}},analysisLoading?'Analyzing...':'Run AI Analysis'),
      analysisLoading && React.createElement('div',{style:{textAlign:'center',padding:20}},React.createElement(Spinner)),
      analysis && analysis.error && React.createElement(Alert,{msg:analysis.error}),
      analysis && !analysis.error && React.createElement('div',null,
        analysis.win_patterns && React.createElement('div',{style:{background:'#2F5C1F15',borderRadius:8,padding:14,marginBottom:10,borderLeft:'4px solid #2F5C1F'}},
          React.createElement('div',{style:{fontSize:12,fontWeight:700,color:'#2F5C1F',marginBottom:4}},'Win Patterns'),
          React.createElement('div',{style:{fontSize:12,color:'#374151',lineHeight:1.6}},typeof analysis.win_patterns==='string'?analysis.win_patterns:JSON.stringify(analysis.win_patterns))
        ),
        analysis.loss_patterns && React.createElement('div',{style:{background:'#FEE2E2',borderRadius:8,padding:14,marginBottom:10,borderLeft:'4px solid #DC2626'}},
          React.createElement('div',{style:{fontSize:12,fontWeight:700,color:'#DC2626',marginBottom:4}},'Loss Patterns'),
          React.createElement('div',{style:{fontSize:12,color:'#374151',lineHeight:1.6}},typeof analysis.loss_patterns==='string'?analysis.loss_patterns:JSON.stringify(analysis.loss_patterns))
        ),
        analysis.recommendations && React.createElement('div',{style:{background:'#B06D3212',borderRadius:8,padding:14,marginBottom:10,borderLeft:'4px solid '+ACCENT}},
          React.createElement('div',{style:{fontSize:12,fontWeight:700,color:ACCENT,marginBottom:4}},'Recommendations'),
          React.createElement('div',{style:{fontSize:12,color:'#374151',lineHeight:1.6}},typeof analysis.recommendations==='string'?analysis.recommendations:Array.isArray(analysis.recommendations)?analysis.recommendations.join('; '):JSON.stringify(analysis.recommendations))
        ),
        !analysis.win_patterns && !analysis.loss_patterns && React.createElement('div',{style:{fontSize:12,color:'#374151',lineHeight:1.6,whiteSpace:'pre-wrap'}},JSON.stringify(analysis,null,2))
      )
    )
  );
}

export default WinLossDB;
