import React, { useState, useEffect, useCallback, useRef, useMemo } from 'react';
import { ACCENT, NAVY, BG, WHITE, BORDER, FONT, N8N, AUTH, api, S, css, gdaNav, NAV_ITEMS, Spinner, Empty, Alert, PageHeader, GDAKpiBar , saveAction, ActionHistory } from '../../lib/gda';
function CompetitorWatchlist() {
  const [tab, setTab] = useState('watchlist');
  const [regionFilter, setRegionFilter] = useState('All');
  const [competitors, setCompetitors] = useState([]);
  const [alerts, setAlerts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [alertLoading, setAlertLoading] = useState(false);
  const [showAdd, setShowAdd] = useState(false);
  const [profileModal, setProfileModal] = useState(null);
  const [profileData, setProfileData] = useState({});
  const [profileLoading, setProfileLoading] = useState(false);
  const [addForm, setAddForm] = useState({name:'',size:'Mid',agencies:'',capabilities:'',reason:''});
  const [addLoading, setAddLoading] = useState(false);
  const [askState, setAskState] = useState({});
  const [toast, setToast] = useState('');
  const [wlAdding, setWlAdding] = React.useState({});
  const [wlAdded, setWlAdded] = React.useState({});
  const sendToWatchlist = async (cname) => {
    setWlAdding(p => ({...p,[cname]:true}));
    try {
      await api.post('gda-competitor-watchlist', {action:'add',name:cname,source:'deep-dive'});
      setWlAdded(p => ({...p,[cname]:true}));
      setTimeout(() => setWlAdded(p => ({...p,[cname]:false})), 3000);
    } catch(e) {}
    setWlAdding(p => ({...p,[cname]:false}));
  };

  const showToast = (m) => { setToast(m); setTimeout(()=>setToast(''), 3000); };

  const load = async () => {
    setLoading(true);
    try {
      const d = await api.post('gda-competitor-watchlist', {action:'list'});
      setCompetitors(d && (d.competitors || d.data || []) || []);
    } catch(e) { setCompetitors([]); }
    setLoading(false);
  };

  useEffect(() => { load(); }, []);

  const loadAlerts = async () => {
    if (tab !== 'alerts') return;
    setAlertLoading(true);
    try {
      const names = competitors.map(c => c.name || c.company_name || '').filter(Boolean);
      const d = await api.post('gda-competitor-watchlist', {action:'monitor', competitors: names});
      setAlerts(d && (d.alerts || d.news || d.data || []) || []);
    } catch(e) { setAlerts([]); }
    setAlertLoading(false);
  };

  useEffect(() => { if (tab==='alerts' && competitors.length>0) loadAlerts(); }, [tab]);

  const addCompetitor = async () => {
    if (!addForm.name.trim()) return;
    setAddLoading(true);
    try {
      await api.post('gda-competitor-watchlist', {
        action:'add', name:addForm.name, size:addForm.size,
        target_agencies: addForm.agencies.split(',').map(s=>s.trim()).filter(Boolean),
        capabilities: addForm.capabilities.split(',').map(s=>s.trim()).filter(Boolean),
        reason: addForm.reason
      });
      setShowAdd(false); setAddForm({name:'',size:'Mid',agencies:'',capabilities:'',reason:''});
      await load();
      showToast('Added '+addForm.name);
    } catch(e) { showToast('Add failed: '+e.message); }
    setAddLoading(false);
  };

  const removeCompetitor = async (name) => {
    try {
      await api.post('gda-competitor-watchlist', {action:'remove', name});
      setCompetitors(cs => cs.filter(c=>(c.name||c.company_name)!==name));
      showToast('Removed '+name);
    } catch(e) { showToast('Remove failed: '+e.message); }
  };

  const openProfile = async (comp) => {
    const name = comp.name || comp.company_name || '';
    setProfileModal({...comp, name});
    if (profileData[name]) return;
    setProfileLoading(true);
    try {
      const d = await api.post('gda-competitor-watchlist', {action:'analyze', name}, {signal: AbortSignal.timeout(40000)}).catch(async (err) => {
        // Fallback: try ask action if analyze fails (502)
        try { return await api.post('gda-competitor-watchlist', {action:'ask', name, question:'Full competitive analysis of ' + name}); } catch(e2) { return {error: 'Deep Dive requires n8n AI Agent fix. Use AI Agent Chat tab for competitor analysis. Error: ' + (err.message || '502')}; }
      });
      setProfileData(pd => ({...pd, [name]: d}));
    } catch(e) { setProfileData(pd => ({...pd, [name]: {error: e.message}})); }
    setProfileLoading(false);
  };

  const askQuestion = async (name, question) => {
    setAskState(s => ({...s, [name]: {...s[name], loading:true, answer:null}}));
    try {
      const d = await api.post('gda-competitor-watchlist', {action:'ask', name, question});
      const ans = d && (d.answer||d.response||d.output||d.Summary||JSON.stringify(d));
      setAskState(s => ({...s, [name]: {...s[name], loading:false, answer: String(ans)}}));
    } catch(e) { setAskState(s => ({...s, [name]: {...s[name], loading:false, answer:'Error: '+e.message}})); }
  };

  const sizeBadge = (sz) => {
    const c = sz==='Large'?'#32448A':sz==='Small'?'#2F5C1F':'#EAB308';
    return <span style={{padding:'2px 8px',borderRadius:10,fontSize:11,fontWeight:600,background:c+'22',color:c,border:'1px solid '+c+'44'}}>{sz||'Mid'}</span>;
  };
  const relBadge = (rel) => {
    const r = (rel||'MONITOR').toUpperCase();
    const c = r==='THREAT'?'#DC2626':r==='TEAM'||r.includes('TEAM')?'#2F5C1F':'#6B7280';
    return <span style={{padding:'2px 8px',borderRadius:10,fontSize:11,fontWeight:600,background:c+'22',color:c,border:'1px solid '+c+'44'}}>{r}</span>;
  };
  const impBadge = (imp) => {
    const r = (imp||'').toUpperCase();
    const c = r==='HIGH'?'#DC2626':r==='LOW'?'#2F5C1F':'#EAB308';
    return <span style={{padding:'2px 8px',borderRadius:10,fontSize:11,fontWeight:600,background:c+'22',color:c,border:'1px solid '+c+'44'}}>{r||'MED'}</span>;
  };
  const threatBadge = (tl) => {
    const level = (tl || 'LOW').toUpperCase();
    const c = level === 'CRITICAL' ? '#DC2626' : level === 'HIGH' ? '#D14A2A' : level === 'MEDIUM' ? '#EAB308' : '#6B7280';
    return <span style={{padding:'2px 8px',borderRadius:10,fontSize:11,fontWeight:600,background:c+'22',color:c,border:'1px solid '+c+'44'}}>{level}</span>;
  };
  const alertTypeBadge = (t) => {
    const colors = {'CONTRACT AWARD':'#2F5C1F','LEADERSHIP':'#32448A','M&A':'#32448A','PROTEST':'#DC2626','PARTNERSHIP':'#D14A2A'};
    const tc = t ? t.toUpperCase() : 'OTHER';
    const c = colors[tc] || '#6B7280';
    return <span style={{padding:'2px 8px',borderRadius:6,fontSize:11,fontWeight:600,background:c+'22',color:c,border:'1px solid '+c+'44'}}>{tc}</span>;
  };

  const alertCount = alerts.filter(a => (a.eis_impact||'').toUpperCase()==='HIGH').length;

  return (
    <div>
      {/* Header */}
      <div style={{display:'flex',justifyContent:'space-between',alignItems:'flex-start',marginBottom:20,flexWrap:'wrap',gap:12}}>
        <div>
          <div style={{fontSize:24,fontWeight:700,color:'#1B2A4A'}}>Competitor Watchlist</div>
          <div style={{fontSize:13,color:'#6B7280',marginTop:4}}>GDA market competitors — {competitors.length} tracked</div>
        </div>
        <div style={{display:'flex',gap:8}}>
          <button onClick={()=>setShowAdd(true)} style={{padding:'8px 16px',background:'#32448A',color:'#fff',border:'none',borderRadius:6,fontSize:12,fontWeight:600,cursor:'pointer'}}>+ Add Competitor</button>
          <button onClick={()=>{setTab('alerts');loadAlerts();}} style={{padding:'8px 16px',background:'#C65D21',color:'#fff',border:'none',borderRadius:6,fontSize:12,fontWeight:600,cursor:'pointer'}}>Run Monitoring Now</button>
        </div>
      </div>

      {/* Tabs + Legend */}
      <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:16,flexWrap:'wrap',gap:8}}>
        <div style={{display:'flex',gap:8}}>
          <button onClick={()=>setTab('watchlist')} style={{padding:'8px 16px',border:'1px solid '+(tab==='watchlist'?'#1B2A4A':'#E8ECF1'),borderRadius:6,background:tab==='watchlist'?'#1B2A4A':'#fff',color:tab==='watchlist'?'#fff':'#1B2A4A',fontSize:12,fontWeight:600,cursor:'pointer'}}>Watchlist ({competitors.length})</button>
          <button onClick={()=>setTab('alerts')} style={{padding:'8px 16px',border:'1px solid '+(tab==='alerts'?'#1B2A4A':'#E8ECF1'),borderRadius:6,background:tab==='alerts'?'#1B2A4A':'#fff',color:tab==='alerts'?'#fff':'#1B2A4A',fontSize:12,fontWeight:600,cursor:'pointer'}}>Alerts {alertCount>0?'('+alertCount+' high)':''}</button>
        </div>
        <div style={{display:'flex',gap:6,alignItems:'center',fontSize:11,color:'#6B7280'}}>
          <span>Size:</span>
          {[['Large','#32448A'],['Mid','#EAB308'],['Small','#2F5C1F']].map(([s,c])=><span key={s} style={{padding:'2px 8px',borderRadius:10,fontSize:11,fontWeight:600,background:c+'22',color:c}}>{s}</span>)}
        </div>
      </div>

      {/* KPI Bar */}
      {!loading && <GDAKpiBar items={[
        {id:'tracked',label:'Competitors',value:competitors.length,color:'#1B2A4A',sub:'in watchlist'},
        {id:'high',label:'High+ Threat',value:competitors.filter(c=>(c.threat_level||'').toUpperCase()==='HIGH'||(c.threat_level||'').toUpperCase()==='CRITICAL').length,color:competitors.filter(c=>(c.threat_level||'').toUpperCase()==='HIGH'||(c.threat_level||'').toUpperCase()==='CRITICAL').length>0?'#DC2626':'#1B2A4A',sub:'medium+ threat'},
        {id:'scored',label:'Avg Threat Score',value:competitors.length>0?Math.round(competitors.reduce((s,c)=>s+(c.threat_score||0),0)/competitors.length):0,color:'#1B2A4A',sub:'out of 100'}
      ]} />}

      {/* Watchlist Tab */}
      {tab==='watchlist' && (
        <div>
          {loading && <div style={{textAlign:'center',padding:40,color:'#9CA3AF'}}>Loading competitors...</div>}
          {!loading && competitors.length===0 && <div style={{textAlign:'center',padding:40,color:'#9CA3AF'}}>No competitors tracked yet. Click "+ Add Competitor" to start.</div>}
          {/* Region Filter Buttons */}
          <div style={{display:'flex',gap:6,marginBottom:12,flexWrap:'wrap'}}>
            {['All','PEO STRI','Fort Liberty','TRADOC','Futures Command','General'].map(r => {
              const cnt = r === 'All' ? competitors.length : competitors.filter(c => c.region === r).length;
              return <button key={r} onClick={() => setRegionFilter(r)} style={{padding:'7px 14px',fontSize:12,borderRadius:20,border:'1px solid '+(regionFilter===r?'#CC5500':'#E8ECF1'),background:regionFilter===r?'#CC5500':'#fff',color:regionFilter===r?'#fff':'#1B2A4A',cursor:'pointer',fontWeight:600}}>{r}{cnt > 0 ? ' ('+cnt+')' : ''}</button>;
            })}
          </div>
          {/* Targeted Intelligence Header */}
          {regionFilter === 'All' && <div style={{fontSize:14,fontWeight:700,color:'#1B2A4A',marginBottom:8,borderBottom:'2px solid #D14A2A',paddingBottom:4}}>Targeted Intelligence</div>}
          {regionFilter === 'All' && ['PEO STRI','Fort Liberty','TRADOC','Futures Command','General'].map(cmd => {
            const cmdItems = competitors.filter(c => c.region === cmd);
            if (cmdItems.length === 0) return null;
            return <div key={cmd} style={{marginBottom:16}}>
              <div style={{fontSize:12,fontWeight:700,color:'#32448A',marginBottom:6,textTransform:'uppercase',letterSpacing:0.5}}>{cmd} ({cmdItems.length})</div>
              <div style={{display:'flex',gap:6,flexWrap:'wrap',marginBottom:8}}>
                {cmdItems.map((c,j) => <span key={j} onClick={() => {setRegionFilter(cmd);}} style={{padding:'4px 10px',background:'#EFF6FF',border:'1px solid #32448A33',borderRadius:6,fontSize:11,color:'#32448A',cursor:'pointer',fontWeight:500}}>{c.name} {c.threat_score ? ' • '+c.threat_score+'/100' : ''}</span>)}
              </div>
            </div>;
          })}
          {regionFilter === 'All' && <div style={{fontSize:14,fontWeight:700,color:'#1B2A4A',marginBottom:8,marginTop:12,borderBottom:'2px solid #5091A7',paddingBottom:4}}>All Competitors ({competitors.length})</div>}
          <div style={{display:'grid',gridTemplateColumns:'repeat(auto-fill,minmax(300px,1fr))',gap:16}}>
            {competitors.filter(c => regionFilter === 'All' || c.region === regionFilter).map((comp,i) => {
              const name = comp.name || comp.company_name || 'Unknown';
              const size = comp.size || 'Mid';
              const rel = comp.relationship || comp.status || 'MONITOR';
              const agencies = comp.target_agencies || comp.agencies || [];
              const caps = comp.capabilities || [];
              const ask = askState[name] || {};
              return (
                <div key={i} style={{background:'#fff',border:'1px solid #E8ECF1',borderRadius:10,padding:16}}>
                  <div style={{display:'flex',justifyContent:'space-between',alignItems:'flex-start',marginBottom:8}}>
                    <div style={{fontSize:16,fontWeight:700,color:'#1B2A4A',flex:1,paddingRight:8}}>{name}</div>
                    <button onClick={()=>removeCompetitor(name)} style={{background:'none',border:'none',color:'#DC2626',cursor:'pointer',fontSize:16,padding:'0 4px',lineHeight:1}}>🗑</button>
                  </div>
                  <div style={{display:'flex',gap:6,flexWrap:'wrap',marginBottom:8,alignItems:'center'}}>
                    {sizeBadge(size)}
                    {comp.threat_level && threatBadge(comp.threat_level)}
                    {comp.threat_score !== undefined && <span style={{fontSize:11,fontWeight:700,padding:'2px 8px',borderRadius:10,color:'#fff',background:comp.threat_score>=70?'#DC2626':comp.threat_score>=40?'#F59E0B':comp.threat_score>0?'#10B981':'#9CA3AF'}}>{comp.threat_score>0?comp.threat_score+'/100':'Unscored'}</span>}
                    {comp.region && comp.region !== 'General' && <span style={{padding:'2px 8px',borderRadius:10,fontSize:11,fontWeight:500,background:'#EFF6FF',color:'#32448A'}}>{comp.region}</span>}
                  </div>
                  {comp.total_obligated && parseFloat(comp.total_obligated) > 0 && <div style={{fontSize:11,color:'#2F5C1F',fontWeight:600,marginBottom:6}}>Obligated: ${(parseFloat(comp.total_obligated)/1000000).toFixed(1)}M</div>}
                  {comp.govtribe_url && <a href={comp.govtribe_url} target="_blank" rel="noopener noreferrer" style={{fontSize:11,color:'#D14A2A',fontWeight:600,textDecoration:'none',display:'block',marginBottom:6}}>View on GovTribe &rarr;</a>}
                  {agencies.length>0 && <div style={{marginBottom:6}}>
                    <div style={{fontSize:11,color:'#9CA3AF',textTransform:'uppercase',marginBottom:3}}>Target Agencies</div>
                    <div style={{display:'flex',gap:4,flexWrap:'wrap'}}>
                      {(Array.isArray(agencies)?agencies:String(agencies).split(',')).map((a,j)=><span key={j} style={{padding:'1px 6px',borderRadius:8,fontSize:11,border:'1px solid #32448A55',color:'#32448A',background:'#EFF6FF'}}>{typeof a==='string'?a.trim():String(a)}</span>)}
                    </div>
                  </div>}
                  {caps.length>0 && <div style={{marginBottom:10}}>
                    <div style={{fontSize:11,color:'#9CA3AF',textTransform:'uppercase',marginBottom:3}}>Capabilities</div>
                    <div style={{display:'flex',gap:4,flexWrap:'wrap'}}>
                      {(Array.isArray(caps)?caps:String(caps).split(',')).slice(0,5).map((c,j)=><span key={j} style={{padding:'1px 6px',borderRadius:8,fontSize:11,border:'1px solid #E8ECF1',color:'#555',background:'#F7F8FA'}}>{typeof c==='string'?c.trim():String(c)}</span>)}
                    </div>
                  </div>}
                  <div style={{display:'flex',gap:6,marginBottom:10}}>
                    <button onClick={()=>openProfile(comp)} style={{flex:1,padding:'6px 0',border:'1px solid #D14A2A',borderRadius:6,background:(profileModal&&profileModal.name===name&&profileLoading)?'#FEF2F2':'#fff',color:'#D14A2A',fontSize:12,fontWeight:600,cursor:'pointer'}}>{(profileModal&&profileModal.name===name&&profileLoading)?'Loading...':'View Profile'}</button>
                    <button style={{padding:'6px 12px',border:'1px solid #E8ECF1',borderRadius:6,background:'#fff',color:'#9CA3AF',fontSize:12,cursor:'pointer'}}>Pause</button>
                  </div>
                  {/* Ask Section */}
                  <div style={{borderTop:'1px solid #F0F0F0',paddingTop:10}}>
                    <div style={{display:'flex',gap:6}}>
                      <input
                        placeholder={'Ask about '+name+'...'}
                        value={ask.question||''}
                        onChange={e=>setAskState(s=>({...s,[name]:{...s[name],question:e.target.value}}))}
                        onKeyDown={e=>e.key==='Enter'&&ask.question&&askQuestion(name,ask.question)}
                        style={{flex:1,padding:'5px 8px',border:'1px solid #E8ECF1',borderRadius:6,fontSize:11,fontFamily:'Inter,sans-serif'}}
                      />
                      <button onClick={()=>ask.question&&askQuestion(name,ask.question)} disabled={ask.loading||!ask.question} style={{padding:'5px 10px',background:'#32448A',color:'#fff',border:'none',borderRadius:6,fontSize:11,fontWeight:600,cursor:'pointer',opacity:ask.loading||!ask.question?0.6:1}}>{ask.loading?'...':'Ask'}</button><button style={{marginLeft:6,padding:'5px 10px',border:'1px solid #1B2A4A',borderRadius:6,background:wlAdded[name]?'#2F5C1F':wlAdding[name]?'#6B7280':'#1B2A4A',color:'#fff',fontSize:11,fontWeight:600,cursor:'pointer'}} onClick={(e)=>{e.stopPropagation();sendToWatchlist(name);}}>{wlAdded[name]?'✓ Added':wlAdding[name]?'Adding...':'→ Watchlist'}</button>
                    </div>
                    {ask.answer && <div style={{marginTop:6,padding:'8px 10px',background:'#F7F8FA',borderRadius:6,fontSize:11,color:'#1B2A4A',lineHeight:1.5}}>{ask.answer}</div>}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Alerts Tab */}
      {tab==='alerts' && (
        <div>
          {alertLoading && <div style={{textAlign:'center',padding:40,color:'#9CA3AF'}}>Running competitive monitoring...</div>}
          {!alertLoading && alerts.length===0 && <div style={{textAlign:'center',padding:40,color:'#9CA3AF'}}>No alerts found. Run monitoring to scan for recent news.</div>}
          {alerts.map((a,i) => (
            <div key={i} style={{background:'#fff',border:'1px solid #E8ECF1',borderRadius:10,padding:16,marginBottom:12}}>
              <div style={{fontSize:16,fontWeight:700,color:'#1B2A4A',marginBottom:8}}>{String(a.headline||a.title||'')}</div>
              <div style={{display:'flex',gap:6,flexWrap:'wrap',alignItems:'center',marginBottom:8}}>
                {a.competitor && <span style={{padding:'2px 8px',borderRadius:10,fontSize:11,fontWeight:600,background:'#EFF6FF',color:'#32448A'}}>{String(a.competitor)}</span>}
                {alertTypeBadge(a.type||a.alert_type||'')}
                {(a.eis_impact||a.impact) && <><span style={{fontSize:11,color:'#6B7280'}}>EIS Impact:</span>{impBadge(a.eis_impact||a.impact)}</>}
              </div>
              {a.summary && <div style={{fontSize:13,color:'#555',lineHeight:1.6,marginBottom:8}}>{String(a.summary)}</div>}
              <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',flexWrap:'wrap',gap:4}}>
                <div style={{fontSize:11,color:'#9CA3AF'}}>{a.source&&String(a.source)}{a.date&&' · '+String(a.date)}</div>
                {a.url && <a href={String(a.url)} target="_blank" rel="noopener noreferrer" style={{fontSize:11,color:'#D14A2A',fontWeight:600}}>Read More →</a>}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Toast */}
      {toast && <div style={{position:'fixed',bottom:24,right:24,background:'#1B2A4A',color:'#fff',padding:'10px 20px',borderRadius:8,fontSize:13,fontWeight:600,zIndex:9999}}>{toast}</div>}

      {/* Add Competitor Modal */}
      {showAdd && (
        <div style={{position:'fixed',inset:0,background:'rgba(0,0,0,0.4)',display:'flex',alignItems:'center',justifyContent:'center',zIndex:9000}} onClick={()=>setShowAdd(false)}>
          <div style={{background:'#fff',borderRadius:12,padding:24,width:'100%',maxWidth:480,boxShadow:'0 20px 60px rgba(0,0,0,0.2)'}} onClick={e=>e.stopPropagation()}>
            <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:20}}>
              <div style={{fontSize:18,fontWeight:700,color:'#1B2A4A'}}>Add Competitor</div>
              <button onClick={()=>setShowAdd(false)} style={{background:'none',border:'none',fontSize:22,cursor:'pointer',color:'#6B7280'}}>×</button>
            </div>
            {[
              {label:'Company Name *', key:'name', placeholder:'e.g., Leidos'},
              {label:'Target Agencies', key:'agencies', placeholder:'SOCOM, TRADOC, DISA (comma-separated)'},
              {label:'Capabilities', key:'capabilities', placeholder:'C5ISR, SATCOM, Cloud (comma-separated)'},
              {label:'Reason for Tracking', key:'reason', placeholder:'Recently won Army C5ISR contract'},
            ].map(f=>(
              <div key={f.key} style={{marginBottom:14}}>
                <div style={{fontSize:12,fontWeight:600,color:'#1B2A4A',marginBottom:4}}>{f.label}</div>
                <input value={addForm[f.key]} onChange={e=>setAddForm(fm=>({...fm,[f.key]:e.target.value}))} placeholder={f.placeholder} style={{width:'100%',padding:'8px 12px',border:'1px solid #E8ECF1',borderRadius:6,fontSize:13,fontFamily:'Inter,sans-serif',boxSizing:'border-box'}} />
              </div>
            ))}
            <div style={{marginBottom:16}}>
              <div style={{fontSize:12,fontWeight:600,color:'#1B2A4A',marginBottom:6}}>Company Size</div>
              <div style={{display:'flex',gap:8}}>
                {['Large','Mid','Small'].map(s=>(
                  <button key={s} onClick={()=>setAddForm(fm=>({...fm,size:s}))} style={{flex:1,padding:'8px 0',border:'1px solid '+(addForm.size===s?'#D14A2A':'#E8ECF1'),borderRadius:6,background:addForm.size===s?'#D14A2A':'#fff',color:addForm.size===s?'#fff':'#1B2A4A',fontSize:12,fontWeight:600,cursor:'pointer'}}>{s}</button>
                ))}
              </div>
            </div>
            <button onClick={addCompetitor} disabled={addLoading||!addForm.name.trim()} style={{width:'100%',padding:'10px 0',background:'#C65D21',color:'#fff',border:'none',borderRadius:8,fontSize:14,fontWeight:600,cursor:'pointer',opacity:addLoading||!addForm.name.trim()?0.6:1}}>{addLoading?'Adding...':'Add Competitor'}</button>
          </div>
        </div>
      )}

      {/* Profile Modal */}
      {profileModal && (
        <div style={{position:'fixed',inset:0,background:'rgba(0,0,0,0.4)',display:'flex',alignItems:'center',justifyContent:'center',zIndex:9000,padding:16}} onClick={()=>setProfileModal(null)}>
          <div style={{background:'#fff',borderRadius:12,padding:24,width:'100%',maxWidth:680,maxHeight:'90vh',overflow:'auto',boxShadow:'0 20px 60px rgba(0,0,0,0.2)'}} onClick={e=>e.stopPropagation()}>
            <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:20}}>
              <div style={{fontSize:20,fontWeight:700,color:'#1B2A4A'}}>{profileModal.name}</div>
              <button onClick={()=>setProfileModal(null)} style={{background:'none',border:'none',fontSize:22,cursor:'pointer',color:'#6B7280'}}>×</button>
            </div>
            {profileLoading && !profileData[profileModal.name] && <div style={{textAlign:'center',padding:40,color:'#9CA3AF'}}><Spinner /><div style={{marginTop:8,fontSize:13}}>Analyzing {profileModal.name}... (20-30s)</div></div>}
            {profileData[profileModal.name] && (()=>{
              const pd = profileData[profileModal.name];
              if (pd.error) return <div style={{color:'#DC2626',padding:20}}>Analysis failed: {pd.error}</div>;
              const overview = pd.overview || pd.company_overview || {};
              const contracts = pd.known_contracts || pd.contracts || [];
              const teaming = pd.teaming_potential || pd.teaming || {};
              const eis = pd.eis_strategy || pd.eis_assessment || {};
              const rel = pd.relationship || pd.recommended_relationship || 'MONITOR';
              const relColor = /THREAT/i.test(rel)?'#DC2626':/TEAM/i.test(rel)?'#2F5C1F':'#EAB308';
              return (
                <div>
                  <div style={{display:'flex',gap:8,marginBottom:16}}>
                    {sizeBadge(profileModal.size)}
                    <span style={{padding:'4px 12px',borderRadius:10,fontSize:12,fontWeight:700,background:relColor+'22',color:relColor,border:'1px solid '+relColor+'44'}}>{rel.toUpperCase()}</span>
                  </div>
                  {/* Overview */}
                  <div style={{padding:'12px 16px',borderRadius:8,borderLeft:'3px solid #32448A',background:'#F7F8FA',marginBottom:12}}>
                    <div style={{fontSize:11,fontWeight:700,color:'#32448A',textTransform:'uppercase',marginBottom:6}}>Company Overview</div>
                    {(pd.overview_text || pd.narrative || pd.summary || pd.executive_summary) && <div style={{fontSize:13,color:'#1B2A4A',lineHeight:1.6,marginBottom:6}}>{String(pd.overview_text || pd.narrative || pd.summary || pd.executive_summary)}</div>}
                    <div style={{display:'flex',gap:16,flexWrap:'wrap',fontSize:12,color:'#555'}}>
                      {overview.revenue && <span><strong>Revenue:</strong> {String(overview.revenue)}</span>}
                      {overview.employees && <span><strong>Employees:</strong> {String(overview.employees)}</span>}
                      {overview.hq && <span><strong>HQ:</strong> {String(overview.hq)}</span>}
                      {overview.certifications && <span><strong>Certs:</strong> {String(Array.isArray(overview.certifications)?overview.certifications.join(', '):overview.certifications)}</span>}
                    </div>
                  </div>
                  {/* Contracts */}
                  {contracts.length>0 && <div style={{padding:'12px 16px',borderRadius:8,borderLeft:'3px solid #EAB308',background:'#F7F8FA',marginBottom:12}}>
                    <div style={{fontSize:11,fontWeight:700,color:'#D14A2A',textTransform:'uppercase',marginBottom:8}}>Known DoD Contracts</div>
                    <table style={{width:'100%',borderCollapse:'collapse',fontSize:12}}>
                      <thead><tr>{['Contract','Agency','Value','Period'].map(h=><th key={h} style={{textAlign:'left',padding:'4px 8px',borderBottom:'1px solid #E8ECF1',color:'#6B7280',fontSize:11}}>{h}</th>)}</tr></thead>
                      <tbody>{contracts.map((c,j)=><tr key={j} style={{borderBottom:'1px solid #F5F5F5'}}><td style={{padding:'6px 8px',color:'#1B2A4A',fontWeight:500}}>{String(c.name||c.contract||'')}</td><td style={{padding:'6px 8px',color:'#555'}}>{String(c.agency||'')}</td><td style={{padding:'6px 8px',color:'#2F5C1F',fontWeight:600}}>{String(c.value||'')}</td><td style={{padding:'6px 8px',color:'#555'}}>{String(c.period||c.dates||'')}</td></tr>)}</tbody>
                    </table>
                  </div>}
                  {/* Teaming */}
                  <div style={{padding:'12px 16px',borderRadius:8,borderLeft:'3px solid #D14A2A',background:'#F7F8FA',marginBottom:12}}>
                    <div style={{fontSize:11,fontWeight:700,color:'#D14A2A',textTransform:'uppercase',marginBottom:6}}>Teaming Potential</div>
                    <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:8,fontSize:12}}>
                      {teaming.viable!==undefined && <div><strong>Viable:</strong> {String(teaming.viable?'Yes':'No')}</div>}
                      {teaming.as_prime && <div><strong>As Prime:</strong> {String(teaming.as_prime)}</div>}
                      {teaming.as_sub && <div><strong>As Sub:</strong> {String(teaming.as_sub)}</div>}
                      {teaming.complementary_capabilities && <div style={{gridColumn:'1/-1'}}><strong>Complementary:</strong> {String(Array.isArray(teaming.complementary_capabilities)?teaming.complementary_capabilities.join(', '):teaming.complementary_capabilities)}</div>}
                    </div>
                  </div>
                  {/* EIS Strategy */}
                  <div style={{padding:'12px 16px',borderRadius:8,borderLeft:'3px solid #DC2626',background:'#FEF2F2'}}>
                    <div style={{fontSize:11,fontWeight:700,color:'#DC2626',textTransform:'uppercase',marginBottom:6}}>EIS Threat Assessment & Strategy</div>
                    <div style={{fontSize:12,color:'#1B2A4A',lineHeight:1.6}}>
                      {eis.if_threat && <div style={{marginBottom:4}}><strong>If Threat:</strong> {String(eis.if_threat)}</div>}
                      {eis.if_partner && <div style={{marginBottom:4}}><strong>If Partner:</strong> {String(eis.if_partner)}</div>}
                      {eis.recommended_action && <div style={{marginTop:6,padding:'6px 10px',background:'#fff',borderRadius:6,fontWeight:500}}><strong>Recommended:</strong> {String(eis.recommended_action)}</div>}
                    </div>
                  </div>
                </div>
              );
            })()}
          </div>
        </div>
      )}
    </div>
  );
}
export default CompetitorWatchlist;