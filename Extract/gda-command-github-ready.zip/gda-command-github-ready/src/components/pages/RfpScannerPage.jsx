import React, { useState, useCallback, useRef, useEffect } from 'react';
import { GDAKpiBar } from '../../lib/gda';

const ACCENT = '#D14A2A';
const NAVY = '#1a2744';
const BORDER = '#e0e0e0';
const WHITE = '#ffffff';
const N8N = '/api';
const AUTH = { 'Content-Type': 'application/json' };

const api = {
  post: async (path, body = {}) => {
    const r = await fetch(`${N8N}/${path}`, { method: 'POST', headers: AUTH, body: JSON.stringify(body) });
    if (!r.ok) throw new Error(`${r.status}`);
    const t = await r.text(); return t.trim() ? JSON.parse(t) : {};
  }
};

// ── Document Parser (lazy-loaded CDN libs) ──
const parsers = {
  ready: false,
  loading: false,
  async init() {
    if (this.ready || this.loading) return;
    this.loading = true;
    const load = (url) => new Promise((res, rej) => {
      if (document.querySelector(`script[src="${url}"]`)) return res();
      const s = document.createElement('script'); s.src = url;
      s.onload = res; s.onerror = rej; document.head.appendChild(s);
    });
    try {
      await Promise.all([
        load('https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js'),
        load('https://cdnjs.cloudflare.com/ajax/libs/mammoth/1.6.0/mammoth.browser.min.js'),
        load('https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js'),
        load('https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js')
      ]);
      if (window.pdfjsLib) window.pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js';
      this.ready = true;
    } catch (e) { console.warn('Parser load failed:', e); }
    this.loading = false;
  },
  async extract(file) {
    await this.init();
    const name = file.name.toLowerCase();
    try {
      if (name.endsWith('.pdf') && window.pdfjsLib) {
        const buf = await file.arrayBuffer();
        const pdf = await window.pdfjsLib.getDocument({ data: buf }).promise;
        let text = '';
        for (let i = 1; i <= pdf.numPages; i++) {
          const page = await pdf.getPage(i);
          const tc = await page.getTextContent();
          text += tc.items.map(t => t.str).join(' ') + '\n';
        }
        return text;
      }
      if ((name.endsWith('.docx') || name.endsWith('.doc')) && window.mammoth) {
        const buf = await file.arrayBuffer();
        const r = await window.mammoth.extractRawText({ arrayBuffer: buf });
        return r.value;
      }
      if ((name.endsWith('.xlsx') || name.endsWith('.xls')) && window.XLSX) {
        const buf = await file.arrayBuffer();
        const wb = window.XLSX.read(buf, { type: 'array' });
        return wb.SheetNames.map(n => window.XLSX.utils.sheet_to_csv(wb.Sheets[n])).join('\n\n');
      }
      if ((name.endsWith('.pptx') || name.endsWith('.ppt')) && window.JSZip) {
        const zip = await window.JSZip.loadAsync(file);
        let text = '';
        const slides = Object.keys(zip.files).filter(f => f.match(/slide\d+\.xml$/)).sort();
        for (const s of slides) {
          const xml = await zip.files[s].async('string');
          text += xml.replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ') + '\n';
        }
        return text;
      }
      if (name.endsWith('.csv') || name.endsWith('.txt')) {
        return await file.text();
      }
      return `[Unsupported format: ${name}]`;
    } catch (e) {
      return `[Extraction failed for ${name}: ${e.message}]`;
    }
  }
};

// ── Styles ──
const sty = {
  card: { background: WHITE, border: `1px solid ${BORDER}`, borderRadius: 8, padding: '16px 20px', marginBottom: 14 },
  cardTitle: { fontSize: 14, fontWeight: 700, color: NAVY, marginBottom: 10 },
  btn: (v = 'primary', sm = false) => ({
    padding: sm ? '5px 10px' : '10px 20px', borderRadius: 6, border: 'none', cursor: 'pointer',
    fontSize: sm ? 11 : 13, fontWeight: 600, transition: 'all 0.15s',
    background: v === 'primary' ? ACCENT : v === 'green' ? '#22a06b' : v === 'outline' ? 'transparent' : '#eee',
    color: v === 'outline' ? ACCENT : WHITE,
    ...(v === 'outline' ? { border: `1px solid ${ACCENT}` } : {})
  }),
  badge: (c = 'gray') => ({
    display: 'inline-block', padding: '3px 10px', borderRadius: 12, fontSize: 11, fontWeight: 600,
    background: c === 'green' ? '#2F5C1F15' : c === 'red' ? '#ffebe6' : c === 'orange' ? '#fff3e0' : '#f4f5f7',
    color: c === 'green' ? '#2F5C1F' : c === 'red' ? '#bf2600' : c === 'orange' ? '#B06D32' : '#555'
  }),
  tab: (active) => ({
    padding: '8px 16px', borderRadius: '6px 6px 0 0', border: `1px solid ${active ? ACCENT : BORDER}`,
    borderBottom: active ? `2px solid ${ACCENT}` : 'none', background: active ? WHITE : '#fafafa',
    color: active ? ACCENT : '#666', fontSize: 12, fontWeight: active ? 700 : 400, cursor: 'pointer'
  }),
  dropZone: (active, over) => ({
    border: `2px dashed ${over ? ACCENT : BORDER}`, borderRadius: 8, padding: '24px 16px',
    textAlign: 'center', cursor: 'pointer', transition: 'all 0.2s', minHeight: 120,
    background: over ? '#fff8f4' : active ? '#f0faf0' : '#fafafa',
    flex: 1
  }),
  fileChip: { display: 'inline-flex', alignItems: 'center', gap: 6, background: '#f0f0f0', borderRadius: 16, padding: '4px 12px', fontSize: 11, margin: '3px 4px' },
};

// ── Compliance Matrix Row ──
const ComplianceRow = ({ item }) => {
  const statusColors = { Compliant: 'green', Partial: 'orange', 'Non-Compliant': 'red', Missing: 'red' };
  return (
    <tr>
      <td style={{ padding: '8px 10px', borderBottom: '1px solid #f0f0f0', fontSize: 12, maxWidth: 300 }}>{item.requirement}</td>
      <td style={{ padding: '8px 10px', borderBottom: '1px solid #f0f0f0', fontSize: 11, color: '#666' }}>{item.rfp_reference || '-'}</td>
      <td style={{ padding: '8px 10px', borderBottom: '1px solid #f0f0f0', fontSize: 11, color: '#666' }}>{item.response_reference || '-'}</td>
      <td style={{ padding: '8px 10px', borderBottom: '1px solid #f0f0f0' }}>
        <span style={sty.badge(statusColors[item.status] || 'gray')}>{item.status}</span>
      </td>
      <td style={{ padding: '8px 10px', borderBottom: '1px solid #f0f0f0', fontSize: 11, color: '#666' }}>{item.notes || ''}</td>
    </tr>
  );
};

// ── Main Component ──
export default function RfpScannerPage() {
  const [govFiles, setGovFiles] = useState([]);
  const [responseFiles, setResponseFiles] = useState([]);
  const [govText, setGovText] = useState('');
  const [responseText, setResponseText] = useState('');
  const [loading, setLoading] = useState(false);
  const [loadingStep, setLoadingStep] = useState('');
  const [result, setResult] = useState(null);
  const [error, setError] = useState('');
  const [activeTab, setActiveTab] = useState('summary');
  const [reviewType, setReviewType] = useState('red');

  const REVIEW_TYPES = [
    { id: 'blue', label: 'Blue Team', desc: 'Pre-Proposal/Strategy', color: '#32448A' },
    { id: 'pink', label: 'Pink Team', desc: 'Storyline/Draft', color: '#DB2777' },
    { id: 'red', label: 'Red Team', desc: 'Evaluation/Critique', color: '#D14A2A' },
    { id: 'green', label: 'Green Team', desc: 'Pricing Review', color: '#2F5C1F' },
    { id: 'gold', label: 'Gold Team', desc: 'Final Approval', color: '#B06D32' },
    { id: 'white', label: 'White Hat', desc: 'Post-Submittal Check', color: '#5091A7' },
  ];
  const [govDragOver, setGovDragOver] = useState(false);
  const [resDragOver, setResDragOver] = useState(false);
  const [chatInput, setChatInput] = useState('');
  const [messages, setMessages] = useState([]);
  const [chatLoading, setChatLoading] = useState(false);
  const [complianceFilter, setComplianceFilter] = useState('all');
  const [pastedGov, setPastedGov] = useState('');
  const [pastedRes, setPastedRes] = useState('');

  useEffect(() => { parsers.init(); }, []);

  // File handling
  const handleFiles = useCallback(async (fileList, side) => {
    const files = Array.from(fileList).filter(f =>
      /\.(pdf|docx?|xlsx?|pptx?|csv|txt)$/i.test(f.name)
    );
    if (!files.length) return;

    const setter = side === 'gov' ? setGovFiles : setResponseFiles;
    const textSetter = side === 'gov' ? setGovText : setResponseText;

    const processed = [];
    for (const f of files) {
      const content = await parsers.extract(f);
      processed.push({ name: f.name, size: f.size, content });
    }

    setter(prev => [...prev, ...processed]);
    textSetter(prev => prev + '\n\n' + processed.map(p => `--- ${p.name} ---\n${p.content}`).join('\n\n'));
  }, []);

  const removeFile = (side, idx) => {
    const setter = side === 'gov' ? setGovFiles : setResponseFiles;
    const textSetter = side === 'gov' ? setGovText : setResponseText;
    setter(prev => {
      const updated = prev.filter((_, i) => i !== idx);
      textSetter(updated.map(p => `--- ${p.name} ---\n${p.content}`).join('\n\n'));
      return updated;
    });
  };

  const openPicker = (side) => {
    const input = document.createElement('input');
    input.type = 'file';
    input.multiple = true;
    input.accept = '.pdf,.docx,.doc,.xlsx,.xls,.pptx,.ppt,.csv,.txt';
    input.onchange = (e) => handleFiles(e.target.files, side);
    input.click();
  };

  const dropHandler = (e, side) => {
    e.preventDefault();
    (side === 'gov' ? setGovDragOver : setResDragOver)(false);
    handleFiles(e.dataTransfer.files, side);
  };

  // Analyze
  const analyze = async () => {
    const allGovText = govText + (pastedGov ? '\n\n' + pastedGov : '');
    const allResText = responseText + (pastedRes ? '\n\n' + pastedRes : '');

    if (!allGovText.trim() && !allResText.trim()) {
      setError('Upload at least one document or paste text to analyze.');
      return;
    }

    setLoading(true); setError(''); setResult(null);
    const steps = ['Extracting document content...', 'Analyzing legal compliance...', 'Evaluating competitive position...', 'Running Black Hat analysis...', 'Assessing operational risk...', 'Computing 5C+4C risk scores...', 'Generating draft response...', 'Building final report...'];
    let stepIdx = 0;
    const interval = setInterval(() => { setLoadingStep(steps[Math.min(stepIdx++, steps.length - 1)]); }, 4000);

    try {
      setLoadingStep(steps[0]);
      const payload = {
        rfp_text: allGovText,
        proposal_text: allResText,
        file_count: govFiles.length + responseFiles.length,
        gov_file_names: govFiles.map(f => f.name),
        response_file_names: responseFiles.map(f => f.name),
        action: 'review',
        review_type: reviewType,
        review_label: (REVIEW_TYPES.find(t => t.id === reviewType) || {}).label || 'Red Team'
      };
      const data = await api.post('gda-red-team', payload);

      if (data.error) {
        setError(data.message || 'Analysis failed');
      } else {
        setResult(data);
        setActiveTab('summary');
      }
    } catch (e) {
      setError('Analysis failed: ' + e.message);
    } finally {
      clearInterval(interval);
      setLoading(false);
      setLoadingStep('');
    }
  };

  // Chat
  const sendChat = async () => {
    if (!chatInput.trim() || !result) return;
    const q = chatInput.trim();
    setChatInput('');
    setMessages(prev => [...prev, { role: 'user', text: q }]);
    setChatLoading(true);
    try {
      const r = await api.post('gda-chat-v2', {
        message: q,
        context: `Red Team analysis for: ${result.rfp_title || 'RFP'}\nAgency: ${result.agency || ''}\nGo/No-Go: ${result.go_no_go || ''}\nWin Probability: ${result.win_probability || ''}`,
        session_id: 'redteam_chat_' + Date.now()
      });
      setMessages(prev => [...prev, { role: 'ai', text: r.reply || r.response || r.output || 'No response.' }]);
    } catch (e) {
      setMessages(prev => [...prev, { role: 'ai', text: 'Error: ' + e.message }]);
    }
    setChatLoading(false);
  };

  // Reset
  const reset = () => {
    setGovFiles([]); setResponseFiles([]); setGovText(''); setResponseText('');
    setPastedGov(''); setPastedRes('');
    setResult(null); setError(''); setMessages([]);
  };

  // ── RENDER: Upload Phase ──
  if (!result && !loading) {
    return (
      <div>
        <div style={{ fontSize: 20, fontWeight: 700, color: NAVY, marginBottom: 4 }}>{(REVIEW_TYPES.find(t => t.id === reviewType) || {}).label || 'Red Team'} Review</div>
        <div style={{ fontSize: 12, color: '#666', marginBottom: 12 }}>Two-document comparison: Government docs vs. your proposal response</div>

        {/* Review Type Selector */}
        <div style={{ display: 'flex', gap: 4, marginBottom: 16, flexWrap: 'wrap' }}>
          {REVIEW_TYPES.map(t => (
            <button key={t.id} onClick={() => setReviewType(t.id)} style={{
              padding: '6px 14px', borderRadius: 6, border: reviewType === t.id ? '2px solid ' + t.color : '1px solid #ddd',
              background: reviewType === t.id ? t.color + '15' : '#fff', cursor: 'pointer',
              display: 'flex', flexDirection: 'column', alignItems: 'flex-start', gap: 1, minWidth: 110,
            }}>
              <span style={{ fontSize: 11, fontWeight: 700, color: reviewType === t.id ? t.color : NAVY }}>{t.label}</span>
              <span style={{ fontSize: 9, color: '#888' }}>{t.desc}</span>
            </button>
          ))}
        </div>

        {error && <div style={{ background: '#ffebe6', color: '#bf2600', padding: '10px 14px', borderRadius: 6, fontSize: 12, marginBottom: 12 }}>{error}</div>}

        <div style={{ display: 'flex', gap: 16, marginBottom: 16 }}>
          {/* LEFT: Government Documents */}
          <div style={{ flex: 1 }}>
            <div style={{ ...sty.card }}>
              <div style={{ ...sty.cardTitle, color: '#32448A' }}>Government Documents</div>
              <div style={{ fontSize: 11, color: '#666', marginBottom: 10 }}>RFP, SOW, PWS, amendments, evaluation criteria</div>
              <div
                style={sty.dropZone(govFiles.length > 0, govDragOver)}
                onClick={() => openPicker('gov')}
                onDrop={(e) => dropHandler(e, 'gov')}
                onDragOver={(e) => { e.preventDefault(); setGovDragOver(true); }}
                onDragLeave={() => setGovDragOver(false)}
              >
                {govFiles.length === 0 ? (
                  <div>
                    <div style={{ fontSize: 28, marginBottom: 6 }}>📄</div>
                    <div style={{ fontSize: 12, color: '#666' }}>Drop government docs here or click to browse</div>
                    <div style={{ fontSize: 10, color: '#aaa', marginTop: 4 }}>PDF, Word, Excel, PowerPoint, CSV, TXT</div>
                  </div>
                ) : (
                  <div style={{ textAlign: 'left' }}>
                    {govFiles.map((f, i) => (
                      <div key={i} style={sty.fileChip}>
                        <span>📄 {f.name}</span>
                        <span style={{ fontSize: 10, color: '#999' }}>({(f.content || '').length.toLocaleString()} chars)</span>
                        <span onClick={(e) => { e.stopPropagation(); removeFile('gov', i); }} style={{ cursor: 'pointer', color: '#e53935', fontWeight: 700 }}>x</span>
                      </div>
                    ))}
                    <div style={{ fontSize: 10, color: '#aaa', marginTop: 6 }}>Click to add more files</div>
                  </div>
                )}
              </div>
              <textarea
                placeholder="Or paste government document text here..."
                value={pastedGov}
                onChange={(e) => setPastedGov(e.target.value)}
                style={{ width: '100%', padding: 8, border: `1px solid ${BORDER}`, borderRadius: 6, fontSize: 11, marginTop: 8, minHeight: 60, resize: 'vertical' }}
              />
            </div>
          </div>

          {/* RIGHT: Our Response */}
          <div style={{ flex: 1 }}>
            <div style={{ ...sty.card }}>
              <div style={{ ...sty.cardTitle, color: '#22a06b' }}>Our Proposal Response</div>
              <div style={{ fontSize: 11, color: '#666', marginBottom: 10 }}>Proposal, past performance, pricing volume, tech approach</div>
              <div
                style={sty.dropZone(responseFiles.length > 0, resDragOver)}
                onClick={() => openPicker('res')}
                onDrop={(e) => dropHandler(e, 'res')}
                onDragOver={(e) => { e.preventDefault(); setResDragOver(true); }}
                onDragLeave={() => setResDragOver(false)}
              >
                {responseFiles.length === 0 ? (
                  <div>
                    <div style={{ fontSize: 28, marginBottom: 6 }}>📝</div>
                    <div style={{ fontSize: 12, color: '#666' }}>Drop proposal response here or click to browse</div>
                    <div style={{ fontSize: 10, color: '#aaa', marginTop: 4 }}>Optional — RFP-only analysis if omitted</div>
                  </div>
                ) : (
                  <div style={{ textAlign: 'left' }}>
                    {responseFiles.map((f, i) => (
                      <div key={i} style={sty.fileChip}>
                        <span>📝 {f.name}</span>
                        <span style={{ fontSize: 10, color: '#999' }}>({(f.content || '').length.toLocaleString()} chars)</span>
                        <span onClick={(e) => { e.stopPropagation(); removeFile('res', i); }} style={{ cursor: 'pointer', color: '#e53935', fontWeight: 700 }}>x</span>
                      </div>
                    ))}
                    <div style={{ fontSize: 10, color: '#aaa', marginTop: 6 }}>Click to add more files</div>
                  </div>
                )}
              </div>
              <textarea
                placeholder="Or paste proposal response text here..."
                value={pastedRes}
                onChange={(e) => setPastedRes(e.target.value)}
                style={{ width: '100%', padding: 8, border: `1px solid ${BORDER}`, borderRadius: 6, fontSize: 11, marginTop: 8, minHeight: 60, resize: 'vertical' }}
              />
            </div>
          </div>
        </div>

        <div style={{ display: 'flex', gap: 12, justifyContent: 'center' }}>
          <button style={sty.btn('primary')} onClick={analyze}>
            Analyze {responseFiles.length > 0 || pastedRes ? '(RFP vs Response)' : '(RFP Only)'}
          </button>
        </div>
      </div>
    );
  }

  // ── RENDER: Loading ──
  if (loading) {
    return (
      <div style={{ textAlign: 'center', padding: '80px 20px' }}>
        <div style={{ width: 48, height: 48, border: `3px solid ${BORDER}`, borderTopColor: ACCENT, borderRadius: '50%', animation: 'spin 0.8s linear infinite', margin: '0 auto 20px' }} />
        <div style={{ fontSize: 16, fontWeight: 600, color: NAVY, marginBottom: 8 }}>Red Team Analysis in Progress</div>
        <div style={{ fontSize: 12, color: '#666', marginBottom: 4 }}>{loadingStep}</div>
        <div style={{ fontSize: 11, color: '#aaa' }}>{govFiles.length + responseFiles.length} document(s) being analyzed by 5 AI reviewers</div>
      </div>
    );
  }

  // ── RENDER: Results ──
  const r = result;
  const goColor = r.go_no_go === 'GO' ? 'green' : r.go_no_go === 'NO-GO' ? 'red' : 'orange';
  const tabs = [
    { id: 'summary', label: 'Summary' },
    { id: 'compliance', label: `Compliance Matrix${r.compliance_matrix?.length ? ` (${r.compliance_matrix.length})` : ''}` },
    { id: 'strengths', label: 'Strengths & Weaknesses' },
    { id: 'ghost', label: 'Ghost Themes' },
    { id: 'technical', label: 'Technical' },
    { id: 'risk', label: 'Risk 5C+4C' },
    { id: 'draft', label: 'Draft Response' }
  ];

  const filteredMatrix = (r.compliance_matrix || []).filter(item =>
    complianceFilter === 'all' ? true :
    complianceFilter === 'issues' ? (item.status !== 'Compliant') :
    item.status === complianceFilter
  );

  return (
    <div>
      {/* Header Bar */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14 }}>
        <div>
          <div style={{ fontSize: 20, fontWeight: 700, color: NAVY }}>{r.rfp_title || 'Red Team Analysis'}</div>
          <div style={{ fontSize: 12, color: '#666' }}>
            {r.agency || ''} {r.solicitation_number ? `| Sol: ${r.solicitation_number}` : ''} {r.naics ? `| NAICS: ${r.naics}` : ''}
            {r.mode === 'comparison' ? ' | Two-Document Comparison' : ' | RFP-Only Analysis'}
          </div>
        </div>
        <div style={{ display: 'flex', gap: 8 }}>
          <button style={sty.btn('outline', true)} onClick={() => navigator.clipboard.writeText(JSON.stringify(r, null, 2))}>Copy JSON</button>
          <button style={sty.btn('outline', true)} onClick={reset}>New Analysis</button>
        </div>
      </div>

      {/* KPI Bar */}
      <GDAKpiBar items={[
        {id:'gonogo',label:'Go / No-Go',value:r.go_no_go||'HOLD',color:(r.go_no_go||'').toUpperCase()==='GO'?'#2F5C1F':(r.go_no_go||'').toUpperCase()==='NO-GO'?'#DC2626':'#B06D32',sub:r.go_confidence?(r.go_confidence+' confidence'):''},
        {id:'pwin',label:'Win Probability',value:(r.win_probability||r.pwin||'--')+'%',color:parseInt(r.win_probability||r.pwin||0)>=60?'#2F5C1F':parseInt(r.win_probability||r.pwin||0)>=30?'#B06D32':'#DC2626',sub:'estimated'},
        {id:'teams',label:'Color Reviews',value:String((r.color_team_reviews||[]).length||0),sub:'completed'}
      ]} />
      <div style={{ display: 'flex', gap: 12, background: WHITE, border: '1px solid '+BORDER, borderRadius: 8, padding: '14px 18px', marginBottom: 14 }}>
        <div style={{ flex: 1 }}>
          <div style={{ fontSize: 9, fontWeight: 700, color: '#888', letterSpacing: '0.5px', textTransform: 'uppercase', marginBottom: 3 }}>Go / No-Go</div>
          <span style={{ ...sty.badge(goColor), fontSize: 16, fontWeight: 700, padding: '6px 16px' }}>{r.go_no_go || 'HOLD'}</span>
          {r.go_confidence && <span style={{ fontSize: 10, color: '#999', marginLeft: 6 }}>({r.go_confidence} confidence)</span>}
        </div>
        <div style={{ flex: 1 }}>
          <div style={{ fontSize: 9, fontWeight: 700, color: '#888', letterSpacing: '0.5px', textTransform: 'uppercase', marginBottom: 3 }}>Win Probability</div>
          <div style={{ fontSize: 22, fontWeight: 700, color: NAVY }}>{r.win_probability || 'N/A'}</div>
          {r.win_probability_rationale && <div style={{ fontSize: 10, color: '#999', marginTop: 2 }}>{r.win_probability_rationale.substring(0, 100)}</div>}
        </div>
        <div style={{ flex: 1 }}>
          <div style={{ fontSize: 9, fontWeight: 700, color: '#888', letterSpacing: '0.5px', textTransform: 'uppercase', marginBottom: 3 }}>Risk Score</div>
          <div style={{ fontSize: 22, fontWeight: 700, color: NAVY }}>{r.overall_risk_score || 'N/A'}</div>
        </div>
        <div style={{ flex: 1 }}>
          <div style={{ fontSize: 9, fontWeight: 700, color: '#888', letterSpacing: '0.5px', textTransform: 'uppercase', marginBottom: 3 }}>Docs Analyzed</div>
          <div style={{ fontSize: 22, fontWeight: 700, color: NAVY }}>{r.file_count || (govFiles.length + responseFiles.length) || 0}</div>
          <div style={{ fontSize: 10, color: '#999' }}>{r.mode === 'comparison' ? 'Gov + Response' : 'Gov only'}</div>
        </div>
        {r.compliance_score != null && (
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 9, fontWeight: 700, color: '#888', letterSpacing: '0.5px', textTransform: 'uppercase', marginBottom: 3 }}>Compliance</div>
            <div style={{ fontSize: 22, fontWeight: 700, color: r.compliance_score >= 80 ? '#22a06b' : r.compliance_score >= 50 ? '#B06D32' : '#bf2600' }}>{r.compliance_score}%</div>
          </div>
        )}
      </div>

      {/* Tabs */}
      <div style={{ display: 'flex', gap: 4, marginBottom: 0, borderBottom: `1px solid ${BORDER}`, paddingBottom: 0 }}>
        {tabs.map(t => <div key={t.id} style={sty.tab(activeTab === t.id)} onClick={() => setActiveTab(t.id)}>{t.label}</div>)}
      </div>

      {/* Tab Content */}
      <div style={{ ...sty.card, borderTopLeftRadius: 0 }}>
        {/* SUMMARY TAB */}
        {activeTab === 'summary' && (
          <div>
            <div style={sty.cardTitle}>Executive Summary</div>
            <p style={{ fontSize: 13, lineHeight: 1.6, color: '#333', marginBottom: 16 }}>{r.summary || 'No summary available.'}</p>

            {r.all_recommendations?.length > 0 && (
              <div style={{ marginTop: 16 }}>
                <div style={{ ...sty.cardTitle, fontSize: 13 }}>Priority Recommendations ({r.all_recommendations.length})</div>
                {r.all_recommendations.slice(0, 10).map((rec, i) => (
                  <div key={i} style={{ display: 'flex', gap: 8, alignItems: 'flex-start', padding: '6px 0', borderBottom: '1px solid #f5f5f5' }}>
                    <span style={sty.badge(rec.priority === 'Critical' ? 'red' : rec.priority === 'High' ? 'orange' : 'gray')}>{rec.priority || 'Med'}</span>
                    <span style={{ fontSize: 12 }}>{rec.text || rec}</span>
                    {rec.source && <span style={{ fontSize: 10, color: '#999', marginLeft: 'auto', whiteSpace: 'nowrap' }}>{rec.source}</span>}
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* COMPLIANCE MATRIX TAB */}
        {activeTab === 'compliance' && (
          <div>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
              <div style={sty.cardTitle}>Compliance Matrix</div>
              <div style={{ display: 'flex', gap: 6 }}>
                {['all', 'Compliant', 'Partial', 'Non-Compliant', 'Missing', 'issues'].map(f => (
                  <button key={f} style={{ ...sty.btn(complianceFilter === f ? 'primary' : 'outline', true), fontSize: 10 }} onClick={() => setComplianceFilter(f)}>
                    {f === 'issues' ? 'All Issues' : f === 'all' ? 'All' : f}
                  </button>
                ))}
              </div>
            </div>

            {(r.compliance_matrix || []).length > 0 ? (
              <div style={{ overflowX: 'auto' }}>
                <table style={{ width: '100%', borderCollapse: 'collapse' }}>
                  <thead>
                    <tr style={{ background: '#fafafa' }}>
                      <th style={{ padding: '8px 10px', textAlign: 'left', fontSize: 10, fontWeight: 700, color: '#777', borderBottom: `1px solid ${BORDER}` }}>Requirement</th>
                      <th style={{ padding: '8px 10px', textAlign: 'left', fontSize: 10, fontWeight: 700, color: '#777', borderBottom: `1px solid ${BORDER}` }}>RFP Ref</th>
                      <th style={{ padding: '8px 10px', textAlign: 'left', fontSize: 10, fontWeight: 700, color: '#777', borderBottom: `1px solid ${BORDER}` }}>Response Ref</th>
                      <th style={{ padding: '8px 10px', textAlign: 'left', fontSize: 10, fontWeight: 700, color: '#777', borderBottom: `1px solid ${BORDER}` }}>Status</th>
                      <th style={{ padding: '8px 10px', textAlign: 'left', fontSize: 10, fontWeight: 700, color: '#777', borderBottom: `1px solid ${BORDER}` }}>Notes</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredMatrix.map((item, i) => <ComplianceRow key={i} item={item} />)}
                  </tbody>
                </table>
              </div>
            ) : (
              <div style={{ textAlign: 'center', padding: 30, color: '#aaa', fontSize: 12 }}>
                {r.mode === 'comparison' ? 'No compliance data extracted. Try uploading clearer RFP documents.' : 'Upload both RFP and proposal for compliance matrix comparison.'}
              </div>
            )}

            {/* Legal Issues below matrix */}
            {r.compliance?.issues?.length > 0 && (
              <div style={{ marginTop: 16 }}>
                <div style={{ ...sty.cardTitle, fontSize: 12, color: '#bf2600' }}>Compliance Issues</div>
                {r.compliance.issues.map((issue, i) => <div key={i} style={{ fontSize: 12, padding: '4px 0', borderBottom: '1px solid #f5f5f5' }}>- {issue}</div>)}
              </div>
            )}
            {r.compliance?.protest_risks?.length > 0 && (
              <div style={{ marginTop: 12 }}>
                <div style={{ ...sty.cardTitle, fontSize: 12, color: '#bf2600' }}>Protest Risks</div>
                {r.compliance.protest_risks.map((risk, i) => <div key={i} style={{ fontSize: 12, padding: '4px 0', borderBottom: '1px solid #f5f5f5' }}>- {risk}</div>)}
              </div>
            )}
          </div>
        )}

        {/* STRENGTHS & WEAKNESSES TAB */}
        {activeTab === 'strengths' && (
          <div style={{ display: 'flex', gap: 16 }}>
            <div style={{ flex: 1 }}>
              <div style={{ ...sty.cardTitle, color: '#22a06b' }}>Strengths ({(r.strengths || []).length})</div>
              {(r.strengths || []).map((s, i) => (
                <div key={i} style={{ padding: '8px 0', borderBottom: '1px solid #f5f5f5' }}>
                  <div style={{ fontSize: 12, fontWeight: 600 }}>{s.theme || s}</div>
                  {s.evidence && <div style={{ fontSize: 11, color: '#666', marginTop: 2 }}>{s.evidence}</div>}
                  {s.eval_factor_alignment && <div style={{ fontSize: 10, color: '#22a06b', marginTop: 2 }}>Aligns with: {s.eval_factor_alignment}</div>}
                </div>
              ))}
              {r.discriminators?.length > 0 && (
                <div style={{ marginTop: 14 }}>
                  <div style={{ fontSize: 12, fontWeight: 700, color: NAVY, marginBottom: 6 }}>Key Discriminators</div>
                  {r.discriminators.map((d, i) => <div key={i} style={{ fontSize: 12, padding: '3px 0' }}>- {d}</div>)}
                </div>
              )}
            </div>
            <div style={{ flex: 1 }}>
              <div style={{ ...sty.cardTitle, color: '#bf2600' }}>Weaknesses ({(r.weaknesses || []).length})</div>
              {(r.weaknesses || []).map((w, i) => (
                <div key={i} style={{ padding: '8px 0', borderBottom: '1px solid #f5f5f5' }}>
                  <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
                    <span style={sty.badge(w.severity === 'Critical' ? 'red' : w.severity === 'High' ? 'orange' : 'gray')}>{w.severity || 'Medium'}</span>
                    <span style={{ fontSize: 12, fontWeight: 600 }}>{w.gap || w}</span>
                  </div>
                  {w.remediation && <div style={{ fontSize: 11, color: '#666', marginTop: 4 }}>Fix: {w.remediation}</div>}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* GHOST THEMES TAB */}
        {activeTab === 'ghost' && (
          <div>
            <div style={sty.cardTitle}>Competitive Black Hat Analysis</div>
            {r.ghost?.competitive_positioning && <p style={{ fontSize: 12, lineHeight: 1.5, color: '#555', marginBottom: 16 }}>{r.ghost.competitive_positioning}</p>}

            {(r.ghost?.likely_competitors || []).length > 0 && (
              <div style={{ marginBottom: 20 }}>
                <div style={{ fontSize: 13, fontWeight: 700, color: NAVY, marginBottom: 8 }}>Likely Competitors</div>
                {r.ghost.likely_competitors.map((c, i) => (
                  <div key={i} style={{ ...sty.card, marginBottom: 8 }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 6 }}>
                      <span style={{ fontWeight: 700, fontSize: 13 }}>{c.name}</span>
                      <span style={sty.badge(c.threat_level === 'CRITICAL' ? 'red' : c.threat_level === 'HIGH' ? 'orange' : 'gray')}>{c.threat_level}</span>
                    </div>
                    <div style={{ fontSize: 12, color: '#555', marginBottom: 6 }}><strong>Strategy:</strong> {c.likely_strategy}</div>
                    {c.strengths_vs_us?.length > 0 && <div style={{ fontSize: 11, color: '#bf2600' }}>Strengths vs us: {c.strengths_vs_us.join('; ')}</div>}
                    {c.weaknesses_vs_us?.length > 0 && <div style={{ fontSize: 11, color: '#22a06b', marginTop: 2 }}>Weaknesses: {c.weaknesses_vs_us.join('; ')}</div>}
                  </div>
                ))}
              </div>
            )}

            {(r.ghost?.ghost_themes || []).length > 0 && (
              <div>
                <div style={{ fontSize: 13, fontWeight: 700, color: NAVY, marginBottom: 8 }}>Ghost Themes (Shipley)</div>
                {r.ghost.ghost_themes.map((g, i) => (
                  <div key={i} style={{ padding: '8px 0', borderBottom: '1px solid #f5f5f5', fontSize: 12 }}>
                    <strong>{g.theme}</strong>
                    {g.target_competitor && <span style={{ color: '#666' }}> (targets: {g.target_competitor})</span>}
                    {g.how_to_emphasize && <div style={{ fontSize: 11, color: '#555', marginTop: 2 }}>How: {g.how_to_emphasize}</div>}
                  </div>
                ))}
              </div>
            )}

            {r.ghost?.counter_strategies?.length > 0 && (
              <div style={{ marginTop: 14 }}>
                <div style={{ fontSize: 13, fontWeight: 700, color: NAVY, marginBottom: 6 }}>Counter Strategies</div>
                {r.ghost.counter_strategies.map((s, i) => <div key={i} style={{ fontSize: 12, padding: '3px 0' }}>- {s}</div>)}
              </div>
            )}
          </div>
        )}

        {/* TECHNICAL TAB */}
        {activeTab === 'technical' && (
          <div>
            <div style={sty.cardTitle}>Technical / Operational Assessment</div>

            {r.technical?.schedule && (
              <div style={{ marginBottom: 14 }}>
                <div style={{ fontSize: 12, fontWeight: 700, marginBottom: 4 }}>Schedule: <span style={sty.badge(r.technical.schedule.timeline_feasibility === 'Feasible' ? 'green' : 'orange')}>{r.technical.schedule.timeline_feasibility || 'N/A'}</span></div>
                {r.technical.schedule.risks?.map((risk, i) => <div key={i} style={{ fontSize: 11, color: '#666', padding: '2px 0' }}>- {risk}</div>)}
              </div>
            )}

            {r.technical?.execution_risks?.length > 0 && (
              <div style={{ marginBottom: 14 }}>
                <div style={{ fontSize: 12, fontWeight: 700, marginBottom: 6 }}>Execution Risks</div>
                {r.technical.execution_risks.map((risk, i) => (
                  <div key={i} style={{ display: 'flex', gap: 6, padding: '4px 0', borderBottom: '1px solid #f5f5f5', alignItems: 'center' }}>
                    <span style={sty.badge(risk.severity === 'Critical' ? 'red' : risk.severity === 'High' ? 'orange' : 'gray')}>{risk.severity}</span>
                    <span style={{ fontSize: 12 }}>{risk.risk}</span>
                    {risk.mitigation && <span style={{ fontSize: 10, color: '#22a06b', marginLeft: 'auto' }}>Mitigation: {risk.mitigation}</span>}
                  </div>
                ))}
              </div>
            )}

            {r.technical?.recommended_changes?.length > 0 && (
              <div>
                <div style={{ fontSize: 12, fontWeight: 700, marginBottom: 6 }}>Recommended Changes</div>
                {r.technical.recommended_changes.map((c, i) => (
                  <div key={i} style={{ padding: '6px 0', borderBottom: '1px solid #f5f5f5' }}>
                    <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
                      <span style={sty.badge(c.priority === 'Critical' ? 'red' : c.priority === 'High' ? 'orange' : 'gray')}>{c.priority}</span>
                      <span style={{ fontSize: 12 }}>{c.change || c}</span>
                    </div>
                    {c.rationale && <div style={{ fontSize: 11, color: '#666', marginTop: 2 }}>{c.rationale}</div>}
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* RISK 5C+4C TAB */}
        {activeTab === 'risk' && (
          <div>
            <div style={sty.cardTitle}>5C + 4C Risk Assessment</div>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 12 }}>
              {r.risk?.five_cs && Object.entries(r.risk.five_cs).map(([key, val]) => (
                <div key={key} style={{ ...sty.card, marginBottom: 0 }}>
                  <div style={{ fontSize: 11, fontWeight: 700, color: '#777', textTransform: 'uppercase', marginBottom: 4 }}>{key}</div>
                  <div style={{ fontSize: 24, fontWeight: 700, color: val.score >= 4 ? '#22a06b' : val.score >= 3 ? '#B06D32' : '#bf2600' }}>{val.score}/5</div>
                  <div style={{ fontSize: 11, color: '#666', marginTop: 4 }}>{val.finding}</div>
                </div>
              ))}
              {r.risk?.four_cs && Object.entries(r.risk.four_cs).map(([key, val]) => (
                <div key={key} style={{ ...sty.card, marginBottom: 0, background: '#fafafa' }}>
                  <div style={{ fontSize: 11, fontWeight: 700, color: '#777', textTransform: 'uppercase', marginBottom: 4 }}>{key}</div>
                  <div style={{ fontSize: 24, fontWeight: 700, color: val.score >= 4 ? '#22a06b' : val.score >= 3 ? '#B06D32' : '#bf2600' }}>{val.score}/5</div>
                  <div style={{ fontSize: 11, color: '#666', marginTop: 4 }}>{val.finding}</div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* DRAFT RESPONSE TAB */}
        {activeTab === 'draft' && (
          <div>
            <div style={sty.cardTitle}>AI-Generated Draft Response</div>
            {r.draft_response ? (
              <div style={{ fontSize: 12, lineHeight: 1.7, whiteSpace: 'pre-wrap', color: '#333', maxHeight: 600, overflow: 'auto', background: '#fafafa', padding: 16, borderRadius: 6 }}>
                {r.draft_response}
              </div>
            ) : (
              <div style={{ textAlign: 'center', padding: 30, color: '#aaa' }}>Draft response will appear after analysis completes.</div>
            )}
            {r.draft_response && (
              <button style={{ ...sty.btn('outline', true), marginTop: 10 }} onClick={() => navigator.clipboard.writeText(r.draft_response)}>Copy Draft</button>
            )}
          </div>
        )}
      </div>

      {/* Chat */}
      <div style={{ ...sty.card, marginTop: 14 }}>
        <div style={sty.cardTitle}>Ask About This Analysis</div>
        <div style={{ maxHeight: 200, overflow: 'auto', marginBottom: 8 }}>
          {messages.map((m, i) => (
            <div key={i} style={{ padding: '6px 0', borderBottom: '1px solid #f5f5f5', fontSize: 12 }}>
              <strong style={{ color: m.role === 'user' ? ACCENT : '#32448A' }}>{m.role === 'user' ? 'You' : 'AI'}:</strong> {m.text}
            </div>
          ))}
          {chatLoading && <div style={{ padding: '6px 0', fontSize: 12, color: '#999' }}>Thinking...</div>}
        </div>
        <div style={{ display: 'flex', gap: 8 }}>
          <input
            style={{ flex: 1, padding: '8px 10px', border: `1px solid ${BORDER}`, borderRadius: 6, fontSize: 12 }}
            placeholder="Ask a follow-up question about this Red Team analysis..."
            value={chatInput}
            onChange={(e) => setChatInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && sendChat()}
          />
          <button style={sty.btn('primary', true)} onClick={sendChat} disabled={chatLoading}>Send</button>
        </div>
      </div>
    </div>
  );
}
