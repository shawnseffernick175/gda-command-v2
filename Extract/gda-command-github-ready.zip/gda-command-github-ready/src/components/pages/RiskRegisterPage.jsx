import React, { useState, useEffect, useCallback, useRef, useMemo } from 'react';
import { ACCENT, NAVY, BG, WHITE, BORDER, FONT, N8N, AUTH, api, S, css, gdaNav, NAV_ITEMS, Spinner, Empty, Alert, PageHeader, SourceTag, GDAKpiBar , saveAction, ActionHistory } from '../../lib/gda';
function RiskRegister() {
  const [risks, setRisks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [tab, setTab] = useState('pending');
  const [riskStatuses, setRiskStatuses] = useState({});
  const [riskSources, setRiskSources] = useState({});
  const [cubeRisks, setCubeRisks] = useState([]);
  const [cubeFilter, setCubeFilter] = useState(null);
  const [kpiDetail, setKpiDetail] = useState(null);
  const [sevFilter, setSevFilter] = useState(null);
  const [placingRisk, setPlacingRisk] = useState(null);
  const [plLikelihood, setPlLikelihood] = useState(2);
  const [plImpact, setPlImpact] = useState(2);
  const [showRiskForm, setShowRiskForm] = useState(false);
  const [riskForm, setRiskForm] = useState({title:"",severity:"HIGH",category:"",description:"",mitigation:""});
  const [riskSaving, setRiskSaving] = useState(false);
  const [acceptingRisk, setAcceptingRisk] = useState(null);
  const [acceptCoords, setAcceptCoords] = useState({likelihood:3, impact:3});
  const [expandedRisk, setExpandedRisk] = useState(null);

  const load = async () => { try { const d = await api.post('gda-risk', {action:'list'}); const items = d.data||[]; setRisks(items); const saved={}; items.forEach(function(r){var id=r.risk_id||r.id; if(r.review_status)saved[id]=r.review_status;}); setRiskStatuses(function(prev){return Object.assign({},saved,prev);}); } catch(e) { console.error(e); } setLoading(false); };
  useEffect(() => { load(); }, []);
  useEffect(() => {
    if (gdaNav.riskTarget) {
      var rt = gdaNav.riskTarget; gdaNav.riskTarget = null;
      setTimeout(function() { var el = document.getElementById('risk-' + rt); if (el) { el.scrollIntoView({ behavior: 'smooth', block: 'center' }); el.style.outline = '2px solid #D14A2A'; setTimeout(function() { el.style.outline = ''; }, 3000); } }, 500);
    }
  });
  const refresh = async () => { setRefreshing(true); try { await api.post('gda-risk', {action:'refresh'}); await load(); } catch(e) {} setRefreshing(false); };
  const nav = function(p) { if (window._gdaNavigate) window._gdaNavigate(p); };

  const SEVS = ['CRITICAL','HIGH','MEDIUM','LOW'];
  const sevColor = (s) => ({CRITICAL:'#DC2626',HIGH:'#EA580C',MEDIUM:'#B06D32',LOW:'#2F5C1F'}[(s||'').toUpperCase()]||'#6B7280');
  const sevBg = (s) => ({CRITICAL:'#FEF2F2',HIGH:'#B06D3212',MEDIUM:'#FEFCE8',LOW:'#2F5C1F12'}[(s||'').toUpperCase()]||'#F9FAFB');
  const SOURCES = [
    {id:'sam',label:'SAM.gov',icon:'\ud83c\udfdb\ufe0f',color:'#32448A',note:'Auto-monitoring via GDA daily scan'},
    {id:'govtribe',label:'GovTribe',icon:'\ud83d\udce1',color:'#32448A',note:'Auto-monitoring via GDA daily scan'},
    {id:'govwin',label:'GovWin',icon:'\ud83d\udcca',color:'#B06D32',note:null},
    {id:'internal',label:'Internal',icon:'\ud83c\udfe2',color:'#6B7280',note:null},
    {id:'schwab',label:'Schwab',icon:'\ud83d\udcc8',color:'#2F5C1F',note:null},
    {id:'manual',label:'Manual',icon:'\u270d\ufe0f',color:'#374151',note:null},
  ];

  function getRiskStatus(r) { return riskStatuses[r.risk_id||r.id] || 'pending'; }
  function setStatus(r, status) {
    var id = r.risk_id || r.id;
    setRiskStatuses(function(p) { var n = Object.assign({}, p); n[id] = status; return n; });
    api.post('gda-risk', { action: 'update', id: id, review_status: status }).catch(function() {});
    api.post('gda-data-learn', {event:'risk_reviewed', context:'risk-register', data:{id:id, status:status}}).catch(function(){});
  }
  function getSource(r) { return riskSources[r.risk_id||r.id] || null; }
  function setSource(r, src) {
    var id = r.risk_id || r.id;
    setRiskSources(function(p) { var n = Object.assign({}, p); n[id] = src; return n; });
    api.post('gda-risk', { action: 'update', id: id, assigned_source: src }).catch(function() {});
  }

  function placeOnCube(risk, l, imp) {
    setCubeRisks(function(prev) { return prev.filter(function(c) { return c.riskId !== (risk.risk_id||risk.id); }).concat([{ riskId: risk.risk_id||risk.id, title: risk.title||'R', likelihood: l, impact: imp, severity: risk.severity }]); });
    setPlacingRisk(null);
  }
  function removeFromCube(riskId) { setCubeRisks(function(prev) { return prev.filter(function(c) { return c.riskId !== riskId; }); }); }
  function isOnCube(r) { return cubeRisks.some(function(c) { return c.riskId === (r.risk_id||r.id); }); }

  var allRisks = risks.filter(function(r) { return (r.status||'').toUpperCase() !== 'RESOLVED'; });
  var pending = allRisks.filter(function(r) { return getRiskStatus(r) === 'pending'; });
  var accepted = allRisks.filter(function(r) { return getRiskStatus(r) === 'accepted'; });
  var rejected = allRisks.filter(function(r) { return getRiskStatus(r) === 'rejected'; });
  var critCount = allRisks.filter(function(r) { return (r.severity||'').toUpperCase() === 'CRITICAL'; }).length;
  var highCount = allRisks.filter(function(r) { return (r.severity||'').toUpperCase() === 'HIGH'; }).length;
  var medCount = allRisks.filter(function(r) { return (r.severity||'').toUpperCase() === 'MEDIUM'; }).length;
  var lowCount = allRisks.filter(function(r) { return (r.severity||'').toUpperCase() === 'LOW'; }).length;

  var tabRisks = tab === 'accepted' ? accepted : tab === 'rejected' ? rejected : pending;
  if (sevFilter) tabRisks = tabRisks.filter(function(r) { return (r.severity||'').toUpperCase() === sevFilter; });
  tabRisks = tabRisks.sort(function(a, b) { var o = {CRITICAL:0,HIGH:1,MEDIUM:2,LOW:3}; return (o[(a.severity||'').toUpperCase()]||4) - (o[(b.severity||'').toUpperCase()]||4); });

  var CUBE_COLORS = [['#22C55E','#22C55E','#22C55E','#EAB308','#EAB308'],['#22C55E','#22C55E','#EAB308','#EAB308','#F97316'],['#22C55E','#EAB308','#EAB308','#F97316','#DC2626'],['#EAB308','#EAB308','#F97316','#DC2626','#DC2626'],['#EAB308','#F97316','#F97316','#DC2626','#DC2626']];
  var Y_LABELS = ['Rare','Unlikely','Possible','Likely','A.Certain'];
  var X_LABELS = ['Neglig.','Minor','Moderate','Major','Severe'];
  var CS = 54, PAD = 56;

  if (loading) return <div style={{padding:40,textAlign:'center'}}>Loading risks...</div>;

  return (<div style={{padding:16,margin:0}}>
    <PageHeader title="Risk Register" sub={allRisks.length+' risks | '+pending.length+' pending | '+accepted.length+' accepted'} action={<div style={{display:'flex',gap:6}}><button style={{background:'#C65D21',color:'#fff',border:'none',borderRadius:6,padding:'6px 14px',fontSize:12,fontWeight:600,cursor:'pointer'}} onClick={function(){setShowRiskForm(true);}}>+ Risk</button><button style={S.btn()} onClick={refresh} disabled={refreshing}>{refreshing?'Refreshing...':'Refresh from Opps'}</button></div>} />


    {/* Add Risk Modal */}
    {showRiskForm&&<div style={{position:'fixed',inset:0,background:'rgba(27,42,74,0.5)',zIndex:10000,display:'flex',alignItems:'center',justifyContent:'center'}} onClick={function(e){if(e.target===e.currentTarget)setShowRiskForm(false);}}>
      <div style={{background:'#fff',padding:24,borderRadius:12,maxWidth:480,width:'90%',margin:'auto'}} onClick={function(e){e.stopPropagation();}}>
        <div style={{fontSize:16,fontWeight:700,color:'#1B2A4A',marginBottom:16}}>Add New Risk</div>
        <div style={{marginBottom:10}}><label style={{fontSize:11,fontWeight:600,color:'#374151',display:'block',marginBottom:4}}>Title</label><input value={riskForm.title} onChange={function(e){setRiskForm(Object.assign({},riskForm,{title:e.target.value}));}} style={{width:'100%',padding:'8px 12px',border:'1px solid #D1D5DB',borderRadius:6,fontSize:13,boxSizing:'border-box'}} placeholder="Risk title..." /></div>
        <div style={{marginBottom:10}}><label style={{fontSize:11,fontWeight:600,color:'#374151',display:'block',marginBottom:4}}>Severity</label><select value={riskForm.severity} onChange={function(e){setRiskForm(Object.assign({},riskForm,{severity:e.target.value}));}} style={{width:'100%',padding:'8px 12px',border:'1px solid #D1D5DB',borderRadius:6,fontSize:13,boxSizing:'border-box'}}><option value="CRITICAL">CRITICAL</option><option value="HIGH">HIGH</option><option value="MEDIUM">MEDIUM</option><option value="LOW">LOW</option></select></div>
        <div style={{marginBottom:10}}><label style={{fontSize:11,fontWeight:600,color:'#374151',display:'block',marginBottom:4}}>Category</label><input value={riskForm.category} onChange={function(e){setRiskForm(Object.assign({},riskForm,{category:e.target.value}));}} style={{width:'100%',padding:'8px 12px',border:'1px solid #D1D5DB',borderRadius:6,fontSize:13,boxSizing:'border-box'}} placeholder="e.g. Technical, Financial, Schedule..." /></div>
        <div style={{marginBottom:10}}><label style={{fontSize:11,fontWeight:600,color:'#374151',display:'block',marginBottom:4}}>Description</label><textarea value={riskForm.description} onChange={function(e){setRiskForm(Object.assign({},riskForm,{description:e.target.value}));}} style={{width:'100%',padding:'8px 12px',border:'1px solid #D1D5DB',borderRadius:6,fontSize:13,minHeight:80,resize:'vertical',boxSizing:'border-box'}} placeholder="Describe the risk..." /></div>
        <div style={{marginBottom:16}}><label style={{fontSize:11,fontWeight:600,color:'#374151',display:'block',marginBottom:4}}>Mitigation</label><textarea value={riskForm.mitigation} onChange={function(e){setRiskForm(Object.assign({},riskForm,{mitigation:e.target.value}));}} style={{width:'100%',padding:'8px 12px',border:'1px solid #D1D5DB',borderRadius:6,fontSize:13,minHeight:80,resize:'vertical',boxSizing:'border-box'}} placeholder="Mitigation strategy..." /></div>
        <div style={{display:'flex',gap:8}}><button disabled={riskSaving||!riskForm.title.trim()} onClick={async function(){setRiskSaving(true);try{await api.post('gda-risk',{action:'create',title:riskForm.title,severity:riskForm.severity,category:riskForm.category,description:riskForm.description,mitigation:riskForm.mitigation,status:'Active'});setShowRiskForm(false);setRiskForm({title:'',severity:'HIGH',category:'',description:'',mitigation:''});await load();}catch(e){console.error(e);}setRiskSaving(false);}} style={{flex:1,padding:'9px',background:'#32448A',color:'#fff',border:'none',borderRadius:6,fontSize:13,fontWeight:600,cursor:riskSaving?'default':'pointer',opacity:riskSaving||!riskForm.title.trim()?0.6:1}}>{riskSaving?'Saving...':'Add Risk'}</button>
          <button onClick={function(){setShowRiskForm(false);setRiskForm({title:'',severity:'HIGH',category:'',description:'',mitigation:''});}} style={{flex:1,padding:'9px',background:'#F3F4F6',color:'#374151',border:'none',borderRadius:6,fontSize:13,cursor:'pointer'}}>Cancel</button></div>
      </div>
    </div>}

    {/* KPI Bar */}
    <GDAKpiBar items={[
      {id:'total',label:'Total Risks',value:allRisks.length,sub:'all tracked'},
      {id:'critical',label:'Critical',value:critCount,color:critCount>0?'#DC2626':'#1B2A4A',sub:'immediate action'},
      {id:'high',label:'High',value:highCount,color:highCount>0?'#B06D32':'#1B2A4A',sub:'needs attention'},
      {id:'medium',label:'Medium',value:medCount,sub:'monitoring'},
      {id:'low',label:'Low',value:lowCount,color:'#2F5C1F',sub:'controlled'},
      {id:'accepted',label:'Accepted',value:accepted.length,color:'#2F5C1F',sub:'resolved'}
    ]} detail={kpiDetail} setDetail={setKpiDetail} />
    {sevFilter && <div style={{display:'flex',alignItems:'center',gap:8,marginBottom:12}}>
      <span style={{fontSize:12,color:'#6B7280'}}>Filtered: <strong style={{color:sevColor(sevFilter)}}>{sevFilter}</strong></span>
      <button onClick={function(){setSevFilter(null);}} style={{fontSize:11,padding:'2px 8px',border:'1px solid #D1D5DB',borderRadius:4,background:'#fff',cursor:'pointer',color:'#374151'}}>Show All</button>
    </div>}

    {/* 5x5 Risk Cube */}
    <div style={{...S.card,marginBottom:16,padding:20}}>
      <div style={{fontSize:15,fontWeight:700,color:'#1B2A4A',marginBottom:12}}>Risk Assessment Matrix</div>
      <svg viewBox={'0 0 '+(PAD+5*(CS+2)+10)+' '+(PAD+5*(CS+2)+30)} style={{width:'100%',maxWidth:420,display:'block',margin:'0 auto'}}>
        <text x={10} y={(PAD+5*(CS+2))/2} fontSize={9} fill="#6B7280" textAnchor="middle" transform={'rotate(-90,10,'+(PAD+5*(CS+2))/2+')'}>{'\u2190 Likelihood \u2192'}</text>
        <text x={PAD+5*(CS+2)/2} y={PAD+5*(CS+2)+24} fontSize={9} fill="#6B7280" textAnchor="middle">{'\u2190 Impact \u2192'}</text>
        {[0,1,2,3,4].map(function(row){return [0,1,2,3,4].map(function(col){
          var x=PAD+col*(CS+2);var y=(4-row)*(CS+2)+4;
          var isSelected=cubeFilter&&cubeFilter.l===row&&cubeFilter.i===col;
          var count=cubeRisks.filter(function(c){return c.likelihood===row&&c.impact===col;}).length;
          return <g key={row+'-'+col} style={{cursor:'pointer'}} onClick={function(){setCubeFilter(cubeFilter&&cubeFilter.l===row&&cubeFilter.i===col?null:{l:row,i:col});}}>
            <rect x={x} y={y} width={CS} height={CS} rx={4} fill={CUBE_COLORS[row][col]} opacity={isSelected?1:0.75} stroke={isSelected?'#1B2A4A':'none'} strokeWidth={isSelected?2:0} />
            {count>0&&<text x={x+CS-8} y={y+12} fontSize={8} fill="rgba(0,0,0,0.3)" textAnchor="end">{count}</text>}
          </g>;
        });})}
        {Y_LABELS.map(function(l,i){return <text key={'y'+i} x={PAD-6} y={(4-i)*(CS+2)+4+CS/2+3} fontSize={8} fill="#6B7280" textAnchor="end">{l}</text>;})}
        {X_LABELS.map(function(l,i){return <text key={'x'+i} x={PAD+i*(CS+2)+CS/2} y={5*(CS+2)+16} fontSize={8} fill="#6B7280" textAnchor="middle">{l}</text>;})}
        {(function(){
          var cellGroups={};
          cubeRisks.forEach(function(cr,ci){
            var allIdx=allRisks.findIndex(function(r){return (r.risk_id||r.id)===cr.riskId;});
            var rNum='R-'+(allIdx>=0?String(allIdx+1).padStart(3,'0'):String(ci+1).padStart(3,'0'));
            var key=cr.likelihood+'-'+cr.impact;
            if(!cellGroups[key])cellGroups[key]=[];
            cellGroups[key].push({cr:cr,ci:ci,rNum:rNum});
          });
          var elems=[];
          Object.keys(cellGroups).forEach(function(key){
            var group=cellGroups[key];
            group.forEach(function(item,indexInCell){
              var cr=item.cr;var rNum=item.rNum;
              var baseX=PAD+cr.impact*(CS+2)+CS/2;var baseY=(4-cr.likelihood)*(CS+2)+4+CS/2;
              var offsetX=(indexInCell-(group.length-1)/2)*18;
              var x=baseX+offsetX;var y=baseY;
              elems.push(<g key={item.ci} style={{cursor:'pointer'}} onClick={function(e){e.stopPropagation();var el=document.getElementById('risk-card-'+cr.riskId);if(el){el.scrollIntoView({behavior:'smooth',block:'center'});el.style.outline='2px solid #D14A2A';el.style.transition='outline 0.3s';setTimeout(function(){el.style.outline='';},2000);}}}>
                <circle cx={x} cy={y} r={14} fill="#fff" stroke="#1B2A4A" strokeWidth={1.5} />
                <text x={x} y={y+3} fontSize={7} fontWeight={700} fill="#1B2A4A" textAnchor="middle">{rNum}</text>
              </g>);
            });
          });
          return elems;
        })()}
        {cubeRisks.length===0&&<text x={PAD+5*(CS+2)/2} y={5*(CS+2)/2} fontSize={10} fill="#D1D5DB" textAnchor="middle">Click "Add to Cube" below</text>}
      </svg>
      {cubeFilter&&<div style={{textAlign:'center',marginTop:8,fontSize:11,color:'#6B7280'}}>
        Showing: {Y_LABELS[cubeFilter.l]} × {X_LABELS[cubeFilter.i]} ({cubeRisks.filter(function(c){return c.likelihood===cubeFilter.l&&c.impact===cubeFilter.i;}).length} risks)
        <button onClick={function(){setCubeFilter(null);}} style={{marginLeft:8,fontSize:10,padding:'1px 6px',border:'1px solid #D1D5DB',borderRadius:4,background:'#fff',cursor:'pointer'}}>Show All</button>
      </div>}
      {cubeRisks.length>0&&<div style={{display:'flex',gap:6,flexWrap:'wrap',marginTop:8,justifyContent:'center'}}>
        {cubeRisks.map(function(cr,ci){return <span key={ci} style={{fontSize:10,padding:'2px 8px',borderRadius:10,background:'#F3F4F6',color:'#374151'}}>{'R'+(ci+1)+': '+(cr.title||'').substring(0,20)}</span>;})}
      </div>}
    </div>

    {/* Placement Dialog */}
    {placingRisk&&<div style={{position:'fixed',inset:0,background:'rgba(0,0,0,0.4)',zIndex:9999,display:'flex',alignItems:'center',justifyContent:'center'}} onClick={function(e){if(e.target===e.currentTarget)setPlacingRisk(null);}}>
      <div style={{background:'#fff',borderRadius:12,padding:24,width:360,maxWidth:'90vw'}} onClick={function(e){e.stopPropagation();}}>
        <div style={{fontSize:15,fontWeight:700,color:'#1B2A4A',marginBottom:4}}>Place on Risk Cube</div>
        <div style={{fontSize:12,color:'#6B7280',marginBottom:16}}>{placingRisk.title||'Risk'}</div>
        <div style={{marginBottom:12}}><label style={{fontSize:11,fontWeight:600,color:'#374151',display:'block',marginBottom:4}}>Likelihood</label>
          <select value={plLikelihood} onChange={function(e){setPlLikelihood(parseInt(e.target.value));}} style={{width:'100%',padding:'8px',border:'1px solid #D1D5DB',borderRadius:6,fontSize:13}}>{Y_LABELS.map(function(l,i){return <option key={i} value={i}>{l}</option>;})}</select></div>
        <div style={{marginBottom:16}}><label style={{fontSize:11,fontWeight:600,color:'#374151',display:'block',marginBottom:4}}>Impact</label>
          <select value={plImpact} onChange={function(e){setPlImpact(parseInt(e.target.value));}} style={{width:'100%',padding:'8px',border:'1px solid #D1D5DB',borderRadius:6,fontSize:13}}>{X_LABELS.map(function(l,i){return <option key={i} value={i}>{l}</option>;})}</select></div>
        <div style={{display:'flex',gap:8}}><button onClick={function(){placeOnCube(placingRisk,plLikelihood,plImpact);}} style={{flex:1,padding:'9px',background:'#32448A',color:'#fff',border:'none',borderRadius:6,fontSize:13,fontWeight:600,cursor:'pointer'}}>Place</button>
          <button onClick={function(){setPlacingRisk(null);}} style={{flex:1,padding:'9px',background:'#F3F4F6',color:'#374151',border:'none',borderRadius:6,fontSize:13,cursor:'pointer'}}>Cancel</button></div>
      </div>
    </div>}

    {/* Tab Bar */}
    <div style={{display:'flex',gap:0,marginBottom:16,background:'#fff',border:'1px solid #E5E7EB',borderRadius:8,overflow:'hidden'}}>
      {[{id:'pending',label:'Pending',count:pending.length,c:'#B06D32'},{id:'accepted',label:'Accepted',count:accepted.length,c:'#2F5C1F'},{id:'rejected',label:'Rejected',count:rejected.length,c:'#9CA3AF'}].map(function(t){
        var active=tab===t.id;
        return <div key={t.id} onClick={function(){setTab(t.id);}} style={{flex:1,textAlign:'center',padding:'10px 0',cursor:'pointer',background:active?t.c:'#fff',color:active?'#fff':'#374151',fontWeight:active?700:500,fontSize:13,borderRight:'1px solid #E5E7EB',transition:'all 0.15s'}}>
          {t.label} <span style={{fontSize:11,opacity:0.8}}>({t.count})</span>
        </div>;
      })}
    </div>

    {/* Risk Cards */}
    {tabRisks.length===0&&<div style={{...S.card,textAlign:'center',padding:24,color:'#9CA3AF'}}>No {tab} risks.{tab==='pending'?' Click Refresh to generate from opportunity data.':''}</div>}
    <div style={{display:'grid',gridTemplateColumns:'repeat(3,minmax(0,1fr))',gap:8}}>
    {tabRisks.map(function(r,idx){
      var id=r.risk_id||r.id||idx;
      var sev=(r.severity||'MEDIUM').toUpperCase();
      var onCube=isOnCube(r);
      var riskNumber='R-'+String(idx+1).padStart(3,'0');
      var isExp=expandedRisk===id;
      return <div key={id} id={'risk-card-'+id} style={{...S.card,padding:10,borderLeft:'4px solid '+sevColor(sev),transition:'all 0.2s',position:'relative',cursor:'pointer'}} onClick={function(){setExpandedRisk(isExp?null:id);}}>
        <div style={{display:'flex',alignItems:'center',gap:8}}>
          <span style={{fontSize:11,fontWeight:700,color:'#D14A2A',background:'#B06D3212',padding:'1px 6px',borderRadius:4}}>{riskNumber}</span>
          <span style={{padding:'2px 8px',borderRadius:10,fontSize:10,fontWeight:700,background:sevBg(sev),color:sevColor(sev)}}>{sev}</span>
          <span style={{fontSize:12,fontWeight:600,color:'#1B2A4A',flex:1,overflow:'hidden',textOverflow:'ellipsis',whiteSpace:isExp?'normal':'nowrap'}}>{r.title||'Risk'}</span>
          <span style={{fontSize:10,color:'#9CA3AF',flexShrink:0}}>{isExp?'▼':'▶'}</span>
        </div>
        {isExp && <div style={{marginTop:10}} onClick={function(e){e.stopPropagation();}}>
          {r.description&&<div style={{fontSize:12,color:'#6B7280',lineHeight:1.5,marginBottom:6}}>{r.description}</div>}
          {r.mitigation&&<div style={{fontSize:11,color:'#2F5C1F',background:'#2F5C1F12',padding:'4px 8px',borderRadius:4,marginBottom:6}}><strong>Mitigation:</strong> {r.mitigation}</div>}
          <div style={{display:'flex',gap:6,flexWrap:'wrap',marginTop:6}}>
            <button disabled={onCube} onClick={function(){setPlacingRisk(r);setPlLikelihood(2);setPlImpact(2);}} style={{padding:'4px 10px',fontSize:11,border:'1px solid '+(onCube?'#D1D5DB':'#D14A2A'),borderRadius:5,background:onCube?'#F9FAFB':'#B06D3212',color:onCube?'#9CA3AF':'#D14A2A',cursor:onCube?'default':'pointer',fontWeight:600}}>{onCube?'✓ On Cube':'Add to Cube'}</button>
            {tab==='pending'&&<>
              <button onClick={function(){var sug={CRITICAL:{likelihood:4,impact:5},HIGH:{likelihood:3,impact:4},MEDIUM:{likelihood:2,impact:3},LOW:{likelihood:1,impact:2}};var coords=sug[sev]||{likelihood:3,impact:3};setStatus(r,'accepted');placeOnCube(r,coords.likelihood,coords.impact);}} style={{padding:'4px 10px',fontSize:11,border:'1px solid #A7F3D0',borderRadius:5,background:'#2F5C1F15',color:'#2F5C1F',cursor:'pointer',fontWeight:600}}>{'✓ Accept'}</button>
              <button onClick={function(){setStatus(r,'rejected');}} style={{padding:'4px 10px',fontSize:11,border:'1px solid #FCA5A5',borderRadius:5,background:'#FEF2F2',color:'#DC2626',cursor:'pointer',fontWeight:600}}>{'✗ Reject'}</button>
            </>}
            {(tab==='accepted'||tab==='rejected')&&<button onClick={function(){setStatus(r,'pending');}} style={{padding:'4px 10px',fontSize:11,border:'1px solid #D1D5DB',borderRadius:5,background:'#fff',color:'#374151',cursor:'pointer',fontWeight:600}}>{'↩ Move to Pending'}</button>}
          </div>
        </div>}
      </div>;
    })}
    </div>
  </div>);
}
export default RiskRegister;