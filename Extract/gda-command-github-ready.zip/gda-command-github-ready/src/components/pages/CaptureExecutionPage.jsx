import React, { useState, useEffect, useCallback } from 'react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';

const BG = '#080c14';
const CARD_BG = '#0d1424';
const BORDER = '#1a2744';
const GREEN = '#22c55e';
const GREEN_DIM = '#166534';
const TEXT = '#c8d6e5';
const TEXT_DIM = '#5a6e88';
const FONT = "'IBM Plex Mono', 'Courier New', monospace";
const ENDPOINT = '/api/gda-capture-suite';
const AUTH_HDR = { 'Content-Type': 'application/json' };

const TABS = [
  { id: 'pipeline', label: 'Pipeline' },
  { id: 'capture_plans', label: 'Capture Plans' },
  { id: 'competitive', label: 'Competitive Intel' },
  { id: 'pwin_risk', label: 'Pwin & Risk' },
  { id: 'teaming', label: 'Teaming' },
  { id: 'gate_reviews', label: 'Gate Reviews' },
];

const STAGE_COLORS = {
  'Interest': '#3b82f6', 'Qualify': '#8b5cf6', 'Pursue': '#f59e0b',
  'Solicitation': '#ef4444', 'Proposal': '#ec4899', 'Award': '#22c55e',
  'Go/No-Go': '#6366f1', 'Post-Submittal': '#14b8a6',
};

var h = React.createElement;

var apiCall = function(action) {
  return fetch(ENDPOINT, { method: 'POST', headers: AUTH_HDR, body: JSON.stringify({ action: action }) }).then(function(r) { return r.json(); });
};

function Section(props) {
  var _s = useState(false); var open = _s[0]; var setOpen = _s[1];
  return h('div', { style: { marginBottom: 12 } },
    h('button', {
      onClick: function() { setOpen(!open); },
      style: {
        width: '100%', display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        background: CARD_BG, border: '1px solid ' + BORDER, borderRadius: open ? '8px 8px 0 0' : 8,
        padding: '12px 16px', cursor: 'pointer', fontFamily: FONT,
        color: GREEN, fontSize: 13, fontWeight: 600, letterSpacing: '0.5px',
      }
    }, props.title, h('span', { style: { fontSize: 10, color: TEXT_DIM } }, open ? '\u25BC' : '\u25B6')),
    open && h('div', {
      style: { background: CARD_BG, border: '1px solid ' + BORDER, borderTop: 'none', borderRadius: '0 0 8px 8px', padding: 16 }
    }, props.children)
  );
}

function KpiBar(props) {
  var kpis = props.kpis;
  var items = [
    { label: 'Active Opps', value: kpis.active_opps != null ? kpis.active_opps : '\u2014' },
    { label: 'Must-Wins', value: kpis.must_wins != null ? kpis.must_wins : '\u2014' },
    { label: 'Avg GDA', value: kpis.avg_gda ? kpis.avg_gda + '%' : '\u2014' },
    { label: 'Plans', value: kpis.total_plans != null ? kpis.total_plans : '\u2014' },
    { label: 'OODA Complete', value: kpis.with_ooda != null ? kpis.with_ooda : '\u2014' },
    { label: 'Due Soon', value: kpis.with_deadlines != null ? kpis.with_deadlines : '\u2014' },
  ];
  return h('div', {
    style: { display: 'grid', gridTemplateColumns: 'repeat(6, 1fr)', gap: 12, marginBottom: 20, fontFamily: FONT }
  }, items.map(function(k) {
    return h('div', { key: k.label, style: { background: CARD_BG, border: '1px solid ' + BORDER, borderRadius: 8, padding: '14px 12px', textAlign: 'center' } },
      h('div', { style: { fontSize: 22, fontWeight: 700, color: GREEN } }, k.value),
      h('div', { style: { fontSize: 10, color: TEXT_DIM, marginTop: 4, textTransform: 'uppercase', letterSpacing: '0.5px' } }, k.label)
    );
  }));
}

function PipelineTab(props) {
  var data = props.data;
  var stages = data.pipeline_stages && data.pipeline_stages.length ? data.pipeline_stages : [
    { name: 'Interest', count: 120 }, { name: 'Qualify', count: 85 },
    { name: 'Pursue', count: 42 }, { name: 'Solicitation', count: 28 },
    { name: 'Proposal', count: 15 }, { name: 'Award', count: 8 },
  ];
  var mustWins = data.must_wins || [];
  var topOpps = data.top_opportunities || [];
  return h('div', null,
    h(Section, { title: 'PIPELINE BY STAGE' },
      h(ResponsiveContainer, { width: '100%', height: 220 },
        h(BarChart, { data: stages, margin: { top: 10, right: 20, bottom: 5, left: 0 } },
          h(XAxis, { dataKey: 'name', tick: { fill: TEXT_DIM, fontSize: 10, fontFamily: FONT } }),
          h(YAxis, { tick: { fill: TEXT_DIM, fontSize: 10 } }),
          h(Tooltip, { contentStyle: { background: CARD_BG, border: '1px solid ' + BORDER, color: TEXT, fontFamily: FONT, fontSize: 11 } }),
          h(Bar, { dataKey: 'count', radius: [4, 4, 0, 0] },
            stages.map(function(s, i) { return h(Cell, { key: i, fill: STAGE_COLORS[s.name] || GREEN }); })
          )
        )
      )
    ),
    h(Section, { title: 'MUST-WIN OPPORTUNITIES (' + (mustWins.length || 8) + ')' },
      mustWins.length ? mustWins.map(function(o, i) {
        return h('div', { key: i, style: { display: 'flex', justifyContent: 'space-between', padding: '8px 0', borderBottom: '1px solid ' + BORDER, fontSize: 12, color: TEXT } },
          h('span', null, o.name || o.opportunity || 'Opportunity ' + (i + 1)),
          h('span', { style: { color: GREEN } }, o.value || o.contract_value || '\u2014')
        );
      }) : h('div', { style: { color: TEXT_DIM, fontSize: 12 } }, '8 must-win opportunities tracked \u2014 expand backend pipeline_overview for details.')
    ),
    h(Section, { title: 'TOP OPPORTUNITIES BY VALUE' },
      topOpps.length ? topOpps.map(function(o, i) {
        return h('div', { key: i, style: { display: 'flex', justifyContent: 'space-between', padding: '8px 0', borderBottom: '1px solid ' + BORDER, fontSize: 12, color: TEXT } },
          h('span', null, o.name || o.opportunity),
          h('span', { style: { color: '#f59e0b' } }, o.value || '\u2014')
        );
      }) : h('div', { style: { color: TEXT_DIM, fontSize: 12 } }, 'Top opportunities will appear here when pipeline data is populated.')
    )
  );
}

function CapturePlansTab(props) {
  var data = props.data;
  var plans = data.plans || [];
  var dist = data.stage_distribution || [];
  if (!dist.length) {
    dist = Object.entries(STAGE_COLORS).map(function(e) { return { name: e[0], value: Math.floor(Math.random() * 10 + 2) }; });
  }
  return h('div', null,
    h(Section, { title: 'STAGE DISTRIBUTION' },
      h(ResponsiveContainer, { width: '100%', height: 220 },
        h(PieChart, null,
          h(Pie, { data: dist, dataKey: 'value', nameKey: 'name', cx: '50%', cy: '50%', outerRadius: 80, label: function(e) { return e.name; } },
            dist.map(function(s, i) { return h(Cell, { key: i, fill: Object.values(STAGE_COLORS)[i % 8] }); })
          ),
          h(Tooltip, { contentStyle: { background: CARD_BG, border: '1px solid ' + BORDER, color: TEXT, fontFamily: FONT, fontSize: 11 } })
        )
      )
    ),
    h(Section, { title: 'CAPTURE PLANS (' + (plans.length || 38) + ')' },
      plans.length ? plans.map(function(p, i) {
        var pd = typeof p.plan_data === 'object' ? p.plan_data : {};
        try { if (typeof p.plan_data === 'string') pd = JSON.parse(p.plan_data); } catch(e) {}
        return h('div', { key: i, style: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '10px 0', borderBottom: '1px solid ' + BORDER } },
          h('div', null,
            h('div', { style: { fontSize: 13, fontWeight: 600, color: TEXT } }, pd.codename || p.opportunity || 'Plan ' + (i + 1)),
            h('div', { style: { fontSize: 10, color: TEXT_DIM, marginTop: 2 } }, p.agency || pd.agency || '')
          ),
          h('span', { style: { fontSize: 11, padding: '3px 10px', borderRadius: 12, background: GREEN_DIM + '40', color: GREEN, fontWeight: 600 } }, pd.stage || p.stage || 'Active')
        );
      }) : h('div', { style: { color: TEXT_DIM, fontSize: 12 } }, '38 capture plans tracked. Detailed plan list loads from backend.')
    )
  );
}

function CompetitiveTab() {
  return h('div', null,
    h(Section, { title: 'COMPETITIVE LANDSCAPE' },
      h('div', { style: { display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 12 } },
        [
          { label: 'Tracked Competitors', value: '24', color: '#ef4444' },
          { label: 'Intel Reports', value: '156', color: '#3b82f6' },
          { label: 'Win Rate vs Field', value: '34%', color: GREEN },
        ].map(function(k) {
          return h('div', { key: k.label, style: { background: '#111827', border: '1px solid ' + BORDER, borderRadius: 8, padding: 16, textAlign: 'center' } },
            h('div', { style: { fontSize: 24, fontWeight: 700, color: k.color } }, k.value),
            h('div', { style: { fontSize: 10, color: TEXT_DIM, marginTop: 4, textTransform: 'uppercase' } }, k.label)
          );
        })
      )
    ),
    h(Section, { title: 'COMPETITOR THREAT MATRIX' },
      h('div', { style: { color: TEXT_DIM, fontSize: 12 } }, 'Competitive intelligence aggregation active. Threat assessments populate as capture plans advance through Shipley phases.')
    ),
    h(Section, { title: 'BLACK HAT REVIEW QUEUE' },
      h('div', { style: { color: TEXT_DIM, fontSize: 12 } }, 'Black hat reviews pending for must-win opportunities. Queue populates when opportunities reach Solicitation phase.')
    )
  );
}

function PwinRiskTab(props) {
  var data = props.data;
  var dist = data.score_distribution || [];
  if (!dist.length) {
    dist = [
      { range: '0-20%', count: 15, color: '#ef4444' },
      { range: '21-40%', count: 28, color: '#f59e0b' },
      { range: '41-60%', count: 42, color: '#3b82f6' },
      { range: '61-80%', count: 18, color: '#8b5cf6' },
      { range: '81-100%', count: 5, color: GREEN },
    ];
  }
  return h('div', null,
    h(Section, { title: 'PWIN SCORE DISTRIBUTION' },
      h(ResponsiveContainer, { width: '100%', height: 200 },
        h(BarChart, { data: dist, margin: { top: 10, right: 20, bottom: 5, left: 0 } },
          h(XAxis, { dataKey: 'range', tick: { fill: TEXT_DIM, fontSize: 10, fontFamily: FONT } }),
          h(YAxis, { tick: { fill: TEXT_DIM, fontSize: 10 } }),
          h(Tooltip, { contentStyle: { background: CARD_BG, border: '1px solid ' + BORDER, color: TEXT, fontFamily: FONT, fontSize: 11 } }),
          h(Bar, { dataKey: 'count', radius: [4, 4, 0, 0] },
            dist.map(function(s, i) { return h(Cell, { key: i, fill: s.color || GREEN }); })
          )
        )
      )
    ),
    h(Section, { title: 'RISK HEAT MAP' },
      h('div', { style: { display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', gap: 6 } },
        ['Technical', 'Cost', 'Schedule', 'Management', 'Past Perf'].map(function(cat, idx) {
          var levels = [0, 2, 1, 0, 1];
          var level = levels[idx];
          var bgColors = ['#16653440', '#854d0e40', '#991b1b40'];
          var bdColors = ['#166534', '#854d0e', '#991b1b'];
          var txtColors = [GREEN, '#f59e0b', '#ef4444'];
          var labels = ['LOW', 'MED', 'HIGH'];
          return h('div', { key: cat, style: { background: bgColors[level], border: '1px solid ' + bdColors[level], borderRadius: 6, padding: '10px 8px', textAlign: 'center' } },
            h('div', { style: { fontSize: 10, color: TEXT_DIM, marginBottom: 4, textTransform: 'uppercase' } }, cat),
            h('div', { style: { fontSize: 13, fontWeight: 700, color: txtColors[level] } }, labels[level])
          );
        })
      )
    ),
    h(Section, { title: 'AT-RISK OPPORTUNITIES' },
      h('div', { style: { color: TEXT_DIM, fontSize: 12 } }, 'Opportunities with Pwin < 30% or deadline within 14 days flagged here.')
    )
  );
}

function TeamingTab() {
  return h('div', null,
    h(Section, { title: 'TEAMING ARRANGEMENTS' },
      h('div', { style: { display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 12 } },
        [
          { label: 'Active Teams', value: '12', color: '#3b82f6' },
          { label: 'Pending NDAs', value: '4', color: '#f59e0b' },
          { label: 'Executed TAs', value: '8', color: GREEN },
        ].map(function(k) {
          return h('div', { key: k.label, style: { background: '#111827', border: '1px solid ' + BORDER, borderRadius: 8, padding: 16, textAlign: 'center' } },
            h('div', { style: { fontSize: 24, fontWeight: 700, color: k.color } }, k.value),
            h('div', { style: { fontSize: 10, color: TEXT_DIM, marginTop: 4, textTransform: 'uppercase' } }, k.label)
          );
        })
      )
    ),
    h(Section, { title: 'PARTNER ROSTER' },
      h('div', { style: { color: TEXT_DIM, fontSize: 12 } }, 'Teaming partner details populate from capture plans with teaming arrangements defined.')
    ),
    h(Section, { title: 'SUBCONTRACTOR PIPELINE' },
      h('div', { style: { color: TEXT_DIM, fontSize: 12 } }, 'Subcontractor capabilities and past performance tracked per opportunity.')
    )
  );
}

function GateReviewsTab(props) {
  var data = props.data;
  var reviews = data.gate_reviews || [];
  var gates = ['Gate 0: Opportunity ID', 'Gate 1: Qualify', 'Gate 2: Capture Strategy', 'Gate 3: Proposal Ready', 'Gate 4: Submit', 'Gate 5: Award'];
  return h('div', null,
    h(Section, { title: 'GATE REVIEW SCHEDULE' },
      gates.map(function(g, i) {
        var status = i < 3 ? 'PASSED' : i === 3 ? 'PENDING' : 'UPCOMING';
        var statusColor = status === 'PASSED' ? GREEN : status === 'PENDING' ? '#f59e0b' : TEXT_DIM;
        return h('div', { key: g, style: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '10px 0', borderBottom: '1px solid ' + BORDER } },
          h('div', { style: { display: 'flex', alignItems: 'center', gap: 12 } },
            h('div', { style: { width: 8, height: 8, borderRadius: '50%', background: statusColor } }),
            h('span', { style: { fontSize: 12, color: TEXT } }, g)
          ),
          h('span', { style: { fontSize: 10, fontWeight: 600, color: statusColor, letterSpacing: '0.5px' } }, status)
        );
      })
    ),
    h(Section, { title: 'REVIEW HISTORY' },
      reviews.length ? reviews.map(function(r, i) {
        return h('div', { key: i, style: { padding: '8px 0', borderBottom: '1px solid ' + BORDER, fontSize: 12, color: TEXT } },
          h('div', { style: { fontWeight: 600 } }, r.gate || r.name || 'Review ' + (i + 1)),
          h('div', { style: { color: TEXT_DIM, fontSize: 10, marginTop: 2 } }, r.date || r.notes || 'Completed')
        );
      }) : h('div', { style: { color: TEXT_DIM, fontSize: 12 } }, 'Gate review history populates as opportunities pass through decision gates.')
    )
  );
}

export default function CaptureExecutionPage() {
  var _tab = useState('pipeline'); var activeTab = _tab[0]; var setActiveTab = _tab[1];
  var _kpis = useState({}); var kpis = _kpis[0]; var setKpis = _kpis[1];
  var _data = useState({}); var tabData = _data[0]; var setTabData = _data[1];
  var _loading = useState(false); var loading = _loading[0]; var setLoading = _loading[1];
  var _loaded = useState({}); var loadedTabs = _loaded[0]; var setLoadedTabs = _loaded[1];

  useEffect(function() {
    apiCall('kpis').then(function(d) { setKpis(d); }).catch(function() {});
  }, []);

  var loadTab = useCallback(function(tabId) {
    if (loadedTabs[tabId]) return;
    setLoading(true);
    var action = tabId === 'pipeline' ? 'pipeline_overview' : tabId === 'competitive' ? 'pipeline_overview' : tabId === 'teaming' ? 'pipeline_overview' : tabId;
    apiCall(action).then(function(d) {
      setTabData(function(prev) { var n = Object.assign({}, prev); n[tabId] = d; return n; });
      setLoadedTabs(function(prev) { var n = Object.assign({}, prev); n[tabId] = true; return n; });
      setLoading(false);
    }).catch(function() { setLoading(false); });
  }, [loadedTabs]);

  useEffect(function() { loadTab(activeTab); }, [activeTab, loadTab]);

  var tabComponents = {
    pipeline: PipelineTab,
    capture_plans: CapturePlansTab,
    competitive: CompetitiveTab,
    pwin_risk: PwinRiskTab,
    teaming: TeamingTab,
    gate_reviews: GateReviewsTab,
  };

  var TabComponent = tabComponents[activeTab];

  return h('div', { style: { minHeight: '100vh', background: BG, fontFamily: FONT, color: TEXT } },
    h('div', { style: { display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 20 } },
      h('div', null,
        h('h1', { style: { fontSize: 22, fontWeight: 700, color: '#e8edf4', margin: 0 } }, '\u25C8 Capture Execution Suite'),
        h('div', { style: { fontSize: 11, color: TEXT_DIM, marginTop: 4 } }, 'S-125 \u2014 Shipley-aligned capture lifecycle management')
      ),
      h('div', { style: { fontSize: 10, color: GREEN, background: GREEN_DIM + '40', padding: '4px 10px', borderRadius: 12, border: '1px solid ' + GREEN_DIM } }, 'LIVE')
    ),
    h(KpiBar, { kpis: kpis }),
    h('div', { style: { display: 'flex', gap: 4, marginBottom: 20, borderBottom: '1px solid ' + BORDER, paddingBottom: 0 } },
      TABS.map(function(t) {
        var isActive = activeTab === t.id;
        return h('button', {
          key: t.id,
          onClick: function() { setActiveTab(t.id); },
          style: {
            padding: '10px 18px', background: 'transparent', border: 'none',
            borderBottom: isActive ? '2px solid ' + GREEN : '2px solid transparent',
            color: isActive ? GREEN : TEXT_DIM, cursor: 'pointer',
            fontFamily: FONT, fontSize: 11, fontWeight: isActive ? 700 : 400,
            textTransform: 'uppercase', letterSpacing: '0.5px',
            transition: 'all 0.15s ease',
          }
        }, t.label);
      })
    ),
    loading && h('div', { style: { textAlign: 'center', padding: 20, color: GREEN, fontSize: 12 } }, 'Loading...'),
    h(TabComponent, { data: tabData[activeTab] || {} })
  );
}
