// QA Center Page — runs read-only and dry-run health checks against same-origin /api routes.
// No secrets in client code. All requests go through the React/nginx /api proxy.
import React, { useState } from 'react';
import { NAVY, ACCENT, BORDER, WHITE, PageHeader, Spinner } from '../../lib/gda';

// Read-only check definitions. method/path/body kept lightweight and idempotent.
// `path` is appended to /api/ by runCheck — no absolute URLs, no x-gda-key headers.
const READONLY_CHECKS = [
  { id: 'platform-health',       label: 'Platform Health',         path: 'gda-platform-health',        method: 'POST', body: {} },
  { id: 'dashboard-mega',        label: 'Dashboard (Mega)',        path: 'gda-dashboard-mega',         method: 'POST', body: {} },
  { id: 'trends',                label: 'Trends',                  path: 'gda-trends',                 method: 'POST', body: {} },
  { id: 'opp-tracker',           label: 'Opportunity Tracker',     path: 'gda-opp-tracker',            method: 'POST', body: {} },
  { id: 'launchpad-funnel',      label: 'Launchpad Funnel',        path: 'gda-launchpad-funnel',       method: 'POST', body: {} },
  { id: 'deep-research-history', label: 'Deep Research History',   path: 'gda-deep-research-history',  method: 'POST', body: { action: 'list', limit: 1 } },
  { id: 'capture-plan',          label: 'Capture Plan',            path: 'gda-capture-plan',           method: 'POST', body: { action: 'list', limit: 1 } },
  { id: 'morning-briefing',      label: 'Morning Briefing',        path: 'gda-morning-briefing',       method: 'POST', body: {} },
];

// Dry-run checks — the proxy/n8n side already supports a dryRun flag.
// These must NOT cause production writes.
const DRYRUN_CHECKS = [
  { id: 'save-opp-dryrun', label: 'Save Opportunity (dry run)', path: 'gda-save-opp', method: 'POST', body: { dryRun: true, opp: { title: 'QA dry run probe', source: 'qa-center' } } },
  { id: 'risk-dryrun',     label: 'Risk Register (dry run)',    path: 'gda-risk',     method: 'POST', body: { dryRun: true, action: 'analyze', target: 'qa-center-probe' } },
];

function classify(httpStatus, bodyText, error) {
  if (error) return { status: 'ERROR', tone: 'red' };
  if (httpStatus === 401 || httpStatus === 403) return { status: 'AUTH FAIL', tone: 'red' };
  if (httpStatus >= 500) return { status: 'FAIL', tone: 'red' };
  if (httpStatus >= 400) return { status: 'FAIL', tone: 'red' };
  if (httpStatus >= 200 && httpStatus < 400) {
    const empty = !bodyText || bodyText.trim() === '' || bodyText.trim() === '{}' || bodyText.trim() === '[]';
    if (empty) return { status: 'EMPTY', tone: 'orange' };
    return { status: 'PASS', tone: 'green' };
  }
  return { status: 'UNKNOWN', tone: 'gray' };
}

async function runCheck(check) {
  const start = Date.now();
  const url = '/api/' + check.path;
  try {
    const resp = await fetch(url, {
      method: check.method || 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(check.body || {}),
      signal: AbortSignal.timeout(20000),
    });
    const text = await resp.text().catch(() => '');
    const ms = Date.now() - start;
    const cls = classify(resp.status, text, null);
    return { id: check.id, label: check.label, path: check.path, http: resp.status, ms, status: cls.status, tone: cls.tone, error: null, bytes: text ? text.length : 0 };
  } catch (e) {
    const ms = Date.now() - start;
    const msg = (e && e.name === 'TimeoutError') ? 'Timeout (20s)' : (e && e.message) || 'Network error';
    return { id: check.id, label: check.label, path: check.path, http: 0, ms, status: 'ERROR', tone: 'red', error: msg, bytes: 0 };
  }
}

function recommend(rows) {
  if (!rows || rows.length === 0) return 'Click Run Health Check to start.';
  const auth = rows.filter(r => r.status === 'AUTH FAIL');
  const fails = rows.filter(r => r.status === 'FAIL' || r.status === 'ERROR');
  const empties = rows.filter(r => r.status === 'EMPTY');
  if (auth.length > 0) {
    return 'Auth failures on ' + auth.length + ' endpoint(s). The /api proxy header is likely missing or invalid on the server. Check nginx config — do not put keys in the React app.';
  }
  if (fails.length > 0) {
    return fails.length + ' endpoint(s) failed. Tell the platform engineer which names are red below; they map to n8n workflow names of the same id.';
  }
  if (empties.length > 0) {
    return empties.length + ' endpoint(s) returned empty. Likely upstream data is missing — usually safe but verify with the workflow owner.';
  }
  return 'All systems healthy. Last run completed successfully.';
}

function StatusPill({ status, tone }) {
  const colors = {
    green:  { bg: '#2F5C1F15', fg: '#2F5C1F' },
    red:    { bg: '#FEE2E2',   fg: '#DC2626' },
    orange: { bg: '#B06D3218', fg: '#B06D32' },
    gray:   { bg: '#F3F4F6',   fg: '#6B7280' },
  };
  const c = colors[tone] || colors.gray;
  return React.createElement('span', {
    'data-testid': 'qa-status-pill',
    style: { fontSize: 11, fontWeight: 700, padding: '2px 8px', borderRadius: 10, color: c.fg, background: c.bg }
  }, status);
}

function ResultsTable({ rows, testIdPrefix }) {
  if (!rows || rows.length === 0) return null;
  return React.createElement('table', { style: { width: '100%', borderCollapse: 'collapse', fontSize: 12, marginBottom: 14 } },
    React.createElement('thead', null,
      React.createElement('tr', { style: { background: '#F8FAFC' } },
        React.createElement('th', { style: { padding: '8px 12px', textAlign: 'left',   color: '#6B7280', borderBottom: '1px solid ' + BORDER } }, 'Check'),
        React.createElement('th', { style: { padding: '8px 12px', textAlign: 'left',   color: '#6B7280', borderBottom: '1px solid ' + BORDER } }, 'Path'),
        React.createElement('th', { style: { padding: '8px 12px', textAlign: 'center', color: '#6B7280', borderBottom: '1px solid ' + BORDER } }, 'Status'),
        React.createElement('th', { style: { padding: '8px 12px', textAlign: 'center', color: '#6B7280', borderBottom: '1px solid ' + BORDER } }, 'HTTP'),
        React.createElement('th', { style: { padding: '8px 12px', textAlign: 'right',  color: '#6B7280', borderBottom: '1px solid ' + BORDER } }, 'ms'),
        React.createElement('th', { style: { padding: '8px 12px', textAlign: 'right',  color: '#6B7280', borderBottom: '1px solid ' + BORDER } }, 'Bytes'),
      )
    ),
    React.createElement('tbody', null,
      rows.map(function(r, i) {
        return React.createElement('tr', {
          key: r.id,
          'data-testid': testIdPrefix + '-row-' + r.id,
          style: { borderBottom: '1px solid #F0F1F4', background: i % 2 === 0 ? WHITE : '#FAFBFC' }
        },
          React.createElement('td', { style: { padding: '8px 12px', fontWeight: 500, color: NAVY } }, r.label),
          React.createElement('td', { style: { padding: '8px 12px', color: '#6B7280', fontFamily: 'monospace', fontSize: 11 } }, '/api/' + r.path),
          React.createElement('td', { style: { padding: '8px 12px', textAlign: 'center' }, 'data-testid': testIdPrefix + '-status-' + r.id }, React.createElement(StatusPill, { status: r.status, tone: r.tone })),
          React.createElement('td', { style: { padding: '8px 12px', textAlign: 'center', color: r.http >= 200 && r.http < 400 ? '#2F5C1F' : '#DC2626' }, 'data-testid': testIdPrefix + '-http-' + r.id }, r.http || '—'),
          React.createElement('td', { style: { padding: '8px 12px', textAlign: 'right', color: '#6B7280' }, 'data-testid': testIdPrefix + '-ms-' + r.id }, r.ms ? r.ms.toLocaleString() : '—'),
          React.createElement('td', { style: { padding: '8px 12px', textAlign: 'right', color: '#9CA3AF' } }, r.bytes ? r.bytes.toLocaleString() : '—'),
        );
      })
    )
  );
}

function Counter({ label, value, color, testid }) {
  return React.createElement('div', {
    'data-testid': testid,
    style: { background: WHITE, border: '1px solid ' + BORDER, borderRadius: 10, padding: '12px', textAlign: 'center', borderTop: '3px solid ' + color }
  },
    React.createElement('div', { style: { fontSize: 11, color: '#6B7280' } }, label),
    React.createElement('div', { style: { fontSize: 22, fontWeight: 700, color: color } }, value)
  );
}

function QACenter() {
  const [readonlyRows, setReadonlyRows] = useState([]);
  const [dryrunRows, setDryrunRows] = useState([]);
  const [running, setRunning] = useState(false);
  const [runningDry, setRunningDry] = useState(false);
  const [lastRun, setLastRun] = useState(null);
  const [lastDryRun, setLastDryRun] = useState(null);

  async function handleRun(checks, setRows, setStamp, setBusy) {
    setBusy(true);
    setRows([]);
    const results = [];
    for (let i = 0; i < checks.length; i++) {
      const r = await runCheck(checks[i]);
      results.push(r);
      setRows(results.slice());
    }
    setStamp(new Date().toISOString());
    setBusy(false);
  }

  function summarize(rows) {
    const passed = rows.filter(r => r.status === 'PASS').length;
    const failed = rows.filter(r => r.status === 'FAIL' || r.status === 'ERROR').length;
    const auth = rows.filter(r => r.status === 'AUTH FAIL').length;
    const empty = rows.filter(r => r.status === 'EMPTY').length;
    return { passed, failed, auth, empty, total: rows.length };
  }

  const sum = summarize(readonlyRows);
  const dsum = summarize(dryrunRows);
  const overall = readonlyRows.length === 0 ? 'Not run' :
    sum.failed > 0 || sum.auth > 0 ? 'Critical Issues' :
    sum.empty > 0 ? 'Degraded' : 'Operational';
  const overallColor = overall === 'Operational' ? '#2F5C1F' : overall === 'Degraded' ? '#B06D32' : overall === 'Not run' ? '#6B7280' : '#DC2626';

  return React.createElement('div', { 'data-testid': 'qa-center-page' },
    React.createElement(PageHeader, {
      title: 'QA Center',
      sub: 'Read-only health checks and dry-run safety probes — runs in your browser, no PowerShell required.',
      action: React.createElement('div', { style: { display: 'flex', gap: 8 } },
        React.createElement('button', {
          'data-testid': 'qa-run-health-check',
          onClick: function() { handleRun(READONLY_CHECKS, setReadonlyRows, setLastRun, setRunning); },
          disabled: running || runningDry,
          style: { padding: '8px 18px', background: ACCENT, color: '#fff', border: 'none', borderRadius: 6, fontSize: 12, fontWeight: 600, cursor: 'pointer', opacity: (running || runningDry) ? 0.5 : 1 }
        }, running ? 'Running…' : 'Run Health Check'),
        React.createElement('button', {
          'data-testid': 'qa-run-dryrun-check',
          onClick: function() { handleRun(DRYRUN_CHECKS, setDryrunRows, setLastDryRun, setRunningDry); },
          disabled: running || runningDry,
          style: { padding: '8px 18px', background: WHITE, color: NAVY, border: '1px solid ' + BORDER, borderRadius: 6, fontSize: 12, fontWeight: 600, cursor: 'pointer', opacity: (running || runningDry) ? 0.5 : 1 }
        }, runningDry ? 'Running…' : 'Run Dry-Run Checks')
      )
    }),

    React.createElement('div', { style: { display: 'flex', gap: 16, alignItems: 'center', marginBottom: 18 } },
      React.createElement('div', {
        style: { width: 70, height: 70, borderRadius: '50%', border: '4px solid ' + overallColor, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }
      },
        React.createElement('span', { style: { fontSize: 11, fontWeight: 800, color: overallColor, textAlign: 'center', padding: 4 } }, overall === 'Not run' ? '—' : overall.split(' ')[0])
      ),
      React.createElement('div', null,
        React.createElement('div', { 'data-testid': 'qa-overall-status', style: { fontSize: 16, fontWeight: 700, color: NAVY } }, overall),
        React.createElement('div', { 'data-testid': 'qa-last-run', style: { fontSize: 11, color: '#6B7280', marginTop: 4 } },
          lastRun ? 'Last health check: ' + new Date(lastRun).toLocaleString() : 'Health check not yet run.'),
        lastDryRun ? React.createElement('div', { 'data-testid': 'qa-last-dryrun', style: { fontSize: 11, color: '#6B7280', marginTop: 2 } }, 'Last dry-run: ' + new Date(lastDryRun).toLocaleString()) : null
      )
    ),

    React.createElement('div', { style: { display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', gap: 10, marginBottom: 18 } },
      React.createElement(Counter, { label: 'Total',      value: sum.total,  color: NAVY,      testid: 'qa-counter-total' }),
      React.createElement(Counter, { label: 'Passed',     value: sum.passed, color: '#2F5C1F', testid: 'qa-counter-passed' }),
      React.createElement(Counter, { label: 'Failed',     value: sum.failed, color: '#DC2626', testid: 'qa-counter-failed' }),
      React.createElement(Counter, { label: 'Auth Fails', value: sum.auth,   color: '#DC2626', testid: 'qa-counter-auth' }),
      React.createElement(Counter, { label: 'Empty',      value: sum.empty,  color: '#B06D32', testid: 'qa-counter-empty' }),
    ),

    React.createElement('div', {
      'data-testid': 'qa-recommendation',
      style: { background: '#F0F4FF', border: '1px solid #C7D2FE', borderRadius: 8, padding: '10px 14px', fontSize: 12, color: NAVY, marginBottom: 18, lineHeight: 1.5 }
    },
      React.createElement('strong', null, 'Next action: '),
      recommend(readonlyRows)
    ),

    React.createElement('div', { style: { fontSize: 14, fontWeight: 700, color: NAVY, marginBottom: 8 } }, 'Read-Only Health Checks'),
    running && readonlyRows.length === 0 ? React.createElement('div', { style: { textAlign: 'center', padding: 20 } }, React.createElement(Spinner)) :
      React.createElement(ResultsTable, { rows: readonlyRows, testIdPrefix: 'qa-ro' }),

    React.createElement('div', { style: { display: 'flex', alignItems: 'center', gap: 10, marginTop: 24, marginBottom: 8 } },
      React.createElement('div', { style: { fontSize: 14, fontWeight: 700, color: NAVY } }, 'Dry-Run Checks'),
      React.createElement('span', {
        style: { fontSize: 10, fontWeight: 700, padding: '2px 8px', borderRadius: 10, color: '#2F5C1F', background: '#2F5C1F15' }
      }, 'NO PRODUCTION WRITES')
    ),
    React.createElement('div', { style: { fontSize: 11, color: '#6B7280', marginBottom: 10 } },
      'Sends dryRun: true to safe endpoints. Backend must honor the flag — verify with the platform engineer if the dry-run rows show writes.'),
    runningDry && dryrunRows.length === 0 ? React.createElement('div', { style: { textAlign: 'center', padding: 20 } }, React.createElement(Spinner)) :
      React.createElement(ResultsTable, { rows: dryrunRows, testIdPrefix: 'qa-dr' }),
    dryrunRows.length > 0 ? React.createElement('div', { 'data-testid': 'qa-dryrun-summary', style: { fontSize: 11, color: '#6B7280' } },
      dsum.passed + ' passed · ' + dsum.failed + ' failed · ' + dsum.empty + ' empty · ' + dsum.auth + ' auth') : null
  );
}

export default QACenter;
