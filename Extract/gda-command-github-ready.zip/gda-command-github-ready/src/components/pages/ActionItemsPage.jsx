import React, { useState, useEffect, useCallback, useRef, useMemo } from 'react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, LineChart, Line, AreaChart, Area, RadarChart, Radar, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Legend, CartesianGrid, ScatterChart, Scatter, ReferenceLine } from 'recharts';
import { ACCENT, NAVY, BG, WHITE, BORDER, FONT, N8N, AUTH, api, S, css, gdaNav, NAV_ITEMS, Spinner, Empty, Alert, PageHeader, GDAKpiBar } from '../../lib/gda';
function ActionItems() {
  const [items,setItems]=useState([]);const [loading,setLoading]=useState(true);
  const [newText,setNewText]=useState('');const [newPri,setNewPri]=useState('medium');
  const [newDue,setNewDue]=useState('');const [newOwner,setNewOwner]=useState('');
  const [saving,setSaving]=useState(false);const [filter,setFilter]=useState('open');
  const [expanded,setExpanded]=useState({});const [view,setView]=useState('list');
  const load=useCallback(async()=>{setLoading(true);try{const d=await api.post('gda-action-items',{action:'list'});setItems(d.items||d.data||[]);}catch{setItems([]);}setLoading(false);},[]);
  useEffect(()=>{load();},[load]);
  const add=async()=>{if(!newText.trim())return;setSaving(true);try{await api.post('gda-action-items',{action:'create',title:newText,status:'open',priority:newPri,due:newDue||undefined,owner:newOwner||undefined});setNewText('');setNewDue('');setNewOwner('');await load();}catch{}setSaving(false);};
  const toggle=async(item)=>{try{await api.post('gda-action-items',{action:'update',id:item.id,status:(item.status||'open').toLowerCase()==='open'?'done':'open'});await load();}catch{}};
  const visible=filter==='all'?items:filter==='overdue'?items.filter(i=>(i.status||'open').toLowerCase()==='open'&&i.due&&new Date(i.due)<new Date()):items.filter(i=>(i.status||'open').toLowerCase()===filter);
  const [kpiDetail, setKpiDetail] = useState(null);
  const total=items.length,open=items.filter(i=>(i.status||'open').toLowerCase()==='open').length,done=items.filter(i=>(i.status||'').toLowerCase()==='done').length,overdue=items.filter(i=>(i.status||'open').toLowerCase()==='open'&&i.due&&new Date(i.due)<new Date()).length;
  const pc=(p)=>p==='high'?'red':p==='medium'?'orange':p==='low'?'green':'gray';
  return (<div>
    <PageHeader title="Action Items" sub="Consolidated task tracking with priority management" action={<div style={{display:'flex',gap:6}}><button onClick={function(){load();}} style={{padding:'4px 12px',fontSize:12,border:'1px solid #D1D5DB',borderRadius:6,background:'#fff',color:'#374151',cursor:'pointer',fontWeight:500,fontFamily:'Inter,sans-serif'}}>{'\u21bb Refresh'}</button>{['list','board'].map(v=><button key={v} onClick={()=>setView(v)} style={{...S.btn(v===view?'primary':'secondary',true),textTransform:'capitalize'}}>{v}</button>)}</div>} />
    <GDAKpiBar items={[
      {id:'total',label:'Total',value:total,sub:'all items'},
      {id:'open',label:'Open',value:open,color:open>0?'#1B2A4A':'#2F5C1F',sub:'in progress'},
      {id:'overdue',label:'Overdue',value:overdue,color:overdue>0?'#DC2626':'#1B2A4A',sub:'past due'},
      {id:'done',label:'Done',value:done,color:'#2F5C1F',sub:'completed'}
    ]} detail={kpiDetail} setDetail={setKpiDetail} />
    <div style={{...S.card,marginBottom:14}}><div style={{fontSize:11,fontWeight:700,color:NAVY,marginBottom:8}}>Quick Add</div>
      <div style={{display:'flex',gap:8,flexWrap:'wrap'}}><input style={{...S.input,flex:2,minWidth:200}} placeholder="Action item title..." value={newText} onChange={e=>setNewText(e.target.value)} onKeyDown={e=>e.key==='Enter'&&add()} />
      <select style={{...S.select,minWidth:90}} value={newPri} onChange={e=>setNewPri(e.target.value)}><option value="high">High</option><option value="medium">Medium</option><option value="low">Low</option></select>
      <input type="date" style={{...S.input,maxWidth:150}} value={newDue} onChange={e=>setNewDue(e.target.value)} />
      <input style={{...S.input,maxWidth:140}} placeholder="Owner" value={newOwner} onChange={e=>setNewOwner(e.target.value)} />
      <button style={S.btn()} onClick={add} disabled={saving||!newText.trim()}>{saving?'Adding...':'+ Add'}</button></div></div>
    <div style={{...S.row(),gap:6,marginBottom:14}}>{['open','done','overdue','all'].map(f=>(<button key={f} onClick={()=>setFilter(f)} style={{...S.btn(f===filter?'primary':'secondary',true),textTransform:'capitalize'}}>{f}</button>))}<div style={{flex:1}}/><div style={{fontSize:11,color:'#888'}}>{visible.length} items</div></div>
    {view==='board'?(<div style={S.grid(3,14)}>{['open','in-progress','done'].map(col=>(<div key={col} style={{...S.card,minHeight:200}}><div style={{fontSize:11,fontWeight:700,color:'#888',textTransform:'uppercase',marginBottom:10}}>{col.replace('-',' ')}</div>
      {items.filter(i=>(col==='open'?(i.status||'open').toLowerCase()==='open':col==='done'?(i.status||'').toLowerCase()==='done':(i.status||'').toLowerCase()==='in-progress')).map((it,j)=>(<div key={j} style={{padding:'8px 10px',background:'#fafafa',borderRadius:6,marginBottom:6,borderLeft:'3px solid '+(it.priority==='high'?'#e53935':it.priority==='medium'?ACCENT:'#22a06b'),fontSize:12,cursor:'pointer'}} onClick={()=>toggle(it)}><div style={{fontWeight:600,color:NAVY}}>{it.item||it.title||it.text||'Untitled'}</div>{it.due&&<div style={{fontSize:10,color:'#888',marginTop:2}}>Due: {it.due}</div>}</div>))}</div>))}</div>)
    :(<div style={S.card}>{loading?<Spinner />:visible.length===0?<Empty msg="No action items yet. Create one above." />:
      visible.map((item,i)=>{var isE=expanded[i];var isOD=(item.status||'open').toLowerCase()==='open'&&item.due&&new Date(item.due)<new Date();return(<div key={i} style={{padding:'10px 0',borderBottom:'1px solid #f0f0f0'}}>
        <div style={{...S.row(),justifyContent:'space-between'}}><div style={{...S.row(),gap:10,flex:1}}>
          <input type="checkbox" checked={(item.status||'').toLowerCase()==='done'} onChange={()=>toggle(item)} style={{width:16,height:16,accentColor:ACCENT,cursor:'pointer'}} />
          <div style={{flex:1}}><div style={{display:'flex',alignItems:'center',gap:6,flexWrap:'wrap'}}>
            <span style={{fontSize:13,textDecoration:(item.status||'').toLowerCase()==='done'?'line-through':'none',color:(item.status||'').toLowerCase()==='done'?'#aaa':NAVY,fontWeight:600}}>{item.item||item.title||item.text||'Untitled'}</span>
            <span style={S.badge(pc(item.priority))}>{item.priority||'medium'}</span>
            {isOD&&<span style={S.badge('red')}>OVERDUE</span>}</div>
            <div style={{display:'flex',gap:12,marginTop:3,fontSize:10,color:'#888'}}>{item.due&&<span>Due: {item.due}</span>}{item.owner&&<span>Owner: {item.owner}</span>}{item.source&&<span>From: {item.source}</span>}</div></div></div>
          <button style={{...S.btn('secondary',true),fontSize:10}} onClick={()=>setExpanded(e=>({...e,[i]:!e[i]}))}>{isE?'Less':'More'}</button></div>
        {isE&&<div style={{marginLeft:26,marginTop:8,padding:10,background:'#fafafa',borderRadius:6,fontSize:11,color:'#555',lineHeight:1.5}}>
          <div><b>Status:</b> {item.status||'open'}</div><div><b>Priority:</b> {item.priority||'medium'}</div>
          {item.due&&<div><b>Due:</b> {item.due}</div>}{item.owner&&<div><b>Owner:</b> {item.owner}</div>}
          {item.source&&<div><b>Source:</b> {item.source}</div>}{item.notes&&<div style={{marginTop:4}}><b>Notes:</b> {item.notes}</div>}
          {item.created_at&&<div><b>Created:</b> {new Date(item.created_at).toLocaleString()}</div>}</div>}
      </div>);})}</div>)}
    {/* Charts */}
    {items.length>0&&<div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:14,marginTop:18}}>
      <div style={S.card}><div style={S.cardTitle}>Items by Status</div>
        <ResponsiveContainer width="100%" height={220}><PieChart><Pie data={[{name:'Open',value:open},{name:'Done',value:done},{name:'Overdue',value:overdue}].filter(d=>d.value>0)} cx="50%" cy="50%" outerRadius={75} dataKey="value" label={e=>e.name+': '+e.value} labelLine={false}>{[ACCENT,'#22a06b','#e53935'].map((c,i)=><Cell key={i} fill={c}/>)}</Pie><Tooltip contentStyle={{fontSize:11,borderRadius:6}}/></PieChart></ResponsiveContainer></div>
      <div style={S.card}><div style={S.cardTitle}>Created per Week</div>
        <ResponsiveContainer width="100%" height={220}><BarChart data={(()=>{const w={};items.forEach(it=>{const d=it.created_at?new Date(it.created_at):new Date();const wk=new Date(d);wk.setDate(wk.getDate()-wk.getDay());const k=wk.toLocaleDateString('en-US',{month:'short',day:'numeric'});w[k]=(w[k]||0)+1;});return Object.entries(w).slice(-8).map(([wk,c])=>({week:wk,count:c}));})()}><XAxis dataKey="week" tick={{fontSize:10,fill:NAVY}}/><YAxis tick={{fontSize:10,fill:'#888'}} allowDecimals={false}/><Tooltip contentStyle={{fontSize:11,borderRadius:6}}/><Bar dataKey="count" fill={ACCENT} radius={[4,4,0,0]}/></BarChart></ResponsiveContainer></div>
    </div>}
  </div>);
}
export default ActionItems;