import React, { useState, useEffect, useCallback, useRef, useMemo } from 'react';
import { ACCENT, NAVY, BG, WHITE, BORDER, FONT, N8N, AUTH, api, S, css, gdaNav, NAV_ITEMS, Spinner, Empty, Alert, PageHeader , saveAction, ActionHistory } from '../../lib/gda';
function DocRAG() {
  // ── Existing state (compare mode + library) ──
  const [docs, setDocs] = useState([]);
  const [docsLoading, setDocsLoading] = useState(true);
  const [mode, setMode] = useState('query');
  const [cmpDocs, setCmpDocs] = useState([]);
  const [cmpLoading, setCmpLoading] = useState(false);
  const [docA, setDocA] = useState('');
  const [docB, setDocB] = useState('');
  const [cmpResult, setCmpResult] = useState(null);
  const [cmpRunning, setCmpRunning] = useState(false);
  const [fileA, setFileA] = useState(null);
  const [fileB, setFileB] = useState(null);
  const [uploadStatus, setUploadStatus] = useState('');
  // ── New query mode state ──
  const [attachedFile, setAttachedFile] = useState(null);
  const [chatHistory, setChatHistory] = useState([]);
  const [chatInput, setChatInput] = useState('');
  const [loading, setLoading] = useState(false);
  const chatEndRef = useRef(null);
  const [ndaaLoading, setNdaaLoading] = useState(false);
  const [ndaaStatus, setNdaaStatus] = useState('');
  const ndaaFileRef = useRef(null);

  const ingestNdaa = async (e) => {
    const file = e?.target?.files?.[0];
    if (!file) return;
    setNdaaLoading(true); setNdaaStatus('Reading ' + file.name + '...');
    try {
      const text = await file.text();
      setNdaaStatus('Ingesting into knowledge base...');
      const d = await api.post('gda-ingest-direct', {
        file_content: btoa(unescape(encodeURIComponent(text))),
        file_type: file.name.split('.').pop().toLowerCase() || 'txt',
        document_id: 'ndaa-' + Date.now(),
        namespace: 'gda-documents',
        metadata: { source: 'NDAA Upload', filename: file.name }
      });
      setNdaaStatus(d.message || d.status || 'NDAA ingestion complete');
      api.post('gda-knowledge-base', { action:'list' }).then(r => setDocs(r.documents || r.data || [])).catch(()=>{});
    } catch (e2) { setNdaaStatus('Error: ' + e2.message); }
    setNdaaLoading(false);
    if (ndaaFileRef.current) ndaaFileRef.current.value = '';
  };

  useEffect(() => {
    api.post('gda-knowledge-base', { action:'list' })
      .then(d => setDocs(d.documents || d.data || []))
      .catch(()=>setDocs([]))
      .finally(()=>setDocsLoading(false));
  }, []);

  useEffect(() => {
    if (mode === 'compare' && cmpDocs.length === 0) {
      setCmpLoading(true);
      api.post('gda-doc-compare', {action:'list'})
        .then(d => setCmpDocs(d.documents || []))
        .catch(() => setCmpDocs([]))
        .finally(() => setCmpLoading(false));
    }
  }, [mode]);

  useEffect(() => { if (chatEndRef.current) chatEndRef.current.scrollIntoView({ behavior: 'smooth' }); }, [chatHistory]);

  const fmtSize = (bytes) => bytes < 1024 * 1024 ? (bytes / 1024).toFixed(1) + ' KB' : (bytes / (1024 * 1024)).toFixed(1) + ' MB';

  const ask = async () => {
    const q = chatInput.trim(); if (!q) return;
    setChatInput('');
    setChatHistory(h => [...h, { role: 'user', content: q }]);
    setLoading(true);
    try {
      const payload = { query: q };
      if (attachedFile) { payload.doc_content = attachedFile.content; payload.filename = attachedFile.name; }
      const d = await api.post('gda-rag-query', payload);
      const ans = d.answer || d.output || d.response || JSON.stringify(d);
      setChatHistory(h => [...h, { role: 'ai', content: ans }]);
    } catch (e) { setChatHistory(h => [...h, { role: 'ai', content: 'Error: ' + e.message }]); }
    setLoading(false);
  };

  const handleAttach = (e) => {
    const file = e.target.files[0]; if (!file) return;
    const reader = new FileReader();
    reader.onload = () => { setAttachedFile({ name: file.name, content: reader.result.split(',')[1] || reader.result, size: file.size }); };
    reader.readAsDataURL(file); e.target.value = '';
  };

  const handleFile = (setter) => (e) => {
    const file = e.target.files[0]; if (!file) return;
    const reader = new FileReader();
    reader.onload = () => { setter({ name: file.name, b64: reader.result.split(',')[1] || reader.result, size: file.size }); };
    reader.readAsDataURL(file);
  };
  const runCompare = async () => {
    if (!fileA || !fileB) return;
    setCmpRunning(true); setCmpResult(null); setUploadStatus('Uploading Document A...');
    try {
      await api.post('gda-ingest-direct', { name: fileA.name, content: fileA.b64 });
      setUploadStatus('Uploading Document B...');
      await api.post('gda-ingest-direct', { name: fileB.name, content: fileB.b64 });
      setUploadStatus('Analyzing differences (30-60s)...');
      const idA = fileA.name.replace(/\.[^.]+$/, '');
      const idB = fileB.name.replace(/\.[^.]+$/, '');
      const d = await api.post('gda-doc-compare', { doc_a_id: idA, doc_b_id: idB });
      setCmpResult(d); saveAction("doc-rag","compare","Doc Compare: "+docA+" vs "+docB,{docA,docB},d);
    } catch (e) { setCmpResult({ error: e.message }); }
    setCmpRunning(false); setUploadStatus('');
  };

  const selStyle = {padding:'6px 10px',borderRadius:6,border:'1px solid '+BORDER,fontSize:12,flex:1,background:WHITE,color:NAVY};
  const cmp = cmpResult && cmpResult.comparison ? cmpResult.comparison : null;
  const CATS = {scope:'Scope',requirements:'Requirements',terms:'Terms & Conditions',dates:'Key Dates',personnel:'Personnel',pricing:'Pricing',deliverables:'Deliverables',compliance:'Compliance',performance_metrics:'Performance',evaluation_criteria:'Evaluation'};

  return (
    <div>
      <PageHeader title="Document RAG" sub="Query your document library with AI" />
      <div style={{display:'flex',gap:4,marginBottom:14,borderBottom:'1px solid '+BORDER,paddingBottom:6}}>
        <button onClick={()=>setMode('query')} style={S.nav(mode==='query')}>Query</button>
        <button onClick={()=>setMode('compare')} style={S.nav(mode==='compare')}>Compare Documents</button>
      </div>

      {mode === 'query' && <>
        <div style={S.card}>
          <div style={S.cardTitle}>Document Query</div>
          {attachedFile ? (
            <div style={{ marginBottom: 12 }}>
              <div style={{ display: 'inline-flex', alignItems: 'center', gap: 8, padding: '6px 12px', background: '#fff7ed', border: '1px solid #fed7aa', borderRadius: 20 }}>
                <span style={{ fontSize: 11, fontWeight: 700, color: ACCENT }}>Querying against: {attachedFile.name}</span>
                <span style={{ fontSize: 10, color: '#888' }}>({fmtSize(attachedFile.size)})</span>
                <span onClick={() => setAttachedFile(null)} style={{ cursor: 'pointer', color: '#aaa', fontWeight: 700, fontSize: 13, lineHeight: 1 }}>×</span>
              </div>
            </div>
          ) : (
            <label style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', minHeight: 72, border: '2px dashed ' + BORDER, borderRadius: 8, cursor: 'pointer', color: '#9ca3af', fontSize: 12, gap: 4, padding: 12, textAlign: 'center', marginBottom: 12 }}>
              <span>Attach a document to query against it directly</span>
              <span style={{ fontSize: 10, color: '#c0c0c0' }}>PDF, DOCX, TXT</span>
              <input type="file" accept=".pdf,.docx,.txt" onChange={handleAttach} style={{ display: 'none' }} />
            </label>
          )}
          <div style={{ maxHeight: 400, overflowY: 'auto', marginBottom: 10, border: chatHistory.length > 0 ? '1px solid ' + BORDER : 'none', borderRadius: 8, padding: chatHistory.length > 0 ? 10 : 0 }}>
            {chatHistory.length === 0 && (
              <div style={{ padding: '12px 0', textAlign: 'center', color: '#aaa', fontSize: 12 }}>Ask a question about your documents...</div>
            )}
            {chatHistory.map((msg, i) => (
              <div key={i} style={{ marginBottom: 8, display: 'flex', justifyContent: msg.role === 'user' ? 'flex-end' : 'flex-start' }}>
                <div style={{ padding: '8px 12px', borderRadius: 10, maxWidth: '80%', background: msg.role === 'user' ? ACCENT : '#f0f0f0', color: msg.role === 'user' ? WHITE : NAVY, fontSize: 12, lineHeight: 1.6, whiteSpace: 'pre-wrap' }}>
                  {msg.content}
                </div>
              </div>
            ))}
            {loading && (
              <div style={{ display: 'flex', justifyContent: 'flex-start', marginBottom: 8 }}>
                <div style={{ padding: '8px 12px', borderRadius: 10, background: '#f0f0f0', display: 'flex', alignItems: 'center', gap: 6 }}>
                  <Spinner /><span style={{ fontSize: 11, color: '#888' }}>Searching...</span>
                </div>
              </div>
            )}
            <div ref={chatEndRef} />
          </div>
          <div style={{ display: 'flex', gap: 8 }}>
            <input style={{ ...S.input, flex: 1 }} placeholder="Search across all ingested documents..." value={chatInput}
              onChange={e => setChatInput(e.target.value)} onKeyDown={e => e.key === 'Enter' && !loading && ask()} />
            <button style={{ ...S.btn(), whiteSpace: 'nowrap', opacity: loading ? 0.6 : 1 }} onClick={ask} disabled={loading}>
              {loading ? 'Searching...' : 'Ask'}
            </button>
          </div>
        </div>
        <div style={S.card}>
          <div style={S.cardTitle}>Document Library ({docsLoading ? '...' : docs.length})</div>
          {docsLoading ? <Spinner /> : docs.length === 0 ? <Empty msg="No documents ingested yet" /> :
            docs.map((d, i) => (
              <div key={i} style={{ ...S.row(), padding: '7px 0', borderBottom: '1px solid #f0f0f0', justifyContent: 'space-between' }}>
                <div style={{ ...S.row(), gap: 8 }}>
                  <div>
                    <div style={{ fontSize: 12, fontWeight: 600 }}>{d.name || d.filename}</div>
                    <div style={{ fontSize: 11, color: '#888' }}>{d.type || 'document'}</div>
                  </div>
                </div>
                {d.date && <div style={{ fontSize: 11, color: '#aaa' }}>{d.date}</div>}
              </div>
            ))
          }
        </div>
        <div style={S.card}>
          <div style={{display:'flex',justifyContent:'space-between',alignItems:'center'}}>
            <div>
              <div style={{fontSize:13,fontWeight:700,color:NAVY}}>NDAA Ingestion</div>
              <div style={{fontSize:11,color:'#888'}}>Ingest National Defense Authorization Act documents into the knowledge base</div>
            </div>
            <label style={{...S.btn(),opacity:ndaaLoading?0.6:1,cursor:ndaaLoading?'wait':'pointer'}}>
              {ndaaLoading?'Ingesting...':'Upload NDAA'}
              <input ref={ndaaFileRef} type="file" accept=".pdf,.docx,.txt,.csv" onChange={ingestNdaa} style={{display:'none'}} disabled={ndaaLoading} />
            </label>
          </div>
          {ndaaStatus && <div style={{marginTop:8,fontSize:11,color:ndaaStatus.startsWith('Error')?'#DC2626':'#2F5C1F',padding:'6px 10px',background:ndaaStatus.startsWith('Error')?'#FEF2F2':'#2F5C1F12',borderRadius:6}}>{ndaaStatus}</div>}
        </div>
      </>}

      {mode === 'compare' && <>
        <div style={{display:'flex',gap:16,marginBottom:16}}>
          <div style={{...S.card,flex:1,borderTop:fileA?'3px solid #16a34a':'3px solid '+BORDER,position:'relative'}}>
            <div style={{fontSize:11,fontWeight:700,color:NAVY,marginBottom:8}}>DOCUMENT A</div>
            {fileA ? (
              <div>
                <div style={{fontSize:13,fontWeight:600,color:NAVY}}>{fileA.name}</div>
                <div style={{fontSize:10,color:'#888',marginTop:2}}>{(fileA.size/1024).toFixed(1)} KB</div>
                <button style={{...S.btn('secondary',true),marginTop:8,fontSize:10}} onClick={()=>setFileA(null)}>Remove</button>
              </div>
            ) : (
              <label style={{display:'flex',flexDirection:'column',alignItems:'center',justifyContent:'center',minHeight:120,border:'2px dashed '+BORDER,borderRadius:8,cursor:'pointer',color:'#9ca3af',fontSize:12,gap:8,padding:16,textAlign:'center'}}>
                <span style={{fontSize:28}}>A</span>
                <span>Drop or click to upload Document A</span>
                <span style={{fontSize:10,color:'#c0c0c0'}}>PDF, Word, Excel, PPT, TXT</span>
                <input type='file' accept='.pdf,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.txt' onChange={handleFile(setFileA)} style={{display:'none'}} />
              </label>
            )}
          </div>
          <div style={{...S.card,flex:1,borderTop:fileB?'3px solid #1a7a3a':'3px solid '+BORDER,position:'relative'}}>
            <div style={{fontSize:11,fontWeight:700,color:NAVY,marginBottom:8}}>DOCUMENT B</div>
            {fileB ? (
              <div>
                <div style={{fontSize:13,fontWeight:600,color:NAVY}}>{fileB.name}</div>
                <div style={{fontSize:10,color:'#888',marginTop:2}}>{(fileB.size/1024).toFixed(1)} KB</div>
                <button style={{...S.btn('secondary',true),marginTop:8,fontSize:10}} onClick={()=>setFileB(null)}>Remove</button>
              </div>
            ) : (
              <label style={{display:'flex',flexDirection:'column',alignItems:'center',justifyContent:'center',minHeight:120,border:'2px dashed '+BORDER,borderRadius:8,cursor:'pointer',color:'#9ca3af',fontSize:12,gap:8,padding:16,textAlign:'center'}}>
                <span style={{fontSize:28}}>B</span>
                <span>Drop or click to upload Document B</span>
                <span style={{fontSize:10,color:'#c0c0c0'}}>PDF, Word, Excel, PPT, TXT</span>
                <input type='file' accept='.pdf,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.txt' onChange={handleFile(setFileB)} style={{display:'none'}} />
              </label>
            )}
          </div>
        </div>
        <div style={{display:'flex',gap:12,alignItems:'center',marginBottom:16}}>
          <button style={S.btn()} onClick={runCompare} disabled={cmpRunning || !fileA || !fileB}>
            {cmpRunning ? uploadStatus || 'Processing...' : 'Compare Documents'}
          </button>
          {cmpRunning && <Spinner />}
          <div style={{fontSize:11,color:'#888'}}>Uploads both documents, ingests to knowledge base, then runs AI-powered comparison (30-90s)</div>
        </div>

        {cmpResult && cmpResult.error && <Alert msg={cmpResult.error} />}

        {cmp && <>
          <div style={{display:'flex',gap:12,marginBottom:0}}>
            <div style={{...S.card,flex:1,borderTop:'3px solid '+ACCENT}}>
              <div style={{fontSize:11,fontWeight:700,color:ACCENT,marginBottom:6}}>DOCUMENT A: {cmpResult.doc_a_id}</div>
              <div style={{fontSize:12,lineHeight:1.6}}>{cmp.summary_a}</div>
              <div style={{fontSize:10,color:'#888',marginTop:6}}>{cmpResult.chunks_a} chunks analyzed</div>
            </div>
            <div style={{...S.card,flex:1,borderTop:'3px solid #1a7a3a'}}>
              <div style={{fontSize:11,fontWeight:700,color:'#1a7a3a',marginBottom:6}}>DOCUMENT B: {cmpResult.doc_b_id}</div>
              <div style={{fontSize:12,lineHeight:1.6}}>{cmp.summary_b}</div>
              <div style={{fontSize:10,color:'#888',marginTop:6}}>{cmpResult.chunks_b} chunks analyzed</div>
            </div>
          </div>

          {cmp.key_differences && cmp.key_differences.length > 0 && (
            <div style={{...S.card,borderLeft:'3px solid #e65100'}}>
              <div style={S.cardTitle}>Key Differences ({cmp.key_differences.length})</div>
              <table style={{width:'100%',borderCollapse:'collapse',fontSize:12}}>
                <thead><tr><th style={{...S.th,width:'15%'}}>Category</th><th style={{...S.th,width:'42%'}}>Doc A</th><th style={{...S.th,width:'43%'}}>Doc B</th></tr></thead>
                <tbody>{cmp.key_differences.map((d,i) => (
                  <tr key={i} style={{borderBottom:'1px solid #f0f0f0'}}>
                    <td style={{...S.td,fontWeight:700,color:NAVY}}>{CATS[d.category]||d.category}</td>
                    <td style={{...S.td,background:'#fff8f0'}}>{d.doc_a}</td>
                    <td style={{...S.td,background:'#f0f8ff'}}>{d.doc_b}</td>
                  </tr>
                ))}</tbody>
              </table>
            </div>
          )}

          {cmp.similarities && cmp.similarities.length > 0 && (
            <div style={{...S.card,borderLeft:'3px solid #2e7d32'}}>
              <div style={S.cardTitle}>Similarities ({cmp.similarities.length})</div>
              {cmp.similarities.map((s,i) => <div key={i} style={{fontSize:12,padding:'4px 0',borderBottom:'1px solid #f5f5f5'}}>{s}</div>)}
            </div>
          )}

          <div style={{display:'flex',gap:12}}>
            {cmp.additions_in_b && cmp.additions_in_b.length > 0 && (
              <div style={{...S.card,flex:1,borderLeft:'3px solid #1565c0'}}>
                <div style={S.cardTitle}>Additions in Doc B ({cmp.additions_in_b.length})</div>
                {cmp.additions_in_b.map((a,i) => <div key={i} style={{fontSize:12,padding:'4px 0',color:'#1565c0'}}>+ {a}</div>)}
              </div>
            )}
            {cmp.removals_from_a && cmp.removals_from_a.length > 0 && (
              <div style={{...S.card,flex:1,borderLeft:'3px solid #c62828'}}>
                <div style={S.cardTitle}>Removals from Doc A ({cmp.removals_from_a.length})</div>
                {cmp.removals_from_a.map((r,i) => <div key={i} style={{fontSize:12,padding:'4px 0',color:'#c62828'}}>- {r}</div>)}
              </div>
            )}
          </div>

          {cmp.risk_flags && cmp.risk_flags.length > 0 && (
            <div style={{...S.card,borderLeft:'3px solid #ff6f00',background:'#fffde7'}}>
              <div style={S.cardTitle}>Risk Flags ({cmp.risk_flags.length})</div>
              {cmp.risk_flags.map((r,i) => <div key={i} style={{fontSize:12,padding:'4px 0',color:'#e65100'}}>{r}</div>)}
            </div>
          )}

          {cmp.recommendation && (
            <div style={{...S.card,borderLeft:'3px solid '+ACCENT,background:'#f0f7ff'}}>
              <div style={S.cardTitle}>Recommendation</div>
              <div style={{fontSize:12,lineHeight:1.7}}>{cmp.recommendation}</div>
            </div>
          )}
        </>}
      </>}
    </div>
  );
}
export default DocRAG;