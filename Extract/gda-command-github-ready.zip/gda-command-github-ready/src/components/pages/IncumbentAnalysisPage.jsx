import { saveAction, ActionHistory } from '../../lib/gda';
import React, { useState, useEffect } from 'react';
const N8N='/api', AUTH={'Content-Type':'application/json'}, ACCENT='#D14A2A', NAVY='#1a2744', WHITE='#ffffff', BORDER='#e0e0e0';
const api={post:async(p,b={})=>{const r=await fetch(N8N+'/'+p,{method:'POST',headers:AUTH,body:JSON.stringify(b)});if(!r.ok)throw new Error(r.status);const t=await r.text();return t.trim()?JSON.parse(t):{}}};
const S={card:{background:WHITE,border:'1px solid '+BORDER,borderRadius:8,padding:'16px 20px',marginBottom:14},th:{padding:'8px 12px',textAlign:'left',fontSize:10,fontWeight:700,color:'#777',letterSpacing:'0.4px',textTransform:'uppercase',borderBottom:'1px solid '+BORDER,background:'#fafafa'},td:{padding:'9px 12px',borderBottom:'1px solid #f0f0f0',fontSize:12},btn:(v='primary')=>({padding:'8px 16px',borderRadius:6,border:'none',cursor:'pointer',fontSize:12,fontWeight:600,background:v==='primary'?ACCENT:'#eee',color:v==='primary'?'#fff':NAVY}),badge:(c='gray')=>({display:'inline-block',padding:'2px 8px',borderRadius:10,fontSize:10,fontWeight:600,background:c==='green'?'#2F5C1F15':c==='red'?'#ffebe6':c==='blue'?'#e6f0ff':'#f4f5f7',color:c==='green'?'#2F5C1F':c==='red'?'#bf2600':c==='blue'?'#32448A':'#555'}),input:{width:'100%',padding:'8px 10px',border:'1px solid '+BORDER,borderRadius:6,fontSize:12,outline:'none',boxSizing:'border-box'}};

export default function IncumbentAnalysis() {
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);
  const [form, setForm] = useState({contract_number:'',vendor_name:'',agency:''});

  const analyze = async () => {
    setLoading(true);
    try {
      const r = await api.post('gda-incumbent-analysis',{auth_key:'gda-api-2026-f584dae2',action:'analyze',...form});
      setResult(r); saveAction("incumbent","analyze",form.contract||"Incumbent Analysis",form,r);
    } catch(e) { setResult({error:e.message}); }
    setLoading(false);
  };

  return React.createElement('div',null,
    React.createElement('div',{style:{fontSize:20,fontWeight:700,color:NAVY,marginBottom:4}},'Incumbent Analysis'),
    React.createElement('div',{style:{fontSize:12,color:'#666',marginBottom:18}},'Analyze incumbent contractors to identify weaknesses and displacement opportunities'),
    React.createElement('div',{style:S.card},
      React.createElement('div',{style:{display:'grid',gridTemplateColumns:'1fr 1fr 1fr auto',gap:10,alignItems:'end'}},
        React.createElement('div',null,React.createElement('label',{style:{fontSize:10,color:'#777',display:'block',marginBottom:2}},'Contract Number'),
          React.createElement('input',{style:S.input,value:form.contract_number,onChange:e=>setForm({...form,contract_number:e.target.value}),placeholder:'W15P7T19D0206'})),
        React.createElement('div',null,React.createElement('label',{style:{fontSize:10,color:'#777',display:'block',marginBottom:2}},'Incumbent Vendor'),
          React.createElement('input',{style:S.input,value:form.vendor_name,onChange:e=>setForm({...form,vendor_name:e.target.value}),placeholder:'OST Inc.'})),
        React.createElement('div',null,React.createElement('label',{style:{fontSize:10,color:'#777',display:'block',marginBottom:2}},'Agency'),
          React.createElement('input',{style:S.input,value:form.agency,onChange:e=>setForm({...form,agency:e.target.value}),placeholder:'PEO STRI'})),
        React.createElement('button',{onClick:analyze,style:S.btn(),disabled:loading},loading?'Analyzing...':'Analyze Incumbent')
      )
    ),
    result&&!result.error&&React.createElement('div',{style:S.card},
      React.createElement('div',{style:{fontSize:13,fontWeight:700,color:NAVY,marginBottom:10}},'Analysis Results'),
      React.createElement('pre',{style:{fontSize:12,color:'#444',whiteSpace:'pre-wrap',lineHeight:1.6}},JSON.stringify(result,null,2))
    ),
    result&&result.error&&React.createElement('div',{style:{...S.card,borderLeft:'3px solid #e53935',background:'#ffebe6'}},
      React.createElement('div',{style:{color:'#bf2600',fontSize:12}},'Error: '+result.error)
    )
  );
}
