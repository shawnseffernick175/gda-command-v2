import React, { useState, useEffect, useCallback, useRef, useMemo } from 'react';
import { ACCENT, NAVY, BG, WHITE, BORDER, FONT, N8N, AUTH, api, S, css, gdaNav, NAV_ITEMS, Spinner, Empty, Alert, PageHeader , saveAction, ActionHistory } from '../../lib/gda';
function renderMarkdown(text) {
  if (!text) return '';
  if (typeof text === 'string' && text.indexOf(' | ') !== -1 && text.split(' | ').length > 2) {
    var pipeItems = text.split(' | ').map(function(item) { return item.trim(); }).filter(function(item) { return item.length > 0; });
    return React.createElement('div', { style: { margin: '4px 0' } },
      pipeItems.map(function(item, pi) {
        return React.createElement('div', { key: pi, style: { display: 'flex', gap: 6, marginBottom: 4, fontSize: 13, lineHeight: 1.5 } },
          React.createElement('span', { style: { color: '#D14A2A', fontWeight: 700, flexShrink: 0 } }, '>'),
          React.createElement('span', null, item)
        );
      })
    );
  }
  function parseInline(line, lineIdx) {
    var parts = [];
    var regex = /\*\*(.+?)\*\*/g;
    var lastIndex = 0;
    var match;
    var cleaned = line;
    while ((match = regex.exec(cleaned)) !== null) {
      if (match.index > lastIndex) parts.push(cleaned.slice(lastIndex, match.index));
      parts.push(React.createElement('strong', { key: 'b' + lineIdx + '-' + match.index, style: { color: '#1B2A4A' } }, match[1]));
      lastIndex = regex.lastIndex;
    }
    if (lastIndex < cleaned.length) parts.push(cleaned.slice(lastIndex));
    if (parts.length === 0) parts.push(line);
    return parts;
  }
  return text.split('\n').map(function(line, i) {
    var trimmed = line.trim();
    if (!trimmed) return React.createElement('div', { key: 'ln' + i, style: { height: 8 } });
    if (trimmed.startsWith('### ')) {
      return React.createElement('div', { key: 'ln' + i, style: { fontSize: 14, fontWeight: 700, color: '#1B2A4A', marginTop: 14, marginBottom: 4 } }, parseInline(trimmed.substring(4), i));
    }
    if (trimmed.startsWith('## ')) {
      return React.createElement('div', { key: 'ln' + i, style: { fontSize: 15, fontWeight: 700, color: '#1B2A4A', marginTop: 16, marginBottom: 6, borderBottom: '1px solid #E8ECF1', paddingBottom: 4 } }, parseInline(trimmed.substring(3), i));
    }
    if (trimmed.startsWith('# ')) {
      return React.createElement('div', { key: 'ln' + i, style: { fontSize: 17, fontWeight: 700, color: '#1B2A4A', marginTop: 18, marginBottom: 8 } }, parseInline(trimmed.substring(2), i));
    }
    if (trimmed.startsWith('- ') || trimmed.startsWith('* ')) {
      var bulletText = trimmed.startsWith('- ') ? trimmed.substring(2) : trimmed.substring(2);
      return React.createElement('div', { key: 'ln' + i, style: { display: 'flex', gap: 6, paddingLeft: 8, marginBottom: 4 } },
        React.createElement('span', { style: { color: '#D14A2A', fontWeight: 700, flexShrink: 0 } }, '>'),
        React.createElement('span', { style: { fontSize: 13, lineHeight: 1.5 } }, parseInline(bulletText, i))
      );
    }
    if (/^\d+\.\s/.test(trimmed)) {
      var numMatch = trimmed.match(/^(\d+)\.\s(.*)$/);
      if (numMatch) {
        return React.createElement('div', { key: 'ln' + i, style: { display: 'flex', gap: 6, paddingLeft: 8, marginBottom: 4 } },
          React.createElement('span', { style: { color: '#D14A2A', fontWeight: 700, flexShrink: 0, minWidth: 18 } }, numMatch[1] + '.'),
          React.createElement('span', { style: { fontSize: 13, lineHeight: 1.5 } }, parseInline(numMatch[2], i))
        );
      }
    }
    if (trimmed.startsWith('**') && trimmed.endsWith('**')) {
      return React.createElement('div', { key: 'ln' + i, style: { fontWeight: 700, marginTop: 12, marginBottom: 4, color: '#1B2A4A', fontSize: 14 } }, parseInline(trimmed, i));
    }
    if (trimmed.startsWith('---') || trimmed.startsWith('___') || trimmed.startsWith('***')) {
      return React.createElement('hr', { key: 'ln' + i, style: { border: 'none', borderTop: '1px solid #E8ECF1', margin: '12px 0' } });
    }
    return React.createElement('div', { key: 'ln' + i, style: { marginBottom: 2, fontSize: 13, lineHeight: 1.5 } }, parseInline(trimmed, i));
  });
}


function OodaLoop() {
  const [target, setTarget] = useState('');
  const [targetType, setTargetType] = useState('Agency');
  const [loading, setLoading] = useState(false);
  const [loadStep, setLoadStep] = useState(0);
  const loadRef = useRef(null);
  const [results, setResults] = useState(null);
  const [error, setError] = useState('');
  const [phase, setPhase] = useState('observe');
  const [userDecision, setUserDecision] = useState(null);
  const [showHistory, setShowHistory] = useState(false);
  const [historyData, setHistoryData] = useState([]);
  const [histLoading, setHistLoading] = useState(false);
  const [chatInput, setChatInput] = useState('');
  const [chatReply, setChatReply] = useState('');
  const [chatLoading, setChatLoading] = useState(false);
  const [notes, setNotes] = useState('');
  const [toast, setToast] = useState('');
  const [pushedItems, setPushedItems] = useState({});
  const [oodaKpiDetail, setOodaKpiDetail] = useState(null);

  const LOAD_STEPS = ['Observing...','Orienting...','Deciding...','Acting...'];
  const QUICK = ['SOCOM','TRADOC','Leidos','Booz Allen Hamilton'];

  useEffect(function() {
    if (gdaNav.oodaTarget) {
      var t = gdaNav.oodaTarget;
      setTarget(t.name || '');
      if (t.type) setTargetType(t.type);
      gdaNav.oodaTarget = null;
    }
  }, []);
  const TYPE_OPTIONS = ['Agency','Opportunity','Competitor'];
  const PHASE_COLORS = {observe:'#D14A2A',orient:'#32448A',decide:'#DC2626',act:'#2F5C1F'};
  const PHASE_IDS = ['observe','orient','decide','act'];

  const showToast = (msg) => { setToast(msg); setTimeout(() => setToast(''), 3000); };

  // Auto-run from Launchpad
  useEffect(() => {
    if (window._gdaOodaTarget && window._gdaOodaTarget.auto_run) {
      var t = window._gdaOodaTarget;
      window._gdaOodaTarget = null;
      setTarget(t.target || '');
      setTargetType(t.target_type || 'opportunity');
      // Delay to let state settle, then trigger run
      setTimeout(() => {
        if (t.target) {
          setLoading(true); setLoadStep(0); setResults(null); setError('');
          var s = 0;
          loadRef.current = setInterval(() => { s = Math.min(s+1,3); setLoadStep(s); }, 7000);
          api.post('gda-ooda', {target: t.target, target_type: t.target_type || 'opportunity'}, {signal: AbortSignal.timeout(60000)}).then(d => {
            clearInterval(loadRef.current);
            if (!d || d.error) { setError((d && d.message) || 'Analysis failed'); } else { setResults(d); saveAction('ooda','analysis',t.target||'OODA Analysis',{target:t.target},d); api.post('gda-data-learn', {event: 'ooda_completed', data_type: 'ooda_result', source: 'ooda-loop-auto', content: JSON.stringify({target: t.target, summary: (d.observe_summary || '').substring(0, 500)})}).catch(()=>{}); }
            setLoading(false);
          }).catch(e => { clearInterval(loadRef.current); setError(e.name==='TimeoutError' ? 'Timed out' : e.message); setLoading(false); });
        }
      }, 200);
    }
  }, []);

  const runOODA = async () => {
    if (!target.trim()) return;
    setLoading(true); setLoadStep(0); setResults(null); setError(''); setUserDecision(null);
    let s = 0;
    loadRef.current = setInterval(() => { s = Math.min(s+1,3); setLoadStep(s); }, 7000);
    try {
      const d = await api.post('gda-ooda', {target: target.trim(), target_type: targetType}, {signal: AbortSignal.timeout(60000)});
      clearInterval(loadRef.current);
      if (!d || d.error) { setError((d && d.message) || 'Analysis failed'); setLoading(false); return; }
      setResults(d); saveAction("ooda","analysis","Manual OODA",{},d);
      // Save OODA result to data-learn for history
      api.post('gda-data-learn', {event: 'ooda_completed', data_type: 'ooda_result', source: 'ooda-loop', content: JSON.stringify({target: target.trim(), target_type: targetType, summary: (d.observe_summary || d.summary || '').substring(0, 500), timestamp: new Date().toISOString()})}).catch(function(){});
    } catch(e) {
      clearInterval(loadRef.current);
      setError(e.name==='TimeoutError' ? 'Timed out (60s). Try again.' : 'Error: '+e.message);
    }
    setLoading(false);
  };

  const openHistory = async () => {
    setShowHistory(true); setHistLoading(true);
    try {
      const d = await api.post('gda-ooda', {action:'history'}, {signal: AbortSignal.timeout(15000)});
      var items = d && (d.loops || d.history || d.data) || [];
      setHistoryData(Array.isArray(items) ? items : []);
    } catch(e) {
      setHistoryData([]);
    }
    setHistLoading(false);
  };

  const loadFromHistory = (h) => {
    setResults(h); setUserDecision(null); setPhase('observe'); setShowHistory(false);
    setTarget(h.target || '');
  };

  const sendChat = async () => {
    if (!chatInput.trim()) return;
    setChatLoading(true); setChatReply('');
    try {
      var aiContext = '';
      if (target) aiContext += 'Current OODA target: ' + target + '. ';
      if (targetType) aiContext += 'Analysis type: ' + targetType + '. ';
      if (results) { var _rs = typeof results === 'string' ? results : JSON.stringify(results); aiContext += 'Latest analysis result: ' + _rs.slice(0, 500) + '... '; }
      var messageWithContext = aiContext + '\nUser question: ' + chatInput;
      const d = await api.post('gda-chat-v2', {message: messageWithContext, session_id: 'ooda_'+Date.now()});
      setChatReply(d && (d.Summary||d.summary||d.response||d.output) || JSON.stringify(d));
    } catch(e) { setChatReply('Error: '+e.message); }
    setChatLoading(false);
  };

  const sendTeamChat = async (team) => {
    const rec = userDecision || (results && results.decide_recommendation) || 'pursue';
    const msg = team==='red'
      ? 'Acting as Red Team analyst, argue AGAINST the decision to '+rec+' on '+target+'. Challenge assumptions and identify risks.'
      : 'Acting as Blue Team advocate, argue FOR the decision to '+rec+' on '+target+'. Highlight strengths and opportunities.';
    setChatInput(msg); setChatLoading(true); setChatReply('');
    try {
      const d = await api.post('gda-chat-v2', {message:msg, session_id:'ooda_'+team+'_'+Date.now()});
      setChatReply(d && (d.Summary||d.summary||d.response||d.output) || JSON.stringify(d));
    } catch(e) { setChatReply('Error: '+e.message); }
    setChatLoading(false);
  };

  const pushActions = async () => {
    if (!results) return;
    const all = [...(results.act_immediate||[]), ...(results.act_capture||[]), ...(results.act_proposal||[])];
    try {
      for (var _pi = 0; _pi < all.length; _pi++) {
        var _a = all[_pi];
        var _text = typeof _a === 'string' ? _a : (_a.action || _a.text || JSON.stringify(_a));
        await api.post('gda-action-items', { action:'create', item:_text, title:_text, status:'Open', priority:'high', source_meeting:'OODA Loop Analysis', owner:getOwner(_text), source:'OODA: '+target});
      }
      showToast('Pushed '+all.length+' items to Action Items Tracker');
      var newPushed = Object.assign({}, pushedItems);
      all.forEach(function(_, idx) { newPushed['imm_'+idx] = true; newPushed['cap_'+idx] = true; newPushed['prop_'+idx] = true; });
      setPushedItems(newPushed);
    } catch(e) { showToast('Push failed: '+e.message); }
  };

  const getOwner = (text) => {
    const t = (text||'').toLowerCase();
    if (/meeting|relationship|engagement|outreach/.test(t)) return 'BD Lead';
    if (/teaming|partner|evaluate|assessment/.test(t)) return 'Capture';
    if (/facility|cleared|clearance|identify/.test(t)) return 'Operations';
    if (/proposal|submit|draft|write|response/.test(t)) return 'Proposals';
    return 'BD Lead';
  };
  const getPriority = (text, idx) => {
    const t = (text||'').toLowerCase();
    if (/critical|urgent|immediate|asap/.test(t)||idx===0) return 'HIGH';
    if (/monitor|watch|low/.test(t)) return 'LOW';
    return 'MED';
  };

  const rawConf = results ? (results.confidence_score||0) : 0;
  const conf = rawConf > 10 ? (rawConf/10).toFixed(1) : rawConf;
  const wp = results ? (results.orient_win_probability||'') : '';
  const wpColor = /HIGH/i.test(wp) ? '#2F5C1F' : /LOW/i.test(wp) ? '#DC2626' : '#EAB308';
  const aiRec = results ? (results.decide_recommendation||results.recommendation||'HOLD') : '';
  const activeRec = (userDecision || aiRec).toUpperCase();
  const recColor = /BID|PURSUE/.test(activeRec) ? '#2F5C1F' : /NO.?BID|NO.?GO/.test(activeRec) ? '#DC2626' : /PARTNER/.test(activeRec) ? '#32448A' : '#EAB308';

  const nodes = [
    {id:'observe', label:'OBSERVE', x:150, y:40,  color:'#D14A2A', count: results ? (results.observe_intel_count||0) : 0},
    {id:'orient',  label:'ORIENT',  x:260, y:150, color:'#32448A', count: results ? (results.orient_capability_gaps||[]).length : 0},
    {id:'decide',  label:'DECIDE',  x:150, y:260, color:'#DC2626', count: results ? (results.decide_rationale||[]).length : 0},
    {id:'act',     label:'ACT',     x:40,  y:150, color:'#2F5C1F', count: results ? ((results.act_immediate||[]).length+(results.act_capture||[]).length) : 0},
  ];
  const arcs = [
    {x1:167, y1:57,  cx:260, cy:40,  x2:243, y2:133},
    {x1:243, y1:167, cx:260, cy:260, x2:167, y2:243},
    {x1:133, y1:243, cx:40,  cy:260, x2:57,  y2:167},
    {x1:57,  y1:133, cx:40,  cy:40,  x2:133, y2:57},
  ];

  const oss = {
    card: {background:'#fff', border:'1px solid #E8ECF1', borderRadius:10, padding:16, marginBottom:12},
    secTitle: (c) => ({fontSize:11, fontWeight:700, color:c||'#1B2A4A', textTransform:'uppercase', letterSpacing:'1px', marginBottom:8}),
    orangeDot: {width:8, height:8, borderRadius:'50%', background:'#C65D21', flexShrink:0, marginTop:6},
    priTag: (p) => ({padding:'2px 8px', borderRadius:10, fontSize:10, fontWeight:600, color:'#fff', background:p==='HIGH'?'#DC2626':p==='LOW'?'#2F5C1F':'#EAB308'}),
    ownerTag: {padding:'2px 8px', borderRadius:10, background:'#EFF6FF', color:'#32448A', fontSize:10, fontWeight:600, whiteSpace:'nowrap'},
    tabBtn: (active, color) => ({padding:'8px 18px', border:'1px solid '+(active?color:'#E8ECF1'), borderRadius:6, background:active?color:'#fff', color:active?'#fff':'#1B2A4A', fontSize:13, fontWeight:600, cursor:'pointer'}),
    pill: (active, color) => ({padding:'6px 14px', borderRadius:20, fontSize:12, fontWeight:600, cursor:'pointer', border:'1px solid '+color, background:active?color:'transparent', color:active?'#fff':color}) };

  const renderObserve = () => {
    if (!results) return <div style={{color:'#9CA3AF',textAlign:'center',padding:40}}>Run OODA to see observation data</div>;
    const sigs = results.observe_key_signals || [];
    return (
      <div>
        {results.observe_summary && <div style={{...oss.card, borderLeft:'3px solid #D14A2A', marginBottom:12}}><div style={{fontSize:14,color:'#1B2A4A',lineHeight:1.7}}>{renderMarkdown(String(results.observe_summary))}</div></div>}
        <div style={{display:'flex',gap:12,marginBottom:oodaKpiDetail?8:16}}>
          {[{label:'Intel Findings',val:results.observe_intel_count||0,color:'#2F5C1F',key:'intel'},{label:'Active Alerts',val:results.observe_alert_count||0,color:'#D14A2A',key:'alerts'},{label:'News Items',val:results.observe_news_count||0,color:'#32448A',key:'news'}].map((m,i) => (
            <div key={i} style={{flex:1,...oss.card,textAlign:'center',padding:16,marginBottom:0,cursor:'pointer',border:oodaKpiDetail===m.key?'2px solid '+m.color:'1px solid #E8ECF1'}} onClick={function(){setOodaKpiDetail(oodaKpiDetail===m.key?null:m.key);}}>
              <div style={{fontSize:28,fontWeight:700,color:m.color}}>{String(m.val)}</div>
              <div style={{fontSize:12,fontWeight:600,color:'#1B2A4A',marginTop:4}}>{m.label}</div>
              <div style={{fontSize:10,color:'#D14A2A',marginTop:2}}>click for detail →</div>
            </div>
          ))}
        </div>
        {oodaKpiDetail && React.createElement('div', {style:{borderRadius:8,padding:'10px 14px',fontSize:12,lineHeight:1.6,marginBottom:12,background:oodaKpiDetail==='intel'?'#2F5C1F12':oodaKpiDetail==='alerts'?'#B06D3218':'#5091A712',color:'#374151',border:'1px solid '+(oodaKpiDetail==='intel'?'#BBF7D0':oodaKpiDetail==='alerts'?'#FDE68A':'#5091A720')}},
          oodaKpiDetail==='intel' && (String(results.observe_intel_count||0)+' intelligence findings from Tavily news search and GovTribe opportunity alerts. The OODA analysis above incorporates these findings for '+String(results.target||target)+'.'),
          oodaKpiDetail==='alerts' && (String(results.observe_alert_count||0)+' opportunities with response deadlines within the next 7 days requiring immediate capture decisions or proposal actions.'),
          oodaKpiDetail==='news' && (String(results.observe_news_count||0)+' defense industry news items from the last 24 hours analyzed for impact on '+String(results.target||target)+'. Key signals are shown below.')
        )}
        {oodaKpiDetail==='news' && (results.observe_raw?.recent_news || results.observe_news_items || []).length > 0 && (
          <div style={{marginBottom:12}}>
            {(results.observe_raw?.recent_news || results.observe_news_items || []).map((item, idx) => {
              let domain = '';
              try { domain = new URL(item.url).hostname.replace('www.',''); } catch(e) {}
              return (
                <div key={idx} style={{background:'#fff',border:'1px solid #E8ECF1',borderRadius:8,padding:12,marginBottom:8}}>
                  <div style={{fontSize:13,fontWeight:700,color:'#1B2A4A',marginBottom:4}}>{item.title || 'Untitled'}</div>
                  {domain && <div style={{fontSize:11,color:'#6B7280',marginBottom:4}}>{domain}</div>}
                  <div style={{fontSize:12,color:'#374151',lineHeight:1.5,marginBottom:6}}>{(item.content || item.summary || '').slice(0, 200)}{(item.content || item.summary || '').length > 200 ? '...' : ''}</div>
                  {item.url && <div style={{fontSize:11,color:'#D14A2A',fontWeight:600,cursor:'pointer'}} onClick={function(){window.open(item.url,'_blank');}}>Read &#8594;</div>}
                </div>
              );
            })}
          </div>
        )}
        {sigs.length>0 && <>
          <div style={oss.secTitle('#D14A2A')}>KEY SIGNALS — CLICK ANY TO OPEN DETAIL</div>
          {sigs.map((sg,i) => <div key={i} style={{display:'flex',gap:8,alignItems:'flex-start',marginBottom:8}}><div style={oss.orangeDot}/><div style={{fontSize:14,color:'#1B2A4A',lineHeight:1.5}}>{typeof sg==='string'?sg:(sg.text||sg.signal||JSON.stringify(sg))}</div></div>)}
        </>}
      </div>
    );
  };

  const renderOrient = () => {
    if (!results) return <div style={{color:'#9CA3AF',textAlign:'center',padding:40}}>Run OODA first</div>;
    const gaps = results.orient_capability_gaps || [];
    const confBadge = /HIGH/i.test(results.orient_confidence||'') ? '#2F5C1F' : /LOW/i.test(results.orient_confidence||'') ? '#DC2626' : '#EAB308';
    return (
      <div>
        <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:12,marginBottom:12}}>
          <div style={{...oss.card,borderLeft:'3px solid #DC2626',marginBottom:0}}>
            <div style={oss.secTitle('#DC2626')}>THREAT ASSESSMENT</div>
            <div style={{fontSize:13,color:'#1B2A4A',lineHeight:1.6}}>{renderMarkdown(String(results.orient_threat||'No threat data'))}</div>
          </div>
          <div style={{...oss.card,borderLeft:'3px solid #2F5C1F',marginBottom:0}}>
            <div style={oss.secTitle('#2F5C1F')}>OPPORTUNITY ASSESSMENT</div>
            <div style={{fontSize:13,color:'#1B2A4A',lineHeight:1.6}}>{renderMarkdown(String(results.orient_opportunity||'No opportunity data'))}</div>
          </div>
        </div>
        <div style={{...oss.card,marginBottom:12}}>
          <div style={{display:'flex',alignItems:'center',gap:12,flexWrap:'wrap'}}>
            <span style={{padding:'4px 14px',borderRadius:14,fontWeight:700,fontSize:13,background:wpColor+'22',color:wpColor,border:'1px solid '+wpColor+'55'}}>{String(results.orient_win_probability||'N/A')}</span>
            <span style={{fontSize:13,color:'#1B2A4A',lineHeight:1.6,flex:1}}>{String(results.orient_win_rationale||'')}</span>
          </div>
        </div>
        {gaps.length>0 && <div style={{marginBottom:12}}>
          <div style={oss.secTitle('#D14A2A')}>CAPABILITY GAPS</div>
          {gaps.map((g,i) => <div key={i} style={{display:'flex',gap:8,alignItems:'flex-start',marginBottom:8}}><div style={oss.orangeDot}/><div style={{fontSize:13,color:'#1B2A4A'}}>{typeof g==='string'?g:(g.text||JSON.stringify(g))}</div></div>)}
        </div>}
        {results.orient_market_forces && <div style={{...oss.card,background:'#F7F8FA',marginBottom:12}}>
          <div style={oss.secTitle()}>MARKET FORCES</div>
          <div style={{fontSize:13,color:'#555',lineHeight:1.6}}>{renderMarkdown(String(results.orient_market_forces))}</div>
        </div>}
        {results.orient_confidence && <div style={{display:'flex',alignItems:'center',gap:8}}>
          <span style={{fontSize:12,color:'#6B7280'}}>Analysis Confidence:</span>
          <span style={{padding:'3px 10px',borderRadius:12,fontSize:12,fontWeight:600,background:confBadge+'22',color:confBadge,border:'1px solid '+confBadge+'44'}}>{String(results.orient_confidence)}</span>
        </div>}
      </div>
    );
  };

  const DECIDE_PILLS = [
    {label:'Bid',     value:'BID',     color:'#2F5C1F'},
    {label:'No-Bid',  value:'NO-BID',  color:'#DC2626'},
    {label:'Monitor', value:'MONITOR', color:'#EAB308'},
    {label:'Partner', value:'PARTNER', color:'#32448A'},
  ];

  const renderDecide = () => {
    if (!results) return <div style={{color:'#9CA3AF',textAlign:'center',padding:40}}>Run OODA first</div>;
    const aiRecUp = aiRec.toUpperCase();
    const rationale = results.decide_rationale || [];
    const alts = results.decide_alternatives || [];
    const triggers = results.decide_triggers || [];
    return (
      <div>
        <div style={{...oss.card,marginBottom:12}}>
          <div style={{fontSize:24,fontWeight:700,color:'#1B2A4A',marginBottom:12}}>{String(userDecision||results.decide_recommendation||'HOLD')}</div>
          <div style={{display:'flex',gap:8,flexWrap:'wrap',marginBottom:8}}>
            {DECIDE_PILLS.map(p => {
              const isA = activeRec===p.value || (p.value==='BID' && /BID|PURSUE/.test(activeRec));
              return <button key={p.value} onClick={() => setUserDecision(p.value)} style={oss.pill(isA,p.color)}>{p.label}</button>;
            })}
          </div>
          {userDecision && userDecision.toUpperCase()!==aiRecUp && <div style={{fontSize:11,color:'#D14A2A'}}>⚠ Overriding AI recommendation ({aiRec})</div>}
        </div>
        {rationale.length>0 && <div style={{...oss.card,marginBottom:12}}>
          <div style={oss.secTitle()}>TOP REASONS</div>
          {rationale.map((r,i) => <div key={i} style={{fontSize:14,color:'#1B2A4A',padding:'4px 0',borderBottom:'1px solid #f5f5f5',lineHeight:1.5}}><strong>{i+1}.</strong> {typeof r==='string'?r:(r.reason||JSON.stringify(r))}</div>)}
        </div>}
        {alts.length>0 && <div style={{marginBottom:12}}>
          <div style={oss.secTitle()}>ALTERNATIVES</div>
          {alts.map((a,i) => <div key={i} style={{padding:12,background:'#B06D3212',borderRadius:6,marginBottom:6,fontSize:12,color:'#1B2A4A'}}>{typeof a==='string'?a:(a.alternative||JSON.stringify(a))}</div>)}
        </div>}
        {triggers.length>0 && <div>
          <div style={oss.secTitle()}>DECISION TRIGGERS</div>
          {triggers.map((t,i) => <div key={i} style={{display:'flex',gap:8,alignItems:'flex-start',marginBottom:6}}><div style={oss.orangeDot}/><div style={{fontSize:13,color:'#1B2A4A'}}>{typeof t==='string'?t:(t.trigger||JSON.stringify(t))}</div></div>)}
        </div>}
      </div>
    );
  };

  const renderAct = () => {
    if (!results) return <div style={{color:'#9CA3AF',textAlign:'center',padding:40}}>Run OODA first</div>;
    const immediate = results.act_immediate||[];
    const capture = results.act_capture||[];
    const proposal = results.act_proposal||[];
    const watch = results.act_watch||[];
    const renderCards = (items, sectionKey) => items.map((a,i) => {
      const text = typeof a==='string'?a:(a.action||a.text||JSON.stringify(a));
      const due = typeof a==='object'&&a.due ? String(a.due) : '';
      const pri = getPriority(text,i);
      const itemKey = sectionKey + '_' + i;
      const isPushed = !!pushedItems[itemKey];
      return (
        <div key={i} style={{background:'#fff',border:'1px solid #E8ECF1',borderRadius:8,padding:12,marginBottom:8,display:'flex',justifyContent:'space-between',alignItems:'flex-start',gap:8}}>
          <div style={{flex:1}}>
            <div style={{fontSize:14,color:'#1B2A4A',lineHeight:1.5,marginBottom:4}}>{renderMarkdown(text)}</div>
            <div style={{display:'flex',gap:8,alignItems:'center'}}>
              {due && <span style={{fontSize:11,color:'#9CA3AF'}}>Due: {due}</span>}
              <span style={oss.priTag(pri)}>{pri}</span>
            </div>
          </div>
          <div style={{display:'flex',gap:6,alignItems:'center',flexShrink:0}}>
            <span style={oss.ownerTag}>{getOwner(text)}</span>
            <button disabled={isPushed} onClick={function(){api.post('gda-action-items',{ action:'create',item:text,title:text,status:'Open',priority:'high',source_meeting:'OODA Loop Analysis',owner:getOwner(text),source:'OODA: '+target}).then(function(){var u=Object.assign({},pushedItems);u[itemKey]=true;setPushedItems(u);showToast('Pushed to tracker');}).catch(function(e){showToast('Push failed: '+e.message);});}} style={{padding:'4px 10px',fontSize:11,background:isPushed?'#9CA3AF':'#2F5C1F',color:'#fff',border:'none',borderRadius:4,cursor:isPushed?'default':'pointer',fontWeight:600}}>{isPushed?'\u2713 Pushed':'Push'}</button>
          </div>
        </div>
      );
    });
    return (
      <div>
        {immediate.length>0 && <><div style={oss.secTitle('#DC2626')}>IMMEDIATE (0–30 DAYS)</div>{renderCards(immediate,'imm')}</>}
        {capture.length>0 && <><div style={{...oss.secTitle('#D14A2A'),marginTop:12}}>CAPTURE (30–90 DAYS)</div>{renderCards(capture,'cap')}</>}
        {proposal.length>0 && <><div style={{...oss.secTitle('#32448A'),marginTop:12}}>PROPOSAL (90+ DAYS)</div>{renderCards(proposal,'prop')}</>}
        {watch.length>0 && <><div style={{...oss.secTitle('#6B7280'),marginTop:12}}>WATCH ITEMS</div>{watch.map((w,i) => <div key={i} style={{display:'flex',gap:8,marginBottom:6,alignItems:'flex-start'}}><div style={oss.orangeDot}/><div style={{fontSize:13,color:'#1B2A4A'}}>{typeof w==='string'?w:(w.item||JSON.stringify(w))}</div></div>)}</>}
        <button onClick={pushActions} style={{width:'100%',marginTop:16,padding:'12px 0',background:'#C65D21',color:'#fff',border:'none',borderRadius:8,fontSize:14,fontWeight:600,cursor:'pointer',height:44}}>Push All to Tracker</button>
      </div>
    );
  };

  return (
    <div style={{fontFamily:"'Inter','Segoe UI',Arial,sans-serif"}}>
      {/* Header */}
      <div style={{display:'flex',justifyContent:'space-between',alignItems:'flex-start',marginBottom:20,flexWrap:'wrap',gap:12}}>
        <div>
          <div style={{fontSize:24,fontWeight:700,color:'#1B2A4A'}}>OODA Loop Intelligence</div>
          <div style={{fontSize:13,color:'#6B7280',marginTop:4}}>Observe → Orient → Decide → Act — AI-powered capture decision support</div>
        </div>
        <div style={{display:'flex',gap:8}}>
          <button style={{padding:'8px 16px',border:'1px solid #E8ECF1',borderRadius:6,background:'#fff',fontSize:12,fontWeight:600,cursor:'pointer',color:'#1B2A4A'}}>Export Excel</button>
          <button onClick={openHistory} style={{padding:'8px 16px',border:'none',borderRadius:6,background:'#1B2A4A',color:'#fff',fontSize:12,fontWeight:600,cursor:'pointer'}}>Loop History</button>
        </div>
      </div>

      {/* Input Section */}
      <div style={{background:'#fff',border:'1px solid #E8ECF1',borderRadius:10,padding:16,marginBottom:16}}>
        <div style={{display:'flex',gap:10,marginBottom:12,flexWrap:'wrap'}}>
          <input value={target} onChange={e=>setTarget(e.target.value)} onKeyDown={e=>e.key==='Enter'&&runOODA()} placeholder="Enter target agency, program, or competitor..." style={{flex:1,padding:'10px 14px',border:'1px solid #E8ECF1',borderRadius:8,fontSize:14,color:'#1B2A4A',fontFamily:'Inter,sans-serif',minWidth:200}} />
          <select value={targetType} onChange={e=>setTargetType(e.target.value)} style={{padding:'10px 14px',border:'1px solid #E8ECF1',borderRadius:8,fontSize:13,color:'#1B2A4A',background:'#fff',width:160}}>
            {TYPE_OPTIONS.map(t => <option key={t} value={t}>{t}</option>)}
          </select>
          <button onClick={runOODA} disabled={loading} style={{padding:'10px 0',width:140,background:'#C65D21',color:'#fff',border:'none',borderRadius:8,fontSize:14,fontWeight:600,cursor:'pointer',opacity:loading?0.7:1}}>
            {loading ? '⏳ Running...' : '▶ Run OODA'}
          </button>
        </div>
        <div style={{display:'flex',gap:8,flexWrap:'wrap'}}>
          {QUICK.map(q => <button key={q} onClick={()=>setTarget(q)} style={{padding:'6px 16px',borderRadius:20,border:'1px solid #D14A2A',background:'transparent',color:'#D14A2A',fontSize:12,fontWeight:600,cursor:'pointer'}}>{q}</button>)}
        </div>
      </div>

      {error && <div style={{background:'#FEF2F2',border:'1px solid #FCA5A5',borderRadius:8,padding:12,marginBottom:12,color:'#991B1B',fontSize:13}}>{error}</div>}

      {/* Loading progress */}
      {loading && (
        <div style={{background:'#fff',border:'1px solid #E8ECF1',borderRadius:10,padding:'24px 20px',marginBottom:16}}>
          <div style={{display:'flex',alignItems:'center',gap:10,marginBottom:16}}><Spinner /><span style={{fontSize:14,fontWeight:600,color:'#1B2A4A'}}>Analyzing {target}...</span></div>
          {LOAD_STEPS.map((s,i) => (
            <div key={i} style={{display:'flex',alignItems:'center',gap:10,padding:'6px 0',fontSize:13,color:i<loadStep?'#2F5C1F':i===loadStep?PHASE_COLORS[PHASE_IDS[i]]:'#D1D5DB'}}>
              <span style={{fontFamily:'monospace',fontWeight:700}}>{i<loadStep?'✓':i===loadStep?'▶':'○'}</span>
              <span style={{fontWeight:i===loadStep?600:400}}>{s}</span>
            </div>
          ))}
        </div>
      )}

      {/* Summary Banner */}
      {results && !loading && (
        <div style={{background:'#F7F8FA',border:'1px solid #E8ECF1',borderRadius:10,padding:16,marginBottom:16}}>
          <div style={{display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:16,marginBottom:results.summary?12:0}}>
            <div><div style={{fontSize:11,color:'#9CA3AF',textTransform:'uppercase',marginBottom:4}}>Target</div><div style={{fontSize:14,fontWeight:700,color:'#1B2A4A'}}>{String(results.target||target)}</div></div>
            <div><div style={{fontSize:11,color:'#9CA3AF',textTransform:'uppercase',marginBottom:4}}>Recommendation</div><span style={{padding:'4px 12px',borderRadius:14,fontWeight:700,fontSize:13,background:recColor+'22',color:recColor,border:'1px solid '+recColor+'55'}}>{String(userDecision||results.decide_recommendation||'HOLD')}</span></div>
            <div><div style={{fontSize:11,color:'#9CA3AF',textTransform:'uppercase',marginBottom:4}}>Win Probability</div><span style={{fontSize:14,fontWeight:700,color:wpColor}}>{String(results.orient_win_probability||'—')}</span></div>
            <div><div style={{fontSize:11,color:'#9CA3AF',textTransform:'uppercase',marginBottom:4}}>Confidence</div><span style={{fontSize:14,fontWeight:700,color:'#32448A'}}>{String(conf)}/10</span></div>
          </div>
          {results.summary && <div style={{fontSize:14,color:'#333',lineHeight:1.7}}>{renderMarkdown(String(results.summary))}</div>}
          {(function() {
            var recommendation = 'EVALUATE';
            var recBadgeColor = '#D14A2A';
            var resultText = typeof results === 'string' ? results : JSON.stringify(results);
            if (/no.?bid|do not bid|not recommend/i.test(resultText)) { recommendation = 'NO BID'; recBadgeColor = '#DC2626'; }
            else if (/partner|team|subcontract|joint venture/i.test(resultText)) { recommendation = 'PARTNER'; recBadgeColor = '#32448A'; }
            else if (/watch|monitor|pre.?sol/i.test(resultText)) { recommendation = 'WATCH'; recBadgeColor = '#C4960C'; }
            else if (/bid|pursue|go after|capture/i.test(resultText)) { recommendation = 'BID'; recBadgeColor = '#2F5C1F'; }
            return React.createElement('div', { style: { marginTop: 8 } },
              React.createElement('span', { style: { display: 'inline-block', padding: '4px 12px', borderRadius: 4, fontWeight: 700, fontSize: 14, color: '#fff', background: recBadgeColor, marginRight: 8 } }, recommendation),
              recommendation === 'PARTNER' && React.createElement('span', { style: { fontSize: 12, color: '#6B7280', fontStyle: 'italic' } }, 'Suggested partners based on NAICS alignment and past performance will appear when competitive analysis is wired to GovTribe award data.')
            );
          })()}
        </div>
      )}

      {/* Main: Wheel + Tabs */}
      {results && !loading && (
        <div style={{display:'flex',gap:24,marginBottom:16,alignItems:'flex-start',flexWrap:'wrap'}}>
          {/* OODA Wheel */}
          <div style={{flex:'0 0 300px',textAlign:'center'}}>
            <svg viewBox="0 0 300 300" style={{width:300,height:300}}>
              <defs>
                <marker id="oodaArrow" markerWidth="8" markerHeight="6" refX="6" refY="3" orient="auto">
                  <polygon points="0 0, 8 3, 0 6" fill="#CBD5E1" />
                </marker>
              </defs>
              {arcs.map((a,i) => (
                <path key={i} d={'M '+a.x1+' '+a.y1+' Q '+a.cx+' '+a.cy+' '+a.x2+' '+a.y2} fill="none" stroke="#CBD5E1" strokeWidth={1.5} markerEnd="url(#oodaArrow)" />
              ))}
              <text x={150} y={135} textAnchor="middle" fill="#1B2A4A" fontSize={11} fontWeight={700} fontFamily="Inter,sans-serif">{String(results.target||target).substring(0,16)}</text>
              <text x={150} y={150} textAnchor="middle" fill="#32448A" fontSize={10} fontFamily="Inter,sans-serif">{'Score: '+String(conf)+'/10'}</text>
              <text x={150} y={165} textAnchor="middle" fill="#9CA3AF" fontSize={9} fontFamily="Inter,sans-serif">{results.generated_at ? new Date(results.generated_at).toLocaleDateString() : ''}</text>
              {nodes.map(n => {
                const isA = phase===n.id;
                return (
                  <g key={n.id} style={{cursor:'pointer'}} onClick={()=>setPhase(n.id)}>
                    <circle cx={n.x} cy={n.y} r={28} fill={isA?n.color:'#fff'} stroke={n.color} strokeWidth={isA?3:2} />
                    <text x={n.x} y={n.y-3} textAnchor="middle" dominantBaseline="middle" fill={isA?'#fff':n.color} fontSize={9} fontWeight={700} fontFamily="Inter,sans-serif">{n.label}</text>
                    <text x={n.x} y={n.y+11} textAnchor="middle" fill={isA?'rgba(255,255,255,0.8)':n.color+'99'} fontSize={8} fontFamily="Inter,sans-serif">{String(n.count)+' items'}</text>
                  </g>
                );
              })}
            </svg>
            <div style={{fontSize:11,color:'#9CA3AF',fontStyle:'italic',marginTop:4}}>Click a node to expand</div>
          </div>
          {/* Phase Tabs */}
          <div style={{flex:1,minWidth:280}}>
            <div style={{display:'flex',gap:8,marginBottom:12,flexWrap:'wrap'}}>
              {nodes.map(n => (
                <button key={n.id} onClick={()=>setPhase(n.id)} style={{padding:'8px 18px',border:'1px solid '+(phase===n.id?n.color:'#E8ECF1'),borderRadius:6,background:phase===n.id?n.color:'#fff',color:phase===n.id?'#fff':'#1B2A4A',fontSize:13,fontWeight:600,cursor:'pointer'}}>{n.label}</button>
              ))}
            </div>
            <div style={{background:'#fff',border:'1px solid #E8ECF1',borderRadius:10,padding:16,minHeight:300}}>
              {phase==='observe' && renderObserve()}
              {phase==='orient'  && renderOrient()}
              {phase==='decide'  && renderDecide()}
              {phase==='act'     && renderAct()}
            </div>
          </div>
        </div>
      )}

      {/* AI Interaction Panel */}
      <div style={{background:'#fff',border:'1px solid #E8ECF1',borderRadius:10,padding:16,marginBottom:16}}>
        <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:12}}>
          <div style={{fontSize:16,fontWeight:700,color:'#1B2A4A'}}>AI Interaction Panel</div>
          <div style={{display:'flex',gap:8}}>
            <button onClick={()=>sendTeamChat('red')} disabled={!results||chatLoading} style={{padding:'6px 14px',background:'#DC2626',color:'#fff',border:'none',borderRadius:6,fontSize:12,fontWeight:600,cursor:'pointer',opacity:(!results||chatLoading)?0.5:1}}>Red Team</button>
            <button onClick={()=>sendTeamChat('blue')} disabled={!results||chatLoading} style={{padding:'6px 14px',background:'#32448A',color:'#fff',border:'none',borderRadius:6,fontSize:12,fontWeight:600,cursor:'pointer',opacity:(!results||chatLoading)?0.5:1}}>Blue Team</button>
          </div>
        </div>
        <div style={{display:'flex',gap:8,marginBottom:8}}>
          <input value={chatInput} onChange={e=>setChatInput(e.target.value)} onKeyDown={e=>e.key==='Enter'&&sendChat()} placeholder={results?('Ask about '+(results.target||target)+"... e.g., 'What if L3Harris teams with Booz Allen?'"):'Run OODA first...'} style={{flex:1,padding:'10px 14px',border:'1px solid #E8ECF1',borderRadius:8,fontSize:13,fontFamily:'Inter,sans-serif'}} />
          <button onClick={sendChat} disabled={chatLoading||!chatInput.trim()} style={{padding:'10px 20px',background:'#C65D21',color:'#fff',border:'none',borderRadius:8,fontSize:13,fontWeight:600,cursor:'pointer',opacity:(chatLoading||!chatInput.trim())?0.6:1}}>Ask</button>
        </div>
        {chatLoading && <div style={{display:'flex',alignItems:'center',gap:8,padding:'8px 0',fontSize:12,color:'#888'}}><Spinner /><span>Thinking...</span></div>}
        {chatReply && <div style={{padding:'12px 16px',background:'#F7F8FA',borderRadius:8,fontSize:13,color:'#1B2A4A',lineHeight:1.7,marginBottom:8}}>{renderMarkdown(chatReply)}</div>}
        <textarea value={notes} onChange={e=>setNotes(e.target.value)} rows={3} placeholder="Your notes on this OODA analysis..." style={{width:'100%',padding:'10px 14px',border:'1px solid #E8ECF1',borderRadius:8,fontSize:12,fontFamily:'Inter,sans-serif',resize:'vertical',boxSizing:'border-box'}} />
      </div>

      {/* Toast */}
      {toast && <div style={{position:'fixed',bottom:24,right:24,background:'#1B2A4A',color:'#fff',padding:'10px 20px',borderRadius:8,fontSize:13,fontWeight:600,zIndex:9999,boxShadow:'0 4px 12px rgba(0,0,0,0.3)'}}>{toast}</div>}

      {/* History Modal */}
      {showHistory && (
        <div style={{position:'fixed',inset:0,background:'rgba(0,0,0,0.4)',display:'flex',alignItems:'center',justifyContent:'center',zIndex:9000}} onClick={()=>setShowHistory(false)}>
          <div style={{background:'#fff',borderRadius:12,padding:24,width:'100%',maxWidth:600,maxHeight:'80vh',display:'flex',flexDirection:'column',boxShadow:'0 20px 60px rgba(0,0,0,0.2)'}} onClick={e=>e.stopPropagation()}>
            <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:16}}>
              <div style={{fontSize:18,fontWeight:700,color:'#1B2A4A'}}>Loop History</div>
              <button onClick={()=>setShowHistory(false)} style={{background:'none',border:'none',fontSize:22,cursor:'pointer',color:'#6B7280',lineHeight:1}}>×</button>
            </div>
            {histLoading && <div style={{textAlign:'center',padding:40,color:'#9CA3AF'}}>Loading...</div>}
            {!histLoading && historyData.length===0 && <div style={{textAlign:'center',padding:40,color:'#9CA3AF'}}>No loop history found</div>}
            <div style={{overflow:'auto',flex:1}}>
              {historyData.map((h,i) => {
                const rawDec = h.decision||h.decide_recommendation||h.recommendation||'';
                const dec = (() => { if (typeof rawDec!=='string') return String(rawDec||''); try { const p=JSON.parse(rawDec); return String(p.recommendation||p.decide||rawDec); } catch { return String(rawDec); } })();
                const decShort = dec.substring(0,30);
                const dc = /BID|PURSUE/i.test(dec)?'#2F5C1F':/NO.?BID|NO.?GO/i.test(dec)?'#DC2626':'#EAB308';
                const cv = h.confidence_score||h.confidence||0;
                const cn = cv>10?(cv/10).toFixed(1):cv;
                return (
                  <div key={i} onClick={()=>loadFromHistory(h)} style={{display:'flex',justifyContent:'space-between',alignItems:'center',padding:'10px 0',borderBottom:'1px solid #E8ECF1',cursor:'pointer'}}>
                    <div style={{flex:1}}>
                      <div style={{fontSize:14,fontWeight:600,color:'#1B2A4A'}}>{String(h.target||'(unknown)')}</div>
                      <div style={{fontSize:11,color:'#9CA3AF',marginTop:2}}>{String(h.created_at?new Date(h.created_at).toLocaleString():(h.timestamp||h.generated_at||''))}</div>
                    </div>
                    <div style={{display:'flex',gap:8,alignItems:'center'}}>
                      {decShort && <span style={{padding:'2px 10px',borderRadius:12,fontSize:11,fontWeight:600,background:dc+'22',color:dc,border:'1px solid '+dc+'44'}}>{decShort}</span>}
                      <span style={{fontSize:11,color:'#32448A',fontWeight:600}}>{String(cn)}/10</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
export default OodaLoop;