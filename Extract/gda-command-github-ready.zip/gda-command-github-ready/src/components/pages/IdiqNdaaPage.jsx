import React, { useState, useEffect, useCallback, useRef, useMemo } from 'react';
import { ACCENT, NAVY, BG, WHITE, BORDER, FONT, N8N, AUTH, api, S, css, gdaNav, NAV_ITEMS, Spinner, Empty, Alert, PageHeader } from '../../lib/gda';

function IdiqOnRamp() {
  const [idiqTab, setIdiqTab] = useState('tracker');
  const [idiqs, setIdiqs] = useState([
    // Source: MDA SHIELD IDIQ HQ085925RE001 — verify ceiling annually
    {id:1, name:'MDA SHIELD', contract:'HQ085925RE001', agency:'Missile Defense Agency', ceiling:'$2.4B', pop:'2025-2030', awardees:12, status:'Monitoring', onramp:'No Open Season', notes:'FAR 16.5 trigger: Mar 2030'},
  ]);
  const [showAddIdiq, setShowAddIdiq] = useState(false);
  const [newIdiq, setNewIdiq] = useState({name:'',contract:'',agency:'',ceiling:'',pop:'',awardees:'',notes:''});
  const [scanResults, setScanResults] = useState([]);
  const [scanLoading, setScanLoading] = useState(false);
  const [ndaaFiles, setNdaaFiles] = useState([]);
  const [ndaaResults, setNdaaResults] = useState(null);
  const [ndaaLoading, setNdaaLoading] = useState(false);
  const [ndaaDragOver, setNdaaDragOver] = useState(false);
  const [taskOrders, setTaskOrders] = useState([]);
  const [toLoading, setToLoading] = useState(false);
  const [searchResults, setSearchResults] = useState([]);
  const [searchLoading, setSearchLoading] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  const TABS = [{id:'tracker',label:'IDIQ Tracker'},{id:'scanner',label:'On-Ramp Scanner'},{id:'ndaa',label:'NDAA Ingestion'},{id:'task-orders',label:'Task Orders'},{id:'search',label:'Search'}];

  const idiqWaitForLib = (key, ms=5000) => new Promise((resolve) => {
    if (window[key]) return resolve(window[key]);
    const start = Date.now();
    const iv = setInterval(() => {
      if (window[key]) { clearInterval(iv); resolve(window[key]); }
      else if (Date.now() - start > ms) { clearInterval(iv); resolve(null); }
    }, 100);
  });

  const idiqExtractText = async (file) => {
    const name = file.name.toLowerCase();
    if (name.endsWith('.txt') || name.endsWith('.csv')) return await file.text();
    if (name.endsWith('.pdf')) {
      try {
        const lib = await idiqWaitForLib('pdfjsLib');
        if (!lib) return '[PDF parser not loaded]';
        const buf = await file.arrayBuffer();
        const pdf = await lib.getDocument({data:buf}).promise;
        let txt = '';
        for (let i = 1; i <= pdf.numPages; i++) { const pg = await pdf.getPage(i); const tc = await pg.getTextContent(); txt += tc.items.map(it => it.str).join(' ') + '\n'; }
        return txt || '[PDF empty]';
      } catch(e) { return '[PDF failed: ' + e.message + ']'; }
    }
    if (name.endsWith('.docx') || name.endsWith('.doc')) {
      try {
        const lib = await idiqWaitForLib('mammoth');
        if (!lib) return '[Word parser not loaded]';
        const buf = await file.arrayBuffer();
        return (await lib.extractRawText({arrayBuffer:buf})).value || '[Empty]';
      } catch(e) { return '[Failed: ' + e.message + ']'; }
    }
    return await file.text();
  };

  const addNdaaFiles = (nf) => {
    Array.from(nf).forEach(async (file) => {
      const extracted = await idiqExtractText(file);
      setNdaaFiles(p => p.find(x => x.name === file.name) ? p : [...p, {name: file.name, content: extracted, size: file.size}]);
    });
  };

  const runOnRampScan = async () => {
    setScanLoading(true); setScanResults([]);
    try {
      const names = idiqs.map(i => i.name + ' ' + i.contract).join(', ');
      const d = await api.post('gda-chat-v2', {message: 'Search SAM.gov and federal procurement news for on-ramp announcements, open season notices, and fair opportunity notices for these IDIQs: ' + names + '. Also check for any IDIQ approaching the FAR 16.5 five-year threshold. Return JSON array: [{idiq, alert_type, title, url, deadline, detail}]. alert_type must be: OPEN_SEASON, FIVE_YEAR_TRIGGER, NEW_TO, OFF_RAMP, or INFO.'}, {signal: AbortSignal.timeout(90000)});
      const raw = d.response || d.output || JSON.stringify(d);
      const m = raw.match(/\[[\s\S]*\]/);
      if (m) setScanResults(JSON.parse(m[0]));
      else setScanResults([{alert_type:'INFO', title:'Scan complete', detail: raw.substring(0, 500)}]);
    } catch(e) { setScanResults([{alert_type:'ERROR', title:'Scan failed', detail: e.message}]); }
    setScanLoading(false);
  };

  const analyzeNdaa = async () => {
    if (ndaaFiles.length === 0) return;
    setNdaaLoading(true); setNdaaResults(null);
    try {
      const text = ndaaFiles.map(f => '=== ' + f.name + ' ===\n' + f.content).join('\n\n');
      const d = await api.post('gda-chat-v2', {message: 'Analyze this NDAA document for GDA-relevant intelligence. GDA targets: SOCOM, TRADOC, PEO STRI, AFC, INSCOM, CYBERCOM, DISA, DLA, MDA. Capabilities: training, simulation, XR, C5ISR, cyber, SIGINT. Extract: (1) Funded programs by agency, (2) Budget changes, (3) New authorities, (4) Set-aside provisions, (5) Mandates creating new opportunities. Return JSON: {programs:[{agency,program,funding,relevance}], budget_changes:[{agency,change,impact}], authorities:[{title,description,opportunity}], set_asides:[{provision,type,impact}]}. NDAA text:\n' + text.substring(0, 15000)}, {signal: AbortSignal.timeout(90000)});
      const raw = d.response || d.output || JSON.stringify(d);
      const match = raw.match(/\{[\s\S]*\}/);
      if (match) setNdaaResults(JSON.parse(match[0]));
      else setNdaaResults({summary: raw.substring(0, 1000)});
    } catch(e) { setNdaaResults({error: e.message}); }
    setNdaaLoading(false);
  };

  const loadTaskOrders = async () => {
    setToLoading(true);
    try {
      const names = idiqs.map(i => i.contract).join(', ');
      const d = await api.post('gda-chat-v2', {message: 'Search for recent task orders issued under these IDIQ contracts: ' + names + '. Focus on task orders matching NAICS 541511, 541512, 541513, 611430, 541990, 541715. Return JSON array: [{idiq, to_number, title, agency, value, date, naics}].'}, {signal: AbortSignal.timeout(60000)});
      const raw = d.response || d.output || JSON.stringify(d);
      const m = raw.match(/\[[\s\S]*\]/);
      if (m) setTaskOrders(JSON.parse(m[0]));
    } catch(e) {}
    setToLoading(false);
  };

  const quickSearch = async (term) => {
    const q = term || searchQuery.trim();
    if (!q) return;
    setSearchLoading(true); setSearchResults([]);
    try {
      const d = await api.post('gda-chat-v2', {message: 'Search for IDIQ on-ramp opportunities matching: "' + q + '". Return JSON array with fields: title, agency, naics, vehicle, deadline, link, value.'}, {signal: AbortSignal.timeout(60000)});
      const raw = d.response || d.output || JSON.stringify(d);
      const m = raw.match(/\[[\s\S]*\]/);
      if (m) setSearchResults(JSON.parse(m[0]));
    } catch(e) {}
    setSearchLoading(false);
  };

  const addIdiq = () => {
    if (!newIdiq.name.trim()) return;
    setIdiqs(p => [...p, {...newIdiq, id: Date.now(), status: 'Monitoring', onramp: 'No Open Season', awardees: parseInt(newIdiq.awardees) || 0}]);
    setNewIdiq({name:'',contract:'',agency:'',ceiling:'',pop:'',awardees:'',notes:''});
    setShowAddIdiq(false);
  };

  const fmtSz = (b) => b < 1048576 ? (b/1024).toFixed(1)+' KB' : (b/1048576).toFixed(1)+' MB';
  const alertColor = (t) => ({OPEN_SEASON:'#DC2626',FIVE_YEAR_TRIGGER:'#B06D32',NEW_TO:'#32448A',OFF_RAMP:'#32448A',ERROR:'#DC2626'}[t] || '#6B7280');

  return (
    <div>
      <PageHeader title="IDIQ & NDAA Intel" sub="Monitor on-ramps, open seasons, NDAA provisions, and task orders" />
      <div style={{display:'flex',gap:0,marginBottom:20}}>
        {TABS.map((t,ti) => (
          <button key={t.id} onClick={() => setIdiqTab(t.id)} style={{padding:'9px 18px',fontSize:12,fontWeight:idiqTab===t.id?700:400,color:idiqTab===t.id?'#fff':NAVY,background:idiqTab===t.id?ACCENT:'#fff',border:'1px solid '+(idiqTab===t.id?ACCENT:BORDER),cursor:'pointer',borderRadius:ti===0?'6px 0 0 6px':ti===TABS.length-1?'0 6px 6px 0':'0'}}>{t.label}</button>
        ))}
      </div>

      {idiqTab==='tracker' && (
        <div>
          <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:12}}>
            <div style={{fontSize:14,fontWeight:700,color:NAVY}}>Tracked IDIQs ({idiqs.length})</div>
            <button onClick={() => setShowAddIdiq(true)} style={{background:ACCENT,color:'#fff',border:'none',borderRadius:6,padding:'6px 14px',fontSize:12,fontWeight:600,cursor:'pointer'}}>+ Add IDIQ</button>
          </div>
          {idiqs.map(idiq => (
            <div key={idiq.id} style={{background:'#fff',border:'1px solid #E8ECF1',borderRadius:10,padding:16,marginBottom:10}}>
              <div style={{display:'flex',justifyContent:'space-between',alignItems:'flex-start'}}>
                <div>
                  <div style={{fontSize:15,fontWeight:700,color:NAVY}}>{idiq.name}</div>
                  <div style={{fontSize:12,color:'#6B7280',marginTop:2}}>{idiq.contract} | {idiq.agency}</div>
                </div>
                <span style={{padding:'3px 10px',borderRadius:8,fontSize:10,fontWeight:700,background:idiq.onramp==='Active Open Season'?'#FEE2E2':idiq.onramp==='Approaching 5-Year Trigger'?'#B06D3218':'#F0F4FF',color:idiq.onramp==='Active Open Season'?'#DC2626':idiq.onramp==='Approaching 5-Year Trigger'?'#B06D32':'#3B82F6'}}>{idiq.onramp}</span>
              </div>
              <div style={{display:'flex',gap:16,marginTop:10,fontSize:11,color:'#6B7280'}}>
                <span>Ceiling: <strong style={{color:NAVY}}>{idiq.ceiling}</strong></span>
                <span>PoP: <strong style={{color:NAVY}}>{idiq.pop}</strong></span>
                <span>Awardees: <strong style={{color:NAVY}}>{idiq.awardees}</strong></span>
              </div>
              {idiq.notes && <div style={{fontSize:11,color:'#9CA3AF',marginTop:6,fontStyle:'italic'}}>{idiq.notes}</div>}
            </div>
          ))}
          {showAddIdiq && (
            <div style={{position:'fixed',inset:0,background:'rgba(27,42,74,0.5)',zIndex:10000,display:'flex',alignItems:'center',justifyContent:'center'}} onClick={e => {if(e.target===e.currentTarget)setShowAddIdiq(false);}}>
              <div style={{background:'#fff',padding:24,borderRadius:12,maxWidth:480,width:'90%'}}>
                <div style={{fontSize:16,fontWeight:700,color:NAVY,marginBottom:12}}>Add IDIQ to Monitor</div>
                {[{k:'name',l:'IDIQ Name',p:'e.g. MDA SHIELD'},{k:'contract',l:'Contract Number',p:'e.g. HQ085925RE001'},{k:'agency',l:'Agency',p:'e.g. Missile Defense Agency'},{k:'ceiling',l:'Ceiling Value',p:'e.g. $2.4B'},{k:'pop',l:'Period of Performance',p:'e.g. 2025-2030'},{k:'awardees',l:'Current Awardees',p:'e.g. 12'},{k:'notes',l:'Notes',p:'FAR 16.5 trigger date, etc.'}].map(f => (
                  <div key={f.k} style={{marginBottom:8}}>
                    <div style={{fontSize:11,fontWeight:600,color:'#666',marginBottom:3}}>{f.l}</div>
                    <input style={{width:'100%',padding:'7px 10px',border:'1px solid #D1D5DB',borderRadius:6,fontSize:12}} placeholder={f.p} value={newIdiq[f.k]} onChange={e => setNewIdiq(p => ({...p,[f.k]:e.target.value}))} />
                  </div>
                ))}
                <div style={{display:'flex',gap:8,marginTop:12}}>
                  <button onClick={addIdiq} style={{background:ACCENT,color:'#fff',border:'none',borderRadius:6,padding:'8px 20px',fontSize:12,fontWeight:600,cursor:'pointer'}}>Add</button>
                  <button onClick={() => setShowAddIdiq(false)} style={{background:'none',border:'1px solid #D1D5DB',borderRadius:6,padding:'8px 16px',fontSize:12,cursor:'pointer',color:'#6B7280'}}>Cancel</button>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {idiqTab==='scanner' && (
        <div>
          <div style={{...S.card,marginBottom:12}}>
            <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:12}}>
              <div style={{fontSize:14,fontWeight:700,color:NAVY}}>On-Ramp Scanner</div>
              <button onClick={runOnRampScan} disabled={scanLoading} style={{...S.btn(),opacity:scanLoading?0.5:1}}>{scanLoading?'Scanning...':'Scan All Tracked IDIQs'}</button>
            </div>
            <div style={{fontSize:12,color:'#6B7280'}}>Searches SAM.gov, GovTribe, and web for on-ramp announcements, open seasons, and FAR 16.5 triggers for your {idiqs.length} tracked IDIQs.</div>
          </div>
          {scanLoading && <div style={{textAlign:'center',padding:20}}><Spinner /><div style={{fontSize:11,color:'#888',marginTop:8}}>Scanning... 30-60s</div></div>}
          {scanResults.map((r,i) => (
            <div key={i} style={{background:'#fff',border:'1px solid #E8ECF1',borderRadius:8,padding:12,marginBottom:8,borderLeft:'4px solid '+alertColor(r.alert_type)}}>
              <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:4}}>
                <span style={{fontSize:10,fontWeight:700,color:alertColor(r.alert_type),textTransform:'uppercase',letterSpacing:'0.5px'}}>{(r.alert_type||'INFO').replace(/_/g,' ')}</span>
                {r.deadline && <span style={{fontSize:10,color:'#6B7280'}}>{r.deadline}</span>}
              </div>
              <div style={{fontSize:13,fontWeight:600,color:NAVY}}>{r.title || 'Alert'}</div>
              {r.detail && <div style={{fontSize:12,color:'#374151',lineHeight:1.5,marginTop:4}}>{r.detail}</div>}
              {r.url && <a href={r.url} target="_blank" rel="noopener" style={{fontSize:11,color:ACCENT,marginTop:4,display:'inline-block'}}>View Source \u2197</a>}
            </div>
          ))}
          {!scanLoading && scanResults.length === 0 && <Empty msg="Click 'Scan All Tracked IDIQs' to search for on-ramp opportunities" />}
        </div>
      )}

      {idiqTab==='ndaa' && (
        <div>
          <div style={{...S.card,marginBottom:12}}>
            <div style={{fontSize:14,fontWeight:700,color:NAVY,marginBottom:8}}>NDAA Document Ingestion</div>
            <div style={{fontSize:12,color:'#6B7280',marginBottom:12}}>Drop NDAA PDFs to extract funded programs, budget changes, new authorities, and set-aside provisions relevant to GDA target agencies.</div>
            <div onDragOver={e=>{e.preventDefault();setNdaaDragOver(true);}} onDragLeave={()=>setNdaaDragOver(false)} onDrop={e=>{e.preventDefault();setNdaaDragOver(false);addNdaaFiles(e.dataTransfer.files);}}
              onClick={()=>{const inp=document.createElement('input');inp.type='file';inp.multiple=true;inp.accept='.pdf,.docx,.txt';inp.onchange=e=>addNdaaFiles(e.target.files);inp.click();}}
              style={{minHeight:80,border:'2px dashed '+(ndaaDragOver?ACCENT:BORDER),borderRadius:8,cursor:'pointer',display:'flex',flexDirection:'column',alignItems:'center',justifyContent:'center',padding:16,background:ndaaDragOver?'#B06D3212':'#FAFBFC',transition:'all 0.2s'}}>
              <span style={{fontSize:13,color:'#6B7280'}}>Drop NDAA PDF, Word, or text files here</span>
              <span style={{fontSize:10,color:'#9CA3AF',marginTop:4}}>AI will extract agency-specific provisions and opportunities</span>
            </div>
            {ndaaFiles.length > 0 && <div style={{marginTop:8}}>
              {ndaaFiles.map((f,i) => (
                <div key={i} style={{display:'flex',alignItems:'center',justifyContent:'space-between',padding:'4px 8px',background:'#2F5C1F12',borderRadius:4,marginBottom:3,fontSize:11}}>
                  <span style={{color:NAVY,fontWeight:500}}>{f.name} ({fmtSz(f.size)})</span>
                  <span onClick={()=>setNdaaFiles(p=>p.filter((_,j)=>j!==i))} style={{cursor:'pointer',color:'#DC2626',fontWeight:700}}>x</span>
                </div>
              ))}
              <button onClick={analyzeNdaa} disabled={ndaaLoading} style={{...S.btn(),marginTop:8,opacity:ndaaLoading?0.5:1}}>{ndaaLoading?'Analyzing...':'Analyze NDAA'}</button>
            </div>}
          </div>
          {ndaaLoading && <div style={{textAlign:'center',padding:20}}><Spinner /><div style={{fontSize:11,color:'#888',marginTop:8}}>Analyzing NDAA... 30-60s</div></div>}
          {ndaaResults && !ndaaResults.error && (
            <div>
              {ndaaResults.programs && ndaaResults.programs.length > 0 && (
                <div style={{...S.card,marginBottom:10,borderLeft:'4px solid #2F5C1F'}}>
                  <div style={{fontSize:12,fontWeight:700,color:'#2F5C1F',marginBottom:8}}>FUNDED PROGRAMS ({ndaaResults.programs.length})</div>
                  {ndaaResults.programs.map((p,i) => (
                    <div key={i} style={{padding:'6px 0',borderBottom:'1px solid #F0F1F4',fontSize:12}}>
                      <span style={{fontWeight:600,color:NAVY}}>{p.program || p.title}</span>
                      <span style={{fontSize:10,padding:'1px 6px',borderRadius:8,background:'#EEF2FF',color:'#4338CA',marginLeft:6}}>{p.agency}</span>
                      {p.funding && <span style={{color:'#2F5C1F',fontWeight:600,marginLeft:8}}>{p.funding}</span>}
                      {p.relevance && <div style={{fontSize:11,color:'#6B7280',marginTop:2}}>{p.relevance}</div>}
                    </div>
                  ))}
                </div>
              )}
              {ndaaResults.budget_changes && ndaaResults.budget_changes.length > 0 && (
                <div style={{...S.card,marginBottom:10,borderLeft:'4px solid #B06D32'}}>
                  <div style={{fontSize:12,fontWeight:700,color:'#B06D32',marginBottom:8}}>BUDGET CHANGES ({ndaaResults.budget_changes.length})</div>
                  {ndaaResults.budget_changes.map((b,i) => (
                    <div key={i} style={{padding:'6px 0',borderBottom:'1px solid #F0F1F4',fontSize:12}}>
                      <span style={{fontWeight:600,color:NAVY}}>{b.agency}: </span>{b.change}
                      {b.impact && <div style={{fontSize:11,color:'#6B7280',marginTop:2}}>Impact: {b.impact}</div>}
                    </div>
                  ))}
                </div>
              )}
              {ndaaResults.authorities && ndaaResults.authorities.length > 0 && (
                <div style={{...S.card,marginBottom:10,borderLeft:'4px solid #32448A'}}>
                  <div style={{fontSize:12,fontWeight:700,color:'#32448A',marginBottom:8}}>NEW AUTHORITIES ({ndaaResults.authorities.length})</div>
                  {ndaaResults.authorities.map((a,i) => (
                    <div key={i} style={{padding:'6px 0',borderBottom:'1px solid #F0F1F4',fontSize:12}}>
                      <span style={{fontWeight:600,color:NAVY}}>{a.title}</span>
                      {a.description && <div style={{fontSize:11,color:'#374151',marginTop:2}}>{a.description}</div>}
                      {a.opportunity && <div style={{fontSize:11,color:ACCENT,marginTop:2}}>Opportunity: {a.opportunity}</div>}
                    </div>
                  ))}
                </div>
              )}
              {ndaaResults.summary && <div style={{...S.card,fontSize:12,color:'#374151',lineHeight:1.6}}>{ndaaResults.summary}</div>}
            </div>
          )}
          {ndaaResults && ndaaResults.error && <Alert msg={'Analysis failed: ' + ndaaResults.error} />}
        </div>
      )}

      {idiqTab==='task-orders' && (
        <div>
          <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:12}}>
            <div style={{fontSize:14,fontWeight:700,color:NAVY}}>Task Order Monitor</div>
            <button onClick={loadTaskOrders} disabled={toLoading} style={{...S.btn(),opacity:toLoading?0.5:1}}>{toLoading?'Loading...':'Refresh Task Orders'}</button>
          </div>
          {toLoading && <div style={{textAlign:'center',padding:20}}><Spinner /></div>}
          {taskOrders.length > 0 ? (
            <div style={S.card}>
              <table style={{width:'100%',borderCollapse:'collapse',fontSize:12}}>
                <thead><tr><th style={S.th}>IDIQ</th><th style={S.th}>TO #</th><th style={S.th}>Title</th><th style={S.th}>Agency</th><th style={S.th}>Value</th><th style={S.th}>Date</th><th style={S.th}>NAICS</th></tr></thead>
                <tbody>{taskOrders.map((to,i) => (
                  <tr key={i} style={{borderBottom:'1px solid #f0f0f0'}}>
                    <td style={{...S.td,fontWeight:600,color:ACCENT}}>{to.idiq||'--'}</td>
                    <td style={S.td}>{to.to_number||'--'}</td>
                    <td style={{...S.td,maxWidth:200}}>{to.title||'--'}</td>
                    <td style={S.td}>{to.agency||'--'}</td>
                    <td style={{...S.td,fontWeight:600}}>{to.value||'--'}</td>
                    <td style={S.td}>{to.date||'--'}</td>
                    <td style={S.td}>{to.naics||'--'}</td>
                  </tr>
                ))}</tbody>
              </table>
            </div>
          ) : (!toLoading && <Empty msg="Click 'Refresh Task Orders' to search for recent TOs on tracked IDIQs" />)}
        </div>
      )}

      {idiqTab==='search' && (
        <div>
          <div style={S.card}>
            <div style={{fontSize:11,fontWeight:700,color:NAVY,marginBottom:8}}>Quick Search</div>
            <div style={{display:'flex',gap:6,flexWrap:'wrap',marginBottom:12}}>
              {['on-ramp','off-ramp','task order','IDIQ add','IDIQ on-ramp','multiple award','fair opportunity','open season'].map(t =>
                <button key={t} onClick={() => {setSearchQuery(t);quickSearch(t);}} style={S.btn('secondary',true)}>{t}</button>
              )}
            </div>
            <div style={{display:'flex',gap:8}}>
              <input style={{...S.input,flex:1}} value={searchQuery} onChange={e => setSearchQuery(e.target.value)} onKeyDown={e => e.key==='Enter' && quickSearch()} placeholder="Search IDIQ on-ramp opportunities..." />
              <button style={S.btn()} onClick={() => quickSearch()} disabled={searchLoading}>{searchLoading?'Searching...':'Search'}</button>
            </div>
          </div>
          {searchLoading && <div style={{textAlign:'center',padding:20}}><Spinner /><div style={{fontSize:11,color:'#888',marginTop:8}}>Searching... 30-60s</div></div>}
          {searchResults.length > 0 && (
            <div style={S.card}>
              <div style={S.cardTitle}>{searchResults.length} Results</div>
              <table style={{width:'100%',borderCollapse:'collapse',fontSize:12}}>
                <thead><tr><th style={S.th}>Opportunity</th><th style={S.th}>Agency</th><th style={S.th}>Vehicle</th><th style={S.th}>NAICS</th><th style={S.th}>Value</th><th style={S.th}>Deadline</th></tr></thead>
                <tbody>{searchResults.map((r,i) => (
                  <tr key={i}><td style={{...S.td,fontWeight:600,color:NAVY}}>{r.link?<a href={r.link} target="_blank" rel="noopener" style={{color:ACCENT,textDecoration:'none'}}>{r.title||'Untitled'}</a>:(r.title||'Untitled')}</td><td style={S.td}>{r.agency||'--'}</td><td style={S.td}>{r.vehicle||'--'}</td><td style={S.td}>{r.naics||'--'}</td><td style={{...S.td,fontWeight:600}}>{r.value||'--'}</td><td style={S.td}>{r.deadline||'--'}</td></tr>
                ))}</tbody>
              </table>
            </div>
          )}
          {!searchLoading && searchResults.length === 0 && <Empty msg="Click a quick term or search above" />}
        </div>
      )}
    </div>
  );
}

export default IdiqOnRamp;
