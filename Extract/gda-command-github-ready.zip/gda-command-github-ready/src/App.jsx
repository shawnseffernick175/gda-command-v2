// CACHE_BUST: 1774286468
// build-tag: 2026-03-15-clean
import React, { useState, useEffect, useCallback, useRef, useMemo } from 'react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, LineChart, Line, AreaChart, Area, RadarChart, Radar, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Legend, CartesianGrid, ScatterChart, Scatter , ReferenceLine} from 'recharts';


// ── Extracted Page Imports (S-094)
import PlatformGuide from './components/pages/PlatformGuidePage';
const Directions = PlatformGuide; // alias for backward compat
import ActionItems from './components/pages/ActionItemsPage';
import EmailDrafter from './components/pages/EmailDrafterPage';
import OpsDashboard from './components/pages/OpsDashboardPage';
import PwinCalculator from './components/pages/PwinCalculatorPage';
import AIAgent from './components/pages/AIAgentPage';
import DocRAG from './components/pages/DocRAGPage';
import RiskRegister from './components/pages/RiskRegisterPage';
import CompetitorWatchlist from './components/pages/CompetitorWatchlistPage';
import ComplianceMatrix from './components/pages/ComplianceMatrixPage';
import RelationshipTracker from './components/pages/RelationshipTrackerPage';
import WinLossDB from './components/pages/WinLossPage';
import PlatformHealth from './components/pages/PlatformHealthPage';
import CaptureIntel from './components/pages/CaptureIntelPage';
import IntelFeedPage from './components/pages/IntelFeedPage';
import RedTeam from './components/pages/RfpScannerPage';
import Presentations from './components/pages/PresentationsPage';
import OodaLoop from './components/pages/OodaLoopPage';
import DailySitrep from './components/pages/DailySitrepPage';
import IdiqOnRamp from './components/pages/IdiqOnRampPage';


import BidStrategy from './components/pages/BidStrategyPage';
import DeepResearch from './components/pages/DeepResearchPage';
import ProposalFactory from './components/pages/ProposalFactoryPage';
import QACenter from './components/pages/QACenterPage';
import { fetchOppData, invalidateOppCache } from './lib/gda';
var gdaNav = {};

/* ═══════════════════════════════════════════════════════════
   GDA COMMAND CENTER — S-060 Clean Build
   Self-contained, no external imports
   Primary: #1a2744 navy | Accent: #D14A2A burnt orange
   Font: Inter | All API calls inline
   ═══════════════════════════════════════════════════════════ */

// ── CONSTANTS ────────────────────────────────────────────────
const ACCENT = '#D14A2A';
const NAVY = '#1a2744';
const BG = '#f5f5f5';
const WHITE = '#ffffff';
const BORDER = '#e0e0e0';
const FONT = "'Inter', 'Segoe UI', Arial, sans-serif";
const N8N = '/api';
const AUTH = { 'Content-Type': 'application/json' };

// ── API HELPERS ──────────────────────────────────────────────
const api = {
  post: async (path, body = {}, opts = {}) => {
    const r = await fetch(`${N8N}/${path}`, { method: 'POST', headers: AUTH, body: JSON.stringify(body), ...opts });
    if (!r.ok) throw new Error(`${r.status}`);
    const _t = await r.text(); return _t.trim() ? JSON.parse(_t) : {};
  },
  get: async (path) => {
    const r = await fetch(`${N8N}/${path}`, { headers: AUTH });
    if (!r.ok) throw new Error(`${r.status}`);
    return r.json();
  }
};

// ── GLOBAL CSS ───────────────────────────────────────────────
const css = `
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { font-family: ${FONT}; background: ${BG}; color: ${NAVY}; font-size: 13px; }
  input, textarea, select, button { font-family: ${FONT}; font-size: 13px; }
  ::-webkit-scrollbar { width: 6px; height: 6px; }
  ::-webkit-scrollbar-track { background: #f1f1f1; }
  ::-webkit-scrollbar-thumb { background: #c1c1c1; border-radius: 3px; }
  @keyframes pulse { 0%,100%{opacity:1} 50%{opacity:0.4} }
  @keyframes spin { to{transform:rotate(360deg)} }
`;

// ── STYLES ───────────────────────────────────────────────────
const S = {
  app: { display:'flex', flexDirection:'column', height:'100vh', overflow:'hidden' },
  header: { background:WHITE, borderBottom:`1px solid ${BORDER}`, padding:'10px 20px', display:'flex', alignItems:'center', justifyContent:'space-between', flexShrink:0 },
  headerLeft: { display:'flex', flexDirection:'column' },
  headerTitle: { fontSize:20, fontWeight:700, color:NAVY, letterSpacing:'-0.5px' },
  headerSub: { fontSize:11, color:'#666', marginTop:1, letterSpacing:'1px' },
  headerRight: { fontSize:11, color:'#888' },
  body: { display:'flex', flex:1, overflow:'hidden' },
  sidebar: { width:185, background:WHITE, borderRight:`1px solid ${BORDER}`, overflow:'auto', flexShrink:0, padding:'10px 0' },
  main: { flex:1, overflow:'auto', padding:'24px 40px', background:BG },
  sidebarGroup: { padding:'8px 14px 3px', fontSize:11, fontWeight:700, color:'#aaa', letterSpacing:'1px', textTransform:'uppercase', marginTop:4 },
  sidebarItem: (active) => ({
    padding:'7px 14px', fontSize:12, color: active ? NAVY : '#555', background: active ? '#f5ede6' : 'transparent',
    cursor:'pointer', borderLeft: active ? `3px solid ${ACCENT}` : '3px solid transparent',
    fontWeight: active ? 600 : 400, display:'flex', alignItems:'center', gap:7,
    transition:'all 0.12s', userSelect:'none'
  }),
  pageTitle: { fontSize:20, fontWeight:700, color:NAVY, marginBottom:4 },
  pageSub: { fontSize:12, color:'#666', marginBottom:18 },
  kpiBar: { display:'flex', gap:12, background:WHITE, border:`1px solid ${BORDER}`, borderRadius:8, padding:'14px 18px', marginBottom:18 },
  kpiItem: { flex:1 },
  kpiLabel: { fontSize:11, fontWeight:700, color:'#888', letterSpacing:'0.5px', textTransform:'uppercase', marginBottom:3 },
  kpiValue: { fontSize:20, fontWeight:700, color:NAVY },
  kpiSub: { fontSize:11, color:'#999', marginTop:1 },
  card: { background:WHITE, border:`1px solid ${BORDER}`, borderRadius:8, padding:'16px 20px', marginBottom:14 },
  cardTitle: { fontSize:13, fontWeight:700, color:NAVY, marginBottom:10 },
  table: { width:'100%', borderCollapse:'collapse', fontSize:12 },
  th: { padding:'8px 12px', textAlign:'left', fontSize:11, fontWeight:700, color:'#777', letterSpacing:'0.4px', textTransform:'uppercase', borderBottom:`1px solid ${BORDER}`, background:'#fafafa' },
  td: { padding:'9px 12px', borderBottom:`1px solid #f0f0f0`, verticalAlign:'middle' },
  btn: (variant='primary', small=false) => ({
    padding: small ? '5px 10px' : '8px 16px',
    borderRadius:6, border:'none', cursor:'pointer',
    fontSize: small ? 11 : 12, fontWeight:600, transition:'all 0.15s',
    background: variant==='primary' ? ACCENT : variant==='green' ? '#22a06b' : variant==='blue' ? '#32448A' : variant==='red' ? '#e53935' : '#eee',
    color: variant==='secondary' ? NAVY : WHITE
  }),
  badge: (color='gray') => ({
    display:'inline-block', padding:'2px 8px', borderRadius:10, fontSize:11, fontWeight:600,
    background: color==='green'?'#2F5C1F15' : color==='red'?'#ffebe6' : color==='orange'?'#fff3e0' : color==='blue'?'#e6f0ff' : '#f4f5f7',
    color: color==='green'?'#2F5C1F' : color==='red'?'#bf2600' : color==='orange'?'#B06D32' : color==='blue'?'#32448A' : '#555'
  }),
  input: { width:'100%', padding:'8px 10px', border:`1px solid ${BORDER}`, borderRadius:6, fontSize:12, outline:'none' },
  textarea: { width:'100%', padding:'8px 10px', border:`1px solid ${BORDER}`, borderRadius:6, fontSize:12, outline:'none', resize:'vertical' },
  select: { padding:'7px 10px', border:`1px solid ${BORDER}`, borderRadius:6, fontSize:12, outline:'none', background:WHITE },
  spinner: { width:20, height:20, border:`2px solid ${BORDER}`, borderTopColor:ACCENT, borderRadius:'50%', animation:'spin 0.7s linear infinite', display:'inline-block' },
  divider: { borderTop:`1px solid ${BORDER}`, margin:'14px 0' },
  row: (gap=12) => ({ display:'flex', gap, alignItems:'center' }),
  col: (gap=12) => ({ display:'flex', flexDirection:'column', gap }),
  grid: (cols=2, gap=14) => ({ display:'grid', gridTemplateColumns:`repeat(${cols}, 1fr)`, gap }),
  nav: (active=false) => ({
    padding:'6px 14px', borderRadius:6, border:`1px solid ${active ? ACCENT : BORDER}`,
    background: active ? ACCENT : WHITE, color: active ? WHITE : '#555',
    fontSize:11, fontWeight: active ? 600 : 400, cursor:'pointer', transition:'all 0.15s'
  }) };

// ── SHARED COMPONENTS ────────────────────────────────────────
const Spinner = () => <div style={S.spinner} />;

const Empty = ({ msg = 'No data' }) => (
  <div style={{textAlign:'center', padding:'40px', color:'#aaa', fontSize:13}}>{msg}</div>
);

const Alert = ({ type='error', msg }) => {
  if (!msg) return null;
  const colors = { error:'#ffebe6', success:'#2F5C1F15', info:'#e6f0ff' };
  const tc = { error:'#bf2600', success:'#2F5C1F', info:'#32448A' };
  return <div style={{background:colors[type], color:tc[type], padding:'10px 14px', borderRadius:6, fontSize:12, marginBottom:12}}>{msg}</div>;
};

const PageHeader = ({ title, sub, action }) => (
  <div style={{...S.row(), justifyContent:'space-between', marginBottom:18}}>
    <div>
      <div style={S.pageTitle}>{title}</div>
      {sub && <div style={S.pageSub}>{sub}</div>}
    </div>
    {action}
  </div>
);

// ── SIDEBAR CONFIG ───────────────────────────────────────────
const NAV_ITEMS = [
  { type:'divider', label:'INTELLIGENCE' },
  { id:'launchpad',        label:'Launchpad',           icon:'🚀' },
  { id:'ai-agent',         label:'AI Agent Chat',       icon:'🤖' },
  { id:'sitrep',           label:'Daily SITREP',        icon:'📋' },
  { id:"daily-brief",      label:"Morning Brief",      icon:"☀️" },
  { id:'intel-feed',       label:'Intel Feed',          icon:'📡' },
  { id:'deep-research',   label:'Deep Research',       icon:'🔬' },
  { id:'meeting-notes',   label:'Meeting Notes',       icon:'📝' },

  { type:'divider', label:'BUSINESS DEVELOPMENT' },
  { id:'comp-intel',       label:'Competitive Intel',   icon:'🔍' },
  { id:'bid-strategy', label:'Bid Strategy', icon:'🎯' },
  { id:'ooda',             label:'OODA Loop',           icon:'🔄' },
  { id:'opp-tracker',      label:'Opportunity Tracker', icon:'🎯' },
  { id:'pwin-calculator',  label:'Pwin Calculator',     icon:'🎲' },



  { type:'divider', label:'CAPTURE & PROPOSALS' },
  { id:'capture-plan',     label:'Capture Plan',        icon:'📋' },
  { id:'compliance-matrix',label:'Compliance Matrix',   icon:'✅' },
  { id:'doc-hub',          label:'Document Hub & PPT',  icon:'📂' },
  { id:'email',            label:'Email Drafter',       icon:'✉️' },
  { id:'red-team',         label:'Proposal Review',     icon:'⚔️' },
  { id:'proposal-factory', label:'Proposal Factory',    icon:'⚙' },
  { id:'risk',             label:'Risk Register',       icon:'🛡️' },

  { type:'divider', label:'FINANCIAL PLANNING' },
  { id:'aop-tracker',      label:'Financial Bible',     icon:'✚' },

  { type:'divider', label:'PLATFORM' },
  { id:'platform-health',  label:'Platform Health',     icon:'💡' },
  { id:'qa-center',        label:'QA Center',           icon:'🩺' },
  { id:'directions',       label:'Platform Guide',      icon:'🧭' },
  { id:'prompt-architect', label:'Prompt Architect',    icon:'🧪' },
]

// ────────────────────────────────────────────────────────────

// ── S-078 CHART HELPERS ─────────────────────────────────────
const formatDollar = (v) => {
  // CANONICAL money formatter. Rule: >=1B $X.XB, >=1M $XM, >=1K $XK, <1K $X, null/0 em-dash.
  if (v === null || v === undefined || v === '' || v === '0' || v === 0) return '—';
  let s = (typeof v === 'string') ? v.replace(/[$,\s]/g, '') : String(v);
  const suf = s.match(/[MBKmbk]$/);
  if (suf) {
    const base = parseFloat(s.slice(0, -1)) || 0;
    const mul = { m: 1e6, M: 1e6, b: 1e9, B: 1e9, k: 1e3, K: 1e3 }[suf[0]];
    s = String(base * mul);
  }
  const n = parseFloat(s);
  if (isNaN(n) || n === 0) return '—';
  const neg = n < 0; const abs = Math.abs(n);
  let out;
  if (abs >= 1e9) out = '$' + (abs / 1e9).toFixed(1).replace(/\.0$/, '') + 'B';
  else if (abs >= 1e6) out = '$' + (abs / 1e6).toFixed(1).replace(/\.0$/, '') + 'M';
  else if (abs >= 1e3) out = '$' + Math.round(abs / 1e3) + 'K';
  else out = '$' + Math.round(abs);
  return neg ? '-' + out : out;
};
if (typeof window !== 'undefined') window.GDA_USD = formatDollar;

const ChartCard = ({ title, question, children, style }) => (
  <div style={{ background:'#fff', borderRadius:12, padding:'20px 24px', boxShadow:'0 2px 8px rgba(0,0,0,0.06)', fontFamily:FONT, ...style }}>
    <div style={{ marginBottom:16 }}>
      <div style={{ fontSize:16, fontWeight:700, color:NAVY }}>{title}</div>
      <div style={{ fontSize:12, color:'#8492A6', marginTop:2 }}>{question}</div>
    </div>
    {children}
  </div>
);

const PipelineFunnel = ({ data = [] }) => {
  const stages = ['Identified','Qualified','Capture','Proposal','Award'];
  const colors = ['#5091A7','#2F5C1F','#B06D32','#D14A2A','#1B2A4A'];
  const m = {}; stages.forEach(s => { m[s] = { count:0, value:0 }; });
  data.forEach(o => { const s = o.stage||o.pipeline_stage||'Identified'; if(m[s]){m[s].count++;m[s].value+=parseFloat(o.estimated_value||o.value||0);} });
  const total = data.length || 1;
  const W = 500, H = 220, padTop = 10;
  const barH = (H - padTop) / stages.length;
  return <ChartCard title="Opportunity Funnel" question="Where are opportunities stuck?">
    <svg viewBox={`0 0 ${W} ${H}`} style={{width:'100%',maxWidth:500}}>
      {stages.map((s,i) => {
        const pct = m[s].count / total;
        const topW = W * (1 - i * 0.15);
        const botW = W * (1 - (i+1) * 0.15);
        const topX = (W - topW) / 2;
        const botX = (W - botW) / 2;
        const y = padTop + i * barH;
        const pts = `${topX},${y} ${topX+topW},${y} ${botX+botW},${y+barH-2} ${botX},${y+barH-2}`;
        return React.createElement('g', {key:s}, [
          React.createElement('polygon', {key:'p', points:pts, fill:colors[i], opacity:0.9, style:{cursor:'pointer'}}),
          React.createElement('text', {key:'t', x:W/2, y:y+barH/2+1, textAnchor:'middle', fill:'#fff', fontSize:13, fontWeight:700, fontFamily:FONT}, s),
          React.createElement('text', {key:'c', x:W/2, y:y+barH/2+16, textAnchor:'middle', fill:'rgba(255,255,255,0.8)', fontSize:11, fontFamily:FONT}, m[s].count + ' opps (' + formatDollar(m[s].value) + ')')
        ]);
      })}
    </svg>
  </ChartCard>;
};




const RiskTrend = ({ data=[] }) => (
  <ChartCard title="Risk Trend (90 Days)" question="Improving or deteriorating?">
    <ResponsiveContainer width="100%" height={200}><AreaChart data={data}><CartesianGrid strokeDasharray="3 3"/><XAxis dataKey="date" fontSize={11}/><YAxis fontSize={11}/><Tooltip/>
      <Area type="monotone" dataKey="red" stackId="1" stroke="#E74C3C" fill="#E74C3C" fillOpacity={0.7} name="Critical"/>
      <Area type="monotone" dataKey="yellow" stackId="1" stroke="#B06D32" fill="#B06D32" fillOpacity={0.7} name="Warning"/>
      <Area type="monotone" dataKey="green" stackId="1" stroke="#2F5C1F" fill="#2F5C1F" fillOpacity={0.5} name="Low"/>
    </AreaChart></ResponsiveContainer>
  </ChartCard>
);




// PAGE COMPONENTS
// ────────────────────────────────────────────────────────────

// ── DOLLAR FORMATTING (BL-033) ────────────────────────────────
function normalizeDept(raw) {
  if (!raw) return 'Unknown';
  var s = String(raw).trim();
  // GovTribe uses dot-delimited: "DEPT OF DEFENSE.DEPT OF THE ARMY..."
  // Non-DoD inverted: "VETERANS AFFAIRS, DEPARTMENT OF.245-NETWORK..."
  // Extract first segment
  var firstSeg = s.indexOf('.') > 0 ? s.split('.')[0].trim() : s;
  var lower = firstSeg.toLowerCase();
  // DoD / Department of War
  if (lower.indexOf('dept of defense') >= 0 || lower.indexOf('department of defense') >= 0 || lower === 'dod' || lower === 'dow' || lower === 'department of war') return 'Department of War';
  // Inverted format: "VETERANS AFFAIRS, DEPARTMENT OF" or "JUSTICE, DEPARTMENT OF"
  if (lower.indexOf('veterans affairs') >= 0) return 'Department of Veterans Affairs';
  if (lower.indexOf('homeland security') >= 0 || lower === 'dhs') return 'Department of Homeland Security';
  if (lower.indexOf('treasury') >= 0) return 'Department of the Treasury';
  if (lower.indexOf('interior') >= 0) return 'Department of the Interior';
  if (lower.indexOf('agriculture') >= 0 || lower.indexOf('usda') >= 0 || lower.indexOf('forest service') >= 0) return 'Department of Agriculture';
  if (lower.indexOf('justice') >= 0 || lower === 'doj' || lower.indexOf('federal prison') >= 0) return 'Department of Justice';
  if (lower.indexOf('energy') >= 0 || lower === 'doe') return 'Department of Energy';
  if (lower.indexOf('commerce') >= 0 || lower === 'doc') return 'Department of Commerce';
  if (lower.indexOf('transportation') >= 0 || lower === 'dot') return 'Department of Transportation';
  if (lower.indexOf('state, department') >= 0 || (lower.indexOf('state') >= 0 && lower.indexOf('department') >= 0)) return 'Department of State';
  if (lower.indexOf('health and human') >= 0 || lower === 'hhs') return 'Department of Health and Human Services';
  if (lower.indexOf('intelligence') >= 0 || lower === 'ic' || lower.indexOf('cia') >= 0 || lower.indexOf('odni') >= 0) return 'Intelligence Community';
  if (lower.indexOf('nasa') >= 0) return 'NASA';
  if (lower.indexOf('gsa') >= 0 || lower.indexOf('general services') >= 0) return 'General Services Administration';
  if (lower.indexOf('national park') >= 0) return 'Department of the Interior';
  if (lower.indexOf('internal revenue') >= 0) return 'Department of the Treasury';
  if (lower.indexOf('fish and wildlife') >= 0) return 'Department of the Interior';
  // Keyword fallback for DoW sub-orgs not caught above
  var dowKw = ['army','navy','naval','marine','air force','space force','socom','tradoc','inscom','cybercom','disa','darpa','dla','mda','dtra','defense logistics','missile defense','defense information','defense contract','defense counter','defense health','defense human','defense threat','national geospatial','national security agency'];
  for (var i=0;i<dowKw.length;i++){if(lower.indexOf(dowKw[i])>=0) return 'Department of War';}
  if (s.indexOf('Department of') === 0) return s;
  return s;
}

function cleanBranch(raw) {
  if (!raw) return 'Unassigned';
  var s = String(raw).trim();
  // GovTribe: "DEPT OF DEFENSE.DEFENSE LOGISTICS AGENCY.DLA LAND.DLA LAND COLUMBUS.DLA LAND AND MARITIME"
  // We want the 2nd segment as branch name if it starts with DEPT OF
  var parts = s.split('.');
  if (parts.length >= 2 && parts[0].toUpperCase().indexOf('DEPT OF') >= 0) {
    // Use segment 2 (index 1) as branch - this is the actual agency
    var branch = parts[1].trim();
    // Clean up common prefixes
    var titleCase = branch.split(' ').map(function(w) {
      if (w.length <= 3 && w === w.toUpperCase()) return w; // Keep acronyms like DLA, OSD
      return w.charAt(0).toUpperCase() + w.slice(1).toLowerCase();
    }).join(' ');
    // Map known names to clean versions
    var branchMap = {
      'dept of the army': 'Dept of the Army', 'dept of the navy': 'Dept of the Navy',
      'dept of the air force': 'Dept of the Air Force', 'defense logistics agency': 'DLA',
      'defense information systems agency': 'DISA', 'defense advanced research projects agency': 'DARPA',
      'defense intelligence agency': 'DIA', 'defense threat reduction agency': 'DTRA',
      'missile defense agency': 'MDA', 'defense contract management agency': 'DCMA',
      'defense counterintelligence and security agency': 'DCSA', 'defense health agency': 'DHA',
      'defense human resources activity': 'DHRA', 'national geospatial-intelligence agency': 'NGA',
      'national security agency': 'NSA', 'office of the secretary of defense': 'OSD',
      'us special operations command': 'USSOCOM', 'us cyber command': 'USCYBERCOM',
      'us transportation command': 'USTRANSCOM', 'us space command': 'USSPACECOM',
      'dod washington headquarters services': 'DoD WHS',
      'united states marine corps': 'USMC', 'us marine corps': 'USMC'
    };
    var bLower = branch.toLowerCase();
    if (branchMap[bLower]) return branchMap[bLower];
    return titleCase;
  }
  // For non-DoD: "VETERANS AFFAIRS, DEPARTMENT OF.245-NETWORK..."
  if (parts.length >= 2) {
    return parts[parts.length >= 3 ? 1 : 0].trim().split(' ').map(function(w) {
      if (w.length <= 3 && w === w.toUpperCase()) return w;
      return w.charAt(0).toUpperCase() + w.slice(1).toLowerCase();
    }).join(' ');
  }
  return s;
}

function calculatePwin(opp) {
  var score = 0;
  var gdaNaics = ['541330','541511','541512','541513','541519','541611','541690','541715','541990','611430','561210','336414'];
  var naicsMatch = gdaNaics.includes(String(opp.naics_code||'')) ? 100 : (String(opp.naics_code||'').substring(0,4) === '5415' ? 50 : 0);
  score += naicsMatch * 0.25;
  var sa = String(opp.set_aside||'').toLowerCase();
  var saScore = sa.includes('small') || sa.includes('8(a)') || sa.includes('sdvosb') ? 100 : sa === '' || sa === 'unrestricted' ? 50 : 30;
  score += saScore * 0.20;
  var gdaAgencies = ['SOCOM','TRADOC','PEO STRI','AFC','INSCOM','CYBERCOM','DISA','DLA','MDA'];
  var agency = String(opp.agency||opp.level_2||'');
  var ppScore = gdaAgencies.some(function(a){return agency.toUpperCase().includes(a);}) ? 100 : 40;
  score += ppScore * 0.20;
  var val = parseFloat(opp.estimated_value) || 0;
  var sizeScore = val >= 500000 && val <= 10000000 ? 100 : val > 10000000 && val <= 50000000 ? 60 : val > 0 ? 40 : 20;
  score += sizeScore * 0.15;
  score += 50 * 0.10;
  var deadline = opp.response_deadline ? new Date(opp.response_deadline) : null;
  var daysLeft = deadline ? Math.ceil((deadline - new Date()) / 86400000) : 60;
  var timeScore = daysLeft > 30 ? 100 : daysLeft > 14 ? 70 : daysLeft > 0 ? 30 : 10;
  score += timeScore * 0.10;
  return Math.round(Math.min(100, Math.max(0, score)));
}


function calculateGDAScore(opp) {
  // GDA Priority Score v2 - "What Do I Look At Today?"
  var GDA_NAICS = ['541330','541511','541512','541513','541519','541611','541690','541715','541990','611430','561210','561110','336414'];
  var SB_NAICS = ['541330','541511','541512','541513','541519','541715','611430','336414'];
  var HELD_VEH = ['shield','mda shield','oasis','oasis+','gsa mas','mas','rs3','maps','cio-sp3','cio-sp4','polaris','sewp','efast','pm traysys','seaport'];
  var t = ((opp.title || opp.name || opp.opp_title || '') + ' ' + (opp.description || '') + ' ' + (opp.agency || '') + ' ' + (opp.set_aside || '')).toLowerCase();
  var n = String(opp.naics_code || opp.naics || '');
  var sa = (opp.set_aside || '').toLowerCase();
  var ag = (opp.agency || opp.department || '').toLowerCase();
  var v = parseFloat(opp.estimated_value || 0);
  var dl = opp.response_deadline ? Math.ceil((new Date(opp.response_deadline) - new Date()) / 86400000) : 180;
  var stg = (opp.stage || '').toLowerCase();
  // Auto-PASS gate: <=30 days + no capture plan
  if (dl <= 30 && dl >= 0 && !opp._hasCap && stg !== 'proposal' && stg !== 'award') return 0;
  var s = 0;
  // T1: NAICS & Domain Fit (40pts)
  s += GDA_NAICS.indexOf(n) >= 0 ? 20 : n.substring(0,4) === '5415' ? 12 : n.substring(0,3) === '541' ? 5 : 0;
  var mis = 0;
  if (/seta|systems engineering|technical assistance/.test(t)) mis = 12;
  if (/simulat|training|virtual|peo stri|tradoc/.test(t)) mis = Math.max(mis, 12);
  if (/cyber|c5isr|information security|protect/.test(t)) mis = Math.max(mis, 10);
  if (/intel|sigint|geoint|inscom/.test(t)) mis = Math.max(mis, 10);
  if (/missile|defense|shield|golden dome/.test(t)) mis = Math.max(mis, 10);
  if (/air traffic|atc|faa|bnatcs/.test(t)) mis = Math.max(mis, 8);
  if (/software|engineer|develop|integrat/.test(t)) mis = Math.max(mis, 6);
  s += Math.min(mis, 12);
  var isSbN = SB_NAICS.indexOf(n) >= 0;
  var isSbSA = /small business|8\(a\)|sdvosb|hubzone|wosb|edwosb|service.disabled/.test(sa);
  s += (isSbN && isSbSA) ? 8 : (isSbN && !/unrestricted|full and open/.test(sa)) ? 4 : isSbSA ? 3 : 0;
  // T2: Competitive Position (30pts)
  s += /incumbent|recompete.*envision|envision.*recompete|iews/.test(t) ? 15 : /recompete|re-compete|follow.on|successor/.test(t) ? 7 : 2;
  s += /sole.source|j&a|limited competition/.test(sa + ' ' + t) ? 8 : (isSbSA && isSbN) ? 8 : isSbSA ? 5 : /full and open|unrestricted/.test(sa) ? 4 : 2;
  var vh = 0; HELD_VEH.forEach(function(x) { if (t.indexOf(x) >= 0) vh = 7; }); if (vh === 0 && /idiq|task order|bpa/.test(t)) vh = 2; s += vh;
  // T3: Urgency (15pts)
  s += dl <= 30 ? 15 : dl <= 60 ? 11 : dl <= 90 ? 7 : dl <= 180 ? 3 : 1;
  // T4: Strategic Value (15pts)
  s += v >= 20e6 ? 8 : v >= 10e6 ? 6 : v >= 5e6 ? 4 : v >= 1e6 ? 2 : 1;
  var tgts = ['socom','tradoc','peo stri','inscom','cybercom','disa','mda','faa','afc','army futures'];
  var isKnown = false; tgts.forEach(function(x) { if (ag.indexOf(x) >= 0) isKnown = true; });
  s += isKnown ? 7 : 2;
  return Math.min(Math.max(Math.round(s), 0), 100);
}

function GDAScoreBadge(props) {
  var score = props.score || 0;
  var label, color, bg;
  if (score >= 80) { label = 'PURSUE'; color = '#2F5C1F'; bg = '#2F5C1F15'; }
  else if (score >= 60) { label = 'EVALUATE'; color = '#D14A2A'; bg = '#B06D3212'; }
  else if (score >= 40) { label = 'MONITOR'; color = '#B06D32'; bg = '#B06D3218'; }
  else { label = 'PASS'; color = '#6B7280'; bg = '#F3F4F6'; }
  return React.createElement('span', {
    style: { display: 'inline-flex', alignItems: 'center', gap: 4, padding: '2px 8px', borderRadius: 12, fontSize: 11, fontWeight: 700, color: color, background: bg }
  }, score, ' \u2014 ', label);
}

function calcPwinBtn() { return null; }

// S-108: Standardized KPI Bar
function GDASparkline(props) {
  var data = props.data || [];
  var color = props.color || '#9CA3AF';
  if (data.length < 2) return null;
  var w = 60, h = 18, pad = 2;
  var vals = data.map(function(d) { return typeof d === 'number' ? d : (d.value || d.v || 0); });
  var mn = Math.min.apply(null, vals);
  var mx = Math.max.apply(null, vals);
  var range = mx - mn || 1;
  var pts = vals.map(function(v, i) {
    return (pad + (i / (vals.length - 1)) * (w - 2 * pad)) + ',' + (h - pad - ((v - mn) / range) * (h - 2 * pad));
  }).join(' ');
  var lastUp = vals.length >= 2 && vals[vals.length - 1] >= vals[vals.length - 2];
  var lineColor = lastUp ? '#2F5C1F' : '#DC2626';
  return React.createElement('svg', { width: w, height: h, style: { display: 'block', margin: '4px auto 0' } },
    React.createElement('polyline', { points: pts, fill: 'none', stroke: color === 'auto' ? lineColor : color, strokeWidth: 1.5, strokeLinecap: 'round', strokeLinejoin: 'round' })
  );
}
function GDAKpiBar(props) {
  var items = props.items || [];
  var detail = props.detail;
  var setDetail = props.setDetail;
  return React.createElement('div', null,
    React.createElement('div', {
      style: { display: 'flex', background: '#FFFFFF', border: '1px solid #E8ECF1', borderRadius: 8, marginBottom: detail ? 0 : 18, overflow: 'hidden' }
    },
      items.map(function(k, i) {
        var isActive = detail === k.id;
        var arrow = k.trend === 'up' ? ' \u2191' : k.trend === 'down' ? ' \u2193' : k.trend === 'flat' ? ' \u2192' : '';
        var arrowColor = k.trend === 'up' ? '#2F5C1F' : k.trend === 'down' ? '#DC2626' : '#9CA3AF';
        return React.createElement('div', {
          key: k.id,
          onClick: function() { if (setDetail) setDetail(isActive ? null : k.id); },
          style: { flex: 1, padding: '14px 18px', textAlign: 'center', borderRight: i < items.length - 1 ? '1px solid #E8ECF1' : 'none', cursor: setDetail ? 'pointer' : 'default', background: isActive ? 'rgba(26,39,68,0.04)' : 'transparent', transition: 'background 0.15s' }
        },
          React.createElement('div', { style: { fontSize: 11, fontWeight: 700, color: '#6B7280', textTransform: 'uppercase', letterSpacing: '0.5px', marginBottom: 4 } }, k.label),
          React.createElement('div', { style: { fontSize: 22, fontWeight: 800, color: k.color || '#1B2A4A', lineHeight: 1.2, display: 'flex', alignItems: 'baseline', justifyContent: 'center', gap: 4 } },
            typeof k.value === 'number' ? k.value.toLocaleString() : k.value,
            arrow ? React.createElement('span', { style: { fontSize: 11, color: arrowColor, marginLeft: 4 } }, arrow) : null
          ),
          k.sub ? React.createElement('div', { style: { fontSize: 11, color: '#9CA3AF', marginTop: 3 } }, k.sub) : null,
          k.sparkData ? React.createElement(GDASparkline, { data: k.sparkData, color: 'auto' }) : null
        );
      })
    ),
    detail && items.find(function(k) { return k.id === detail; }) ? React.createElement('div', {
      style: { background: '#F9FAFB', border: '1px solid #E8ECF1', borderRadius: '0 0 8px 8px', borderTop: 'none', padding: '10px 16px', marginBottom: 18, fontSize: 12, color: '#374151', lineHeight: 1.6 }
    }, items.find(function(k) { return k.id === detail; }).detail || '') : null
  );
}




// BL-034/036
// BL-034: Source citation badges
function SourceTag({url,label}){
  if(!url&&!label)return null;
  var colors = {'GovTribe':{bg:'#E8F5E9',text:'#2E7D32'},'SAM.gov':{bg:'#E3F2FD',text:'#1565C0'},'GovWin':{bg:'#FFF3E0',text:'#E65100'},'FPDS':{bg:'#F3E5F5',text:'#6A1B9A'},'USASpending':{bg:'#E8F5E9',text:'#1B5E20'},'IDIQ TO Monitor':{bg:'#FFF8E1',text:'#F57F17'}};
  var c = colors[label] || {bg:'rgba(26,39,68,0.07)',text:ACCENT};
  return <a href={url||'#'} target="_blank" rel="noopener noreferrer" style={{display:'inline-flex',alignItems:'center',gap:3,padding:'1px 7px',borderRadius:10,background:c.bg,color:c.text,fontSize:11,fontFamily:FONT,textDecoration:'none',cursor:url?'pointer':'default',border:'1px solid '+c.text+'22',marginLeft:6,fontWeight:600}}>{label||'SRC'} {url?'\u2192':''}</a>;
}
// BL-036: Composite scoring model
function compositeScore(n,bT,bA,o){
  var nN=Math.min(10,Math.max(0,n||0))*4;
  var fP=bT>0?Math.min(100,(bA/bT)*100):0;
  return Math.round(Math.min(100,nN+(fP/100)*30+Math.min(100,Math.max(0,o||0))*0.3));
}
function ScoreBadge({score,size,need,budget,addressable,ooda}){
  var s=score||0,cl=s>=70?'#1a7a3a':s>=40?'#b8860b':'#c0392b';
  var sz=size==='sm'?{fontSize:11,padding:'1px 6px'}:{fontSize:13,padding:'2px 10px'};
  var nPts=Math.min(10,Math.max(0,need||0))*4;
  var fPts=budget>0?Math.min(30,Math.round((addressable||0)/(budget||1)*30)):0;
  var oPts=Math.round(Math.min(100,Math.max(0,ooda||0))*0.3);
  var tip='Score: '+s+'/100\nNeed Assessment: '+nPts+'/40 ('+Math.round(need||0)+'/10 raw)\nFinancial Fit: '+fPts+'/30'+(budget?' ($'+Math.round((addressable||0)/1e6)+'M / $'+Math.round((budget||0)/1e6)+'M)':'')+'\nOODA Analysis: '+oPts+'/30 ('+(ooda||0)+'/100 raw)';
  return <span title={tip} style={{...sz,borderRadius:8,fontWeight:700,fontFamily:FONT,color:WHITE,background:cl,display:'inline-block',marginLeft:6,cursor:'help'}}>{s}/100</span>;
}

// ── LAUNCHPAD ────────────────────────────────────────────────
// -- useTrendData hook (S-085) --
function useTrendData(endpoint = 'gda-trends') {
  const [trends, setTrends] = useState({ pipeline: [], winRate: [], risk: [] });
  const [tLoading, setTLoading] = useState(true);
  useEffect(() => {
    setTLoading(true);
    api.post(endpoint, {}).then(d => {
      const p = d.pipeline_trend || d.pipeline || [];
      const w = d.win_rate_trend || d.winRate || [];
      const r = d.risk_trend || d.risk || [];
      setTrends({ pipeline: p, winRate: w, risk: r });
    }).catch(() => {}).finally(() => setTLoading(false));
  }, [endpoint]);
  return { trends, tLoading };
}

function LaunchpadFunnel() {
  var _d = React.useState(null), data = _d[0], setData = _d[1];
  var _l = React.useState(true), ldg = _l[0], setLdg = _l[1];
  var _e = React.useState(null), err = _e[0], setErr = _e[1];
  React.useEffect(function() {
    api.post('gda-launchpad-funnel', {}).then(function(r) { setData(r); setLdg(false); }).catch(function(e) { setErr('Failed to load funnel'); setLdg(false); });
  }, []);
  var h = React.createElement;
  if (ldg) return h('div', {style:{background:'#fff',border:'1px solid #E8ECF1',borderRadius:10,padding:20,minHeight:280}}, h('div',{style:{fontSize:13,fontWeight:700,color:'#1a2744',marginBottom:12}},'Pipeline Intelligence'), h('div',{style:{textAlign:'center',padding:40,color:'#9CA3AF',fontSize:12}},'Loading funnel data...'));
  if (err || !data) return h('div',{style:{background:'#fff',border:'1px solid #E8ECF1',borderRadius:10,padding:20}}, h('div',{style:{fontSize:13,fontWeight:700,color:'#1a2744',marginBottom:8}},'Pipeline Intelligence'), h('div',{style:{color:'#DC2626',fontSize:12}},err || 'No data'));
  var sm = data.summary || {};
  var os = data.oppStages || [];
  var cs = data.captureStages || [];
  var top = data.topOpps || [];
  var capColors = {'Go/No-Go':'#1B2A4A','Interest':'#5091A7','Qualify':'#2F5C1F','Pursue':'#B06D32','Solicitation':'#D14A2A','Proposal':'#D14A2A','Post-Submittal':'#8B5E3C','Award':'#2F5C1F'};
  var oppColors = {'Identified':'#5091A7','Qualified':'#2F5C1F','Forecast':'#B06D32','Pre-RFP':'#D14A2A','Proposal':'#D14A2A','Award':'#1B2A4A'};
  var fmtM = function(v) { var n=parseFloat(v); if(isNaN(n)||n===0) return '—'; return formatDollar(n*1e6); };
  var fmtV = formatDollar;
  return h('div',{style:{background:'#fff',border:'1px solid #E8ECF1',borderRadius:10,padding:20,marginBottom:16}},
    h('div',{style:{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:16}},
      h('div',null,
        h('div',{style:{fontSize:14,fontWeight:700,color:'#1a2744'}},'Pipeline Intelligence'),
        h('div',{style:{fontSize:11,color:'#6B7280',marginTop:2}},'Live from capture database \u2014 '+sm.totalOpps+' opps | $'+(sm.totalValue||0).toFixed(1)+'M | '+sm.totalCapture+' capture plans')
      ),
      h('div',{style:{fontSize:10,color:'#9CA3AF'}},data.generatedAt ? new Date(data.generatedAt).toLocaleString() : '')
    ),
    h('div',{style:{display:'grid',gridTemplateColumns:'repeat(5,1fr)',gap:10,marginBottom:18}},
      [{l:'Total Opps',v:sm.totalOpps,c:'#1B2A4A'},{l:'Pipeline Value',v:'$'+(sm.totalValue||0).toFixed(1)+'M',c:'#2F5C1F'},{l:'Capture Plans',v:sm.totalCapture,c:'#D14A2A'},{l:'Capture TCV',v:fmtM(sm.totalTCV),c:'#5091A7'},{l:'Alloc Revenue',v:fmtM(sm.totalAlloc),c:'#B06D32'}].map(function(kp,i){
        return h('div',{key:i,style:{background:kp.c+'0A',border:'1px solid '+kp.c+'25',borderRadius:6,padding:'8px 10px',textAlign:'center'}},
          h('div',{style:{fontSize:16,fontWeight:800,color:kp.c}},kp.v),
          h('div',{style:{fontSize:9,fontWeight:600,color:'#6B7280',textTransform:'uppercase',letterSpacing:'0.5px',marginTop:2}},kp.l));
      })
    ),
    h('div',{style:{display:'grid',gridTemplateColumns:'1fr 1fr',gap:16,marginBottom:18}},
      h('div',null,
        h('div',{style:{fontSize:11,fontWeight:700,color:'#1a2744',marginBottom:8,textTransform:'uppercase',letterSpacing:'0.5px'}},'Opportunity Stages'),
        os.map(function(s,i){
          var maxC = Math.max.apply(null, os.map(function(x){return parseInt(x.count)||1;})) || 1;
          var pct = Math.max((parseInt(s.count)||0) / maxC * 100, 8);
          return h('div',{key:i,style:{display:'flex',alignItems:'center',gap:8,marginBottom:6}},
            h('div',{style:{width:80,fontSize:10,fontWeight:600,color:'#374151',textAlign:'right'}},s.stage),
            h('div',{style:{flex:1,position:'relative',height:24,background:'#F3F4F6',borderRadius:4,overflow:'hidden'}},
              h('div',{style:{width:pct+'%',height:'100%',background:oppColors[s.stage]||'#5091A7',borderRadius:4,transition:'width 0.5s'}}),
              h('div',{style:{position:'absolute',top:0,left:8,height:'100%',display:'flex',alignItems:'center',fontSize:10,fontWeight:700,color:'#fff'}},s.count+' ('+fmtM(s.value_m)+')')
            )
          );
        })
      ),
      h('div',null,
        h('div',{style:{fontSize:11,fontWeight:700,color:'#1a2744',marginBottom:8,textTransform:'uppercase',letterSpacing:'0.5px'}},'Capture Plan Stages'),
        cs.map(function(s,i){
          var maxC = Math.max.apply(null, cs.map(function(x){return parseInt(x.count)||1;})) || 1;
          var pct = Math.max((parseInt(s.count)||0) / maxC * 100, 8);
          return h('div',{key:i,style:{display:'flex',alignItems:'center',gap:8,marginBottom:6}},
            h('div',{style:{width:80,fontSize:10,fontWeight:600,color:'#374151',textAlign:'right'}},s.stage),
            h('div',{style:{flex:1,position:'relative',height:24,background:'#F3F4F6',borderRadius:4,overflow:'hidden'}},
              h('div',{style:{width:pct+'%',height:'100%',background:capColors[s.stage]||'#1B2A4A',borderRadius:4,transition:'width 0.5s'}}),
              h('div',{style:{position:'absolute',top:0,left:8,height:'100%',display:'flex',alignItems:'center',fontSize:10,fontWeight:700,color:'#fff'}},s.count+' (Alloc: '+fmtM(s.alloc_m)+')')
            )
          );
        })
      )
    ),
    h('div',null,
      h('div',{style:{fontSize:11,fontWeight:700,color:'#1a2744',marginBottom:8,textTransform:'uppercase',letterSpacing:'0.5px'}},'Top Opportunities by Contract Value'),
      h('div',{style:{display:'grid',gridTemplateColumns:'2fr 1fr 100px 90px 60px',gap:0,fontSize:10,fontWeight:700,color:'#6B7280',textTransform:'uppercase',padding:'6px 8px',borderBottom:'1px solid #E8ECF1'}},
        h('div',null,'Opportunity'),h('div',null,'Agency'),h('div',{style:{textAlign:'right'}},'Value'),h('div',null,'Stage'),h('div',{style:{textAlign:'right'}},'PWin')
      ),
      top.slice(0,8).map(function(o,i){
        var pw = parseInt(o.pwin)||0;
        return h('div',{key:i,style:{display:'grid',gridTemplateColumns:'2fr 1fr 100px 90px 60px',gap:0,fontSize:11,padding:'6px 8px',borderBottom:'1px solid #F3F4F6',alignItems:'center',background:i%2===0?'#FAFBFC':'#fff'}},
          h('div',{style:{fontWeight:600,color:'#1a2744',overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}},o.opp_title),
          h('div',{style:{color:'#6B7280',overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}},o.agency),
          h('div',{style:{textAlign:'right',fontWeight:600,color:'#2F5C1F'}},fmtV(o.contract_value)),
          h('div',null,h('span',{style:{fontSize:9,padding:'2px 6px',borderRadius:4,background:(capColors[o.stage]||'#1B2A4A')+'15',color:capColors[o.stage]||'#1B2A4A',fontWeight:600}},o.stage)),
          h('div',{style:{textAlign:'right',fontWeight:700,color:pw>=60?'#2F5C1F':pw>=30?'#D97706':'#DC2626'}},pw+'%')
        );
      })
    )
  );
}


function Launchpad() {
  const calcPwin = async (opp) => {
    const id = opp.id || opp.govtribe_id;
    setPwinCalcing(id);
    try {
      const d = await api.post('gda-pwin-calculator', {action:'calculate', opportunity: opp.opp_title || opp.title, agency: opp.agency, opp_id: id});
      // Reload opps to get updated pwin
      setPwinCalcing(null);
    } catch(e) { setPwinCalcing(null); }
  };
  var _opps = React.useState([]); var opps = _opps[0]; var setOpps = _opps[1];
  var _sitrep = React.useState(null); var sitrep = _sitrep[0]; var setSitrep = _sitrep[1];
  var _risks = React.useState([]); var risks = _risks[0]; var setRisks = _risks[1];
  var _intel = React.useState([]); var intel = _intel[0]; var setIntel = _intel[1];
  var _loading = React.useState(true); var loading = _loading[0]; var setLoading = _loading[1];
  var _drillDown = React.useState(null); var drillDown = _drillDown[0]; var setDrillDown = _drillDown[1];
  var _kpiDetail = React.useState(null); var kpiDetail = _kpiDetail[0]; var setKpiDetail = _kpiDetail[1];
  var _expandedDepts = React.useState({sec_latest: true, sec_pred: true}); var expandedDepts = _expandedDepts[0]; var setExpandedDepts = _expandedDepts[1];
  var _expandedOpp = React.useState(null); var _intelAlerts = React.useState([]); var intelAlerts = _intelAlerts[0]; var setIntelAlerts = _intelAlerts[1]; var expandedOpp = _expandedOpp[0]; var setExpandedOpp = _expandedOpp[1];
  var _scoringOpen = React.useState(false); var scoringOpen = _scoringOpen[0]; var setScoringOpen = _scoringOpen[1];
  var _predQuestion = React.useState(''); var predQuestion = _predQuestion[0]; var setPredQuestion = _predQuestion[1];
  var _predAnswer = React.useState(''); var predAnswer = _predAnswer[0]; var setPredAnswer = _predAnswer[1];
  var _predLoading = React.useState(false); var predLoading = _predLoading[0]; var setPredLoading = _predLoading[1];
  var _scoreBreakdown = React.useState(null); var scoreBreakdown = _scoreBreakdown[0]; var setScoreBreakdown = _scoreBreakdown[1];
  var _lpMarketDept = React.useState('Department of War'); var lpMarketDept = _lpMarketDept[0]; var setLpMarketDept = _lpMarketDept[1];
  var _trends = React.useState({}); var trends = _trends[0]; var setTrends = _trends[1];
  var _dailyActions = React.useState(null); var dailyActions = _dailyActions[0]; var setDailyActions = _dailyActions[1];
  var _daLoading = React.useState(false); var daLoading = _daLoading[0]; var setDaLoading = _daLoading[1];
  var _daDone = React.useState({}); var daDone = _daDone[0]; var setDaDone = _daDone[1];
  var _daOpen = React.useState(false); var daOpen = _daOpen[0]; var setDaOpen = _daOpen[1];

  React.useEffect(function() {
    // MEGA PREFETCH: single call replaces trends + risk + sitrep
    api.post('gda-dashboard-mega', {}).then(function(mega) {
      if (mega.trends && mega.trends.length) setIntel(mega.trends);
      if (mega.risks && mega.risks.length) setRisks(mega.risks);
      if (mega.sitrep) setSitrep(mega.sitrep);
      if (mega.stats) { window._gdaMegaStats = mega.stats; }
      if (mega.funnel) { window._gdaMegaFunnel = mega.funnel; }
    }).catch(function(){});
    api.post('gda-trends', {action:'latest'}).then(function(d) { setTrends(d.data || d || {}); }).catch(function(){});
    // Fetch daily actions (background, non-blocking)
    setDaLoading(true);
    api.post('gda-daily-actions', {}, {signal: AbortSignal.timeout(25000)}).then(function(d) { setDailyActions(d); setDaLoading(false); }).catch(function() { setDaLoading(false); });
  }, []);

  var trendArrow = function(key) {
    var v = trends[key];
    if (!v && v !== 0) return React.createElement('span', {style:{color:'#9CA3AF',fontSize:11}}, ' \u2192');
    if (v > 0) return React.createElement('span', {style:{color:'#2F5C1F',fontSize:11}}, ' \u2191' + v);
    if (v < 0) return React.createElement('span', {style:{color:'#DC2626',fontSize:11}}, ' \u2193' + Math.abs(v));
    return React.createElement('span', {style:{color:'#9CA3AF',fontSize:11}}, ' \u2192');
  };

  React.useEffect(function() {
    var done = 0;
    var safetyT = setTimeout(function() { setLoading(false); }, 8000);
    var check = function() { done++; if (done >= 2) { clearTimeout(safetyT); setLoading(false); } };

    fetchOppData()
      .then(function(r) {
        var items = [];
        if (r && r.opportunities && r.opportunities.length > 0) { items = r.opportunities; }
        else if (r && Array.isArray(r.departments)) {
          r.departments.forEach(function(d) {
            (d.agencies || []).forEach(function(a) {
              (a.programs || []).forEach(function(p) {
                items.push(Object.assign({}, p, {
                  agency: p.agency || a.agency,
                  cabinet_department: mapDepartment(a.agency) || p.cabinet_department || d.dept,
                  title: p.title || p.name,
                  response_deadline: p.response_deadline || p.due,
                  solicitation_number: p.solicitation_number || p.sol,
                  naics_code: p.naics_code || p.naics,
                  eis_fit_score: p.eis_fit_score || p.score || 0,
                  estimated_value: p.estimated_value || p.contract_value || p.value || null
                }));
              });
            });
          });
        // opportunities already handled above
        } else if (Array.isArray(r)) { items = r; } else if (r && r.opportunities) { items = r.opportunities.map(function(o) { return Object.assign({}, o, { title: o.title || o.name, cabinet_department: o.cabinet_department || o.dept || mapDepartment(o.agency) }); }); }
        if (!Array.isArray(items)) items = [];
        items = items.map(function(o) {
          return Object.assign({}, o, {
            title: o.opp_title || o.title || o.name || o.agency,
            cabinet_department: normalizeDept(o.level_1 || o.cabinet_department || o.dept || mapDepartment(o.agency)),
            level_2: o.level_2 || agencyToLevel2(o.agency),
            level_3: o.level_3 || 'Unassigned',
            eis_fit_score: o.eis_fit_score || o.fit_score || o.score || calculateEisFitScore(o)
          });
        });
        setOpps(items);
        check();
      }).catch(function() { check(); });

    // sitrep now handled by mega prefetch (S-140)

    // risks now handled by mega prefetch (S-140) — check() called inline
    check();
  }, []);

  var totalOpps = opps.length;
  var totalValue = opps.reduce(function(s, o) { return s + (parseFloat(o.estimated_value) || 0); }, 0);
  var highFitCount = opps.filter(function(o) { return (o.gda_score || 0) >= 80; }).length;
  var avgFit = totalOpps > 0 ? Math.round(opps.reduce(function(s, o) { return s + (o.gda_score || calculateGDAScore(o)); }, 0) / totalOpps) : 0;
  var redRisks = risks.filter(function(r) { var s=(r.severity||'').toUpperCase(); return s === 'CRITICAL' || s === 'HIGH'; }).length;
  var urgentOpps = opps.filter(function(o) {
    return o.response_deadline && (new Date(o.response_deadline) - new Date()) < 14 * 86400000 && (new Date(o.response_deadline) - new Date()) > 0 && !o.has_capture_plan && !o._hasCap && (o.gda_label || '') !== 'PASS';
  }).length;

  var deptData = React.useMemo(function() {
    var map = {};
    opps.forEach(function(o) {
      var rawL1 = normalizeDept(o.level_1 || o.cabinet_department || o.dept || 'Unknown');
      var d = DOD_CABINET_MAP[rawL1] || rawL1;
      if (!map[d]) map[d] = { name: d, value: 0, count: 0 };
      map[d].value += (parseFloat(o.estimated_value) || 0);
      map[d].count++;
    });
    return Object.values(map).sort(function(a, b) { return b.value - a.value; }).slice(0, 5);
  }, [opps]);

  var deptHierarchy = React.useMemo(function() {
    // Level 1: Cabinet Dept  Level 2: Military Branch (dept)  Level 3: Program
    var cabinet = {};
    // Defense Agencies bucket removed S-111 - level_2 is now clean in DB
    opps.forEach(function(o) {
      var agencyDept = o.level_1 || o.cabinet_department || o.dept || '';
      var L1 = normalizeDept(agencyDept);
      var rawL2 = cleanBranch(o.level_2 || o.agency || agencyDept || 'Unassigned');
      var L2 = rawL2;
      if (!cabinet[L1]) cabinet[L1] = { name: L1, branches: {}, opp_count: 0, total_value: 0 };
      if (!cabinet[L1].branches[L2]) cabinet[L1].branches[L2] = { name: L2, opps: [], total_value: 0 };
      cabinet[L1].branches[L2].opps.push(o);
      cabinet[L1].branches[L2].total_value += (parseFloat(o.estimated_value) || 0);
      cabinet[L1].opp_count++;
      cabinet[L1].total_value += (parseFloat(o.estimated_value) || 0);
    });
    return Object.values(cabinet)
      .sort(function(a, b) { return b.total_value - a.total_value || b.opp_count - a.opp_count; })
      .slice(0, 5)
      .map(function(c) {
        return Object.assign({}, c, {
          branches: Object.values(c.branches)
            .filter(function(br) { return br.name !== c.name; })
            .sort(function(a, b) { return b.total_value - a.total_value || b.opps.length - a.opps.length; })
            .map(function(br) {
              var sorted = br.opps.slice().sort(function(a, b) { return (b.gda_score || 0) - (a.gda_score || 0); });
              var active = sorted.filter(function(o) { return (o.gda_score || 0) >= 40 && o.gda_label !== 'PASS'; });
              var pass = sorted.filter(function(o) { return (o.gda_score || 0) < 40 || o.gda_label === 'PASS'; });
              return Object.assign({}, br, { opps: active, passOpps: pass });
            })
        });
      });
  }, [opps]);

  var fitDistribution = React.useMemo(function() {
    var high = 0, med = 0, low = 0;
    opps.forEach(function(o) { var s = o.gda_score || calculateGDAScore(o); if (s >= 80) high++; else if (s >= 60) med++; else low++;
    });
    return [
      { name: 'Pursue (80+)', value: high, fill: '#2F5C1F' },
      { name: 'Evaluate (60-79)', value: med, fill: '#D14A2A' },
      { name: 'Monitor (40-59)', value: (opps||[]).filter(function(o){var s=o.gda_score||calculateGDAScore(o);return s>=40&&s<60;}).length, fill: '#B06D32' },
      { name: 'Pass (<40)', value: (opps||[]).filter(function(o){return (o.gda_score||calculateGDAScore(o))<40;}).length, fill: '#DC2626' }
    ];
  }, [opps]);

  var stageData = React.useMemo(function() {
    var map = { Identified: 0, Qualified: 0, Capture: 0, Proposal: 0, Award: 0 };
    opps.forEach(function(o) {
      var stage = o.stage || o.status || 'Identified';
      if (map[stage] !== undefined) map[stage]++;
      else map['Identified']++;
    });
    return Object.entries(map).map(function(e) { return { name: e[0], count: e[1] }; });
  }, [opps]);

  var topOpps = React.useMemo(function() {
    return opps.slice().sort(function(a, b) { return (b.gda_score || 0) - (a.gda_score || 0); }).slice(0, 10);
  }, [opps]);

  var newsItems = React.useMemo(function() {
    if (!sitrep) return [];
    var news = sitrep.news || sitrep.top_news || sitrep.headlines || [];
    if (!Array.isArray(news)) {
      if (sitrep.intelligence && sitrep.intelligence.news) news = sitrep.intelligence.news;
      else if (sitrep.market_intelligence) news = sitrep.market_intelligence;
    }
    if (!Array.isArray(news)) return [];
    return news.slice(0, 5);
  }, [sitrep]);

  function goToTab(tabId, context) {
    if (typeof _gdaNavigate === 'function') _gdaNavigate(tabId, context);
  }

  var S = {
    page: { padding: '24px', fontFamily: 'Inter, sans-serif' },
    h2: { margin: '0 0 20px', color: '#1B2A4A', fontSize: '24px', fontWeight: 700 },
    kpiGrid: { display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(150px, 1fr))', gap: '10px', marginBottom: '16px', justifyContent: 'center' },
    kpiCard: function(accent) {
      return { background: '#fff', border: '1px solid #E8ECF1', borderRadius: '10px', padding: '16px 12px', textAlign: 'center', borderTop: '3px solid ' + (accent || '#1B2A4A'), cursor: 'pointer', transition: 'box-shadow 0.2s', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', minHeight: 100 };
    },
    kpiVal: { fontSize: '28px', fontWeight: 700, color: '#1B2A4A', margin: '4px 0', display: 'flex', alignItems: 'baseline', justifyContent: 'center', gap: 4 },
    kpiLabel: { fontSize: '11px', color: '#6B7280', textTransform: 'uppercase', letterSpacing: '0.5px', textAlign: 'center' },
    kpiSub: { fontSize: '11px', color: '#9CA3AF', marginTop: '2px', textAlign: 'center' },
    chartGrid: { display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px', marginBottom: '24px' },
    chartCard: { background: '#fff', border: '1px solid #E8ECF1', borderRadius: '10px', padding: '20px' },
    chartTitle: { fontSize: '15px', fontWeight: 600, color: '#1B2A4A', margin: '0 0 4px' },
    chartQ: { fontSize: '12px', color: '#D14A2A', margin: '0 0 16px', fontStyle: 'italic' },
    section: { background: '#fff', border: '1px solid #E8ECF1', borderRadius: '10px', padding: '20px', marginBottom: '16px' },
    sectionTitle: { fontSize: '16px', fontWeight: 600, color: '#1B2A4A', margin: '0 0 14px' },
    tblHeader: { textAlign: 'left', padding: '8px 10px', borderBottom: '2px solid #E8ECF1', color: '#1B2A4A', fontWeight: 600, fontSize: '12px', textTransform: 'uppercase', letterSpacing: '0.3px' },
    tblCell: { padding: '10px 10px', borderBottom: '1px solid #E8ECF1', fontSize: '13px', color: '#1B2A4A' },
    fitBadge: function(score) {
      var bg = score >= 30 ? '#2F5C1F15' : score >= 15 ? '#B06D3212' : '#F3F4F6';
      var fg = score >= 30 ? '#2F5C1F' : score >= 15 ? '#D14A2A' : '#6B7280';
      return { background: bg, color: fg, padding: '2px 10px', borderRadius: '12px', fontWeight: 700, fontSize: '12px' };
    },
    link: { color: '#D14A2A', textDecoration: 'none', fontWeight: 600, fontSize: '12px', cursor: 'pointer' },
    newsCard: { padding: '12px 0', borderBottom: '1px solid #E8ECF1' },
    riskItem: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '10px 0', borderBottom: '1px solid #E8ECF1', cursor: 'pointer' }
  };

  var COLORS = ['#1B2A4A', '#D14A2A', '#2F5C1F', '#32448A', '#5091A7'];

  if (loading) {
    return React.createElement('div', { style: Object.assign({}, S.page, { textAlign: 'center', paddingTop: '80px' }) },
      React.createElement('div', { style: { fontSize: '14px', color: '#6B7280' } }, 'Loading command center...')
    );
  }

  return React.createElement('div', { style: S.page },
    React.createElement('div', { style: { display: 'flex', alignItems: 'center', marginBottom: 20 } },
      React.createElement('h2', { style: Object.assign({}, S.h2, { marginBottom: 0 }) }, 'Command Center'),
      React.createElement('button', { onClick: function() { setScoringOpen(!scoringOpen); }, style: { marginLeft: 12, padding: '4px 12px', fontSize: 11, fontWeight: 600, background: scoringOpen ? '#1B2A4A' : 'transparent', color: scoringOpen ? '#fff' : '#D14A2A', border: '1.5px solid #D14A2A', borderRadius: 20, cursor: 'pointer' } }, '\ud83d\udcca How Scoring Works')
    ),
    scoringOpen && React.createElement('div', { style: { background: '#fff', border: '1px solid #E8ECF1', borderRadius: 10, padding: 20, marginBottom: 16 } },
      React.createElement('div', { style: { fontSize: 14, fontWeight: 700, color: '#1B2A4A', marginBottom: 14 } }, 'GDA Priority Score v2 (0\u2013100) \u2014 What Do I Look At Today?'),
      React.createElement('div', { style: { display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 12, marginBottom: 16 } },
        React.createElement('div', { style: { borderLeft: '4px solid #2F5C1F', borderRadius: 6, padding: '12px', background: '#2F5C1F12' } },
          React.createElement('div', { style: { fontSize: 13, fontWeight: 700, color: '#2F5C1F', marginBottom: 6 } }, 'Tier 1: NAICS & Domain Fit (40 pts)'),
          React.createElement('div', { style: { fontSize: 11, color: '#374151', lineHeight: 1.6 } }, '\u25B8 NAICS Match: 20 pts\n\u25B8 Mission Alignment: 12 pts\n\u25B8 SB NAICS Advantage: 8 pts')
        ),
        React.createElement('div', { style: { borderLeft: '4px solid #D14A2A', borderRadius: 6, padding: '12px', background: '#B06D3212' } },
          React.createElement('div', { style: { fontSize: 13, fontWeight: 700, color: '#D14A2A', marginBottom: 6 } }, 'Tier 2: Competitive Position (30 pts)'),
          React.createElement('div', { style: { fontSize: 11, color: '#374151', lineHeight: 1.6 } }, '\u25B8 Recompete/Incumbent: 15 pts\n\u25B8 Set-Aside Match: 8 pts\n\u25B8 IDIQ Vehicle Held: 7 pts')
        ),
        React.createElement('div', { style: { borderLeft: '4px solid #B06D32', borderRadius: 6, padding: '12px', background: '#B06D3212' } },
          React.createElement('div', { style: { fontSize: 13, fontWeight: 700, color: '#B06D32', marginBottom: 6 } }, 'Tier 3: Urgency (15 pts)'),
          React.createElement('div', { style: { fontSize: 11, color: '#374151', lineHeight: 1.6 } }, '\u25B8 Days to Action (hybrid): 15 pts\n\u25B8 Soonest of your milestone or gov deadline')
        ),
        React.createElement('div', { style: { borderLeft: '4px solid #32448A', borderRadius: 6, padding: '12px', background: '#32448A12' } },
          React.createElement('div', { style: { fontSize: 13, fontWeight: 700, color: '#32448A', marginBottom: 6 } }, 'Tier 4: Strategic Value (15 pts)'),
          React.createElement('div', { style: { fontSize: 11, color: '#374151', lineHeight: 1.6 } }, '\u25B8 Contract Value: 8 pts\n\u25B8 Gateway Effect: 7 pts')
        )
      ),
      React.createElement('div', { style: { background: '#FEF3C7', border: '1px solid #F59E0B', borderRadius: 6, padding: '8px 12px', marginBottom: 12, fontSize: 11, color: '#92400E' } }, '\u26A0 Auto-PASS: Opportunities within 30 days of deadline with no capture plan are automatically scored 0 and marked PASS.'),
      React.createElement('div', { style: { display: 'flex', gap: 16, fontSize: 11, color: '#374151' } },
        React.createElement('span', null, React.createElement('span', { style: { display: 'inline-block', width: 10, height: 10, borderRadius: 2, background: '#2F5C1F', marginRight: 4, verticalAlign: 'middle' } }), '75\u2013100: PURSUE'),
        React.createElement('span', null, React.createElement('span', { style: { display: 'inline-block', width: 10, height: 10, borderRadius: 2, background: '#D14A2A', marginRight: 4, verticalAlign: 'middle' } }), '60\u201379: EVALUATE'),
        React.createElement('span', null, React.createElement('span', { style: { display: 'inline-block', width: 10, height: 10, borderRadius: 2, background: '#B06D32', marginRight: 4, verticalAlign: 'middle' } }), '40\u201359: MONITOR'),
        React.createElement('span', null, React.createElement('span', { style: { display: 'inline-block', width: 10, height: 10, borderRadius: 2, background: '#9CA3AF', marginRight: 4, verticalAlign: 'middle' } }), '0\u201339: PASS')
      )
    ),
    React.createElement(GDAKpiBar, {
      items: [
        { id: 'opps', label: 'Active Opportunities', sparkData: trends.opp_count_history || [], value: opps.filter(function(o){return (o.gda_score || calculateGDAScore(o)) >= 40;}).length, color: '#1B2A4A', sub: 'from GovTribe + manual', trend: null, detail: totalOpps + ' active opportunities tracked across ' + (function() { var d = {}; opps.forEach(function(o) { d[o.cabinet_department || 'Other'] = 1; }); return Object.keys(d).length; })() + ' departments. Data sourced from GovTribe MCP and SAM.gov.' },
        { id: 'value', label: 'Opportunity Value', sparkData: trends.pipeline_history || [], value: totalValue > 0 ? formatDollar(totalValue) : '$0', color: '#2F5C1F', sub: (function(){ var c = (opps||[]).filter(function(o){return parseFloat(o.estimated_value)>0;}).length; return c + ' of ' + totalOpps + ' opps valued'; })(), trend: null, detail: formatDollar(totalValue) + ' total estimated contract value across all ' + totalOpps + ' tracked opportunities.' },
        { id: 'highfit', label: 'Pursue (80+)', sparkData: trends.highfit_history || [], value: highFitCount, color: '#1B2A4A', sub: 'scoring 80+ GDA', trend: null, detail: highFitCount + ' opportunities scoring 80+ on GDA Priority Score. These are the highest priority for BD investment.' },
        { id: 'avgfit', label: 'Avg GDA Score', sparkData: trends.score_history || [], value: avgFit, color: '#1B2A4A', sub: 'across all opportunities', trend: null, detail: 'Average GDA Score of ' + avgFit + '. 80+ = PURSUE, 60-79 = EVALUATE, 40-59 = MONITOR, <40 = PASS.' },
        { id: 'risks', label: 'Active Risks', sparkData: trends.risk_history || [], value: redRisks, color: redRisks > 0 ? '#DC2626' : '#1B2A4A', sub: risks.length + ' total tracked', trend: null, detail: redRisks + ' critical/high risks out of ' + risks.length + ' total. Review risk register for details.' },
        { id: 'urgent', label: 'Due in 14 Days', sparkData: trends.urgent_history || [], value: urgentOpps, color: urgentOpps > 5 ? '#B06D32' : '#1B2A4A', sub: 'response deadlines', trend: null, detail: urgentOpps + ' opportunities with response deadlines in the next 14 days.' }
      ],
      detail: kpiDetail,
      setDetail: setKpiDetail
    }),
    
        React.createElement(LaunchpadFunnel, null),

    React.createElement('div', { style: { display: 'grid', gridTemplateColumns: '2fr 1fr', gap: '16px', alignItems: 'stretch', marginBottom: '16px', overflow: 'hidden' } },
    (function() {
      var mktData = DEPT_MARKET_DATA[lpMarketDept] || DEPT_MARKET_DATA['Department of War'];
      return React.createElement('div', { style: { background: '#fff', border: '1px solid #E8ECF1', borderRadius: '10px', padding: '20px' } },
        React.createElement('div', { style: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 } },
          React.createElement('div', null,
            React.createElement('h3', { style: S.chartTitle },
              'Market Analysis',
              React.createElement('span', { title: 'SAM: Real GovTribe award data (trailing 12mo) across 16 GDA NAICS codes. $53.6B total, 62,122 awards. SOM: Active opportunity value ($310.8M across 32 tracked opps). Updated 2026-03-18.', style: { cursor: 'help', marginLeft: 8, fontSize: 14, color: '#9CA3AF' } }, '\u24D8')
            ),
            React.createElement('p', { style: Object.assign({}, S.chartQ, { margin: 0 }) }, 'PAM / TAM / SAM / SOM sizing for federal IT & advisory services')
          ),
          React.createElement('select', {
            value: lpMarketDept,
            onChange: function(e) { setLpMarketDept(e.target.value); },
            style: { fontSize: 12, padding: '4px 8px', borderRadius: 4, border: '1px solid #D1D5DB' }
          },
            Object.keys(DEPT_MARKET_DATA).map(function(d) {
              return React.createElement('option', { key: d, value: d }, d);
            })
          )
        ),
        React.createElement('div', { style: { display: 'flex', alignItems: 'flex-start', gap: 12, flexDirection: 'column' } },
          React.createElement('svg', { viewBox: '0 0 520 220', preserveAspectRatio: 'xMidYMid meet', style: { width: '100%', maxWidth: 500, height: 'auto', display: 'block', margin: '0 auto' } },
            React.createElement('circle', { cx: 105, cy: 110, r: 100, fill: '#1B2A4A', opacity: 0.85 }),
            React.createElement('circle', { cx: 257, cy: 110, r: 82, fill: '#D14A2A', opacity: 0.82 }),
            React.createElement('circle', { cx: 377, cy: 110, r: 62, fill: '#C4960C', opacity: 0.8 }),
            React.createElement('circle', { cx: 465, cy: 110, r: 44, fill: '#2F5C1F', opacity: 0.82 }),
            React.createElement('text', { x: 105, y: 105, fill: '#fff', fontSize: 17, fontWeight: 'bold', textAnchor: 'middle' }, formatMarketVal(mktData.pam)),
            React.createElement('text', { x: 105, y: 125, fill: 'rgba(255,255,255,0.85)', fontSize: 13, fontWeight: 700, textAnchor: 'middle' }, 'PAM'),
            React.createElement('text', { x: 257, y: 105, fill: '#fff', fontSize: 15, fontWeight: 'bold', textAnchor: 'middle' }, formatMarketVal(mktData.tam)),
            React.createElement('text', { x: 257, y: 123, fill: 'rgba(255,255,255,0.85)', fontSize: 12, fontWeight: 700, textAnchor: 'middle' }, 'TAM'),
            React.createElement('text', { x: 377, y: 105, fill: '#fff', fontSize: 13, fontWeight: 'bold', textAnchor: 'middle' }, formatMarketVal(mktData.sam)),
            React.createElement('text', { x: 377, y: 123, fill: 'rgba(255,255,255,0.9)', fontSize: 10, fontWeight: 700, textAnchor: 'middle' }, 'SAM'),
            React.createElement('text', { x: 465, y: 107, fill: '#fff', fontSize: 11, fontWeight: 'bold', textAnchor: 'middle' }, formatMarketVal(mktData.som)),
            React.createElement('text', { x: 465, y: 122, fill: 'rgba(255,255,255,0.9)', fontSize: 9, fontWeight: 700, textAnchor: 'middle' }, 'SOM')
          ),
          React.createElement('div', { style: { fontSize: 12, color: '#374151', lineHeight: 1.4 } },
            React.createElement('div', { style: { marginBottom: 2 } },
              React.createElement('div', null,
                React.createElement('span', { style: { display: 'inline-block', width: 10, height: 10, borderRadius: '50%', background: '#1B2A4A', marginRight: 6, verticalAlign: 'middle' } }),
                React.createElement('span', { style: { fontWeight: 700 } }, 'PAM \u2013 Potential Addressable Market'),
                React.createElement('span', { style: { color: '#6B7280', fontSize: 10 } }, ' = Total U.S. federal IT & advisory spending for selected department. Source: USASpending.gov + OMB IT Dashboard.')
              )
            ),
            React.createElement('div', { style: { marginBottom: 2 } },
              React.createElement('div', null,
                React.createElement('span', { style: { display: 'inline-block', width: 10, height: 10, borderRadius: '50%', background: '#D14A2A', marginRight: 6, verticalAlign: 'middle' } }),
                React.createElement('span', { style: { fontWeight: 700 } }, 'TAM \u2013 Total Addressable Market'),
                React.createElement('span', { style: { color: '#6B7280', fontSize: 10 } }, ' = Subset of PAM matching GDA\u2019s 16 NAICS codes (541511\u2013541690, 517410\u2013518210, 561210\u2013611430). Source: FPDS + SAM.gov trailing 12 months.')
              )
            ),
            React.createElement('div', { style: { marginBottom: 2 } },
              React.createElement('div', null,
                React.createElement('span', { style: { display: 'inline-block', width: 10, height: 10, borderRadius: '50%', background: '#C4960C', marginRight: 6, verticalAlign: 'middle' } }),
                React.createElement('span', { style: { fontWeight: 700 } }, 'SAM \u2013 Serviceable Available Market'),
                React.createElement('span', { style: { color: '#6B7280', fontSize: 10 } }, ' = TAM filtered by set-aside eligibility, geographic reach, clearance level, and past performance. Source: GovTribe MCP \u2014 $53.6B across 62,122 awards.')
              )
            ),
            React.createElement('div', { style: { marginBottom: 2 } },
              React.createElement('div', null,
                React.createElement('span', { style: { display: 'inline-block', width: 10, height: 10, borderRadius: '50%', background: '#2F5C1F', marginRight: 6, verticalAlign: 'middle' } }),
                React.createElement('span', { style: { fontWeight: 700 } }, 'SOM \u2013 Serviceable & Obtainable Market'),
                React.createElement('span', { style: { color: '#6B7280', fontSize: 10 } }, ' = Active opportunity value from OppTracker. Currently ' + formatDollar(totalValue) + ' across ' + totalOpps + ' tracked opportunities.')
              )
            ),
          )
        )
      );
    })(),
    React.createElement('div', { style: { background: '#fff', border: '1px solid #E8ECF1', borderRadius: '10px', padding: '20px', display: 'flex', flexDirection: 'column', justifyContent: 'flex-start', minHeight: 0, overflow: 'hidden', minWidth: 0 } },
      React.createElement('h3', { style: { fontSize: 14, fontWeight: 700, color: '#1B2A4A', margin: '0 0 4px' } }, 'Upcoming Deadlines'),
      React.createElement('p', { style: { fontSize: 11, color: '#8492A6', margin: '0 0 14px' } }, 'Next opportunities requiring action'),
      (function() {
        var now = new Date();
        var upcoming = (opps || []).filter(function(o) {
          var d = o.due_date || o.deadline || o.response_deadline;
          return d && new Date(d) >= now && (o.gda_label || '') !== 'PASS';
        }).sort(function(a,b) {
          return new Date(a.due_date || a.deadline || a.response_deadline) - new Date(b.due_date || b.deadline || b.response_deadline);
        });
        var overduePursue = (opps || []).filter(function(o) { var d = o.response_deadline || o.due_date || o.deadline; return d && new Date(d) < now && (o.gda_label === 'PURSUE' || o.gda_label === 'EVALUATE'); });
        var overdueEl = (overduePursue.length > 0) ? React.createElement('div', { style: { padding: '8px 12px', background: '#FEE2E2', borderRadius: 6, borderLeft: '3px solid #DC2626', marginBottom: 10 } },
              React.createElement('div', { style: { fontSize: 11, fontWeight: 700, color: '#DC2626', marginBottom: 4 } }, '⚠ ' + overduePursue.length + ' Overdue PURSUE/EVALUATE'),
              overduePursue.slice(0,3).map(function(o, idx) {
                var d = o.response_deadline || o.due_date || o.deadline;
                var daysAgo = Math.abs(Math.ceil((new Date(d) - now) / 86400000));
                return React.createElement('div', { key: idx, style: { fontSize: 11, color: '#374151', padding: '2px 0' } }, '• ' + (o.opp_title||'').substring(0,50) + ' — ' + daysAgo + 'd ago');
              })
            ) : null;
        var groups = [
          {label:'< 30 Days', color:'#DC2626', bg:'#FEE2E2', items: upcoming.filter(function(o){var d=Math.ceil((new Date(o.due_date||o.deadline||o.response_deadline)-now)/86400000);return d<=30;})},
          {label:'30-60 Days', color:'#D14A2A', bg:'#FFF3E0', items: upcoming.filter(function(o){var d=Math.ceil((new Date(o.due_date||o.deadline||o.response_deadline)-now)/86400000);return d>30&&d<=60;})},
          {label:'60-90 Days', color:'#B06D32', bg:'#FEF3C7', items: upcoming.filter(function(o){var d=Math.ceil((new Date(o.due_date||o.deadline||o.response_deadline)-now)/86400000);return d>60&&d<=90;})},
          {label:'> 90 Days', color:'#2F5C1F', bg:'#E8F5E9', items: upcoming.filter(function(o){var d=Math.ceil((new Date(o.due_date||o.deadline||o.response_deadline)-now)/86400000);return d>90;})}
        ];
        return React.createElement('div', { style: { flex: 1 } },
          overdueEl,
          groups.filter(function(g){return g.items.length>0;}).map(function(g, gi) {
            var gKey = 'dl_' + gi;
            var gOpen = expandedDepts[gKey];
            return React.createElement('div', { key: gi, style: { marginBottom: 4 } },
              React.createElement('div', { onClick: function() { var n = Object.assign({}, expandedDepts); n[gKey] = !n[gKey]; setExpandedDepts(n); }, style: { display: 'flex', justifyContent: 'space-between', padding: '5px 8px', background: g.bg, borderRadius: 4, cursor: 'pointer', fontSize: 11, fontWeight: 700, color: g.color } },
                React.createElement('span', null, (gOpen ? '\u25BC ' : '\u25B6 ') + g.label),
                React.createElement('span', null, g.items.length)
              ),
              gOpen && g.items.slice(0,10).map(function(o, i) {
                var due = new Date(o.due_date || o.deadline || o.response_deadline);
                var days = Math.ceil((due - now) / 86400000);
                return React.createElement('div', { key: i, style: { display: 'flex', alignItems: 'center', gap: 6, padding: '3px 8px', borderBottom: '1px solid #F3F4F6', cursor: 'pointer' }, onClick: function() { gdaNav.oppTarget = { id: o.id, solicitation: o.solicitation_number, title: o.opp_title || o.title }; if (window._gdaNavigate) window._gdaNavigate('opp-tracker'); } },
                  React.createElement('span', { style: { minWidth: 28, fontSize: 11, fontWeight: 700, color: g.color } }, days + 'd'),
                  React.createElement('span', { style: { flex: 1, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', fontSize: 11, color: '#1B2A4A' } }, o.opp_title || o.title || o.name || 'Untitled'),
                  React.createElement('span', { style: { color: '#6B7280', fontSize: 10, flexShrink: 0, fontWeight: 600 } }, (o.stage || o.pipeline_stage || '')),
                  React.createElement('span', { style: { color: '#2F5C1F', fontWeight: 600, flexShrink: 0, fontSize: 11 } }, formatDollar(parseFloat(String(o.estimated_value || '0').replace(/[$,]/g, '')) || 0))
                );
              })
            );
          })
        );
      })()
    )
    ),
    React.createElement('div', { style: S.section },
      React.createElement('div', { style: { display: 'flex', gap: '10px', marginBottom: '20px' } },
      React.createElement('div', { style: { background: '#fff', border: '1px solid #E8ECF1', borderRadius: '8px', padding: '10px 16px', textAlign: 'center' } },
        React.createElement('div', { style: { fontSize: 20, fontWeight: 700, color: '#2F5C1F' } }, (opps || []).filter(function(o) { return (o.gda_score || calculateGDAScore(o)) >= 80; }).length),
        React.createElement('div', { style: { fontSize: 10, color: '#6B7280' } }, 'Pursue (80+)')
      ),
      React.createElement('div', { style: { background: '#fff', border: '1px solid #E8ECF1', borderRadius: '8px', padding: '10px 16px', textAlign: 'center' } },
        React.createElement('div', { style: { fontSize: 20, fontWeight: 700, color: '#D14A2A' } }, (opps || []).filter(function(o) { var s = o.gda_score || calculateGDAScore(o); return s >= 60 && s < 80; }).length),
        React.createElement('div', { style: { fontSize: 10, color: '#6B7280' } }, 'Evaluate (60-79)')
      ),
      React.createElement('div', { style: { background: '#fff', border: '1px solid #E8ECF1', borderRadius: '8px', padding: '10px 16px', textAlign: 'center' } },
        React.createElement('div', { style: { fontSize: 20, fontWeight: 700, color: '#B06D32' } }, (opps || []).filter(function(o) { var s = o.gda_score || calculateGDAScore(o); return s >= 40 && s < 60; }).length),
        React.createElement('div', { style: { fontSize: 10, color: '#6B7280' } }, 'Monitor (40-59)')
      ),
      React.createElement('div', { style: { background: '#fff', border: '1px solid #E8ECF1', borderRadius: '8px', padding: '10px 16px', textAlign: 'center' } },
        React.createElement('div', { style: { fontSize: 20, fontWeight: 700, color: '#DC2626' } }, (opps || []).filter(function(o) { return (o.gda_score || calculateGDAScore(o)) < 40; }).length),
        React.createElement('div', { style: { fontSize: 10, color: '#6B7280' } }, 'Pass (<40)')
      )
    ),
    React.createElement('div', { style: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '14px', marginTop: '24px' } },
      React.createElement('h3', { style: S.sectionTitle }, 'Top 10 Opportunities by GDA Score'),
      React.createElement('span', { style: S.link, onClick: function() { goToTab('opp-tracker'); } }, 'View All in Opp Tracker')
    ),
    React.createElement('table', { style: { width: '100%', borderCollapse: 'collapse' } },
        React.createElement('thead', null,
          React.createElement('tr', null,
            React.createElement('th', { style: S.tblHeader }, 'Opportunity'),
            React.createElement('th', { style: S.tblHeader }, 'Agency'),
            React.createElement('th', { style: S.tblHeader }, 'Department'),
            React.createElement('th', { style: S.tblHeader }, 'GDA Score', ),
            React.createElement('th', { style: S.tblHeader }, 'Value'),
            
            React.createElement('th', { style: S.tblHeader }, 'Action')
          )
        ),
        React.createElement('tbody', null,
          topOpps.map(function(opp, idx) {
            var fitScore = opp.gda_score || calculateGDAScore(opp);
            var deadlineStr = opp.response_deadline ? new Date(opp.response_deadline).toLocaleDateString() : '--';
            return React.createElement('tr', { key: opp.govtribe_id || idx, style: { background: idx % 2 === 0 ? '#fff' : '#F8F9FB' } },
              React.createElement('td', { style: Object.assign({}, S.tblCell, { fontWeight: 500, maxWidth: '250px' }) },
                opp.title ? (opp.title.length > 60 ? opp.title.substring(0, 60) + '...' : opp.title) : 'Untitled'
              ),
              React.createElement('td', { style: S.tblCell }, opp.agency || opp.level_2 || opp.federal_agency || 'N/A'),
              React.createElement('td', { style: S.tblCell }, opp.level_1 || opp.cabinet_department || opp.dept || '--'),
              React.createElement('td', { style: Object.assign({}, S.tblCell, { cursor: 'pointer' }), onClick: function() { setScoreBreakdown(opp); } }, React.createElement(GDAScoreBadge, {score: fitScore})),
              React.createElement('td', { style: S.tblCell }, formatDollar(opp.estimated_value)),
              
              React.createElement('td', { style: S.tblCell },
                React.createElement('span', { style: S.link, onClick: function() { window._gdaOodaTarget = { target: opp.opp_title || opp.title || opp.name || '', target_type: 'opportunity', agency: opp.agency || opp.level_2 || '', auto_run: true }; gdaNav.oodaTarget = { name: opp.opp_title || opp.title || opp.name || '', agency: opp.agency || opp.level_2 || '', department: opp.level_1 || '', solicitation: opp.solicitation_number || '', type: 'Opportunity', autoTrigger: true }; goToTab('ooda'); } }, 'Analyze'),
                (function() { var srcUrl = opp.source_url && opp.source_url !== 'https://sam.gov' && opp.source_url !== 'https://www.sam.gov' ? opp.source_url : null; var solNum = opp.solicitation_number; var isRealSam = solNum && !/^MAS-|^GDA-|^MOCK|^TEST/i.test(solNum) && solNum.length > 8; var href = srcUrl || (isRealSam ? 'https://sam.gov/opp/' + encodeURIComponent(solNum) + '/view' : null) || 'https://govtribe.com/search#/opportunity?query=' + encodeURIComponent(opp.opp_title || opp.title || ''); return React.createElement('a', { href: href, target: '_blank', rel: 'noopener', style: Object.assign({}, S.link, { marginLeft: '10px' }) }, 'Source'); })()
              )
            );
          }),
          topOpps.length === 0 && React.createElement('tr', null,
            React.createElement('td', { colSpan: 7, style: { padding: '20px', textAlign: 'center', color: '#9CA3AF' } }, 'No opportunities loaded')
          )
        )
      )
    ),
    
    React.createElement('div', { style: { marginBottom: '16px' } },
      // S-109: AI DAILY ACTIONS
      React.createElement('div', { style: { background: '#fff', border: '1px solid #E8ECF1', borderRadius: 10, marginBottom: 16, overflow: 'hidden' } },
        React.createElement('div', { onClick: function() { setDaOpen(!daOpen); }, style: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '14px 18px', cursor: 'pointer', background: daOpen ? '#1B2A4A' : '#fff', color: daOpen ? '#fff' : '#1B2A4A', transition: 'all 0.2s' } },
          React.createElement('div', { style: { display: 'flex', alignItems: 'center', gap: 10 } },
            React.createElement('span', { style: { fontSize: 12, transform: daOpen ? 'rotate(90deg)' : 'rotate(0deg)', transition: 'transform 0.2s' } }, '\u25B6'),
            React.createElement('span', { style: { fontWeight: 700, fontSize: 14 } }, 'AI DAILY ACTIONS'),
            dailyActions && React.createElement('span', { style: { background: daOpen ? 'rgba(255,255,255,0.2)' : '#C65D21', color: '#fff', borderRadius: 12, padding: '2px 10px', fontSize: 11, fontWeight: 600 } }, dailyActions.action_count || 0),
            daLoading && React.createElement('span', { style: { fontSize: 11, color: daOpen ? '#9CA3AF' : '#6B7280' } }, 'Loading...')
          ),
          dailyActions && dailyActions.generated_at && React.createElement('span', { style: { fontSize: 11, color: daOpen ? '#9CA3AF' : '#9CA3AF' } }, (function() { var m = Math.round((Date.now() - new Date(dailyActions.generated_at).getTime()) / 60000); return m < 1 ? 'Just now' : m < 60 ? m + 'm ago' : Math.round(m/60) + 'h ago'; })())
        ),
        daOpen && React.createElement('div', { style: { padding: 18, borderTop: '1px solid #E8ECF1' } },
          dailyActions && dailyActions.summary && React.createElement('div', { style: { background: '#F0F4FF', borderRadius: 8, padding: '10px 14px', marginBottom: 14, fontSize: 12, color: '#1B2A4A', lineHeight: 1.6, borderLeft: '3px solid #C65D21' } }, dailyActions.summary),
          daLoading && !dailyActions && React.createElement('div', { style: { textAlign: 'center', padding: 30 } }, React.createElement(Spinner), React.createElement('div', { style: { fontSize: 11, color: '#6B7280', marginTop: 8 } }, 'AI generating daily actions (12-16s)...')),
          dailyActions && dailyActions.actions && dailyActions.actions.filter(function(a) { return !daDone[a.opp_id || a.action]; }).map(function(a, i) {
            var urgColor = (a.urgency || '').toUpperCase() === 'URGENT' ? '#ef4444' : (a.urgency || '').toUpperCase() === 'HIGH' ? '#f59e0b' : '#3b82f6';
            var catColors = { Capture: '#C65D21', Risk: '#DC2626', Teaming: '#32448A', Pipeline: '#2F5C1F', Competitive: '#B06D32' };
            return React.createElement('div', { key: i, style: { background: '#fff', border: '1px solid #E8ECF1', borderLeft: '4px solid ' + urgColor, borderRadius: 8, padding: '12px 14px', marginBottom: 8 } },
              React.createElement('div', { style: { display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 6 } },
                React.createElement('div', { style: { display: 'flex', gap: 6, alignItems: 'center' } },
                  React.createElement('span', { style: { padding: '2px 8px', borderRadius: 4, fontSize: 11, fontWeight: 700, background: urgColor + '22', color: urgColor, textTransform: 'uppercase', fontFamily: 'monospace' } }, a.urgency || 'MEDIUM'),
                  a.category && React.createElement('span', { style: { padding: '2px 8px', borderRadius: 4, fontSize: 11, fontWeight: 600, background: (catColors[a.category] || '#6B7280') + '15', color: catColors[a.category] || '#6B7280' } }, a.category)
                ),
                a.deadline && React.createElement('span', { style: { fontSize: 11, color: '#DC2626', fontWeight: 600 } }, a.deadline)
              ),
              React.createElement('div', { style: { fontSize: 13, color: '#1B2A4A', lineHeight: 1.6, marginBottom: 8 } }, a.action),
              React.createElement('div', { style: { display: 'flex', gap: 8, alignItems: 'center' } },
                a.source_link && React.createElement('a', { href: a.source_link, target: '_blank', rel: 'noopener', style: { fontSize: 11, color: '#C65D21', fontWeight: 600, textDecoration: 'none' } }, 'Source \u2192'),
                a.opp_id && React.createElement('span', { onClick: function() { gdaNav.oppTarget = { id: a.opp_id, title: a.opp_title }; goToTab('opp-tracker'); }, style: { fontSize: 11, color: '#32448A', fontWeight: 600, cursor: 'pointer' } }, 'View Opp \u2192'),
                React.createElement('button', { onClick: function() { var key = a.opp_id || a.action; setDaDone(function(p) { var n = Object.assign({}, p); n[key] = true; return n; }); api.post('gda-data-learn', { event: 'daily_action_completed', data_type: 'interaction', source: 'launchpad', content: JSON.stringify({ action: a.action, opp_id: a.opp_id, completed_at: new Date().toISOString() }) }).catch(function() {}); }, style: { marginLeft: 'auto', padding: '4px 12px', background: '#fff', border: '1px solid #E8ECF1', borderRadius: 6, fontSize: 11, color: '#2F5C1F', fontWeight: 600, cursor: 'pointer' } }, 'Mark Done')
              )
            );
          }),
          dailyActions && dailyActions.actions && Object.keys(daDone).length > 0 && React.createElement('div', { style: { fontSize: 11, color: '#2F5C1F', textAlign: 'center', padding: 6 } }, Object.keys(daDone).length + ' action(s) completed'),
          React.createElement('button', { onClick: function() { setDaLoading(true); setDailyActions(null); api.post('gda-daily-actions', {}, {signal: AbortSignal.timeout(25000)}).then(function(d) { setDailyActions(d); setDaLoading(false); }).catch(function() { setDaLoading(false); }); }, disabled: daLoading, style: { marginTop: 8, padding: '6px 16px', background: '#C65D21', color: '#fff', border: 'none', borderRadius: 6, fontSize: 12, fontWeight: 700, cursor: 'pointer', opacity: daLoading ? 0.5 : 1 } }, daLoading ? 'Generating...' : 'Refresh Actions')
        )
      ),

      React.createElement('div', { style: S.section },
        React.createElement('div', { style: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: expandedDepts['sec_latest'] ? '14px' : '0', cursor: 'pointer' }, onClick: function() { var n = Object.assign({}, expandedDepts); n['sec_latest'] = !n['sec_latest']; setExpandedDepts(n); } },
          React.createElement('h3', { style: Object.assign({}, S.sectionTitle, { margin: 0 }) }, (expandedDepts['sec_latest'] ? '▼ ' : '▶ ') + 'Latest Intelligence'),
          React.createElement('span', { style: S.link, onClick: function(e) { e.stopPropagation(); goToTab('sitrep'); } }, 'View Full SITREP →')
        ),
        expandedDepts['sec_latest'] && (function() {
          var synthesis = sitrep && (sitrep.strategic_synthesis || (sitrep.bluf && sitrep.bluf[0]));
          var pipelineStatus = sitrep && sitrep.pipeline_status;
          var criticalActions = sitrep && sitrep.critical_actions;
          if (synthesis || newsItems.length > 0) {
            return React.createElement('div', null,
              synthesis && React.createElement('div', {
                style: { background: '#F0F4FF', borderRadius: 8, padding: '10px 12px', marginBottom: 10, fontSize: 12, color: '#1B2A4A', lineHeight: 1.6, borderLeft: '3px solid #D14A2A' }
              }, synthesis.length > 300 ? synthesis.slice(0, 300) + '...' : synthesis),
              pipelineStatus && React.createElement('div', {
                style: { display: 'flex', gap: 8, flexWrap: 'wrap', marginBottom: 10 }
              },
                [
                  { label: 'Opportunities', val: '$' + (pipelineStatus.total_value_m || 0) + 'M', color: '#1B2A4A' },
                  { label: 'Proposals', val: pipelineStatus.proposal_count || 0, color: '#2F5C1F' },
                  { label: 'Capture', val: pipelineStatus.capture_count || 0, color: '#D14A2A' },
                ].map(function(kpi) {
                  return React.createElement('div', { key: kpi.label, style: { background: '#F8FAFC', borderRadius: 6, padding: '4px 10px', fontSize: 11 } },
                    React.createElement('span', { style: { color: '#9CA3AF' } }, kpi.label + ': '),
                    React.createElement('span', { style: { fontWeight: 700, color: kpi.color } }, String(kpi.val))
                  );
                })
              ),
              criticalActions && criticalActions.length > 0 && React.createElement('div', { style: { marginBottom: 8 } },
                React.createElement('div', { style: { fontSize: 10, fontWeight: 700, color: '#DC2626', marginBottom: 4, letterSpacing: '0.5px' } }, 'CRITICAL ACTIONS'),
                criticalActions.slice(0, 2).map(function(a, i) {
                  return React.createElement('div', { key: i, style: { fontSize: 11, color: '#374151', padding: '2px 0', display: 'flex', gap: 6, cursor: 'pointer' }, onClick: function() { if (a && (a.risk_id || a.risk_title)) { gdaNav.riskTarget = a.risk_id || a.risk_title; goToTab('risk'); } else { goToTab('actions'); } } },
                    React.createElement('span', { style: { color: '#DC2626', fontWeight: 700 } }, (i+1) + '.'),
                    React.createElement('span', null, typeof a === 'string' ? a : (a.action || JSON.stringify(a)))
                  );
                })
              ),
              newsItems.length > 0 && React.createElement('div', null,
                React.createElement('div', { style: { fontSize: 10, fontWeight: 700, color: '#9CA3AF', marginBottom: 6, letterSpacing: '0.5px' } }, 'MARKET INTEL'),
                newsItems.slice(0, 3).map(function(item, idx) {
                  var title = item.title || item.headline || item.name || 'Intel Update';
                  var url = item.url || item.source_url || item.link || null;
                  var srcLabel = item.source_label || item.source || null;
                  return React.createElement('div', { key: idx, style: { ...S.newsCard } },
                    React.createElement('div', { style: { display: 'flex', alignItems: 'flex-start', flexWrap: 'wrap', gap: 4 } },
                      url ? React.createElement('a', {
                        href: url, target: '_blank', rel: 'noopener',
                        style: { color: '#1B2A4A', textDecoration: 'none', fontSize: '12px', fontWeight: 500, lineHeight: '1.4' }
                      }, title) : React.createElement('span', { style: { fontSize: '12px', fontWeight: 500, color: '#1B2A4A' } }, title),
                      srcLabel && React.createElement(SourceTag, { url: url, label: srcLabel })
                    ),
                    url && React.createElement('div', { style: { fontSize: '10px', color: '#D14A2A', marginTop: '2px' } },
                      React.createElement('a', { href: url, target: '_blank', rel: 'noopener', style: { color: '#D14A2A', textDecoration: 'none' } }, 'Read →')
                    )
                  );
                })
              ),
              newsItems.length === 0 && intelAlerts.length > 0 && React.createElement('div', null,
                React.createElement('div', { style: { fontSize: 10, fontWeight: 700, color: '#9CA3AF', marginBottom: 6, letterSpacing: '0.5px' } }, 'OPPORTUNITY ALERTS'),
                intelAlerts.slice(0, 5).map(function(alert, idx) {
                  var title = alert.title || alert.opp_title || 'Alert';
                  var url = alert.source_url || alert.url || null;
                  return React.createElement('div', { key: idx, style: { padding: '6px 0', borderBottom: '1px solid #F0F1F4', fontSize: 12 } },
                    React.createElement('div', { style: { display: 'flex', justifyContent: 'space-between', alignItems: 'center' } },
                      url ? React.createElement('a', { href: url, target: '_blank', rel: 'noopener', style: { color: '#1B2A4A', textDecoration: 'none', fontWeight: 500, flex: 1 } }, title.length > 60 ? title.substring(0, 60) + '...' : title)
                        : React.createElement('span', { style: { fontWeight: 500, color: '#1B2A4A', flex: 1 } }, title.length > 60 ? title.substring(0, 60) + '...' : title),
                      alert.agency && React.createElement('span', { style: { fontSize: 10, color: '#6B7280', flexShrink: 0, marginLeft: 8 } }, alert.agency)
                    ),
                    alert.ai_fit_reasoning && React.createElement('div', { style: { fontSize: 11, color: '#6B7280', marginTop: 2 } }, alert.ai_fit_reasoning.substring(0, 100)),
                    alert.due_date && React.createElement('span', { style: { fontSize: 10, color: '#D14A2A' } }, 'Due: ' + new Date(alert.due_date).toLocaleDateString())
                  );
                })
              )
            );
          }
          return React.createElement('div', { style: { padding: '20px', textAlign: 'center', color: '#9CA3AF', fontSize: '13px' } },
            React.createElement('div', { style: { marginBottom: 8 } }, 'No SITREP generated today'),
            React.createElement('button', {
              onClick: function() { goToTab('sitrep'); },
              style: { padding: '6px 14px', borderRadius: 6, border: 'none', background: '#D14A2A', color: '#fff', fontSize: 11, fontWeight: 600, cursor: 'pointer' }
            }, 'Generate SITREP →')
          );
        })()
      )
    ),
    scoreBreakdown && React.createElement('div', {
      style: { position: 'fixed', inset: 0, background: 'rgba(27,42,74,0.5)', zIndex: 10000, display: 'flex', alignItems: 'center', justifyContent: 'center' },
      onClick: function(e) { if (e.target === e.currentTarget) setScoreBreakdown(null); }
    },
      React.createElement('div', { style: { background: '#fff', padding: 24, borderRadius: 12, boxShadow: '0 8px 32px rgba(0,0,0,0.2)', maxWidth: 420, width: '90%' } },
        React.createElement('div', { style: { display: 'flex', justifyContent: 'space-between', marginBottom: 12 } },
          React.createElement('h3', { style: { margin: 0, color: '#1B2A4A', fontSize: 15 } }, (scoreBreakdown.opp_title || scoreBreakdown.title || 'Opportunity').substring(0, 50)),
          React.createElement('button', { onClick: function() { setScoreBreakdown(null); }, style: { background: 'none', border: 'none', fontSize: 18, cursor: 'pointer', color: '#6B7280' } }, '\u2715')
        ),
        React.createElement('div', { style: { fontSize: 36, fontWeight: 700, color: (scoreBreakdown.gda_score || scoreBreakdown.eis_fit_score || 0) >= 70 ? '#2F5C1F' : (scoreBreakdown.gda_score || scoreBreakdown.eis_fit_score || 0) >= 40 ? '#D14A2A' : '#9CA3AF', textAlign: 'center', marginBottom: 12 } }, (scoreBreakdown.gda_score || scoreBreakdown.eis_fit_score || 0) + '/100'),
        (function() {
          var mfScore = scoreBreakdown.eis_fit_score || scoreBreakdown.mission_fit_score || 0;
          var winScore = Math.round((scoreBreakdown.needs_score || 0) + (scoreBreakdown.financials_score || 0));
          var svScore = scoreBreakdown.ooda_score || scoreBreakdown.strategic_value_score || 0;
          // If we don't have sub-scores, derive from total
          var total = scoreBreakdown.gda_score || scoreBreakdown.eis_fit_score || 0;
          if (!mfScore && !winScore && !svScore && total > 0) {
            mfScore = Math.round(total * 0.40); winScore = Math.round(total * 0.35); svScore = Math.round(total * 0.25);
          }
          var rows = [
            { label: 'Mission Fit', max: 40, val: Math.min(mfScore, 40), color: mfScore >= 30 ? '#2F5C1F' : mfScore >= 20 ? '#D14A2A' : '#9CA3AF' },
            { label: 'Winnability', max: 35, val: Math.min(winScore, 35), color: winScore >= 26 ? '#2F5C1F' : winScore >= 17 ? '#D14A2A' : '#9CA3AF' },
            { label: 'Strategic Value', max: 25, val: Math.min(svScore, 25), color: svScore >= 18 ? '#2F5C1F' : svScore >= 10 ? '#D14A2A' : '#9CA3AF' }
          ];
          return rows.map(function(row, i) {
            return React.createElement('div', { key: i, style: { padding: '8px 0', borderBottom: '1px solid #F3F4F6' } },
              React.createElement('div', { style: { display: 'flex', justifyContent: 'space-between', fontSize: 13, marginBottom: 4 } },
                React.createElement('span', { style: { color: '#374151' } }, row.label + ' (/' + row.max + ')'),
                React.createElement('span', { style: { fontWeight: 700, color: row.color } }, row.val + ' pts')
              ),
              React.createElement('div', { style: { height: 6, background: '#F3F4F6', borderRadius: 3, overflow: 'hidden' } },
                React.createElement('div', { style: { height: '100%', width: Math.round((row.val/row.max)*100) + '%', background: row.color, borderRadius: 3, transition: 'width 0.4s ease' } })
              )
            );
          });
        })(),
        scoreBreakdown.source_url && React.createElement('a', { href: scoreBreakdown.source_url, target: '_blank', rel: 'noopener', style: { display: 'block', marginTop: 12, fontSize: 12, color: '#D14A2A', textDecoration: 'underline' } }, 'View source on GovTribe \u2197'),
        React.createElement('div', { style: { marginTop: 12, fontSize: 11, color: '#9CA3AF', fontStyle: 'italic' } }, 'GDA Unified Score (0-100): Mission Fit (40pts) + Winnability (35pts) + Strategic Value (25pts). Bands: 75+ PURSUE / 60-74 EVALUATE / 40-59 MONITOR / <40 PASS.')
      )
    ),
    drillDown && React.createElement('div', {
      style: { position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, background: 'rgba(27,42,74,0.5)', zIndex: 9999, display: 'flex', alignItems: 'center', justifyContent: 'center' },
      onClick: function(e) { if (e.target === e.currentTarget) setDrillDown(null); }
    },
      React.createElement('div', { style: { background: '#fff', borderRadius: '12px', padding: '24px', maxWidth: '900px', width: '90%', maxHeight: '80vh', overflow: 'auto', border: '1px solid #E8ECF1' } },
        React.createElement('div', { style: { display: 'flex', justifyContent: 'space-between', marginBottom: '16px' } },
          React.createElement('h3', { style: { margin: 0, color: '#1B2A4A', fontSize: '18px' } }, drillDown.title),
          React.createElement('button', { onClick: function() { setDrillDown(null); }, style: { background: 'none', border: 'none', fontSize: '18px', cursor: 'pointer', color: '#6B7280' } }, 'X')
        ),
        React.createElement('div', { style: { marginBottom: '12px', fontSize: '13px', color: '#6B7280' } },
          drillDown.data.length + ' opportunities | Total: ' + formatDollar(drillDown.data.reduce(function(s, o) { return s + (parseFloat(o.estimated_value) || 0); }, 0))
        ),
        React.createElement('table', { style: { width: '100%', borderCollapse: 'collapse', fontSize: '12px' } },
          React.createElement('thead', null,
            React.createElement('tr', null,
              React.createElement('th', { style: S.tblHeader }, 'Title'),
              React.createElement('th', { style: S.tblHeader }, 'Agency'),
              React.createElement('th', { style: S.tblHeader }, 'Fit'),
              React.createElement('th', { style: S.tblHeader }, 'Value'),
              React.createElement('th', { style: S.tblHeader }, 'Source')
            )
          ),
          React.createElement('tbody', null,
            drillDown.data.map(function(o, i) {
              return React.createElement('tr', { key: i, style: { background: i % 2 === 0 ? '#fff' : '#F8F9FB' } },
                React.createElement('td', { style: S.tblCell }, (o.title || 'Untitled').substring(0, 50)),
                React.createElement('td', { style: S.tblCell }, o.agency || '--'),
                React.createElement('td', { style: S.tblCell }, React.createElement(GDAScoreBadge, { score: o.gda_score || calculateGDAScore(o) })),
                React.createElement('td', { style: S.tblCell }, formatDollar(o.estimated_value)),
                React.createElement('td', { style: S.tblCell },
                  o.source_url ? React.createElement('a', { href: o.source_url, target: '_blank', rel: 'noopener', style: S.link }, 'View') : '--'
                )
              );
            })
          )
        )
      )
    ),
  (function() {
      var predictions = [];
      var now = new Date();
      var thirtyDays = new Date(now.getTime() + 30 * 86400000);
      var sevenDays = new Date(now.getTime() + 7 * 86400000);
      // Overdue PURSUE/EVALUATE - flag these as critical first
      var overdueOpps = opps.filter(function(o) { var d = o.response_deadline ? new Date(o.response_deadline) : null; return d && d < now && (o.gda_label === 'PURSUE' || o.gda_label === 'EVALUATE'); });
      if (overdueOpps.length > 0) {
        predictions.push({ type: 'OVERDUE', color: '#DC2626', icon: 'Ὢ8', title: overdueOpps.length + ' PURSUE/EVALUATE Opportunities Past Deadline', text: overdueOpps.slice(0,3).map(function(o){return (o.opp_title||'').substring(0,40);}).join(', ') + (overdueOpps.length > 3 ? ' +' + (overdueOpps.length-3) + ' more' : '') + ' — triage required.', confidence: 'Critical', source: 'OppTracker', action: 'Review and close or extend' });
      }
      var upcomingOpps = opps.filter(function(o) { var d = new Date(o.response_deadline); return d > now && d < thirtyDays; }).sort(function(a,b) { return new Date(a.response_deadline) - new Date(b.response_deadline); });
      if (upcomingOpps.length > 0) {
        upcomingOpps.slice(0, 3).forEach(function(o) {
          var dl = new Date(o.response_deadline);
          var daysLeft = Math.ceil((dl - now) / 86400000);
          var shipleyPhase = daysLeft <= 7 ? 'Phase 3: Proposal' : daysLeft <= 14 ? 'Phase 2: Capture' : 'Phase 1: Pursuit';
          var action = daysLeft <= 7 ? 'Final proposal review and compliance check' : daysLeft <= 14 ? 'Complete capture plan and pricing' : 'Qualify and assign capture lead';
          predictions.push({ type: 'DEADLINE', color: daysLeft <= 7 ? '#DC2626' : daysLeft <= 14 ? '#D14A2A' : '#1B2A4A', icon: daysLeft <= 7 ? '\u26a0\ufe0f' : '\ud83d\udcc5', title: (o.opp_title || o.title || 'Untitled').substring(0, 60), text: action, confidence: daysLeft <= 7 ? 'Critical' : daysLeft <= 14 ? 'High' : 'Medium', source: 'Shipley ' + shipleyPhase, deadline: dl.toLocaleDateString('en-US', {month:'short', day:'numeric', year:'numeric'}), daysLeft: daysLeft });
        });
      }
      var totalVal = opps.reduce(function(s,o) { return s + (parseFloat(o.estimated_value) || 0); }, 0);
      var highFitCount = opps.filter(function(o) { return (o.gda_score || calculateGDAScore(o)) >= 60; }).length;
      var identifiedCount = opps.filter(function(o) { return !o.stage || o.stage === 'Identified'; }).length;
      var capturePlanCount = opps.filter(function(o) { return o.stage === 'Capture' || o.stage === 'Pursuing'; }).length;
      if (highFitCount > 0) {
        var trendDir = highFitCount > opps.length * 0.4 ? 'improving' : highFitCount < opps.length * 0.15 ? 'declining' : 'stable';
        var arrow = trendDir === 'improving' ? '\u2191' : trendDir === 'declining' ? '\u2193' : '\u2192';
        predictions.push({ type: 'TREND ' + arrow, color: trendDir === 'improving' ? '#2F5C1F' : trendDir === 'declining' ? '#DC2626' : '#6B7280', icon: trendDir === 'improving' ? '\ud83d\udcc8' : trendDir === 'declining' ? '\ud83d\udcc9' : '\u27a1\ufe0f', title: 'Opportunity Quality: ' + trendDir.charAt(0).toUpperCase() + trendDir.slice(1), text: highFitCount + ' of ' + opps.length + ' opportunities have GDA score 60+.', confidence: 'Medium', source: 'GDA Score Analysis' });
      }
      var deptCounts = {};
      opps.forEach(function(o) { var d = o.level_1 || o.cabinet_department || 'Other'; deptCounts[d] = (deptCounts[d] || 0) + 1; });
      var deptKeys = Object.keys(deptCounts);
      if (deptKeys.length > 0) {
        var topDept = deptKeys.sort(function(a, b) { return deptCounts[b] - deptCounts[a]; })[0];
        var topPct = Math.round((deptCounts[topDept] / opps.length) * 100);
        if (topPct > 50) {
          predictions.push({ type: 'RISK ALERT', color: '#DC2626', icon: '\u26a1', title: 'Concentration Risk: ' + topDept, text: topPct + '% of opportunities in single department. Diversify across agencies.', confidence: 'High', source: 'Risk Register', action: 'Run OODA on underrepresented depts', analysis: topPct + '% portfolio concentration in ' + topDept + ' creates recompete risk. Recommended: add 2-3 opportunities in underrepresented agencies within 30 days. Reference: GDA Risk Register \u2192 Concentration Risk category.' });
        }
      }
      if (identifiedCount > 3) {
        predictions.push({ type: 'ACTION', color: '#1B2A4A', icon: '\u2705', title: identifiedCount + ' Opportunities Need Qualification', text: 'Move high-fit Identified opportunities to Qualified stage per Shipley Phase 1.', confidence: 'High', source: 'Shipley Capture Lifecycle', action: 'Review and qualify top ' + Math.min(identifiedCount, 5) });
      }
      if (capturePlanCount > 0) {
        predictions.push({ type: 'CAPTURE', color: '#2F5C1F', icon: '\ud83c\udfaf', title: capturePlanCount + ' Active Capture Plans', text: 'Ensure win themes, pricing, and teaming are complete per Shipley Phase 2.', confidence: 'Medium', source: 'Shipley Capture Lifecycle' });
      }
      var valSorted = opps.slice().sort(function(a, b) { return (parseFloat(b.estimated_value) || 0) - (parseFloat(a.estimated_value) || 0); });
      if (valSorted[0] && parseFloat(valSorted[0].estimated_value) > 0) {
        predictions.push({ type: 'TOP VALUE', color: '#32448A', icon: '\ud83d\udcb0', title: (valSorted[0].opp_title || valSorted[0].title || 'Untitled').substring(0, 50), text: formatDollar(valSorted[0].estimated_value) + ' - Highest value in portfolio.', confidence: 'High', source: 'Portfolio Analysis', deadline: valSorted[0].response_deadline ? new Date(valSorted[0].response_deadline).toLocaleDateString('en-US', {month:'short', day:'numeric'}) : null, source_url: valSorted[0].solicitation_number ? 'https://sam.gov/opp/' + valSorted[0].solicitation_number + '/view' : (valSorted[0].govtribe_url || null), govtribe_url: valSorted[0].govtribe_url || null, analysis: 'Top value opportunity: ' + formatDollar(valSorted[0].estimated_value) + '. Agency: ' + (valSorted[0].agency || valSorted[0].cabinet_department || 'Unknown') + '. Stage: ' + (valSorted[0].stage || 'Unknown') + '. GDA Score: ' + (valSorted[0].gda_score || 0) + '/100.' });
      }
      var allMktDepts = Object.keys(DEPT_MARKET_DATA).filter(function(d) { return d !== 'All Departments'; });
      var gapDepts = allMktDepts.filter(function(d) { return !deptCounts[d]; });
      if (gapDepts.length > 0) {
        predictions.push({ type: 'GROWTH', color: '#32448A', icon: '\ud83d\udcc8', title: 'Market Gap: ' + gapDepts.length + ' Departments', text: gapDepts.slice(0, 3).join(', ') + (gapDepts.length > 3 ? ' +' + (gapDepts.length - 3) + ' more' : '') + ' have zero opportunities.', confidence: 'Low', source: 'Market Analysis', action: 'Run OODA analysis' });
      }
      return React.createElement('div', { style: { background: '#fff', border: '1px solid #E8ECF1', borderRadius: 10, padding: 20, marginTop: 16 } },
        React.createElement('div', { style: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', cursor: 'pointer', marginBottom: expandedDepts['sec_pred'] ? 4 : 0 }, onClick: function() { var n = Object.assign({}, expandedDepts); n['sec_pred'] = !n['sec_pred']; setExpandedDepts(n); } },
          React.createElement('h3', { style: { fontSize: 16, fontWeight: 700, color: '#1B2A4A', margin: 0 } }, (expandedDepts['sec_pred'] ? '\u25BC ' : '\u25B6 ') + 'Predictive Intelligence'),
          React.createElement('span', { style: { fontSize: 11, color: '#9CA3AF' } }, predictions.length + ' insights')
        ),
        expandedDepts['sec_pred'] && React.createElement('div', { style: { fontSize: 11, color: '#9CA3AF', marginBottom: 14, marginTop: 4 } }, 'Shipley-aligned recommendations \u00b7 ' + predictions.length + ' insights'),
        expandedDepts['sec_pred'] && (
        predictions.length === 0
          ? React.createElement('div', { style: { fontSize: 13, color: '#9CA3AF', padding: '12px 0' } }, 'No actionable predictions.')
          : React.createElement('div', { style: { display: 'flex', flexDirection: 'column', gap: 10 } },
              predictions.map(function(p, i) {
                return React.createElement('div', { key: i, onClick: function() { var el = document.getElementById('pred-detail-' + i); if(el) el.style.display = el.style.display === 'none' ? 'block' : 'none'; }, style: { padding: '12px 16px', background: '#FAFBFC', borderRadius: 8, borderLeft: '4px solid ' + p.color, cursor: 'pointer' } },
                  React.createElement('div', { style: { display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 4 } },
                    React.createElement('div', { style: { display: 'flex', gap: 8, alignItems: 'center' } },
                      React.createElement('span', { style: { fontSize: 14 } }, p.icon),
                      React.createElement('span', { style: { fontSize: 10, fontWeight: 700, color: p.color, textTransform: 'uppercase', letterSpacing: '0.5px' } }, p.type)
                    ),
                    React.createElement('div', { style: { display: 'flex', gap: 8, alignItems: 'center' } },
                      p.confidence && React.createElement('span', { style: { fontSize: 9, padding: '1px 6px', borderRadius: 8, fontWeight: 600, background: p.confidence === 'Critical' ? '#FEE2E2' : p.confidence === 'High' ? '#B06D3218' : '#F0F4FF', color: p.confidence === 'Critical' ? '#DC2626' : p.confidence === 'High' ? '#B06D32' : '#3B82F6' } }, p.confidence),
                      p.deadline && React.createElement('span', { style: { fontSize: 10, color: '#6B7280' } }, p.deadline),
                      p.daysLeft != null && React.createElement('span', { style: { fontSize: 9, fontWeight: 700, padding: '1px 5px', borderRadius: 6, background: p.daysLeft <= 7 ? '#FEE2E2' : '#B06D3218', color: p.daysLeft <= 7 ? '#DC2626' : '#B06D32' } }, p.daysLeft + 'd')
                    )
                  ),
                  p.title && React.createElement('div', { style: { fontSize: 13, fontWeight: 600, color: '#1B2A4A', marginBottom: 3 } }, p.title),
                  React.createElement('div', { style: { fontSize: 12, color: '#374151', lineHeight: 1.5 } }, p.text),
                  (p.source || p.action) && React.createElement('div', { style: { display: 'flex', gap: 12, marginTop: 6, fontSize: 10 } },
                    p.source && React.createElement('span', { style: { color: '#9CA3AF' } }, '\ud83d\udccc ' + p.source),
                    p.action && React.createElement('span', { style: { color: '#D14A2A', fontWeight: 600, cursor: 'pointer' } }, '\u2192 ' + p.action)
                  ),
                  p.source_url && React.createElement('a', { href: p.source_url, target: '_blank', rel: 'noopener', onClick: function(e){e.stopPropagation();}, style: { display: 'inline-block', marginTop: 4, fontSize: 10, color: '#D14A2A', textDecoration: 'underline' } }, '\u2197 View Source'),
                  React.createElement('div', { id: 'pred-detail-' + i, style: { display: 'none', marginTop: 8, padding: '8px 10px', background: '#F0F4FF', borderRadius: 6, fontSize: 11, color: '#1B2A4A', lineHeight: 1.6 } },
                    p.analysis || p.text || 'No additional analysis available.',
                    p.sam_url && React.createElement('div', { style: { marginTop: 4 } }, React.createElement('a', { href: p.sam_url, target: '_blank', rel: 'noopener', onClick: function(e){e.stopPropagation();}, style: { fontSize: 10, color: '#D14A2A', textDecoration: 'underline' } }, '\u2197 SAM.gov')),
                    p.govtribe_url && React.createElement('div', { style: { marginTop: 2 } }, React.createElement('a', { href: p.govtribe_url, target: '_blank', rel: 'noopener', onClick: function(e){e.stopPropagation();}, style: { fontSize: 10, color: '#1B2A4A', textDecoration: 'underline' } }, '\u2197 GovTribe'))
                  )
                );
              })
            )
        ),
        expandedDepts['sec_pred'] && React.createElement('div', { style: { display: 'flex', gap: 8, marginTop: 12 } },
          React.createElement('input', {
            value: predQuestion,
            onChange: function(e) { setPredQuestion(e.target.value); },
            onKeyDown: function(e) { if (e.key === 'Enter' && predQuestion.trim()) {
              setPredLoading(true); setPredAnswer('');
              var ctx = 'Opportunities: ' + opps.length + ' opps, ' + formatDollar(totalValue) + '. ';
              var dCounts = {}; opps.forEach(function(o) { var d = o.level_1 || 'Other'; dCounts[d] = (dCounts[d]||0)+1; });
              ctx += 'Depts: ' + Object.keys(dCounts).join(', ') + '. ';
              ctx += 'Question: ' + predQuestion;
              api.post('gda-chat-v2', { message: ctx }).then(function(r) {
                setPredAnswer(r.response || r.output || r.Summary || r.summary || JSON.stringify(r));
                setPredLoading(false);
              }).catch(function() { setPredAnswer('Unable to generate prediction.'); setPredLoading(false); });
            } },
            placeholder: 'Ask about predictions... e.g., "What departments should we target next?"',
            style: { flex: 1, padding: '8px 12px', border: '1px solid #D1D5DB', borderRadius: 6, fontSize: 12 }
          }),
          React.createElement('button', {
            onClick: function() {
              if (!predQuestion.trim()) return;
              setPredLoading(true); setPredAnswer('');
              var ctx = 'Opportunities: ' + opps.length + ' opps, ' + formatDollar(totalValue) + '. ';
              var dCounts = {}; opps.forEach(function(o) { var d = o.level_1 || 'Other'; dCounts[d] = (dCounts[d]||0)+1; });
              ctx += 'Depts: ' + Object.keys(dCounts).join(', ') + '. ';
              ctx += 'Question: ' + predQuestion;
              api.post('gda-chat-v2', { message: ctx }).then(function(r) {
                setPredAnswer(r.response || r.output || r.Summary || r.summary || JSON.stringify(r));
                setPredLoading(false);
              }).catch(function() { setPredAnswer('Unable to generate prediction.'); setPredLoading(false); });
            },
            disabled: predLoading || !predQuestion.trim(),
            style: { padding: '8px 16px', background: '#1B2A4A', color: '#fff', border: 'none', borderRadius: 6, cursor: 'pointer', fontSize: 12, fontWeight: 600, opacity: (predLoading || !predQuestion.trim()) ? 0.5 : 1 }
          }, predLoading ? 'Thinking...' : 'Ask')
        ),
        predAnswer && React.createElement('div', { style: { marginTop: 8, padding: '10px 14px', background: '#F0F4FF', borderRadius: 8, fontSize: 12, color: '#1B2A4A', lineHeight: 1.6, borderLeft: '3px solid #D14A2A' } }, predAnswer)
      );
    })()
  );
}

// ── OPPORTUNITY TRACKER ───────

// ── S-079 DOD DEPT MAP ──────────────────────────────────────

// ============================================================
// SHARED: DOD_DEPT_MAP + Utilities (S-085-T6)
// 80+ agencies mapped to 13 cabinet-level departments
// Top 5 determined by DATA (value x fit), never hardcoded
// ============================================================
const DOD_DEPT_MAP = {
  'Department of Defense': 'Department of War',
  'Dept of Defense': 'Department of War',
  'DoD': 'Department of War',
  'OSD': 'Department of War',
  'Office of the Secretary of Defense': 'Department of War',
  'Department of the Army': 'Department of War',
  'Dept of the Army': 'Department of War',
  'U.S. Army': 'Department of War',
  'Army': 'Department of War',
  'TRADOC': 'Department of War',
  'Army Futures Command': 'Department of War',
  'AFC': 'Department of War',
  'PEO STRI': 'Department of War',
  'PEO IEW&S': 'Department of War',
  'PEO EIS': 'Department of War',
  'PEO Soldier': 'Department of War',
  'PEO Aviation': 'Department of War',
  'PEO CS&CSS': 'Department of War',
  'PEO Missiles and Space': 'Department of War',
  'PEO C3T': 'Department of War',
  'INSCOM': 'Department of War',
  'CECOM': 'Department of War',
  'DEVCOM': 'Department of War',
  'Army DEVCOM': 'Department of War',
  'CERDEC': 'Department of War',
  'Army Research Lab': 'Department of War',
  'ARL': 'Department of War',
  'AMCOM': 'Department of War',
  'SMDC': 'Department of War',
  'USACE': 'Department of War',
  'Army Corps of Engineers': 'Department of War',
  'Department of the Navy': 'Department of War',
  'Dept of the Navy': 'Department of War',
  'U.S. Navy': 'Department of War',
  'Navy': 'Department of War',
  'NAVAIR': 'Department of War',
  'NAVSEA': 'Department of War',
  'NAVWAR': 'Department of War',
  'SPAWAR': 'Department of War',
  'NIWC': 'Department of War',
  'NIWC Pacific': 'Department of War',
  'NIWC Atlantic': 'Department of War',
  'ONR': 'Department of War',
  'Marine Corps': 'Department of War',
  'USMC': 'Department of War',
  'MARCORSYSCOM': 'Department of War',
  'Department of the Air Force': 'Department of War',
  'Dept of the Air Force': 'Department of War',
  'U.S. Air Force': 'Department of War',
  'Air Force': 'Department of War',
  'AFLCMC': 'Department of War',
  'AFRL': 'Department of War',
  'Air Force Research Lab': 'Department of War',
  'Space Force': 'Department of War',
  'USSF': 'Department of War',
  'Space Systems Command': 'Department of War',
  'SSC': 'Department of War',
  'DISA': 'Department of War',
  'Defense Information Systems Agency': 'Department of War',
  'DARPA': 'Department of War',
  'DIA': 'Department of War',
  'Defense Intelligence Agency': 'Department of War',
  'DLA': 'Department of War',
  'Defense Logistics Agency': 'Department of War',
  'MDA': 'Department of War',
  'Missile Defense Agency': 'Department of War',
  'DTRA': 'Department of War',
  'DCSA': 'Department of War',
  'DCMA': 'Department of War',
  'DFAS': 'Department of War',
  'DeCA': 'Department of War',
  'WHS': 'Department of War',
  'DPAA': 'Department of War',
  'SOCOM': 'Department of War',
  'U.S. Special Operations Command': 'Department of War',
  'USSOCOM': 'Department of War',
  'CYBERCOM': 'Department of War',
  'U.S. Cyber Command': 'Department of War',
  'INDOPACOM': 'Department of War',
  'U.S. Indo-Pacific Command': 'Department of War',
  'CENTCOM': 'Department of War',
  'U.S. Central Command': 'Department of War',
  'EUCOM': 'Department of War',
  'U.S. European Command': 'Department of War',
  'AFRICOM': 'Department of War',
  'NORTHCOM': 'Department of War',
  'SOUTHCOM': 'Department of War',
  'STRATCOM': 'Department of War',
  'TRANSCOM': 'Department of War',
  'SPACECOM': 'Department of War',
  'JSOC': 'Department of War',
  'Department of Homeland Security': 'DHS',
  'DHS': 'DHS',
  'CBP': 'DHS',
  'Customs and Border Protection': 'DHS',
  'ICE': 'DHS',
  'Immigration and Customs Enforcement': 'DHS',
  'TSA': 'DHS',
  'Transportation Security Administration': 'DHS',
  'FEMA': 'DHS',
  'Secret Service': 'DHS',
  'Coast Guard': 'DHS',
  'Department of Transportation': 'Department of Transportation',
  'DOT': 'Department of Transportation',
  'FAA': 'Department of Transportation',
  'Federal Aviation Administration': 'Department of Transportation',
  'FHWA': 'Department of Transportation',
  'FRA': 'Department of Transportation',
  'NHTSA': 'Department of Transportation',
  'MARAD': 'Department of Transportation',
  'USCG': 'DHS',
  'CISA': 'DHS',
  'CIA': 'Intelligence Community',
  'Central Intelligence Agency': 'Intelligence Community',
  'NSA': 'Intelligence Community',
  'National Security Agency': 'Intelligence Community',
  'NGA': 'Intelligence Community',
  'National Geospatial-Intelligence Agency': 'Intelligence Community',
  'NRO': 'Intelligence Community',
  'National Reconnaissance Office': 'Intelligence Community',
  'DNI': 'Intelligence Community',
  'ODNI': 'Intelligence Community',
  'Office of the Director of National Intelligence': 'Intelligence Community',
  'Department of Veterans Affairs': 'VA',
  'VA': 'VA',
  'Veterans Affairs': 'VA',
  'VHA': 'VA',
  'VBA': 'VA',
  'Department of Energy': 'DOE',
  'DOE': 'DOE',
  'NNSA': 'DOE',
  'National Nuclear Security Administration': 'DOE',
  'NASA': 'NASA',
  'National Aeronautics and Space Administration': 'NASA',
  'Department of Justice': 'DOJ',
  'DOJ': 'DOJ',
  'FBI': 'DOJ',
  'DEA': 'DOJ',
  'ATF': 'DOJ',
  'U.S. Marshals Service': 'DOJ',
  'Bureau of Prisons': 'DOJ',
  'Department of State': 'State',
  'State Department': 'State',
  'State': 'State',
  'USAID': 'State',
  'Department of Commerce': 'Commerce',
  'Commerce': 'Commerce',
  'NOAA': 'Commerce',
  'NIST': 'Commerce',
  'Census Bureau': 'Commerce',
  'USPTO': 'Commerce',
  'BIS': 'Commerce',
  'Department of Health and Human Services': 'HHS',
  'HHS': 'HHS',
  'CDC': 'HHS',
  'NIH': 'HHS',
  'FDA': 'HHS',
  'CMS': 'HHS',
  'Department of the Interior': 'Interior',
  'Interior': 'Interior',
  'USGS': 'Interior',
  'BLM': 'Interior',
  'NPS': 'Interior',
  'Bureau of Reclamation': 'Interior',
  'General Services Administration': 'GSA',
  'GSA': 'GSA',
}

// Shared utility: resolve any agency string to a cabinet department
const DOD_CABINET_MAP = {
  // Department of War
  "Department of War": "Department of War",
  "Department of the Army": "Department of War",
  "Department of the Air Force": "Department of War",
  "Department of the Navy": "Department of War",
  "US Marine Corps": "Department of War",
  "US Space Force": "Department of War",
  "Defense Information Systems Agency": "Department of War",
  "Defense Logistics Agency": "Department of War",
  "Defense Advanced Research Projects Agency": "Department of War",
  "Missile Defense Agency": "Department of War",
  "Defense Contract Management Agency": "Department of War",
  "Defense Health Agency": "Department of War",
  "Defense Threat Reduction Agency": "Department of War",
  "US Special Operations Command": "Department of War",
  "US Cyber Command": "Department of War",
  "US Indo-Pacific Command": "Department of War",
  "US Central Command": "Department of War",
  "US Northern Command": "Department of War",
  "US European Command": "Department of War",
  "US Africa Command": "Department of War",
  "US Southern Command": "Department of War",
  "US Transportation Command": "Department of War",
  "US Strategic Command": "Department of War",
  // Department of Homeland Security
  "Department of Homeland Security": "Department of Homeland Security",
  "DHS": "Department of Homeland Security",
  "Customs and Border Protection": "Department of Homeland Security",
  "Immigration and Customs Enforcement": "Department of Homeland Security",
  "Transportation Security Administration": "Department of Homeland Security",
  "Cybersecurity and Infrastructure Security Agency": "Department of Homeland Security",
  "FEMA": "Department of Homeland Security",
  "Coast Guard": "Department of Homeland Security",
  "Secret Service": "Department of Homeland Security",
  "US Citizenship and Immigration Services": "Department of Homeland Security",
  // Intelligence Community
  "Intelligence Community": "Intelligence Community",
  "National Security Agency": "Intelligence Community",
  "National Geospatial-Intelligence Agency": "Intelligence Community",
  "National Reconnaissance Office": "Intelligence Community",
  "Central Intelligence Agency": "Intelligence Community",
  "Office of the Director of National Intelligence": "Intelligence Community",
  "Defense Intelligence Agency": "Intelligence Community",
  // Department of Veterans Affairs
  "Department of Veterans Affairs": "Department of Veterans Affairs",
  // S-111: Full department name mappings
  "VA": "Department of Veterans Affairs",
  "HHS": "Department of Health and Human Services",
  "DOI": "Department of the Interior",
  "DOC": "Department of Commerce",
  "DOE": "Department of Energy",
  "DOT": "Department of Transportation",
  "GSA": "General Services Administration",
  "General Services Administration": "General Services Administration",
  "National Aeronautics and Space Administration": "National Aeronautics and Space Administration",
  "Environmental Protection Agency": "Environmental Protection Agency",
  "Federal Communications Commission": "Federal Communications Commission",
  "U.S. Postal Service": "U.S. Postal Service",
  "Administrative Office of the U.S. Courts": "Administrative Office of the U.S. Courts",
  "Department of Housing and Urban Development": "Department of Housing and Urban Development",
  "HUD": "Department of Housing and Urban Development",
  "Veterans Benefits Administration": "Department of Veterans Affairs",
  "Veterans Health Administration": "Department of Veterans Affairs",
  "National Cemetery Administration": "Department of Veterans Affairs",
  // Department of Energy
  "Department of Energy": "Department of Energy",
  "National Nuclear Security Administration": "Department of Energy",
  "Office of Science": "Department of Energy",
  // NASA
  "NASA": "NASA",
  "National Aeronautics and Space Administration": "NASA",
  // Department of Justice
  "Department of Justice": "Department of Justice",
  "Federal Bureau of Investigation": "Department of Justice",
  "Drug Enforcement Administration": "Department of Justice",
  "Bureau of Alcohol Tobacco Firearms and Explosives": "Department of Justice",
  "Bureau of Prisons": "Department of Justice",
  "US Marshals Service": "Department of Justice",
  // Department of State
  "Department of State": "Department of State",
  "US Agency for International Development": "Department of State",
  // Department of Commerce
  "Department of Commerce": "Department of Commerce",
  "National Oceanic and Atmospheric Administration": "Department of Commerce",
  "National Institute of Standards and Technology": "Department of Commerce",
  "Bureau of the Census": "Department of Commerce",
  // Department of Health and Human Services
  "Department of Health and Human Services": "Department of Health and Human Services",
  "Centers for Disease Control and Prevention": "Department of Health and Human Services",
  "National Institutes of Health": "Department of Health and Human Services",
  "Food and Drug Administration": "Department of Health and Human Services",
  "Centers for Medicare and Medicaid Services": "Department of Health and Human Services",
  // Department of the Interior
  "Department of the Interior": "Department of the Interior",
  "Bureau of Land Management": "Department of the Interior",
  "National Park Service": "Department of the Interior",
  "US Fish and Wildlife Service": "Department of the Interior",
  "Bureau of Indian Affairs": "Department of the Interior",
  // Department of Transportation
  "Department of Transportation": "Department of Transportation",
  "Federal Aviation Administration": "Department of Transportation",
  "Federal Highway Administration": "Department of Transportation",
  "Federal Transit Administration": "Department of Transportation",
  // General Services Administration
  "General Services Administration": "General Services Administration",
  "Public Buildings Service": "General Services Administration",
  "Federal Acquisition Service": "General Services Administration",
}
const DEPT_BUDGETS = {
  "Department of War": { total: 886e9, label: "$886B" },
  "Department of Homeland Security": { total: 98e9, label: "$98B" },
  "Intelligence Community": { total: 71e9, label: "$71B" },
  "Department of Veterans Affairs": { total: 325e9, label: "$325B" },
  "Department of Energy": { total: 51e9, label: "$51B" },
  "NASA": { total: 25e9, label: "$25B" },
  "Department of Justice": { total: 42e9, label: "$42B" },
  "Department of State": { total: 58e9, label: "$58B" },
  "Department of Commerce": { total: 16e9, label: "$16B" },
  "Department of Health and Human Services": { total: 127e9, label: "$127B" },
  "Department of the Interior": { total: 18e9, label: "$18B" },
  "Department of Transportation": { total: 29e9, label: "$29B" },
  "General Services Administration": { total: 32e9, label: "$32B" } };
// SOURCE: GovTribe federal contract award aggregations, trailing 12 months
// NAICS: All 16 GDA codes across EIS + PD Systems + Riverstone
// EIS: 541330, 541512, 541519, 541611, 541715, 541990, 611430, 611512
// PD Systems: 541511, 541512, 541513, 541519, 541715, 518210, 334511
// Riverstone: 541512, 541519, 517410, 517919, 561621, 541690
// Total SAM: $53.6B across 62,122 awards (as of 2026-03-18)
var DEPT_MARKET_DATA = {
  'All Departments':                          { pam: 6750000000000, tam: 750000000000, sam: 53646000000, som: 310800000 },
  'Department of War':                        { pam: 886000000000, tam: 395000000000, sam: 38200000000, som: 297500000 },
  'Department of Homeland Security':          { pam: 62000000000, tam: 18600000000, sam: 2400000000, som: 7800000 },
  'Intelligence Community':                   { pam: 71700000000, tam: 21500000000, sam: 2100000000, som: 0 },
  'Department of Veterans Affairs':           { pam: 325000000000, tam: 16200000000, sam: 1070000000, som: 450000 },
  'Department of Energy':                     { pam: 52000000000, tam: 15600000000, sam: 1200000000, som: 0 },
  'NASA':                                     { pam: 25000000000, tam: 7500000000, sam: 890000000, som: 0 },
  'Department of Justice':                    { pam: 40000000000, tam: 12000000000, sam: 920000000, som: 0 },
  'Department of State':                      { pam: 58000000000, tam: 5800000000, sam: 480000000, som: 350000 },
  'Department of Commerce':                   { pam: 12000000000, tam: 3600000000, sam: 410000000, som: 0 },
  'Department of Health and Human Services':  { pam: 127000000000, tam: 12700000000, sam: 1350000000, som: 0 },
  'Department of the Interior':               { pam: 17000000000, tam: 5100000000, sam: 520000000, som: 3500000 },
  'Department of Transportation':             { pam: 105000000000, tam: 10500000000, sam: 1830000000, som: 1200000 },
  'General Services Administration':          { pam: 1500000000, tam: 750000000, sam: 580000000, som: 0 }
};
function formatMarketVal(v) {
  if (!v || v === 0) return '$0';
  if (v >= 1000000000000) return '$' + (v / 1000000000000).toFixed(1) + 'T';
  if (v >= 1000000000) return '$' + (v / 1000000000).toFixed(1) + 'B';
  return formatDollar(v);
}

// S-106: Parse raw agency string into Level 2 (military dept / defense agency)
function agencyToLevel2(agencyStr) {
  if (!agencyStr) return 'Unassigned';
  var a = agencyStr.toUpperCase();
  // Defense agencies (standalone Level 2)
  if (a.indexOf('DEFENSE LOGISTICS') !== -1 || a.indexOf('DLA ') !== -1 || a === 'DLA') return 'Defense Logistics Agency';
  if (a.indexOf('DEFENSE INFORMATION SYSTEMS') !== -1 || a.indexOf('DISA') !== -1) return 'DISA';
  if (a.indexOf('DEFENSE ADVANCED RESEARCH') !== -1 || a.indexOf('DARPA') !== -1) return 'DARPA';
  if (a.indexOf('MISSILE DEFENSE AGENCY') !== -1 || a === 'MDA') return 'MDA';
  if (a.indexOf('SPECIAL OPERATIONS COMMAND') !== -1 || a.indexOf('SOCOM') !== -1 || a.indexOf('USSOCOM') !== -1) return 'USSOCOM';
  if (a.indexOf('CYBER COMMAND') !== -1 || a.indexOf('CYBERCOM') !== -1) return 'USCYBERCOM';
  if (a.indexOf('TRANSPORTATION COMMAND') !== -1 || a.indexOf('TRANSCOM') !== -1) return 'USTRANSCOM';
  if (a.indexOf('DEFENSE INTELLIGENCE') !== -1) return 'DIA';
  if (a.indexOf('DEFENSE CONTRACT') !== -1 || a.indexOf('DCAA') !== -1 || a.indexOf('DCMA') !== -1) return 'DCMA/DCAA';
  if (a.indexOf('DEFENSE THREAT') !== -1 || a.indexOf('DTRA') !== -1) return 'DTRA';
  if (a.indexOf('DEFENSE HEALTH') !== -1) return 'Defense Health Agency';
  if (a.indexOf('NATIONAL GUARD') !== -1) return 'National Guard Bureau';
  // Military departments
  if (a.indexOf('DEPARTMENT OF THE ARMY') !== -1 || a.indexOf('DEPT OF THE ARMY') !== -1 || (a.indexOf('ARMY') !== -1 && a.indexOf('SALVATION') === -1)) return 'Dept of the Army';
  if (a.indexOf('DEPARTMENT OF THE NAVY') !== -1 || a.indexOf('DEPT OF THE NAVY') !== -1 || a.indexOf('NAVAL') !== -1 || a.indexOf('NAVSEA') !== -1 || a.indexOf('NAVAIR') !== -1 || a.indexOf('NAVSUP') !== -1 || a.indexOf('NAVFAC') !== -1 || a.indexOf('NAVWAR') !== -1) return 'Dept of the Navy';
  if (a.indexOf('MARINE CORPS') !== -1 || a.indexOf('USMC') !== -1) return 'Dept of the Navy';
  if (a.indexOf('DEPARTMENT OF THE AIR FORCE') !== -1 || a.indexOf('DEPT OF THE AIR FORCE') !== -1 || a.indexOf('AIR FORCE') !== -1 || a.indexOf('USAF') !== -1) return 'Dept of the Air Force';
  if (a.indexOf('SPACE FORCE') !== -1) return 'Dept of the Air Force';
  // Non-DoD — parse the sub-agency
  if (a.indexOf('GSA') !== -1 || a.indexOf('GENERAL SERVICES') !== -1) {
    if (a.indexOf('FAS') !== -1 || a.indexOf('FEDERAL ACQUISITION') !== -1) return 'GSA FAS';
    if (a.indexOf('PBS') !== -1 || a.indexOf('PUBLIC BUILDINGS') !== -1) return 'GSA PBS';
    return 'GSA';
  }
  if (a.indexOf('FAA') !== -1 || a.indexOf('FEDERAL AVIATION') !== -1) return 'FAA';
  if (a.indexOf('FHWA') !== -1 || a.indexOf('FEDERAL HIGHWAY') !== -1) return 'FHWA';
  if (a.indexOf('NIH') !== -1 || a.indexOf('NATIONAL INSTITUTES OF HEALTH') !== -1) return 'NIH';
  if (a.indexOf('CDC') !== -1 || a.indexOf('CENTERS FOR DISEASE') !== -1) return 'CDC';
  if (a.indexOf('CMS') !== -1 || a.indexOf('CENTERS FOR MEDICARE') !== -1) return 'CMS';
  if (a.indexOf('CUSTOMS AND BORDER') !== -1 || a.indexOf('CBP') !== -1) return 'CBP';
  if (a.indexOf('ICE') !== -1 && a.indexOf('IMMIGRATION') !== -1) return 'ICE';
  if (a.indexOf('TSA') !== -1 || a.indexOf('TRANSPORTATION SECURITY') !== -1) return 'TSA';
  if (a.indexOf('FEMA') !== -1) return 'FEMA';
  if (a.indexOf('CISA') !== -1 || a.indexOf('CYBERSECURITY AND INFRASTRUCTURE') !== -1) return 'CISA';
  if (a.indexOf('SECRET SERVICE') !== -1) return 'Secret Service';
  if (a.indexOf('COAST GUARD') !== -1) return 'Coast Guard';
  if (a.indexOf('FBI') !== -1 || a.indexOf('FEDERAL BUREAU OF INVESTIGATION') !== -1) return 'FBI';
  if (a.indexOf('DEA') !== -1 && a.indexOf('DRUG') !== -1) return 'DEA';
  if (a.indexOf('NOAA') !== -1 || a.indexOf('NATIONAL OCEANIC') !== -1) return 'NOAA';
  if (a.indexOf('NIST') !== -1 || a.indexOf('NATIONAL INSTITUTE OF STANDARDS') !== -1) return 'NIST';
  if (a.indexOf('NASA') !== -1) return 'NASA';
  if (a.indexOf('NNSA') !== -1 || a.indexOf('NUCLEAR SECURITY') !== -1) return 'NNSA';
  // Fallback: use raw agency string, truncated to something reasonable
  // Strip common prefixes
  var clean = agencyStr.replace(/^(DEPT OF DEFENSE\.?|Department of Defense\.?)/i, '').replace(/^\./,'').trim();
  if (clean.length > 40) clean = clean.substring(0, 40) + '...';
  return clean || agencyStr.substring(0, 40) || 'Unassigned';
}

function mapDepartment(agencyName) {
  if (!agencyName) return 'Unknown';
  // Direct match
  if (DOD_DEPT_MAP[agencyName]) return DOD_DEPT_MAP[agencyName];
  // Substring match (handles partial names like "Army Contracting Command")
  var upper = agencyName.toUpperCase();
  var keys = Object.keys(DOD_DEPT_MAP);
  for (var i = 0; i < keys.length; i++) {
    if (upper.indexOf(keys[i].toUpperCase()) !== -1 || keys[i].toUpperCase().indexOf(upper) !== -1) {
      return DOD_DEPT_MAP[keys[i]];
    }
  }
  // Fallback heuristics
  if (upper.indexOf('ARMY') !== -1 || upper.indexOf('SOLDIER') !== -1) return 'Department of War';
  if (upper.indexOf('NAVY') !== -1 || upper.indexOf('NAVAL') !== -1 || upper.indexOf('MARINE') !== -1) return 'Department of War';
  if (upper.indexOf('AIR FORCE') !== -1 || upper.indexOf('USAF') !== -1) return 'Department of War';
  if (upper.indexOf('DEFENSE') !== -1 || upper.indexOf('DOD') !== -1) return 'Department of War';
  return agencyName.substring(0, 50) || 'Unassigned';
}

// Shared utility: calculate EIS fit score for an opportunity
// SETA=+20, sim/training=+15, cyber=+10, IT=+5, target agency=+10, SB set-aside=+5
function calculateEisBonus(opp) {
  var bonus = 0; var bonuses = [];
  var text = ((opp.title || '') + ' ' + (opp.description || '') + ' ' + (opp.naics_code || opp.naics || '')).toUpperCase();
  if (text.indexOf('SETA') !== -1 || text.indexOf('SYSTEMS ENGINEERING') !== -1 || text.indexOf('TECHNICAL ASSISTANCE') !== -1) { bonus += 20; bonuses.push('SETA +20'); }
  if (text.indexOf('SIMULATION') !== -1 || text.indexOf('TRAINING') !== -1 || text.indexOf('MODELING') !== -1) { bonus += 15; bonuses.push('Sim/Training +15'); }
  if (text.indexOf('CYBER') !== -1 || text.indexOf('INFORMATION ASSURANCE') !== -1 || text.indexOf('CYBERSECURITY') !== -1) { bonus += 10; bonuses.push('Cyber +10'); }
  if (text.indexOf('541512') !== -1 || text.indexOf('COMPUTER SYSTEMS') !== -1 || text.indexOf('IT ') !== -1 || text.indexOf('INFORMATION TECHNOLOGY') !== -1) { bonus += 5; bonuses.push('IT +5'); }
  var TA = ['SOCOM', 'TRADOC', 'PEO STRI', 'INSCOM', 'CYBERCOM', 'DISA', 'INDOPACOM', 'AFC', 'ARMY FUTURES'];
  for (var i = 0; i < TA.length; i++) { if (text.indexOf(TA[i]) !== -1) { bonus += 10; bonuses.push('Target Agency +10'); break; } }
  var sa = ((opp.setAside || '') + ' ' + (opp.set_aside || '')).toUpperCase();
  if (sa.indexOf('SMALL') !== -1 || sa.indexOf('SBA') !== -1 || sa.indexOf('8(A)') !== -1 || sa.indexOf('SDVOSB') !== -1 || sa.indexOf('WOSB') !== -1 || sa.indexOf('HUBZONE') !== -1) { bonus += 5; bonuses.push('Set-Aside +5'); }
  return { bonus: bonus, bonuses: bonuses };
}
function calculateEisFitScore(opp) {
  // Real composite: (Needs×4) + (Financials×30) + (OODA×0.3) + EIS bonuses, capped 100
  var bd = calculateEisBonus(opp);
  if (opp.needs_score != null && opp.financials_score != null && opp.ooda_score != null) {
    return Math.min(100, Math.round((opp.needs_score * 4) + (opp.financials_score * 30) + (opp.ooda_score * 0.3) + bd.bonus));
  }
  return Math.min(100, bd.bonus);
}

// ============================================================
const OPP_URGENCY_COLOR = {critical:'#dc2626',high:'#ea580c',medium:'#d97706',low:'#65a30d',none:'#6b7280'};
function OppSourceBadge({source}){const c={'SAM.gov':'#2563eb','GovWin':'#7c3aed','GovTribe':'#0891b2','FPDS':'#2F5C1F',manual:'#6b7280'};const bg={'SAM.gov':'#eff6ff','GovWin':'#f5f3ff','GovTribe':'#ecfeff','FPDS':'#ecfdf5',manual:'#f3f4f6'};return <span style={{display:'inline-block',padding:'1px 7px',borderRadius:10,fontSize:11,fontWeight:600,background:bg[source]||'#f3f4f6',color:c[source]||'#6b7280',border:`1px solid ${c[source]||'#d1d5db'}33`}}>{source||'Unknown'}</span>;}
function OppFitBar({score,max=10}){const pct=Math.min(100,(score/max)*100);const color=pct>=70?'#16a34a':pct>=40?'#d97706':'#dc2626';return <div style={{display:'flex',alignItems:'center',gap:6}}><div style={{width:60,height:6,background:'#e5e7eb',borderRadius:3}}><div style={{width:pct+'%',height:'100%',background:color,borderRadius:3}}/></div><span style={{fontSize:11,fontWeight:600,color}}>{score.toFixed(1)}</span></div>;}
function getDeptForAgency(agency){
  return mapDepartment(agency||'');
}


var STAGE_COLORS = {
  Identified:    { bg: '#F3F4F6', text: '#6B7280' },
  Investigating: { bg: '#EFF6FF', text: '#32448A' },
  Pursuing:      { bg: '#B06D3212', text: '#B06D32' },
  Proposal:      { bg: '#32448A12', text: '#32448A' },
  Submitted:     { bg: '#ECFEFF', text: '#5091A7' },
  Won:           { bg: '#2F5C1F15', text: '#2F5C1F' },
  Lost:          { bg: '#FEF2F2', text: '#DC2626' },
  'No-Go':       { bg: '#F3F4F6', text: '#374151' },
  Qualified:     { bg: '#EFF6FF', text: '#1D4ED8' },
  Capture:       { bg: '#B06D3212', text: '#C2410C' },
  Award:         { bg: '#2F5C1F15', text: '#2F5C1F' }
};
var VALID_STAGES = ['Identified','Investigating','Pursuing','Proposal','Submitted','Won','Lost','No-Go'];
var STAGE_MAP = { Qualified: 'Investigating', Capture: 'Pursuing', Award: 'Won' };
function normalizeStage(s) { return STAGE_MAP[s] || s || 'Identified'; }
function stageColor(s) { return STAGE_COLORS[s] || STAGE_COLORS[normalizeStage(s)] || STAGE_COLORS.Identified; }
function suggestedStage(o) {
  if ((o.stage || 'Identified') !== 'Identified') return null;
  var dl = o.response_deadline ? Math.ceil((new Date(o.response_deadline) - new Date()) / 86400000) : null;
  if (dl !== null && dl <= 30 && dl > 0) return 'Investigating';
  if ((o.eis_fit_score || 0) >= 30) return 'Investigating';
  return null;
}
function inferCommand(opp) {
  var title = (opp.agency || opp.title || '').toUpperCase();
  var milDept = (opp.cabinet_department || opp.dept || '').toUpperCase();
  if (milDept.indexOf('ARMY') !== -1) {
    if (title.indexOf('SIMULATION') !== -1 || title.indexOf('C2 DIGITAL') !== -1 || title.indexOf('MODELING') !== -1 || title.indexOf('SIM SUPPORT') !== -1) return 'PEO STRI';
    if (title.indexOf('TRAINING') !== -1 || title.indexOf('TRADOC') !== -1 || title.indexOf('TARGETING') !== -1 || title.indexOf('RANGE') !== -1) return 'TRADOC / PEO STRI';
    if (title.indexOf('INTEL') !== -1 || title.indexOf('INSCOM') !== -1 || title.indexOf('MIOSS') !== -1 || title.indexOf('OSINT') !== -1) return 'INSCOM / G2';
    if (title.indexOf('FUTURES') !== -1 || title.indexOf('AUTONOMY') !== -1 || title.indexOf('AFC') !== -1 || title.indexOf('MODERNIZ') !== -1) return 'Army Futures Command';
    if (title.indexOf('CYBER') !== -1 || title.indexOf('ARCYBER') !== -1) return 'ARCYBER';
    return 'ASA(ALT)';
  }
  if (milDept.indexOf('AIR FORCE') !== -1) {
    if (title.indexOf('DC3') !== -1 || title.indexOf('CRIME') !== -1) return 'DC3 / AFOSI';
    if (title.indexOf('TRAINING') !== -1 || title.indexOf('RANGE') !== -1) return 'AETC';
    if (title.indexOf('ACQUISITION') !== -1 || title.indexOf('AF ACQ') !== -1) return 'SAF/AQ';
    if (title.indexOf('AI ') !== -1 || title.indexOf('ARTIFICIAL') !== -1) return 'SAF/DT';
    if (title.indexOf('CYBER') !== -1 || title.indexOf('ISR') !== -1) return '16th Air Force';
    return 'HAF';
  }
  if (milDept.indexOf('NAVY') !== -1 || milDept.indexOf('NAVAL') !== -1 || milDept.indexOf('MARINE') !== -1) {
    if (title.indexOf('NAWCAD') !== -1 || title.indexOf('SUAS') !== -1 || title.indexOf('NAVAIR') !== -1) return 'NAVAIR';
    if (title.indexOf('NAVSEA') !== -1 || title.indexOf('SHIPYARD') !== -1) return 'NAVSEA';
    if (title.indexOf('TRAINING') !== -1 || title.indexOf('EWTG') !== -1) return 'NETC';
    if (title.indexOf('MARITIME') !== -1) return 'OPNAV';
    return 'ONR';
  }
  if (milDept.indexOf('SPECIAL OPERATIONS') !== -1) {
    if (title.indexOf('TGM') !== -1 || title.indexOf('DRIVING') !== -1) return 'USASOC';
    if (title.indexOf('MEDICAL') !== -1) return 'USSOCOM J4';
    return 'HQ SOCOM';
  }
  if (milDept.indexOf('DEFENSE INFORMATION SYSTEMS') !== -1 || title.indexOf('DISA') !== -1) return 'DISA Direct';
  if (milDept.indexOf('TRANSPORTATION COMMAND') !== -1) return 'TRANSCOM J6';
  if (milDept.indexOf('DEFENSE INTELLIGENCE') !== -1) return 'DIA Direct';
  if (milDept.indexOf('SPACE FORCE') !== -1) return 'Space Systems Command';
  if (milDept.indexOf('GEOSPATIAL') !== -1) return 'NGA Direct';
  if (milDept.indexOf('CYBER COMMAND') !== -1) return 'CYBERCOM Direct';
  return agencyToLevel2(opp.agency || '') || opp.level_2 || (opp.agency ? opp.agency.substring(0,40) : 'Other');
}
function OppTracker() {
  var _opps = React.useState([]); var opps = _opps[0]; var setOpps = _opps[1];
  var _loading = React.useState(true); var loading = _loading[0]; var setLoading = _loading[1];
  var _refreshing = React.useState(false); var refreshing = _refreshing[0]; var setRefreshing = _refreshing[1];
  var _lastRefresh = React.useState(null); var lastRefresh = _lastRefresh[0]; var setLastRefresh = _lastRefresh[1];
  var _error = React.useState(null); var error = _error[0]; var setError = _error[1];
  var _deptFilter = React.useState('all'); var deptFilter = _deptFilter[0]; var setDeptFilter = _deptFilter[1];
  var _sizeFilter = React.useState('all'); var sizeFilter = _sizeFilter[0]; var setSizeFilter = _sizeFilter[1];
  var _ouFilter = React.useState([]); var ouFilter = _ouFilter[0]; var setOuFilter = _ouFilter[1];
  var _naicsFilter = React.useState('all'); var naicsFilter = _naicsFilter[0]; var setNaicsFilter = _naicsFilter[1];
  var _fitFilter = React.useState('all'); var fitFilter = _fitFilter[0]; var setFitFilter = _fitFilter[1];
  var _saFilter = React.useState('all'); var saFilter = _saFilter[0]; var setSaFilter = _saFilter[1];
  var _sortBy = React.useState('fit'); var sortBy = _sortBy[0]; var setSortBy = _sortBy[1];
  var _detail = React.useState(null); var detail = _detail[0]; var setDetail = _detail[1];
  var _viewMode = React.useState('grouped'); var viewMode = _viewMode[0]; var setViewMode = _viewMode[1];
  var _openCabs = React.useState(function() { return new Set(); }); var openCabs = _openCabs[0]; var setOpenCabs = _openCabs[1];
  var _closedAgs = React.useState(function() { return new Set(); }); var closedAgs = _closedAgs[0]; var setClosedAgs = _closedAgs[1];
  var _openScores = React.useState(function() { return new Set(); }); var openScores = _openScores[0]; var setOpenScores = _openScores[1];
  var _openAnalysis = React.useState(function() { return new Set(); }); var openAnalysis = _openAnalysis[0]; var setOpenAnalysis = _openAnalysis[1];
  var _showScoreLegend = React.useState(false); var showScoreLegend = _showScoreLegend[0]; var setShowScoreLegend = _showScoreLegend[1];
  var _openDepts = React.useState(function() { return new Set(); }); var openDepts = _openDepts[0]; var setOpenDepts = _openDepts[1];
  var _openCmds = React.useState(function() { return new Set(); }); var openCmds = _openCmds[0]; var setOpenCmds = _openCmds[1];
  var _marketOpen = React.useState(false); var marketOpen = _marketOpen[0]; var setMarketOpen = _marketOpen[1];
  var _marketDept = React.useState('Department of War'); var marketDept = _marketDept[0]; var setMarketDept = _marketDept[1];
  var _openDetails = React.useState(function() { return new Set(); }); var openDetails = _openDetails[0]; var setOpenDetails = _openDetails[1];
  var _aiState = React.useState({}); var aiState = _aiState[0]; var setAiState = _aiState[1];
  var _idiqs = React.useState([]); var idiqs = _idiqs[0]; var setIdiqs = _idiqs[1];
  var _idiqOpen = React.useState(false); var idiqOpen = _idiqOpen[0]; var setIdiqOpen = _idiqOpen[1];
  var _idiqExpanded = React.useState(null); var idiqExpanded = _idiqExpanded[0]; var setIdiqExpanded = _idiqExpanded[1];
  var _idiqSummary = React.useState({}); var idiqSummary = _idiqSummary[0]; var setIdiqSummary = _idiqSummary[1];

  // ── Performance: debounced filters ──────────────────────
  var _debouncedFilters = React.useState(function() {
    return { deptFilter: 'all', naicsFilter: 'all', fitFilter: 'all', saFilter: 'all', sortBy: 'fit' };
  });
  var debouncedFilters = _debouncedFilters[0]; var setDebouncedFilters = _debouncedFilters[1];

  React.useEffect(function() {
    var timer = setTimeout(function() {
      setDebouncedFilters({ deptFilter: deptFilter, naicsFilter: naicsFilter, fitFilter: fitFilter, saFilter: saFilter, sortBy: sortBy });
    }, 150);
    return function() { clearTimeout(timer); };
  }, [deptFilter, naicsFilter, fitFilter, saFilter, sortBy]);

  function fetchOpps() {
    setLoading(true); setError(null);
    fetchOppData()
      .then(function(r) {
        var items = [];
        if (r && r.opportunities && r.opportunities.length > 0) { items = r.opportunities; }
        else if (r && Array.isArray(r.departments)) {
          r.departments.forEach(function(d) {
            (d.agencies || []).forEach(function(a) {
              (a.programs || []).forEach(function(p) {
                items.push(Object.assign({}, p, {
                  agency: p.agency || a.agency,
                  cabinet_department: mapDepartment(a.agency) || p.cabinet_department || d.dept,
                  title: p.title || p.name,
                  response_deadline: p.response_deadline || p.due,
                  solicitation_number: p.solicitation_number || p.sol,
                  naics_code: p.naics_code || p.naics,
                  eis_fit_score: p.eis_fit_score || p.score || 0,
                  estimated_value: p.estimated_value || p.contract_value || p.value || null
                }));
              });
            });
          });
        // opportunities already handled above
        } else if (Array.isArray(r)) { items = r; } else if (r && r.opportunities) { items = r.opportunities.map(function(o) { return Object.assign({}, o, { title: o.title || o.name, cabinet_department: o.cabinet_department || o.dept || mapDepartment(o.agency) }); }); }
        if (!Array.isArray(items)) items = [];
        // govtribe_alerts stored separately, NOT merged into main display
        var _govAlerts = (r && Array.isArray(r.govtribe_alerts)) ? r.govtribe_alerts : [];
        items = items.map(function(o) {
          return Object.assign({}, o, {
            title: o.opp_title || o.title || o.name || o.agency,
            cabinet_department: normalizeDept(o.level_1 || o.cabinet_department || o.dept || mapDepartment(o.agency)),
            level_2: o.level_2 || agencyToLevel2(o.agency),
            level_3: o.level_3 || 'Unassigned',
            eis_fit_score: o.eis_fit_score || o.fit_score || o.score || calculateEisFitScore(o)
          });
        });
        setOpps(items);
        setLastRefresh(new Date().toLocaleString());
        setLoading(false);
        // S-106: Auto-navigate to target opp from Launchpad
        if (gdaNav.oppTarget) {
          var target = gdaNav.oppTarget;
          gdaNav.oppTarget = null;
          setViewMode('flat');
          var found = items.find(function(o) {
            if (target.id && o.id === target.id) return true;
            if (target.solicitation && o.solicitation_number === target.solicitation) return true;
            if (target.title && (o.opp_title || o.title || '') === target.title) return true;
            return false;
          });
          if (found) {
            var oppKey = found.id || found.govtribe_id || ((found.opp_title || found.title || '') + '0');
            setTimeout(function() { setDetail(oppKey); }, 300);
          }
        }
        api.post('gda-data-learn', {event:'opps_loaded', context:'opp-tracker', data:{count:items.length}}).catch(function(){});
    api.post('gda-idiq-tracker',{action:'list'}).then(function(r){setIdiqs(r.idiqs||r.data||[]);setIdiqSummary(r.summary||{});}).catch(function(){});
      })
      .catch(function(err) { setError('Failed to load: ' + err.message); setLoading(false); });
  }

  function handleRefresh() {
    setRefreshing(true);
    setError(null);
    invalidateOppCache(); api.post('gda-opp-tracker', {action:'refresh'})
      .then(function() {
        setRefreshing(false);
        fetchOpps();
      })
      .catch(function() { setRefreshing(false); setError('Refresh failed — data shown is last loaded.'); fetchOpps(); });
  }

  function updateStage(opp, newStage) {
    setOpps(function(prev) {
      return prev.map(function(o) { return o.id === opp.id ? Object.assign({}, o, { stage: newStage }) : o; });
    });
    api.post('gda-data-learn',{event:'opp_stage_change',data_type:'interaction',context:'opp-tracker',data:{opp_id:opp.id,new_stage:newStage}}).catch(function(){}); api.post('gda-opp-tracker', { action: 'update_stage', opp_id: opp.id, stage: newStage })
      .catch(function() {
        setOpps(function(prev) {
          return prev.map(function(o) { return o.id === opp.id ? Object.assign({}, o, { stage: opp.stage || 'Identified' }) : o; });
        });
      });
  }

  function askAiForOpp(opp, question) {
    var key = opp.govtribe_id || opp.id || opp.agency;
    setAiState(function(p) { return Object.assign({}, p, {[key]: Object.assign({}, p[key], { loading: true, answer: null })}); });
    api.post('gda-opp-tracker', { action: 'ask', opp_id: opp.id || opp.govtribe_id, question: question, opp_title: opp.title || opp.agency, opp_context: (opp.description || '') })
      .then(function(r) {
        var ans = r.answer || r.response || r.result || r.text || (typeof r === 'string' ? r : JSON.stringify(r));
        setAiState(function(p) { return Object.assign({}, p, {[key]: { loading: false, answer: ans, pendingQ: question }}); });
      })
      .catch(function(err) {
        setAiState(function(p) { return Object.assign({}, p, {[key]: { loading: false, answer: 'Could not reach AI endpoint: ' + err.message, pendingQ: question }}); });
      });
  }

  function runOodaForOpp(opp, key) {
    var tid = setTimeout(function() {
      setAiState(function(p) {
        if (!p[key] || !p[key].oodaLoading) return p;
        return Object.assign({}, p, {[key]: Object.assign({}, p[key], { oodaLoading: false, oodaError: 'Analysis timed out' })});
      });
    }, 45000);
    api.post('gda-ooda', { target: opp.title || opp.agency, target_type: 'opportunity' })
      .then(function(r) {
        clearTimeout(tid);
        var data = r || {};
        var pwin = data.win_probability || data.pwin || data._pwin || 0;
        var confidence = data.confidence || data.confidence_score || 0;
        data._pwin = pwin; data._confidence = confidence;
        data._recommendation = data.recommendation || (pwin >= 50 ? 'BID' : pwin >= 25 ? 'EVALUATE' : 'MONITOR');
        setAiState(function(p) { return Object.assign({}, p, {[key]: Object.assign({}, p[key], { oodaLoading: false, oodaResult: data })}); });
      })
      .catch(function(err) {
        clearTimeout(tid);
        setAiState(function(p) { return Object.assign({}, p, {[key]: Object.assign({}, p[key], { oodaLoading: false, oodaError: err.message })}); });
      });
  }

  function addActionItemForOpp(opp, key) {
    setAiState(function(p) { return Object.assign({}, p, {[key]: Object.assign({}, p[key], { actionAdding: true })}); });
    api.post('gda-action-items', { action: 'create', title: 'Follow up: ' + (opp.title || opp.agency), status: 'open', priority: 'high', source: 'Opp Tracker', description: formatDollar(opp.estimated_value) + ' | ' + (opp.stage || 'Identified') + ' | ' + (opp.cabinet_department || opp.dept || '') })
      .then(function() {
        setAiState(function(p) { return Object.assign({}, p, {[key]: Object.assign({}, p[key], { actionAdding: false, actionAdded: true })}); });
        setTimeout(function() { setAiState(function(p) { return Object.assign({}, p, {[key]: Object.assign({}, p[key], { actionAdded: false })}); }); }, 3000);
      })
      .catch(function() {
        setAiState(function(p) { return Object.assign({}, p, {[key]: Object.assign({}, p[key], { actionAdding: false })}); });
      });
  }

  React.useEffect(function() { if (opps.length === 0) fetchOpps(); }, []);

  var filtered = React.useMemo(function() {
    var df = debouncedFilters;
    var result = opps.slice();
    if (df.deptFilter !== 'all') result = result.filter(function(o) { var rawL1 = o.level_1 || o.cabinet_department || o.dept || ''; var mappedL1 = DOD_CABINET_MAP[rawL1] || rawL1; return mappedL1 === df.deptFilter; });
    // S-111: Business size filter
    if (sizeFilter === 'sb') result = result.filter(function(o) { return o.sb_qualified === true; });
    if (sizeFilter === 'lb') result = result.filter(function(o) { return o.sb_qualified === false; });
    // S-111: OU filter (OR logic)
    if (ouFilter.length > 0) result = result.filter(function(o) { if (!o.assigned_ou) return false; return ouFilter.some(function(ou) { return (o.assigned_ou || '').indexOf(ou) !== -1; }); });
    if (df.naicsFilter !== 'all') result = result.filter(function(o) { return (o.naics_code || o.naics || '').indexOf(df.naicsFilter) !== -1; });
    if (df.fitFilter === 'high') result = result.filter(function(o) { return (o.gda_score || calculateGDAScore(o)) >= 60; });
    else if (df.fitFilter === 'medium') result = result.filter(function(o) { var s = o.gda_score || calculateGDAScore(o); return s >= 40 && s < 60; });
    else if (df.fitFilter === 'low') result = result.filter(function(o) { return (o.gda_score || calculateGDAScore(o)) < 40; });
    if (df.saFilter !== 'all') result = result.filter(function(o) { return (o.set_aside || '').toUpperCase().indexOf(df.saFilter.toUpperCase()) !== -1; });
    if (df.sortBy === 'fit') result.sort(function(a, b) { return (b.gda_score || calculateGDAScore(b)) - (a.gda_score || calculateGDAScore(a)); });
    else if (df.sortBy === 'value') result.sort(function(a, b) { return (b.estimated_value || 0) - (a.estimated_value || 0); });
    else if (df.sortBy === 'deadline') result.sort(function(a, b) {
      var da = a.response_deadline ? new Date(a.response_deadline) : new Date('2099-01-01');
      var db = b.response_deadline ? new Date(b.response_deadline) : new Date('2099-01-01');
      return da - db;
    });
    return result;
  }, [opps, debouncedFilters, sizeFilter, ouFilter]);

  var groupedOpps = React.useMemo(function() {
    var cabMap = {};
    filtered.forEach(function(o) {
      var cab = o.level_1 || DOD_CABINET_MAP[o.cabinet_department] || o.cabinet_department || 'Department of War';
      var agencyDept = o.level_2 || agencyToLevel2(o.agency) || 'Other';
      var cmd = o.level_3 || inferCommand(o);
      if (!cabMap[cab]) cabMap[cab] = { name: cab, depts: {}, count: 0, value: 0, totalFit: 0 };
      var cabObj = cabMap[cab];
      if (!cabObj.depts[agencyDept]) cabObj.depts[agencyDept] = { name: agencyDept, commands: {}, count: 0, value: 0, totalFit: 0 };
      var deptObj = cabObj.depts[agencyDept];
      if (!deptObj.commands[cmd]) deptObj.commands[cmd] = { name: cmd, opps: [], count: 0, value: 0 };
      var cmdObj = deptObj.commands[cmd];
      cmdObj.opps.push(o);
      cmdObj.count++;
      cmdObj.value += (parseFloat(o.estimated_value) || 0);
      deptObj.count++;
      deptObj.value += (parseFloat(o.estimated_value) || 0);
      deptObj.totalFit += (o.gda_score || calculateGDAScore(o));
      cabObj.count++;
      cabObj.value += (parseFloat(o.estimated_value) || 0);
      cabObj.totalFit += (o.gda_score || calculateGDAScore(o));
    });
    return Object.values(cabMap).map(function(c) {
      c.avgFit = c.count > 0 ? Math.round(c.totalFit / c.count) : 0;
      // Add PASS subcomponent: collect all PASS-scored opps under each dept
      var passOpps = [];
      c.depts = Object.values(c.depts).map(function(d) {
        d.commands = Object.values(d.commands).sort(function(a, b) { return b.count - a.count || b.value - a.value; });
        return d;
      });
      // Separate active depts from PASS depts at level 2
      var activeDepts = [];
      var cabinetPassOpps = [];
      c.depts.forEach(function(d) {
        var deptActive = [];
        var deptPass = [];
        (d.commands || []).forEach(function(cmd) {
          (cmd.opps || []).forEach(function(o) {
            var sc = o.gda_score || calculateGDAScore(o);
            if (sc < 40 || o.gda_label === 'PASS') { deptPass.push(o); } else { deptActive.push(o); }
          });
        });
        if (deptActive.length > 0) {
          activeDepts.push(Object.assign({}, d, { count: deptActive.length, value: deptActive.reduce(function(s,o){ return s + (parseFloat(o.estimated_value)||0); }, 0), totalFit: deptActive.reduce(function(s,o){ return s + (o.gda_score || calculateGDAScore(o)); }, 0) }));
        }
        cabinetPassOpps = cabinetPassOpps.concat(deptPass);
      });
      if (cabinetPassOpps.length > 0) {
        activeDepts.push({ name: 'PASS', count: cabinetPassOpps.length, value: cabinetPassOpps.reduce(function(s,o){ return s + (parseFloat(o.estimated_value)||0); }, 0), totalFit: 0, commands: [{ name: 'Archived', opps: cabinetPassOpps, count: cabinetPassOpps.length, value: cabinetPassOpps.reduce(function(s,o){ return s + (parseFloat(o.estimated_value)||0); }, 0) }], isPassBucket: true });
      }
      c.depts = activeDepts.sort(function(a, b) { if (a.isPassBucket) return 1; if (b.isPassBucket) return -1; return b.value - a.value; });
      c.count = activeDepts.reduce(function(s,d){ return s + d.count; }, 0);
      return c;
    }).sort(function(a, b) { return b.value - a.value; });
  }, [filtered]);

  var _initCollapse = React.useRef(false);
  React.useEffect(function() {
    if (_initCollapse.current || groupedOpps.length === 0) return;
    _initCollapse.current = true;
    // L1: all cabinets expanded
    var allCabNames = groupedOpps.map(function(c) { return c.name; });
    setOpenCabs(new Set(allCabNames));
    // L2: only the single largest dept expanded
    var maxDept = { key: '', count: 0 };
    groupedOpps.forEach(function(cab) {
      (cab.depts || []).forEach(function(dept) {
        var key = cab.name + '::' + dept.name;
        if (dept.count > maxDept.count) maxDept = { key: key, count: dept.count };
      });
    });
    setOpenDepts(new Set(maxDept.key ? [maxDept.key] : []));
    // L3: all commands collapsed (BL-046)
    setOpenCmds(new Set());
  }, [groupedOpps]);

  var deptStats = React.useMemo(function() {
    var map = {};
    opps.forEach(function(o) {
      var d = o.level_2 || DOD_CABINET_MAP[o.cabinet_department] || o.cabinet_department || 'Unknown';
      if (!map[d]) map[d] = { name: d, count: 0, value: 0, avgFit: 0, totalFit: 0 };
      map[d].count++;
      map[d].value += (parseFloat(o.estimated_value) || 0);
      map[d].totalFit += (o.eis_fit_score || 0);
    });
    var arr = Object.values(map);
    arr.forEach(function(d) { d.avgFit = d.count > 0 ? Math.round(d.totalFit / d.count) : 0; });
    arr.sort(function(a, b) { return b.value - a.value; });
    return arr.slice(0, 5);
  }, [opps]);

  var departments = React.useMemo(function() {
    var s = new Set(); opps.forEach(function(o) { var rawL1 = o.level_1 || o.cabinet_department || o.dept; if (rawL1) s.add(DOD_CABINET_MAP[rawL1] || rawL1); });
    return Array.from(s).sort();
  }, [opps]);

  var naicsCodes = React.useMemo(function() {
    var s = new Set(); opps.forEach(function(o) { if (o.naics_code) s.add(o.naics_code); });
    return Array.from(s).sort();
  }, [opps]);

  var totalValue = opps.reduce(function(s, o) { return s + (parseFloat(o.estimated_value) || 0); }, 0);
  var highFitCount = opps.filter(function(o) { return (o.gda_score || calculateGDAScore(o)) >= 60; }).length;
  var avgFit = opps.length > 0 ? Math.round(opps.reduce(function(s, o) { return s + (o.gda_score || calculateGDAScore(o)); }, 0) / opps.length) : 0;

  var predictiveInsights = React.useMemo(function() {
    var now = new Date();
    var activeCabs = new Set(groupedOpps.map(function(c) { return c.name; }));
    var gaps = Object.keys(DEPT_BUDGETS).filter(function(k) { return !activeCabs.has(k); });
    var weekMap = {};
    filtered.forEach(function(o) {
      if (!o.response_deadline) return;
      var d = new Date(o.response_deadline);
      if (d < now) return;
      var wk = Math.floor((d - now) / (7 * 86400000));
      if (wk < 0 || wk > 26) return;
      if (!weekMap[wk]) weekMap[wk] = { week: wk, count: 0, opps: [] };
      weekMap[wk].count++; weekMap[wk].opps.push(o.title || 'Untitled');
    });
    var clusters = Object.values(weekMap).filter(function(w) { return w.count >= 3; }).sort(function(a, b) { return a.week - b.week; });
    var recompetes = filtered.filter(function(o) { return (o.title || '').toLowerCase().indexOf('recompete') !== -1; });
    var ungated = filtered.filter(function(o) { return (parseFloat(o.estimated_value) || 0) > 50e6 && (!o.stage || o.stage === 'Identified' || o.stage === 'Qualified'); });
    return { gaps: gaps, clusters: clusters, recompetes: recompetes, ungated: ungated };
  }, [filtered, groupedOpps]);

  var S = {
    page: { padding: '24px', fontFamily: 'Inter, sans-serif' },
    header: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' },
    h2: { margin: 0, color: '#1B2A4A', fontSize: '22px', fontWeight: 700 },
    kpiRow: { display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(160px, 1fr))', gap: '12px', marginBottom: '20px', justifyContent: 'center' },
    kpiCard: function(accent) { return { background: '#fff', border: '1px solid #E8ECF1', borderRadius: '10px', padding: '16px 12px', textAlign: 'center', borderTop: '3px solid ' + (accent || '#1B3A6B'), display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', minHeight: 90 }; },
    kpiVal: { fontSize: '24px', fontWeight: 700, color: '#1B2A4A', margin: '4px 0', textAlign: 'center' },
    kpiLabel: { fontSize: '12px', color: '#6B7280', textTransform: 'uppercase', letterSpacing: '0.5px', textAlign: 'center' },
    deptRow: { display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', gap: '10px', marginBottom: '20px' },
    deptCard: { background: '#1B2A4A', border: '1px solid #1B2A4A', borderRadius: '10px', padding: '14px', cursor: 'pointer', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', textAlign: 'center' },
    filterRow: { display: 'flex', gap: '10px', marginBottom: '16px', flexWrap: 'wrap', alignItems: 'center' },
    select: { padding: '8px 12px', border: '1px solid #E8ECF1', borderRadius: '6px', fontSize: '13px', color: '#1B2A4A', background: '#fff', fontFamily: 'Inter, sans-serif' },
    btn: { padding: '8px 16px', border: '1px solid #E8ECF1', borderRadius: '6px', fontSize: '13px', cursor: 'pointer', fontFamily: 'Inter, sans-serif' },
    refreshBtn: { padding: '8px 16px', background: '#D14A2A', color: '#fff', border: 'none', borderRadius: '6px', fontSize: '13px', cursor: 'pointer', fontWeight: 600 },
    card: { background: '#fff', border: '1px solid #E8ECF1', borderRadius: '10px', padding: '16px', marginBottom: '10px' },
    cardTitle: { fontSize: '15px', fontWeight: 600, color: '#1B2A4A', margin: '0 0 8px' },
    cardMeta: { display: 'flex', gap: '16px', flexWrap: 'wrap', fontSize: '12px', color: '#6B7280' },
    badge: function(score) {
      var bg = score >= 30 ? '#2F5C1F15' : score >= 15 ? '#B06D3212' : '#F3F4F6';
      var fg = score >= 30 ? '#2F5C1F' : score >= 15 ? '#D14A2A' : '#6B7280';
      return { background: bg, color: fg, padding: '2px 10px', borderRadius: '12px', fontWeight: 700, fontSize: '13px', display: 'inline-block' };
    },
    link: { color: '#D14A2A', textDecoration: 'none', fontSize: '12px', fontWeight: 600 }
  };

  if (loading) {
    return React.createElement('div', { style: Object.assign({}, S.page, { textAlign: 'center', paddingTop: '80px' }) },
      React.createElement('div', { style: { fontSize: '14px', color: '#6B7280' } }, 'Loading opportunities...')
    );
  }

  try { return React.createElement('div', { style: S.page },
    React.createElement('div', { style: S.header },
      React.createElement('div', null,
        React.createElement('h2', { style: S.h2 }, 'Opportunity Tracker'),
        lastRefresh && React.createElement('span', { style: { fontSize: '12px', color: '#6B7280' } }, 'Last refreshed: ' + lastRefresh)
      ),
      React.createElement('div', { style: { display: 'flex', gap: '8px', alignItems: 'center' } },
        React.createElement('span', { style: { fontSize: '13px', color: '#6B7280' } }, filtered.length + ' of ' + opps.length + ' shown'),
        React.createElement('button', {
          style: Object.assign({}, S.refreshBtn, refreshing ? { opacity: 0.6 } : {}),
          onClick: handleRefresh, disabled: refreshing
        }, refreshing ? 'Syncing...' : 'Refresh from GovWin / SAM.gov')
      )
    ),
    error && React.createElement('div', {
      style: { background: '#FEF2F2', border: '1px solid #FCA5A5', borderRadius: '8px', padding: '12px', marginBottom: '16px', color: '#991B1B', fontSize: '13px' }
    }, error),
    React.createElement('div', { style: S.kpiRow },
      React.createElement('div', { style: S.kpiCard('#2F5C1F') },
        React.createElement('div', { style: S.kpiLabel }, 'Total Opportunity Value'),
        React.createElement('div', { style: S.kpiVal }, formatDollar(totalValue))
      ),
      React.createElement('div', { style: S.kpiCard('#1B3A6B') },
        React.createElement('div', { style: S.kpiLabel }, 'Opportunities'),
        React.createElement('div', { style: S.kpiVal }, opps.length)
      ),
      React.createElement('div', { style: S.kpiCard('#1B3A6B') },
        React.createElement('div', { style: S.kpiLabel }, 'Evaluate+ (60+)'),
        React.createElement('div', { style: Object.assign({}, S.kpiVal, { color: '#2F5C1F' }) }, highFitCount)
      ),
      React.createElement('div', { style: S.kpiCard('#1B3A6B') },
        React.createElement('div', { style: S.kpiLabel }, 'Avg GDA Score'),
        React.createElement('div', { style: S.kpiVal }, avgFit)
      )
    ),
    React.createElement('div', { style: { marginBottom: '20px' } },
      React.createElement('h3', { style: { fontSize: '15px', color: '#1B2A4A', margin: '0 0 10px', fontWeight: 600 } }, 'Top Departments by Opportunity Value'),
      React.createElement('div', { style: S.deptRow },
        deptStats.map(function(d) {
          return React.createElement('div', {
            key: d.name, style: Object.assign({}, S.deptCard, deptFilter === d.name ? { borderColor: '#ffffff', borderWidth: '2px', boxShadow: '0 0 0 1px #D14A2A' } : {}),
            onClick: function() { setDeptFilter(deptFilter === d.name ? 'all' : d.name); }
          },
            React.createElement('div', { style: { fontSize: '13px', fontWeight: 600, color: '#ffffff', marginBottom: '6px' } }, d.name),
            React.createElement('div', { style: { fontSize: '18px', fontWeight: 700, color: '#ffffff' } }, formatDollar(d.value)),
            React.createElement('div', { style: { fontSize: '11px', color: 'rgba(255,255,255,0.7)', marginTop: '4px' } }, d.count + ' opps | Avg GDA: ' + d.avgFit)
          );
        })
      )
    ),
    React.createElement('div', { style: { display: 'flex', gap: '10px', marginBottom: '16px', flexWrap: 'wrap' } },
      React.createElement('select', { style: S.select, value: sizeFilter, onChange: function(e) { setSizeFilter(e.target.value); } },
        React.createElement('option', { value: 'all' }, 'All Sizes'),
        React.createElement('option', { value: 'sb' }, '✅ SB Qualified'),
        React.createElement('option', { value: 'lb' }, '⚠ Large Business')
      ),
      React.createElement('select', { style: S.select, value: naicsFilter, onChange: function(e) { setNaicsFilter(e.target.value); } },
        React.createElement('option', { value: 'all' }, 'All NAICS'),
        naicsCodes.map(function(n) { return React.createElement('option', { key: n, value: n }, n); })
      ),
      React.createElement('div', { style: { display: 'flex', gap: 4, alignItems: 'center' } },
        React.createElement('span', { style: { fontSize: 11, color: '#6B7280', fontWeight: 600, marginRight: 4 } }, 'OU:'),
        ['Enable', 'Protect', 'Train'].map(function(ou) {
          var isActive = ouFilter.indexOf(ou) !== -1;
          return React.createElement('button', {
            key: ou,
            onClick: function() { setOuFilter(function(prev) { return isActive ? prev.filter(function(x){return x!==ou;}) : prev.concat(ou); }); },
            style: { padding: '4px 10px', fontSize: 11, fontWeight: 600, borderRadius: 14, border: isActive ? '1.5px solid #D14A2A' : '1px solid #D1D5DB', background: isActive ? '#D14A2A15' : '#fff', color: isActive ? '#D14A2A' : '#6B7280', cursor: 'pointer', fontFamily: 'Inter,sans-serif' }
          }, ou);
        })
      ),
      React.createElement('span', { style: { fontSize: '12px', color: '#6B7280', marginLeft: '8px' } }, 'Sort:'),
      React.createElement('select', { style: S.select, value: sortBy, onChange: function(e) { setSortBy(e.target.value); } },
        React.createElement('option', { value: 'fit' }, 'GDA Score'),
        React.createElement('option', { value: 'value' }, 'Value ($)'),
        React.createElement('option', { value: 'deadline' }, 'Deadline')
      ),
            React.createElement('div', { style: { marginLeft: 'auto', display: 'flex', border: '1px solid #D1D5DB', borderRadius: 6, overflow: 'hidden' } },
        React.createElement('button', { style: { padding: '7px 14px', fontSize: 12, fontWeight: 600, cursor: 'pointer', border: 'none', background: viewMode === 'grouped' ? '#1B2A4A' : '#fff', color: viewMode === 'grouped' ? '#fff' : '#6B7280', fontFamily: 'Inter,sans-serif' }, onClick: function() { setViewMode('grouped'); } }, 'Grouped'),
        React.createElement('button', { style: { padding: '7px 14px', fontSize: 12, fontWeight: 600, cursor: 'pointer', border: 'none', borderLeft: '1px solid #D1D5DB', background: viewMode === 'flat' ? '#1B2A4A' : '#fff', color: viewMode === 'flat' ? '#fff' : '#6B7280', fontFamily: 'Inter,sans-serif' }, onClick: function() { setViewMode('flat'); } }, 'Flat')
      )
    ),
    showScoreLegend && React.createElement('div', { style: { background: '#fff', border: '1px solid #E8ECF1', borderRadius: 10, padding: 20, marginBottom: 16 } },
      React.createElement('div', { style: { fontSize: 14, fontWeight: 700, color: '#1B2A4A', marginBottom: 14 } }, 'GDA Priority Score v2 (0\u2013100) \u2014 What Do I Look At Today?'),
      React.createElement('div', { style: { display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 12, marginBottom: 16 } },
        React.createElement('div', { style: { borderLeft: '4px solid #2F5C1F', borderRadius: 6, padding: '12px', background: '#2F5C1F12' } },
          React.createElement('div', { style: { fontSize: 13, fontWeight: 700, color: '#2F5C1F', marginBottom: 6 } }, 'Tier 1: NAICS & Domain Fit (40 pts)'),
          React.createElement('div', { style: { fontSize: 11, color: '#374151', lineHeight: 1.6 } }, '\u25B8 NAICS Match: 20 pts\n\u25B8 Mission Alignment: 12 pts\n\u25B8 SB NAICS Advantage: 8 pts')
        ),
        React.createElement('div', { style: { borderLeft: '4px solid #D14A2A', borderRadius: 6, padding: '12px', background: '#B06D3212' } },
          React.createElement('div', { style: { fontSize: 13, fontWeight: 700, color: '#D14A2A', marginBottom: 6 } }, 'Tier 2: Competitive Position (30 pts)'),
          React.createElement('div', { style: { fontSize: 11, color: '#374151', lineHeight: 1.6 } }, '\u25B8 Recompete/Incumbent: 15 pts\n\u25B8 Set-Aside Match: 8 pts\n\u25B8 IDIQ Vehicle Held: 7 pts')
        ),
        React.createElement('div', { style: { borderLeft: '4px solid #B06D32', borderRadius: 6, padding: '12px', background: '#B06D3212' } },
          React.createElement('div', { style: { fontSize: 13, fontWeight: 700, color: '#B06D32', marginBottom: 6 } }, 'Tier 3: Urgency (15 pts)'),
          React.createElement('div', { style: { fontSize: 11, color: '#374151', lineHeight: 1.6 } }, '\u25B8 Days to Action (hybrid): 15 pts\n\u25B8 Soonest of your milestone or gov deadline')
        ),
        React.createElement('div', { style: { borderLeft: '4px solid #32448A', borderRadius: 6, padding: '12px', background: '#32448A12' } },
          React.createElement('div', { style: { fontSize: 13, fontWeight: 700, color: '#32448A', marginBottom: 6 } }, 'Tier 4: Strategic Value (15 pts)'),
          React.createElement('div', { style: { fontSize: 11, color: '#374151', lineHeight: 1.6 } }, '\u25B8 Contract Value: 8 pts\n\u25B8 Gateway Effect: 7 pts')
        )
      ),
      React.createElement('div', { style: { background: '#FEF3C7', border: '1px solid #F59E0B', borderRadius: 6, padding: '8px 12px', marginBottom: 12, fontSize: 11, color: '#92400E' } }, '\u26A0 Auto-PASS: Opportunities within 30 days of deadline with no capture plan are automatically scored 0 and marked PASS.'),
      React.createElement('div', { style: { display: 'flex', gap: 16, fontSize: 11, color: '#374151' } },
        React.createElement('span', null, React.createElement('span', { style: { display: 'inline-block', width: 10, height: 10, borderRadius: 2, background: '#2F5C1F', marginRight: 4, verticalAlign: 'middle' } }), '75\u2013100: PURSUE'),
        React.createElement('span', null, React.createElement('span', { style: { display: 'inline-block', width: 10, height: 10, borderRadius: 2, background: '#D14A2A', marginRight: 4, verticalAlign: 'middle' } }), '60\u201379: EVALUATE'),
        React.createElement('span', null, React.createElement('span', { style: { display: 'inline-block', width: 10, height: 10, borderRadius: 2, background: '#B06D32', marginRight: 4, verticalAlign: 'middle' } }), '40\u201359: MONITOR'),
        React.createElement('span', null, React.createElement('span', { style: { display: 'inline-block', width: 10, height: 10, borderRadius: 2, background: '#9CA3AF', marginRight: 4, verticalAlign: 'middle' } }), '0\u201339: PASS')
      )
    ),
    // Predictive Insights removed S-101 per Shawn
        filtered.length === 0 && React.createElement('div', {
      style: { textAlign: 'center', padding: '40px', color: '#6B7280', fontSize: '14px' }
    }, 'No opportunities match current filters'),
    viewMode === 'grouped' ? groupedOpps.map(function(cab, ci) {
      var cabOpen = openCabs.has(cab.name);
      return React.createElement('div', { key: ci, style: { marginBottom: 12 } },
        React.createElement('div', {
          style: { display: 'flex', alignItems: 'center', gap: 10, padding: '10px 16px', background: '#1B2A4A', color: '#fff', borderRadius: cabOpen ? '8px 8px 0 0' : 8, cursor: 'pointer', userSelect: 'none' },
          onClick: function() { setOpenCabs(function(prev) { var s = new Set(prev); s.has(cab.name) ? s.delete(cab.name) : s.add(cab.name); return s; }); }
        },
          React.createElement('span', { style: { fontSize: 13, marginRight: 4 } }, cabOpen ? '▼' : '►'),
          React.createElement('span', { style: { fontWeight: 700, fontSize: 14, flex: 1 } }, cab.name.toUpperCase()),
          React.createElement('span', { style: { fontSize: 12, opacity: 0.85 } }, (function() { var b = DEPT_BUDGETS[cab.name]; return (b ? b.label + ' / ' + formatDollar(cab.value) + ' addressable' : formatDollar(cab.value)) + ' | ' + cab.count + ' opps | Avg Score: ' + cab.avgFit; })())
        ),
        cabOpen && React.createElement('div', { style: { border: '1px solid #E8ECF1', borderTop: 'none', borderRadius: '0 0 8px 8px', overflow: 'hidden' } },
          cab.depts.map(function(dept, di) {
            var deptKey = cab.name + '::' + dept.name;
            var deptOpen = openDepts.has(deptKey);
            return React.createElement('div', { key: di },
              React.createElement('div', {
                style: { display: 'flex', alignItems: 'center', gap: 8, padding: '8px 16px 8px 24px', background: dept.isPassBucket ? '#FEF2F2' : '#F0F4F8', borderBottom: '1px solid ' + (dept.isPassBucket ? '#FECACA' : '#E8ECF1'), borderLeft: dept.isPassBucket ? '3px solid #9CA3AF' : 'none', cursor: 'pointer', userSelect: 'none' },
                onClick: function() { setOpenDepts(function(prev) { var s = new Set(prev); s.has(deptKey) ? s.delete(deptKey) : s.add(deptKey); return s; }); }
              },
                React.createElement('span', { style: { fontSize: 11, marginRight: 2 } }, deptOpen ? '▼' : '►'),
                React.createElement('span', { style: { fontWeight: 700, fontSize: 13, color: dept.isPassBucket ? '#6B7280' : '#1B2A4A', flex: 1 } }, dept.isPassBucket ? '⛔ PASS — No Active Pursuit' : dept.name),
                React.createElement('span', { style: { fontSize: 11, color: '#6B7280', fontStyle: dept.isPassBucket ? 'italic' : 'normal' } }, dept.isPassBucket ? (dept.count + ' opp' + (dept.count !== 1 ? 's' : '') + ' archived') : (formatDollar(dept.value) + ' | ' + dept.count + ' opp' + (dept.count !== 1 ? 's' : '')))
              ),
              deptOpen && React.createElement('div', null,
                dept.commands.map(function(cmd, cmi) {
                  var cmdKey = deptKey + '::' + cmd.name;
                  var cmdOpen = openCmds.has(cmdKey);
                  return React.createElement('div', { key: cmi },
                    React.createElement('div', {
                      style: { display: 'flex', alignItems: 'center', gap: 8, padding: '7px 16px 7px 36px', background: cmd.isPassBucket ? '#FEF2F2' : '#F8FAFC', borderBottom: '1px solid ' + (cmd.isPassBucket ? '#FECACA' : '#E8ECF1'), cursor: 'pointer', userSelect: 'none', borderLeft: cmd.isPassBucket ? '3px solid #9CA3AF' : 'none' },
                      onClick: function() { setOpenCmds(function(prev) { var s = new Set(prev); s.has(cmdKey) ? s.delete(cmdKey) : s.add(cmdKey); return s; }); }
                    },
                      React.createElement('span', { style: { fontSize: 10, marginRight: 2 } }, cmd.isPassBucket ? (cmdOpen ? '▼' : '►') : (cmdOpen ? '▼' : '►')),
                      React.createElement('span', { style: { fontWeight: 600, fontSize: 12, color: cmd.isPassBucket ? '#6B7280' : '#374151', flex: 1 } }, cmd.isPassBucket ? '⛔ PASS — No Active Pursuit' : cmd.name),
                      React.createElement('span', { style: { fontSize: 11, color: cmd.isPassBucket ? '#9CA3AF' : '#9CA3AF', fontStyle: cmd.isPassBucket ? 'italic' : 'normal' } }, cmd.count + ' opp' + (cmd.count !== 1 ? 's' : '') + (cmd.isPassBucket ? ' archived' : ' | ' + formatDollar(cmd.value)))
                    ),
                    cmdOpen && React.createElement('div', { style: { background: '#fff' } },
                      cmd.opps.map(function(opp, oi) {
                        var fs = opp.eis_fit_score || 0;
                        var dl = opp.response_deadline ? new Date(opp.response_deadline).toLocaleDateString() : 'TBD';
                        var urgent = opp.response_deadline && (new Date(opp.response_deadline) - new Date()) < 14 * 86400000;
                        var detailKey = opp.govtribe_id || opp.id || opp.agency || oi;
                        var detailOpen = openDetails.has(detailKey);
                        return React.createElement('div', { key: detailKey },
                          React.createElement('div', {
                            style: { display: 'flex', alignItems: 'center', gap: 10, padding: '8px 16px 8px 48px', borderBottom: detailOpen ? 'none' : '1px solid #F3F4F6', background: detailOpen ? '#EFF6FF' : (oi % 2 === 0 ? '#fff' : '#FAFBFC'), cursor: 'pointer' },
                            onClick: function() {
                            var wasOpen = openDetails.has(detailKey);
                            setOpenDetails(function(prev) { var s = new Set(prev); s.has(detailKey) ? s.delete(detailKey) : s.add(detailKey); return s; });
                            if (!wasOpen) {
                              setAiState(function(p) {
                                var cur = p[detailKey] || {};
                                if (cur.oodaResult !== undefined || cur.oodaLoading) return p;
                                setTimeout(function() { runOodaForOpp(opp, detailKey); }, 0);
                                return Object.assign({}, p, {[detailKey]: Object.assign({}, cur, { oodaLoading: true })});
                              });
                            }
                          }
                          },
                            React.createElement('span', { style: S.badge(fs) }, fs),
                            (function() { var co = getGDACompany(opp); return React.createElement('span', { style: { fontSize: 9, fontWeight: 700, padding: '1px 6px', borderRadius: 8, background: co.bg, color: co.color, flexShrink: 0, letterSpacing: '0.3px' } }, co.name); })(),
                            React.createElement('span', { style: { flex: 1, fontSize: 13, color: '#1B2A4A', fontWeight: 500, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', minWidth: 0, cursor: 'pointer' } }, opp.opp_title || opp.title || opp.agency || 'Untitled'), opp.source_url && React.createElement('a', { href: opp.source_url, target: '_blank', rel: 'noopener', onClick: function(e) { e.stopPropagation(); }, style: { fontSize: 11, color: '#6B7280', flexShrink: 0, textDecoration: 'none', marginLeft: 4, padding: '2px 4px' }, title: 'Open source' }, '↗'),
                            React.createElement('span', { style: { fontSize: 12, color: '#6B7280', minWidth: 80, textAlign: 'right', flexShrink: 0 } }, formatDollar(opp.estimated_value)),
                            React.createElement('select', {
                              value: normalizeStage(opp.stage),
                              onChange: function(e) { e.stopPropagation(); updateStage(opp, e.target.value); },
                              onClick: function(e) { e.stopPropagation(); },
                              style: { fontSize: 10, padding: '2px 4px', borderRadius: 4, border: '1px solid ' + (stageColor(normalizeStage(opp.stage)).text), background: '#fff', color: stageColor(normalizeStage(opp.stage)).text, fontWeight: 600, cursor: 'pointer', flexShrink: 0 }
                            },
                              React.createElement('option', { value: 'Identified' }, 'Identified'),
                              React.createElement('option', { value: 'Investigating' }, 'Investigating'),
                              React.createElement('option', { value: 'Pursuing' }, 'Pursuing'),
                              React.createElement('option', { value: 'Proposal' }, 'Proposal'),
                              React.createElement('option', { value: 'Submitted' }, 'Submitted'),
                              React.createElement('option', { value: 'Won' }, 'Won'),
                              React.createElement('option', { value: 'Lost' }, 'Lost'),
                              React.createElement('option', { value: 'No-Go' }, 'No-Go')
                            ),
                            React.createElement('span', { style: { fontSize: 11, color: urgent ? '#DC2626' : '#9CA3AF', minWidth: 75, textAlign: 'right', flexShrink: 0 } }, dl),
                            React.createElement('span', { style: { fontSize: 10, color: '#9CA3AF', flexShrink: 0, marginLeft: 4 } }, detailOpen ? '▲' : '▼'),
                            opp.source_url && React.createElement(SourceTag, { url: opp.source_url, label: opp.data_source || 'GovTribe' })
                          ),
                          detailOpen && renderOppDetailPanel(opp, detailKey, openScores, setOpenScores, openAnalysis, setOpenAnalysis, aiState, setAiState, askAiForOpp, runOodaForOpp, addActionItemForOpp, S, calculateEisBonus)
                        );
                      })
                    )
                  );
                })
              )
            );
          })
        )
      );
    }) : filtered.map(function(opp, idx) {
      return renderOppCard(opp, idx, openScores, setOpenScores, openAnalysis, setOpenAnalysis, updateStage, S, formatDollar, calculateEisBonus, stageColor, suggestedStage);
    })
  ,
    React.createElement('div', {style:{border:'1px solid #E8ECF1',borderRadius:10,marginTop:20,overflow:'hidden'}},
      React.createElement('div', {onClick:function(){setIdiqOpen(!idiqOpen);},style:{display:'flex',justifyContent:'space-between',alignItems:'center',padding:'12px 16px',background:'#F8FAFC',cursor:'pointer',userSelect:'none'}},
        React.createElement('div', {style:{display:'flex',alignItems:'center',gap:10}},
          React.createElement('span', {style:{color:ACCENT,fontSize:12}}, idiqOpen?'\u25BC':'\u25B6'),
          React.createElement('span', {style:{fontSize:15,fontWeight:700,color:NAVY}}, 'IDIQ Vehicles')
        ),
        React.createElement('div', {style:{display:'flex',gap:8}},
          React.createElement('span', {style:{fontSize:11,fontWeight:700,padding:'2px 8px',borderRadius:10,background:'#2F5C1F15',color:'#2F5C1F'}}, (idiqSummary.holders||0)+' Held'),
          React.createElement('span', {style:{fontSize:11,fontWeight:700,padding:'2px 8px',borderRadius:10,background:'#B06D3218',color:'#B06D32'}}, (idiqSummary.targeting||0)+' Targeting'),
          idiqSummary.total_ceiling && React.createElement('span', {style:{fontSize:11,fontWeight:600,color:'#6B7280'}}, formatDollar(idiqSummary.total_ceiling)+' ceiling')
        )
      ),
      idiqOpen && React.createElement('div', {style:{padding:16}},
        (function(){
          var held = idiqs.filter(function(v){return v.gda_position==='holder';}).sort(function(a,b){return (b.contract_ceiling||0)-(a.contract_ceiling||0);});
          var targeting = idiqs.filter(function(v){return v.gda_position==='targeting'||v.gda_position==='teaming';}).sort(function(a,b){return (b.contract_ceiling||0)-(a.contract_ceiling||0);});
          var posBadge = function(pos){var c={holder:'#2F5C1F',teaming:'#32448A',targeting:'#B06D32'};var bg={holder:'#2F5C1F15',teaming:'#EFF6FF',targeting:'#B06D3218'};return React.createElement('span',{style:{fontSize:11,fontWeight:700,padding:'1px 6px',borderRadius:8,color:c[pos]||'#6B7280',background:bg[pos]||'#F3F4F6'}},pos?pos.toUpperCase():'');};
          var typeBadge = function(t){return React.createElement('span',{style:{fontSize:11,padding:'1px 5px',borderRadius:4,background:'#F0F4FF',color:'#3B82F6',fontWeight:600}},t||'IDIQ');};
          var renderCard = function(v,i,borderColor){
            var isExp = idiqExpanded === v.contract_number;
            var ceiling = v.contract_ceiling > 0 ? formatDollar(v.contract_ceiling) : 'TBD';
            var yearsLeft = v.period_of_performance_end ? Math.max(0,Math.round((new Date(v.period_of_performance_end)-new Date())/(365.25*86400000)*10)/10) : null;
            return React.createElement('div',{key:v.contract_number||i,style:{background:'#fff',border:'1px solid #E8ECF1',borderRadius:8,padding:'10px 14px',marginBottom:8,borderLeft:'4px solid '+borderColor,cursor:'pointer'},onClick:function(){setIdiqExpanded(isExp?null:v.contract_number);}},
              React.createElement('div',{style:{display:'flex',justifyContent:'space-between',alignItems:'flex-start'}},
                React.createElement('div',{style:{flex:1}},
                  React.createElement('div',{style:{display:'flex',alignItems:'center',gap:6,flexWrap:'wrap'}},
                    v.source_url?React.createElement('a',{href:v.source_url,target:'_blank',rel:'noopener',onClick:function(e){e.stopPropagation();},style:{fontSize:13,fontWeight:600,color:NAVY,textDecoration:'none'}},v.idiq_name):React.createElement('span',{style:{fontSize:13,fontWeight:600,color:NAVY}},v.idiq_name||'Untitled'),
                    typeBadge(v.vehicle_type),
                    posBadge(v.gda_position)
                  ),
                  React.createElement('div',{style:{fontSize:11,color:'#6B7280',marginTop:2}},v.agency||''),
                  v.contract_number && React.createElement('div',{style:{fontSize:11,color:'#9CA3AF'}},v.contract_number)
                ),
                React.createElement('div',{style:{textAlign:'right',flexShrink:0}},
                  React.createElement('div',{style:{fontSize:14,fontWeight:700,color:'#2F5C1F'}},ceiling),
                  yearsLeft!==null && React.createElement('div',{style:{fontSize:11,color:yearsLeft<2?'#DC2626':'#6B7280'}},'~'+yearsLeft+'yr left'),
                  v.tracked_tos>0 && React.createElement('div',{style:{fontSize:11,color:ACCENT}},v.tracked_tos+' TOs tracked')
                )
              ),
              v.on_ramp_status==='open' && React.createElement('span',{style:{display:'inline-block',marginTop:4,fontSize:11,fontWeight:700,padding:'2px 6px',borderRadius:8,background:'#FEE2E2',color:'#DC2626'}},'ON-RAMP OPEN'),
              v.on_ramp_deadline && React.createElement('span',{style:{fontSize:11,color:'#B06D32',marginLeft:6}},'Deadline: '+new Date(v.on_ramp_deadline).toLocaleDateString()),
              isExp && React.createElement('div',{style:{marginTop:10,paddingTop:10,borderTop:'1px solid #E8ECF1',fontSize:12,lineHeight:1.6}},
                v.set_aside && React.createElement('div',null,React.createElement('strong',null,'Set-Aside: '),v.set_aside),
                v.gda_prime_or_sub && React.createElement('div',null,React.createElement('strong',null,'GDA Role: '),v.gda_prime_or_sub),
                Array.isArray(v.naics_codes)&&v.naics_codes.length>0 && React.createElement('div',{style:{marginTop:4}},React.createElement('strong',null,'NAICS: '),v.naics_codes.map(function(n,j){return React.createElement('span',{key:j,style:{display:'inline-block',padding:'1px 5px',borderRadius:4,background:'#F3F4F6',color:'#374151',fontSize:11,marginRight:4,marginBottom:2}},n);})),
                Array.isArray(v.competitors)&&v.competitors.length>0 && React.createElement('div',{style:{marginTop:4}},React.createElement('strong',null,'Competitors: '),v.competitors.map(function(c,j){return React.createElement('span',{key:j,style:{display:'inline-block',padding:'1px 5px',borderRadius:4,background:'#FEF2F2',color:'#991B1B',fontSize:11,marginRight:4,marginBottom:2}},c);})),
                Array.isArray(v.incumbent_primes)&&v.incumbent_primes.length>0 && React.createElement('div',{style:{marginTop:4}},React.createElement('strong',null,'Incumbents: '),v.incumbent_primes.join(', ')),
                v.notes && React.createElement('div',{style:{marginTop:4,color:'#6B7280',fontStyle:'italic'}},v.notes),
                v.total_tos_issued>0 && React.createElement('div',{style:{marginTop:4}},React.createElement('strong',null,'TOs Issued: '),v.total_tos_issued,' (',formatDollar(v.total_to_value||0),')')
              )
            );
          };
          return React.createElement('div',null,
            held.length>0 && React.createElement('div',{style:{marginBottom:16}},
              React.createElement('div',{style:{fontSize:12,fontWeight:700,color:'#2F5C1F',marginBottom:8}},'VEHICLES WE HOLD ('+held.length+')'),
              held.map(function(v,i){return renderCard(v,i,'#2F5C1F');})
            ),
            targeting.length>0 && React.createElement('div',null,
              React.createElement('div',{style:{fontSize:12,fontWeight:700,color:'#B06D32',marginBottom:8}},'ON-RAMP TARGETS ('+targeting.length+')'),
              targeting.map(function(v,i){return renderCard(v,i,'#B06D32');})
            ),
            idiqs.length===0 && React.createElement('div',{style:{textAlign:'center',padding:20,color:'#9CA3AF',fontSize:12}},'Loading IDIQ vehicles...')
          );
        })()
      )
    )
  ,
    // ── IDIQ & NDAA Intel (merged from standalone tab, S-101) ──
    React.createElement('div', { style: { marginTop: 32, paddingTop: 24, borderTop: '2px solid #E8ECF1' } },
      React.createElement('div', { style: { fontSize: 16, fontWeight: 700, color: '#1B2A4A', marginBottom: 4 } }, '\ud83d\udd17 IDIQ & NDAA Intelligence'),
      React.createElement('div', { style: { fontSize: 12, color: '#6B7280', marginBottom: 16 } }, 'Vehicle tracking, on-ramp monitoring, and NDAA analysis'),
      React.createElement(IdiqOnRamp, null)
    )
  );
} catch(renderErr) {
    console.error('OppTracker render error:', renderErr);
    return React.createElement('div', { style: { padding: 40, textAlign: 'center' } },
      React.createElement('div', { style: { fontSize: 16, fontWeight: 700, color: '#DC2626', marginBottom: 8 } }, 'OppTracker Error'),
      React.createElement('div', { style: { fontSize: 13, color: '#6B7280', marginBottom: 12 } }, String(renderErr.message || renderErr)),
      React.createElement('button', { onClick: function() { window.location.reload(); }, style: { padding: '8px 16px', background: '#1B2A4A', color: '#fff', border: 'none', borderRadius: 6, cursor: 'pointer' } }, 'Reload')
    );
  }
}

function getGDACompany(opp) {
  var txt = ((opp.opp_title||opp.title||'') + ' ' + (opp.description||'') + ' ' + (opp.naics_code||'')).toLowerCase();
  if (txt.match(/cyber|sigint|humint|classified|scif|ts.sci|intel|c5isr|soc|noc|security.operations/)) return { name: 'Riverstone', color: '#32448A', bg: '#32448A12' };
  if (txt.match(/simulation|training|peo.stri|tradoc|virtual|xr|ar.vr|modeling|immersive|synthetic/)) return { name: 'PD Systems', color: '#32448A', bg: '#EFF6FF' };
  return { name: 'EIS', color: '#2F5C1F', bg: '#2F5C1F12' };
}

function renderOppDetailPanel(opp, detailKey, openScores, setOpenScores, openAnalysis, setOpenAnalysis, aiState, setAiState, askAiForOpp, runOodaForOpp, addActionItemForOpp, S, calculateEisBonus) {
  var fs = opp.eis_fit_score || 0;
  var bd = calculateEisBonus(opp);
  var aiOpp = aiState[detailKey] || {};

  function phaseText(d) {
    if (!d) return '';
    if (typeof d === 'string') {
      var s = d.trim();
      if ((s.charAt(0) === '{' || s.charAt(0) === '[') && s.length > 2) { try { return phaseText(JSON.parse(s)); } catch(e) { return s; } }
      return s;
    }
    if (Array.isArray(d)) return d.map(function(x) { return typeof x === 'string' ? x : String(x); }).join('; ');
    var out = [];
    if (d.summary) out.push(String(d.summary));
    if (d.threat_assessment) out.push('Threat: ' + String(d.threat_assessment));
    if (d.opportunity_assessment) out.push('Opportunity: ' + String(d.opportunity_assessment));
    if (d.win_probability) out.push('Win Prob: ' + String(d.win_probability));
    if (d.win_probability_rationale) out.push(String(d.win_probability_rationale));
    if (d.confidence) out.push('Confidence: ' + String(d.confidence));
    if (d.recommendation) out.push('Rec: ' + String(d.recommendation));
    if (d.rationale) out.push(String(d.rationale));
    if (d.market_forces) out.push('Market: ' + String(d.market_forces));
    if (d.key_signals && Array.isArray(d.key_signals)) out.push('Signals: ' + d.key_signals.join(' | '));
    if (d.capability_gaps && Array.isArray(d.capability_gaps)) out.push('Gaps: ' + d.capability_gaps.join(' | '));
    if (d.alternatives && Array.isArray(d.alternatives)) out.push('Alternatives: ' + d.alternatives.join(' | '));
    if (d.decision_triggers && Array.isArray(d.decision_triggers)) out.push('Triggers: ' + d.decision_triggers.join(' | '));
    if (d.immediate_30d && Array.isArray(d.immediate_30d)) out.push('30d: ' + d.immediate_30d.join(' | '));
    if (d.capture_30_90d && Array.isArray(d.capture_30_90d)) out.push('30-90d: ' + d.capture_30_90d.join(' | '));
    if (out.length > 0) return out.join('\n');
    try { return String(JSON.stringify(d)).substring(0, 500); } catch(e) { return ''; }
  }

  var recColor = { BID: '#2F5C1F', PURSUE: '#2F5C1F', EVALUATE: '#B06D32', MONITOR: '#6B7280', 'NO-BID': '#DC2626' };
  var recBg   = { BID: '#2F5C1F15', PURSUE: '#2F5C1F15', EVALUATE: '#B06D3212', MONITOR: '#F3F4F6', 'NO-BID': '#FEF2F2' };
  var rec = (aiOpp.oodaResult && aiOpp.oodaResult._recommendation) ? aiOpp.oodaResult._recommendation.toUpperCase() : null;

  return React.createElement('div', { style: { borderBottom: '1px solid #E8ECF1', background: '#F9FAFB', padding: '14px 20px 14px 48px' } },

    // ── Header ──────────────────────────────────────────────
    React.createElement('div', { style: { display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 10 } },
      React.createElement('div', { style: { flex: 1 } },
        React.createElement('div', { style: { fontWeight: 700, color: '#1B2A4A', fontSize: 14, marginBottom: 4 } }, opp.opp_title || opp.title || opp.agency || 'Untitled'),
        React.createElement('div', { style: { fontSize: 12, color: '#6B7280', lineHeight: 1.7 } },
          'Agency: ' + (opp.cabinet_department || opp.dept || 'N/A') +
          (opp.naics_code ? ' | NAICS: ' + opp.naics_code : '') +
          (opp.set_aside ? ' | Set-Aside: ' + opp.set_aside : '')
        ),
        React.createElement('div', { style: { fontSize: 12, color: '#6B7280' } },
          'Value: ' + formatDollar(opp.estimated_value) +
          (opp.response_deadline ? ' | Deadline: ' + new Date(opp.response_deadline).toLocaleDateString() : '') +
          ' | Stage: ' + normalizeStage(opp.stage)
        )
      ),
      React.createElement('span', { style: S.badge(fs) }, 'Fit: ' + fs)
    ),

    // ── OODA Analysis (inline, auto-fired) ──────────────────
    React.createElement('div', { style: { marginBottom: 12, padding: '12px 14px', background: '#fff', borderRadius: 8, border: '1px solid #E5E7EB' } },
      React.createElement('div', { style: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 } },
        React.createElement('div', { style: { fontSize: 11, fontWeight: 700, color: '#374151', textTransform: 'uppercase', letterSpacing: '0.5px' } }, 'OODA Analysis'),
        aiOpp.oodaResult && React.createElement('div', { style: { display: 'flex', alignItems: 'center', gap: 8 } },
          rec && React.createElement('span', { style: { fontSize: 11, fontWeight: 700, padding: '2px 8px', borderRadius: 10, background: recBg[rec] || '#F3F4F6', color: recColor[rec] || '#6B7280' } }, rec),
          aiOpp.oodaResult._pwin > 0 && React.createElement('span', { style: { fontSize: 11, color: '#6B7280' } }, 'P(win): ' + aiOpp.oodaResult._pwin + '%'),
          React.createElement('button', {
            style: { fontSize: 11, padding: '3px 8px', border: '1px solid #D1D5DB', borderRadius: 4, background: '#fff', cursor: 'pointer', fontFamily: 'Inter,sans-serif', color: '#4B5563' },
            onClick: function() { if (window._gdaNavigate) window._gdaNavigate('ooda'); }
          }, 'View in OODA Loop →')
        )
      ),
      aiOpp.oodaLoading && React.createElement('div', { style: { display: 'flex', alignItems: 'center', gap: 8, color: '#6B7280', fontSize: 12, padding: '8px 0' } },
        React.createElement('div', { style: { width: 14, height: 14, border: '2px solid #D1D5DB', borderTopColor: '#1B2A4A', borderRadius: '50%', animation: 'spin 0.8s linear infinite', flexShrink: 0 } }),
        'Analyzing opportunity...'
      ),
      aiOpp.oodaError && React.createElement('div', { style: { display: 'flex', alignItems: 'center', gap: 8, fontSize: 12 } },
        React.createElement('span', { style: { color: '#DC2626' } }, 'OODA analysis unavailable — ' + aiOpp.oodaError),
        React.createElement('button', {
          style: { fontSize: 11, padding: '2px 8px', border: '1px solid #FCA5A5', borderRadius: 4, background: '#FEF2F2', color: '#DC2626', cursor: 'pointer', fontFamily: 'Inter,sans-serif' },
          onClick: function() {
            setAiState(function(p) { return Object.assign({}, p, {[detailKey]: Object.assign({}, p[detailKey], { oodaError: null, oodaLoading: true })}); });
            runOodaForOpp(opp, detailKey);
          }
        }, 'Retry')
      ),
      aiOpp.oodaResult && (function() {
        var r = aiOpp.oodaResult;
        var phases = [
          { key: 'observe', label: 'OBSERVE', color: '#2563eb' },
          { key: 'orient',  label: 'ORIENT',  color: '#7c3aed' },
          { key: 'decide',  label: 'DECIDE',  color: '#ea580c' },
          { key: 'act',     label: 'ACT',     color: '#16a34a' }
        ];
        return React.createElement('div', { style: { display: 'grid', gap: 8 } },
          phases.map(function(p) {
            var text = phaseText(r[p.key] || r[p.key.charAt(0).toUpperCase() + p.key.slice(1)] || r[p.label]);
            if (!text) return null;
            return React.createElement('div', { key: p.key, style: { display: 'flex', gap: 8, fontSize: 12 } },
              React.createElement('span', { style: { fontWeight: 700, color: p.color, minWidth: 58, flexShrink: 0, fontSize: 11 } }, p.label + ':'),
              React.createElement('div', { style: { color: '#374151', lineHeight: 1.6 } },
                (text || '').split('\n').map(function(line, li) {
                  if (!line.trim()) return null;
                  if (line.indexOf(' | ') !== -1 && line.split(' | ').length > 2) {
                    var pipeParts = line.split(' | ').map(function(s){return s.trim();}).filter(function(s){return s;});
                    var labelPart = '';
                    if (pipeParts[0] && pipeParts[0].indexOf(':') > 0 && pipeParts[0].indexOf(':') < 20) {
                      labelPart = pipeParts[0].split(':')[0];
                      pipeParts[0] = pipeParts[0].split(':').slice(1).join(':').trim();
                    }
                    return React.createElement('div', { key: li, style: { marginBottom: 4 } },
                      labelPart && React.createElement('strong', { style: { color: '#1B2A4A', fontSize: 11 } }, labelPart + ': '),
                      React.createElement('div', { style: { margin: '2px 0' } },
                        pipeParts.map(function(bp, bpi) {
                          return React.createElement('div', { key: bpi, style: { display: 'flex', alignItems: 'flex-start', fontSize: 12, marginBottom: 2, lineHeight: 1.4, color: '#374151' } }, React.createElement('span', {style:{color:'#D14A2A',fontWeight:700,marginRight:6}}, '>'), bp);
                        })
                      )
                    );
                  }
                  var isLabel = line.indexOf(':') > 0 && line.indexOf(':') < 20;
                  return React.createElement('div', { key: li, style: { marginBottom: 3, paddingLeft: isLabel ? 0 : 8 } },
                    isLabel ? React.createElement('span', null,
                      React.createElement('strong', { style: { color: '#1B2A4A' } }, line.split(':')[0] + ': '),
                      line.split(':').slice(1).join(':')
                    ) : line
                  );
                })
              )
            );
          })
        );
      })()
    ),

    // ── Score Breakdown (collapsible) ────────────────────────
    React.createElement('button', {
      style: { fontSize: 11, color: '#4B5563', background: 'none', border: 'none', cursor: 'pointer', padding: 0, fontFamily: 'Inter,sans-serif', fontWeight: 600, display: 'block', marginBottom: 4 },
      onClick: function() { setOpenScores(function(p) { var s = new Set(p); s.has(detailKey) ? s.delete(detailKey) : s.add(detailKey); return s; }); }
    }, (openScores.has(detailKey) ? '▼' : '►') + ' Score Breakdown'),
    openScores.has(detailKey) && (function() {
      var hasComp = opp.needs_score != null && opp.financials_score != null && opp.ooda_score != null;
      return React.createElement('div', { style: { marginBottom: 8, padding: '8px 10px', background: '#fff', borderRadius: 6, fontSize: 12 } },
        hasComp ? [
          [{ label: 'Needs (×4)', contrib: Math.round(opp.needs_score * 4), pct: opp.needs_score / 10 },
           { label: 'Financials (×30)', contrib: Math.round(opp.financials_score * 30), pct: parseFloat(opp.financials_score) },
           { label: 'OODA (×0.3)', contrib: Math.round(opp.ooda_score * 0.3), pct: opp.ooda_score / 100 }
          ].map(function(row, ri) {
            return React.createElement('div', { key: ri, style: { display: 'flex', alignItems: 'center', gap: 6, marginBottom: 5 } },
              React.createElement('span', { style: { width: 110, color: '#6B7280', fontSize: 11 } }, row.label),
              React.createElement('div', { style: { flex: 1, height: 5, background: '#E5E7EB', borderRadius: 3 } },
                React.createElement('div', { style: { width: Math.min(100, Math.round(row.pct * 100)) + '%', height: '100%', background: '#1B2A4A', borderRadius: 3 } })
              ),
              React.createElement('span', { style: { width: 30, textAlign: 'right', fontWeight: 700, color: '#1B2A4A', fontSize: 11 } }, '+' + row.contrib)
            );
          }),
          bd.bonuses.length > 0 && React.createElement('div', { key: 'bon', style: { color: '#2F5C1F', fontSize: 11, marginTop: 3 } }, 'EIS: ' + bd.bonuses.join(', ')),
          React.createElement('div', { key: 'tot', style: { marginTop: 4, borderTop: '1px solid #E5E7EB', paddingTop: 4, fontWeight: 700, color: '#1B2A4A', fontSize: 12 } }, 'Total: ' + fs + '/100')
        ] : [
          bd.bonuses.length > 0 && React.createElement('div', { key: 'bon', style: { color: '#2F5C1F', fontSize: 11 } }, 'EIS Bonuses: ' + bd.bonuses.join(', ')),
          React.createElement('div', { key: 'sc', style: { fontWeight: 700, color: '#1B2A4A', fontSize: 12, marginTop: 4 } }, 'Score: ' + fs + '/100'),
          React.createElement('div', { key: 'pnd', style: { color: '#9CA3AF', fontSize: 11, marginTop: 2 } }, 'AI component scores pending')
        ]
      );
    })(),

    // ── AI Analysis (collapsible, if populated) ──────────────
    opp.ai_analysis && React.createElement('div', { style: { marginBottom: 6 } },
      React.createElement('button', {
        style: { fontSize: 11, color: '#4B5563', background: 'none', border: 'none', cursor: 'pointer', padding: 0, fontFamily: 'Inter,sans-serif', fontWeight: 600, display: 'block', marginBottom: 4 },
        onClick: function() { setOpenAnalysis(function(p) { var s = new Set(p); s.has(detailKey) ? s.delete(detailKey) : s.add(detailKey); return s; }); }
      }, (openAnalysis.has(detailKey) ? '▼' : '►') + ' AI Analysis'),
      openAnalysis.has(detailKey) && React.createElement('div', { style: { padding: '8px 10px', background: '#5091A712', borderRadius: 6, fontSize: 12, color: '#1B2A4A', lineHeight: 1.6, borderLeft: '3px solid #0EA5E9', marginBottom: 6 } }, opp.ai_analysis)
    ),

    // ── Capture Intelligence ─────────────────────────────────
    (function() {
      function parseListField(val) {
        if (!val) return null;
        if (Array.isArray(val)) return val.filter(function(x){return x;});
        var s = String(val).trim();
        if (s.charAt(0) === '[') { try { var p = JSON.parse(s); if (Array.isArray(p)) return p.filter(function(x){return x;}); } catch(e){} }
        var parts = s.split(/[,;\n]+/).map(function(x){return x.trim();}).filter(function(x){return x.length > 0;});
        return parts.length > 0 ? parts : [s];
      }
      var competitors = parseListField(opp.likely_competitors);
      var vehicles = parseListField(opp.eligible_vehicles);
      var incumbentText = opp.incumbent_analysis ? String(opp.incumbent_analysis) : null;
      var chipStyle = function(bg, fg) { return { display: 'inline-block', padding: '1px 7px', borderRadius: 10, fontSize: 11, fontWeight: 600, background: bg, color: fg, marginRight: 4, marginBottom: 3 }; };
      return React.createElement('div', { style: { padding: '10px 12px', background: '#fff', borderRadius: 6, marginBottom: 10, border: '1px solid #F3F4F6' } },
        React.createElement('div', { style: { fontSize: 11, fontWeight: 700, color: '#374151', marginBottom: 8, textTransform: 'uppercase', letterSpacing: '0.5px' } }, 'Capture Intelligence'),
        React.createElement('div', { style: { display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '4px 16px', fontSize: 12, color: '#4B5563', marginBottom: incumbentText || competitors || vehicles ? 8 : 0 } },
          React.createElement('div', null, 'Source: ',
            opp.source_url
              ? React.createElement('a', { href: opp.source_url, target: '_blank', rel: 'noopener', style: { color: '#D14A2A', fontWeight: 600 } }, opp.data_source || 'View')
              : React.createElement('span', { style: { color: '#9CA3AF' } }, opp.data_source || 'N/A')
          ),
          opp.solicitation_number && React.createElement('div', null, 'Sol. #: ', React.createElement('span', { style: { fontWeight: 600 } }, opp.solicitation_number)),
          opp.place_of_performance && React.createElement('div', null, 'PoP: ', opp.place_of_performance)
        ),
        incumbentText && React.createElement('div', { style: { marginBottom: 7, fontSize: 12 } },
          React.createElement('span', { style: { fontWeight: 700, color: '#374151', marginRight: 6 } }, 'Incumbent Analysis:'),
          React.createElement('span', { style: { color: '#4B5563', lineHeight: 1.5 } }, incumbentText)
        ),
        competitors && competitors.length > 0 && React.createElement('div', { style: { marginBottom: 6 } },
          React.createElement('div', { style: { fontSize: 11, fontWeight: 700, color: '#6B7280', marginBottom: 4, textTransform: 'uppercase', letterSpacing: '0.4px' } }, 'Likely Competitors'),
          React.createElement('div', null, competitors.map(function(c, i) {
            return React.createElement('span', { key: i, style: chipStyle('#FEF2F2', '#991B1B') }, c);
          }))
        ),
        vehicles && vehicles.length > 0 && React.createElement('div', { style: { marginBottom: 4 } },
          React.createElement('div', { style: { fontSize: 11, fontWeight: 700, color: '#6B7280', marginBottom: 4, textTransform: 'uppercase', letterSpacing: '0.4px' } }, 'Eligible Vehicles'),
          React.createElement('div', null, vehicles.map(function(v, i) {
            return React.createElement('span', { key: i, style: chipStyle('#EFF6FF', '#1D4ED8') }, v);
          }))
        ),
        !incumbentText && !competitors && !vehicles && React.createElement('div', { style: { fontSize: 11, color: '#9CA3AF', fontStyle: 'italic' } }, 'No capture intelligence on file for this opportunity.')
      );
    })(),

    // ── Action Buttons ───────────────────────────────────────
    React.createElement('div', { style: { display: 'flex', gap: 8, flexWrap: 'wrap', marginBottom: 10 } },
      React.createElement('button', {
        style: { fontSize: 12, padding: '6px 12px', borderRadius: 5, border: '1px solid #D1D5DB', cursor: 'pointer', background: '#fff', fontFamily: 'Inter,sans-serif', fontWeight: 500 },
        onClick: function() { if (window._gdaNavigate) window._gdaNavigate('email'); }
      }, 'Draft Outreach Email'),
      React.createElement('button', {
        style: {
          fontSize: 12, padding: '6px 12px', borderRadius: 5, border: '1px solid ' + (aiOpp.actionAdded ? '#A7F3D0' : '#D1D5DB'),
          cursor: aiOpp.actionAdding ? 'default' : 'pointer',
          background: aiOpp.actionAdded ? '#2F5C1F15' : '#fff',
          color: aiOpp.actionAdded ? '#2F5C1F' : '#374151',
          fontFamily: 'Inter,sans-serif', fontWeight: aiOpp.actionAdded ? 700 : 500,
          transition: 'all 0.2s'
        },
        disabled: aiOpp.actionAdding || aiOpp.actionAdded,
        onClick: function() { addActionItemForOpp(opp, detailKey); }
      }, aiOpp.actionAdding ? 'Adding...' : aiOpp.actionAdded ? 'Added ✓' : 'Add to Action Items'),
      React.createElement('button', {
        style: { fontSize: 12, padding: '6px 12px', borderRadius: 5, border: 'none', cursor: 'pointer', background: '#1B2A4A', color: '#fff', fontFamily: 'Inter,sans-serif', fontWeight: 600 },
        onClick: function() { if (window._gdaNavigate) window._gdaNavigate('ai-agent'); }
      }, 'Open AI Agent'),
      React.createElement('button', {
        style: { fontSize: 11, padding: '5px 12px', borderRadius: 6, border: 'none', cursor: 'pointer', background: '#32448A', color: '#fff', fontFamily: 'Inter,sans-serif', fontWeight: 600 },
        onClick: function() {
          gdaNav.captureOpp = {
            opportunity: opp.opp_title || opp.title || '',
            agency: opp.agency || opp.cabinet_department || '',
            contract_value: opp.estimated_value ? String(opp.estimated_value) : '',
            contract_type: opp.contract_type || 'IDIQ',
            set_aside: opp.set_aside || 'Unrestricted',
            naics: opp.naics_code || opp.naics || '',
            solicitation_number: opp.solicitation_number || '',
            incumbent: opp.incumbent || ''
          };
          window.dispatchEvent(new CustomEvent('gda-capture-opp'));
          if (window._gdaNavigate) window._gdaNavigate('capture-plan');
        }
      }, '\ud83d\udccb Capture Plan')
    ),

    // ── Ask AI inline ────────────────────────────────────────
    React.createElement('div', { style: { borderTop: '1px solid #E5E7EB', paddingTop: 10 } },
      React.createElement('div', { style: { fontSize: 11, fontWeight: 700, color: '#374151', marginBottom: 6, textTransform: 'uppercase', letterSpacing: '0.5px' } }, 'Ask AI About This Opp'),
      React.createElement('div', { style: { display: 'flex', gap: 8 } },
        React.createElement('input', {
          type: 'text',
          placeholder: 'e.g. What are the key requirements? Who are likely incumbents?',
          value: aiOpp.pendingQ || '',
          onChange: function(e) { var v = e.target.value; setAiState(function(p) { return Object.assign({}, p, {[detailKey]: Object.assign({}, p[detailKey], { pendingQ: v })}); }); },
          onKeyDown: function(e) { if (e.key === 'Enter' && aiOpp.pendingQ) askAiForOpp(opp, aiOpp.pendingQ); },
          style: { flex: 1, padding: '6px 10px', border: '1px solid #D1D5DB', borderRadius: 5, fontSize: 12, fontFamily: 'Inter,sans-serif' }
        }),
        React.createElement('button', {
          onClick: function() { if (aiOpp.pendingQ) askAiForOpp(opp, aiOpp.pendingQ); },
          disabled: !aiOpp.pendingQ || aiOpp.loading,
          style: { fontSize: 12, padding: '6px 14px', borderRadius: 5, border: 'none', background: aiOpp.pendingQ ? '#D14A2A' : '#E5E7EB', color: aiOpp.pendingQ ? '#fff' : '#9CA3AF', cursor: aiOpp.pendingQ ? 'pointer' : 'default', fontFamily: 'Inter,sans-serif', fontWeight: 600, flexShrink: 0 }
        }, aiOpp.loading ? 'Asking...' : 'Ask')
      ),
      aiOpp.answer && React.createElement('div', { style: { marginTop: 8, padding: '10px 12px', background: '#5091A712', borderRadius: 6, fontSize: 12, color: '#1B2A4A', lineHeight: 1.7, borderLeft: '3px solid #0EA5E9' } },
        aiOpp.answer
      )
    )
  );
}

function renderOppCard(opp, idx, openScores, setOpenScores, openAnalysis, setOpenAnalysis, updateStage, S, formatDollar, calculateEisBonus, stageColor, suggestedStage) {
      var fitScore = opp.eis_fit_score || 0;
      var deadlineStr = opp.response_deadline ? new Date(opp.response_deadline).toLocaleDateString() : 'TBD';
      var isUrgent = opp.response_deadline && (new Date(opp.response_deadline) - new Date()) < 14 * 86400000;
      return React.createElement('div', { key: opp.govtribe_id || idx, style: S.card },
        React.createElement('div', { style: { display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' } },
          React.createElement('div', { style: { flex: 1 } },
            React.createElement('div', { style: { display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '6px' } },
              React.createElement('span', { style: S.badge(fitScore) }, 'Fit: ' + fitScore),
              opp.source && React.createElement('span', {
                style: { background: '#EEF2FF', color: '#4338CA', padding: '2px 8px', borderRadius: '10px', fontSize: '11px' }
              }, opp.source),
              isUrgent && React.createElement('span', {
                style: { background: '#FEF2F2', color: '#DC2626', padding: '2px 8px', borderRadius: '10px', fontSize: '11px', fontWeight: 600 }
              }, 'Due Soon'),
              opp.source_url && React.createElement(SourceTag, { url: opp.source_url, label: opp.data_source || 'GovTribe' })
            ),
            React.createElement('h4', { style: S.cardTitle }, opp.title || 'Untitled'),
            React.createElement('div', { style: S.cardMeta },
              React.createElement('span', null, 'Agency: ' + (opp.agency || 'N/A')),
              React.createElement('span', null, 'Dept: ' + (opp.cabinet_department || 'N/A')),
              React.createElement('span', null, 'NAICS: ' + (opp.naics_code || opp.naics || 'N/A')),
              opp.set_aside && React.createElement('span', null, 'Set-aside: ' + opp.set_aside),
              React.createElement('span', null, 'Deadline: ' + deadlineStr)
            )
          ),
          React.createElement('div', { style: { textAlign: 'right', minWidth: '100px' } },
            React.createElement('div', { style: { fontSize: '18px', fontWeight: 700, color: '#1B2A4A' } },
              formatDollar(opp.estimated_value)
            ),
            opp.source_url && React.createElement('a', {
              href: opp.source_url, target: '_blank', rel: 'noopener', style: S.link
            }, 'View Source')
          )
        ),
        React.createElement('div', { style: { display: 'flex', alignItems: 'center', gap: 8, marginTop: 10, flexWrap: 'wrap' } },
          React.createElement('span', { style: { fontSize: 11, color: '#6B7280', fontWeight: 600 } }, 'Stage:'),
          React.createElement('select', {
            value: normalizeStage(opp.stage),
            onChange: function(e) { e.stopPropagation(); updateStage(opp, e.target.value); },
            style: { fontSize: 12, padding: '3px 10px', borderRadius: 6, border: '1px solid #D1D5DB', background: stageColor(normalizeStage(opp.stage)).bg, color: stageColor(normalizeStage(opp.stage)).text, fontWeight: 600, cursor: 'pointer' }
          },
            React.createElement('option', { value: 'Identified' }, 'Identified'),
            React.createElement('option', { value: 'Investigating' }, 'Investigating'),
            React.createElement('option', { value: 'Pursuing' }, 'Pursuing'),
            React.createElement('option', { value: 'Proposal' }, 'Proposal'),
            React.createElement('option', { value: 'Submitted' }, 'Submitted'),
            React.createElement('option', { value: 'Won' }, 'Won'),
            React.createElement('option', { value: 'Lost' }, 'Lost'),
            React.createElement('option', { value: 'No-Go' }, 'No-Go')
          ),
          suggestedStage(opp) && React.createElement('span', {
            style: { fontSize: 11, background: '#EFF6FF', color: '#1D4ED8', padding: '2px 8px', borderRadius: 10, cursor: 'pointer', fontWeight: 600 },
            title: 'Click to apply suggestion',
            onClick: function() { updateStage(opp, suggestedStage(opp)); }
          }, '⬆ Suggested: ' + suggestedStage(opp))
        ),
        React.createElement('div', { style: { marginTop: 10, borderTop: '1px solid #F3F4F6', paddingTop: 8 } },
          React.createElement('button', {
            style: { fontSize: 11, color: '#4B5563', background: 'none', border: 'none', cursor: 'pointer', padding: 0, fontFamily: 'Inter,sans-serif', fontWeight: 600 },
            onClick: function() { var key = opp.govtribe_id || opp.id; setOpenScores(function(prev) { var s = new Set(prev); if(s.has(key)){s.delete(key);}else{s.add(key);api.post('gda-data-learn',{event:'opp_viewed',context:'opp-tracker',data:{title:opp.title||''}}).catch(function(){});} return s; }); }
          }, (openScores.has(opp.govtribe_id || opp.id) ? '▼' : '►') + ' Score Breakdown'),
          openScores.has(opp.govtribe_id || opp.id) && (function() {
            var bd = calculateEisBonus(opp);
            var fs = opp.eis_fit_score || 0;
            var hasComponents = opp.needs_score != null && opp.financials_score != null && opp.ooda_score != null;
            return React.createElement('div', { style: { marginTop: 8, padding: '10px 12px', background: '#F9FAFB', borderRadius: 8, fontSize: 12 } },
              hasComponents ? [
                [{ label: 'Needs (×4)', val: opp.needs_score + '/10', contrib: Math.round(opp.needs_score * 4), pct: opp.needs_score / 10 },
                 { label: 'Financials (×30)', val: parseFloat(opp.financials_score).toFixed(2), contrib: Math.round(opp.financials_score * 30), pct: parseFloat(opp.financials_score) },
                 { label: 'OODA (×0.3)', val: opp.ooda_score + '/100', contrib: Math.round(opp.ooda_score * 0.3), pct: opp.ooda_score / 100 }
                ].map(function(r, ri) {
                  return React.createElement('div', { key: ri, style: { display: 'flex', alignItems: 'center', gap: 8, marginBottom: 6 } },
                    React.createElement('span', { style: { width: 120, color: '#6B7280', flexShrink: 0, fontSize: 11 } }, r.label),
                    React.createElement('div', { style: { flex: 1, height: 6, background: '#E5E7EB', borderRadius: 3 } },
                      React.createElement('div', { style: { width: Math.min(100, Math.round(r.pct * 100)) + '%', height: '100%', background: '#1B2A4A', borderRadius: 3 } })
                    ),
                    React.createElement('span', { style: { width: 50, textAlign: 'right', color: '#4B5563', flexShrink: 0, fontSize: 11 } }, r.val),
                    React.createElement('span', { style: { width: 34, textAlign: 'right', fontWeight: 700, color: '#1B2A4A', flexShrink: 0, fontSize: 11 } }, '=' + r.contrib)
                  );
                }),
                bd.bonuses.length > 0 && React.createElement('div', { key: 'bon', style: { color: '#2F5C1F', fontSize: 11, marginTop: 4 } }, 'EIS Bonus: ' + bd.bonuses.join(', ') + ' = +' + bd.bonus),
                React.createElement('div', { key: 'tot', style: { marginTop: 6, borderTop: '1px solid #E5E7EB', paddingTop: 6, fontWeight: 700, color: '#1B2A4A', fontSize: 12 } },
                  (function() { var raw = Math.round(opp.needs_score*4) + Math.round(opp.financials_score*30) + Math.round(opp.ooda_score*0.3) + bd.bonus; return raw > 100 ? 'Total: ' + raw + ' → capped at 100' : 'Total: ' + fs + '/100'; })()
                )
              ] : [
                bd.bonuses.length > 0 && React.createElement('div', { key: 'bon', style: { color: '#2F5C1F', fontSize: 11 } }, 'EIS Bonuses: ' + bd.bonuses.join(', ')),
                React.createElement('div', { key: 'sc', style: { fontWeight: 700, color: '#1B2A4A', fontSize: 12, marginTop: 4 } }, 'Score: ' + fs + '/100'),
                React.createElement('div', { key: 'pend', style: { color: '#9CA3AF', fontSize: 11, marginTop: 4 } }, 'Needs / Financials / OODA components pending AI analysis')
              ]
            );
          })()
        ),
        opp.ai_analysis && React.createElement('div', { style: { marginTop: 8 } },
          React.createElement('button', {
            style: { fontSize: 11, color: '#4B5563', background: 'none', border: 'none', cursor: 'pointer', padding: 0, fontFamily: 'Inter,sans-serif', fontWeight: 600 },
            onClick: function() { var key = opp.govtribe_id || opp.id; setOpenAnalysis(function(prev) { var s = new Set(prev); s.has(key) ? s.delete(key) : s.add(key); return s; }); }
          }, (openAnalysis.has(opp.govtribe_id || opp.id) ? '▼' : '►') + ' AI Analysis'),
          openAnalysis.has(opp.govtribe_id || opp.id) && React.createElement('div', {
            style: { marginTop: 6, padding: '10px 12px', background: '#5091A712', borderRadius: 8, fontSize: 12, color: '#1B2A4A', lineHeight: 1.6, borderLeft: '3px solid #0EA5E9' }
          }, opp.ai_analysis)
        ),
        opp.description && React.createElement('p', {
          style: { margin: '8px 0 0', fontSize: '12px', color: '#6B7280', lineHeight: '1.5' }
        }, opp.description.length > 200 ? opp.description.substring(0, 200) + '...' : opp.description)
      );
}


// ── S-079 OODA LOOP HELPERS


// ── S-079 OODA LOOP HELPERS ─────────────────────────────────

function renderMarkdown(text) {
  if (!text) return '';
  if (typeof text === 'string' && text.indexOf(' | ') !== -1 && text.split(' | ').length > 2) {
    var pipeItems = text.split(' | ').map(function(item) { return item.trim(); }).filter(function(item) { return item.length > 0; });
    return React.createElement('div', { style: { margin: '4px 0' } },
      pipeItems.map(function(item, pi) {
        return React.createElement('div', { key: pi, style: { display: 'flex', gap: 6, marginBottom: 4, fontSize: 13, lineHeight: 1.5 } },
          React.createElement('span', { style: { color: '#D14A2A', fontWeight: 700, flexShrink: 0 } }, '>'),
          React.createElement('span', null, item)
        );
      })
    );
  }
  function parseInline(line, lineIdx) {
    var parts = [];
    var regex = /\*\*(.+?)\*\*/g;
    var lastIndex = 0;
    var match;
    var cleaned = line;
    while ((match = regex.exec(cleaned)) !== null) {
      if (match.index > lastIndex) parts.push(cleaned.slice(lastIndex, match.index));
      parts.push(React.createElement('strong', { key: 'b' + lineIdx + '-' + match.index, style: { color: '#1B2A4A' } }, match[1]));
      lastIndex = regex.lastIndex;
    }
    if (lastIndex < cleaned.length) parts.push(cleaned.slice(lastIndex));
    if (parts.length === 0) parts.push(line);
    return parts;
  }
  return text.split('\n').map(function(line, i) {
    var trimmed = line.trim();
    if (!trimmed) return React.createElement('div', { key: 'ln' + i, style: { height: 8 } });
    if (trimmed.startsWith('### ')) {
      return React.createElement('div', { key: 'ln' + i, style: { fontSize: 14, fontWeight: 700, color: '#1B2A4A', marginTop: 14, marginBottom: 4 } }, parseInline(trimmed.substring(4), i));
    }
    if (trimmed.startsWith('## ')) {
      return React.createElement('div', { key: 'ln' + i, style: { fontSize: 15, fontWeight: 700, color: '#1B2A4A', marginTop: 16, marginBottom: 6, borderBottom: '1px solid #E8ECF1', paddingBottom: 4 } }, parseInline(trimmed.substring(3), i));
    }
    if (trimmed.startsWith('# ')) {
      return React.createElement('div', { key: 'ln' + i, style: { fontSize: 17, fontWeight: 700, color: '#1B2A4A', marginTop: 18, marginBottom: 8 } }, parseInline(trimmed.substring(2), i));
    }
    if (trimmed.startsWith('- ') || trimmed.startsWith('* ')) {
      var bulletText = trimmed.startsWith('- ') ? trimmed.substring(2) : trimmed.substring(2);
      return React.createElement('div', { key: 'ln' + i, style: { display: 'flex', gap: 6, paddingLeft: 8, marginBottom: 4 } },
        React.createElement('span', { style: { color: '#D14A2A', fontWeight: 700, flexShrink: 0 } }, '>'),
        React.createElement('span', { style: { fontSize: 13, lineHeight: 1.5 } }, parseInline(bulletText, i))
      );
    }
    if (/^\d+\.\s/.test(trimmed)) {
      var numMatch = trimmed.match(/^(\d+)\.\s(.*)$/);
      if (numMatch) {
        return React.createElement('div', { key: 'ln' + i, style: { display: 'flex', gap: 6, paddingLeft: 8, marginBottom: 4 } },
          React.createElement('span', { style: { color: '#D14A2A', fontWeight: 700, flexShrink: 0, minWidth: 18 } }, numMatch[1] + '.'),
          React.createElement('span', { style: { fontSize: 13, lineHeight: 1.5 } }, parseInline(numMatch[2], i))
        );
      }
    }
    if (trimmed.startsWith('**') && trimmed.endsWith('**')) {
      return React.createElement('div', { key: 'ln' + i, style: { fontWeight: 700, marginTop: 12, marginBottom: 4, color: '#1B2A4A', fontSize: 14 } }, parseInline(trimmed, i));
    }
    if (trimmed.startsWith('---') || trimmed.startsWith('___') || trimmed.startsWith('***')) {
      return React.createElement('hr', { key: 'ln' + i, style: { border: 'none', borderTop: '1px solid #E8ECF1', margin: '12px 0' } });
    }
    return React.createElement('div', { key: 'ln' + i, style: { marginBottom: 2, fontSize: 13, lineHeight: 1.5 } }, parseInline(trimmed, i));
  });
}

// Extracted to components/pages/OodaLoopPage.jsx



// ── RFP RED TEAM ─────────────────────────────────────────────
// Extracted to components/pages/RfpScannerPage.jsx



// ── S-079 INTEL FEED ─────────────────────────────────────────
// Extracted to components/pages/IntelFeedPage.jsx


// GDA Competitive Intelligence — Full Rebuild (S-097)
// Inline in App.jsx — replaces function CompIntel()

function CompIntel() {
  var _comps = useState([]); var comps = _comps[0]; var setComps = _comps[1];
  var _loading = useState(true); var loading = _loading[0]; var setLoading = _loading[1];
  var _expanded = useState(null); var expanded = _expanded[0]; var setExpanded = _expanded[1];
  var _sizeFilter = useState('All'); var sizeFilter = _sizeFilter[0]; var setSizeFilter = _sizeFilter[1];
  var _search = useState(''); var search = _search[0]; var setSearch = _search[1];
  var h = React.createElement;
  useEffect(function() {
    api.post('gda-competitor-watchlist', {action:'list'}).then(function(d) {
      setComps(d.competitors || []);
    }).catch(function() {}).finally(function() { setLoading(false); });
  }, []);
  var filtered = comps.filter(function(c) {
    if (sizeFilter !== 'All' && c.size !== sizeFilter) return false;
    if (search && c.name.toLowerCase().indexOf(search.toLowerCase()) === -1 && (c.why_they_matter||'').toLowerCase().indexOf(search.toLowerCase()) === -1) return false;
    return true;
  });
  var sizeCounts = {All:comps.length, Large:0, Mid:0, Small:0};
  comps.forEach(function(c) { if (sizeCounts[c.size] !== undefined) sizeCounts[c.size]++; });
  function fmt(v) { return formatDollar(v); }
  function sizeBadge(sz) {
    var colors = {Large:['#DC2626','#FEF2F2'], Mid:['#D97706','#FFFBEB'], Small:['#16A34A','#ECFDF5']};
    var c = colors[sz] || ['#6B7280','#F3F4F6'];
    return h('span', {style:{fontSize:10, fontWeight:700, color:c[0], background:c[1], padding:'2px 8px', borderRadius:10, border:'1px solid '+c[0]+'30'}}, sz || 'Unknown');
  }
  function agencyPills(str) {
    if (!str) return null;
    return h('div', {style:{display:'flex', flexWrap:'wrap', gap:4, marginTop:4}}, str.split(',').slice(0,4).map(function(a,i) {
      return h('span', {key:i, style:{fontSize:9, padding:'1px 6px', background:'#EFF6FF', color:'#1D4ED8', borderRadius:8, border:'1px solid #BFDBFE', fontWeight:600}}, a.trim());
    }));
  }
  if (loading) return h('div', {style:{padding:40, textAlign:'center', color:'#6B7280'}}, 'Loading 35 competitors...');
  return h('div', null,
    h('div', {style:{display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:16}},
      h('div', null,
        h('div', {style:{fontSize:18, fontWeight:700, color:NAVY}}, 'Competitive Intelligence'),
        h('div', {style:{fontSize:12, color:'#6B7280', marginTop:2}}, filtered.length + ' of ' + comps.length + ' competitors')
      ),
      h('div', {style:{display:'flex', gap:8, alignItems:'center'}},
        h('input', {placeholder:'Search competitors...', value:search, onChange:function(e){setSearch(e.target.value);}, style:Object.assign({}, S.input, {width:200, fontSize:12})}),
        ['All','Large','Mid','Small'].map(function(sz) {
          return h('button', {key:sz, onClick:function(){setSizeFilter(sz);}, style:{padding:'4px 12px', fontSize:11, fontWeight:600, borderRadius:6, border:'1px solid '+(sizeFilter===sz?ACCENT:BORDER), background:sizeFilter===sz?ACCENT:'#fff', color:sizeFilter===sz?'#fff':NAVY, cursor:'pointer'}}, sz + ' (' + sizeCounts[sz] + ')');
        })
      )
    ),
    h('div', {style:{display:'grid', gridTemplateColumns:'repeat(4, 1fr)', gap:12}},
      filtered.map(function(c) {
        var isExp = expanded === c.id;
        return h('div', {key:c.id, onClick:function(){setExpanded(isExp?null:c.id);}, style:{background:'#fff', border:'1px solid '+(isExp?ACCENT:BORDER), borderRadius:10, padding:14, cursor:'pointer', transition:'all 0.2s', boxShadow:isExp?'0 4px 12px rgba(0,0,0,0.1)':'0 1px 3px rgba(0,0,0,0.04)'}},
          h('div', {style:{display:'flex', justifyContent:'space-between', alignItems:'flex-start', marginBottom:8}},
            h('div', {style:{fontSize:13, fontWeight:700, color:NAVY, lineHeight:1.3, flex:1, marginRight:6}}, c.name),
            sizeBadge(c.size)
          ),
          c.sba_certs && c.sba_certs !== 'None - Large Business' && c.sba_certs !== 'None - Mid-Tier' && h('div', {style:{fontSize:10, color:'#7C3AED', fontWeight:600, marginBottom:4}}, c.sba_certs),
          h('div', {style:{fontSize:11, color:'#374151', lineHeight:1.5, marginBottom:8, minHeight:32}}, c.why_they_matter || 'Awaiting analysis...'),
          h('div', {style:{fontSize:10, color:'#6B7280', fontWeight:600, marginBottom:2}}, 'TOP AGENCIES'),
          agencyPills(c.top_agencies || c.target_agencies),
          c.total_obligated && h('div', {style:{marginTop:8, display:'flex', justifyContent:'space-between', alignItems:'center'}},
            h('div', null,
              h('div', {style:{fontSize:9, color:'#6B7280', fontWeight:600}}, 'FPDS OBLIGATED'),
              h('div', {style:{fontSize:14, fontWeight:700, color:NAVY}}, fmt(c.total_obligated))
            ),
            c.govtribe_url && h('a', {href:c.govtribe_url, target:'_blank', onClick:function(e){e.stopPropagation();}, style:{fontSize:10, color:ACCENT, textDecoration:'none', fontWeight:600}}, 'GovTribe \u2197')
          ),
          c.idiq_vehicles && h('div', {style:{marginTop:6}},
            h('div', {style:{fontSize:9, color:'#6B7280', fontWeight:600, marginBottom:2}}, 'IDIQ VEHICLES'),
            h('div', {style:{fontSize:10, color:'#374151', lineHeight:1.4}}, c.idiq_vehicles)
          ),
          c.capture_plan_overlap && h('div', {style:{marginTop:6, padding:'4px 8px', background:'#FEF2F2', borderRadius:4, border:'1px solid #FECACA'}},
            h('div', {style:{fontSize:9, color:'#DC2626', fontWeight:700}}, '\u26A0 COMPETES ON: ' + c.capture_plan_overlap)
          ),
          isExp && h('div', {style:{marginTop:10, paddingTop:10, borderTop:'1px solid '+BORDER}},
            typeof c.govtribe_summary==='string' && c.govtribe_summary && h('div', {style:{marginBottom:8}},
              h('div', {style:{fontSize:10, fontWeight:700, color:NAVY, marginBottom:3}}, 'GOVTRIBE SUMMARY'),
              h('div', {style:{fontSize:11, color:'#374151', lineHeight:1.5, maxHeight:120, overflow:'auto'}}, c.govtribe_summary)
            ),
            typeof c.teaming_potential==='string' && c.teaming_potential && h('div', {style:{marginBottom:6}},
              h('div', {style:{fontSize:10, fontWeight:700, color:'#16A34A', marginBottom:2}}, 'TEAMING POTENTIAL'),
              h('div', {style:{fontSize:11, color:'#374151'}}, c.teaming_potential)
            ),
            typeof c.eis_strategy==='string' && c.eis_strategy && h('div', {style:{marginBottom:6}},
              h('div', {style:{fontSize:10, fontWeight:700, color:'#D97706', marginBottom:2}}, 'STRATEGY'),
              h('div', {style:{fontSize:11, color:'#374151'}}, c.eis_strategy)
            ),
            typeof c.known_contracts==='string' && c.known_contracts && h('div', null,
              h('div', {style:{fontSize:10, fontWeight:700, color:'#6B7280', marginBottom:2}}, 'KNOWN CONTRACTS'),
              h('div', {style:{fontSize:11, color:'#374151'}}, c.known_contracts)
            )
          )
        );
      })
    )
  );
}
function DocumentHub() {
  const [dhTab, setDhTab] = useState('library');
  return (
    <div>
      <PageHeader title="Document Hub" sub="Upload, query, and generate documents from your knowledge base" />
      <div style={{display:'flex',gap:0,marginBottom:20}}>
        {[{id:'library',label:'Library'},{id:'generate',label:'Generate'}].map((t,ti) => (
          <button key={t.id} onClick={() => setDhTab(t.id)} style={{padding:'9px 22px',fontSize:12,fontWeight:dhTab===t.id?700:400,color:dhTab===t.id?'#fff':NAVY,background:dhTab===t.id?ACCENT:'#fff',border:'1px solid '+(dhTab===t.id?ACCENT:BORDER),cursor:'pointer',borderRadius:ti===0?'6px 0 0 6px':'0 6px 6px 0'}}>{t.label}</button>
        ))}
      </div>
      {dhTab === 'library' && <DocRAGEmbed />}
      {dhTab === 'generate' && <PresentationsEmbed />}
    </div>
  );
}

function DocRAGEmbed() { return React.createElement(DocRAG, null); }
function PresentationsEmbed() { return React.createElement(Presentations, null); }

// Extracted to components/pages/PresentationsPage.jsx


// ── DIRECTIONS ───────────────────────────────────────────────
// Extracted to components/pages/PlatformGuidePage.jsx


// ── AI AGENT CHAT ────────────────────────────────────────────
// Extracted to components/pages/AIAgentPage.jsx



// -- ACTION ITEMS (ACT-003) ----
// Extracted to components/pages/ActionItemsPage.jsx


// -- GLOBAL ACTION FAB (ACT-001/002) ----
function GlobalActionFab({currentPage, onNavigate}) {
  const [open,setOpen]=useState(false);const [text,setText]=useState('');const [pri,setPri]=useState('medium');const [saving,setSaving]=useState(false);const [flash,setFlash]=useState('');
  if(currentPage==='actions') return null;
  const names={'launchpad':'Launchpad','opp-tracker':'Opp Tracker','ooda':'OODA Loop','red-team':'Proposal Review','comp-intel':'Comp Intel','intel-feed':'Intel Feed','presentations':'Document Generator','doc-hub':'Document Hub','directions':'Directions','ai-agent':'AI Agent','sitrep':'SITREP','email':'Email Drafter','doc-rag':'Doc RAG','ops':'Ops Dashboard'};
  const pageName=names[currentPage]||currentPage;
  const submit=async()=>{if(!text.trim())return;setSaving(true);try{await api.post('gda-action-items',{action:'create',title:text,status:'open',priority:pri,source:pageName});setText('');setOpen(false);setFlash('Action item added!');setTimeout(()=>setFlash(''),2500);}catch(e){setFlash('Error: '+e.message);setTimeout(()=>setFlash(''),3000);}setSaving(false);};
  return (<>
    {flash&&<div style={{position:'fixed',bottom:80,right:24,background:'#1a7a3a',color:WHITE,padding:'8px 16px',borderRadius:8,fontSize:12,fontWeight:600,zIndex:10001,boxShadow:'0 2px 12px rgba(0,0,0,0.15)'}}>{flash}</div>}
    {open&&<div style={{position:'fixed',inset:0,background:'rgba(0,0,0,0.3)',zIndex:9999}} onClick={()=>setOpen(false)} />}
    {open&&<div style={{position:'fixed',bottom:80,right:24,width:340,background:WHITE,border:'1px solid '+BORDER,borderRadius:12,padding:18,zIndex:10000,boxShadow:'0 8px 30px rgba(0,0,0,0.12)'}}>
      <div style={{fontSize:14,fontWeight:700,color:NAVY,marginBottom:4}}>Quick Action Item</div>
      <div style={{fontSize:11,color:'#888',marginBottom:12}}>From: {pageName}</div>
      <input style={{...S.input,marginBottom:8}} placeholder="What needs to be done?" value={text} onChange={e=>setText(e.target.value)} onKeyDown={e=>e.key==='Enter'&&submit()} autoFocus />
      <div style={{display:'flex',gap:8,marginBottom:12}}>{['high','medium','low'].map(p=>(<button key={p} onClick={()=>setPri(p)} style={{...S.btn(p===pri?'primary':'secondary',true),flex:1,textTransform:'capitalize'}}>{p}</button>))}</div>
      <div style={{display:'flex',gap:8}}><button style={{...S.btn(),flex:1}} onClick={submit} disabled={saving||!text.trim()}>{saving?'Saving...':'Add Item'}</button>
        <button style={{...S.btn('secondary'),flex:0}} onClick={()=>{setOpen(false);onNavigate('actions');}}>View All</button></div>
    </div>}
    <button onClick={()=>setOpen(!open)} style={{position:'fixed',bottom:24,right:24,width:48,height:48,borderRadius:'50%',background:ACCENT,color:WHITE,border:'none',fontSize:24,fontWeight:700,cursor:'pointer',boxShadow:'0 4px 16px rgba(198,93,33,0.4)',zIndex:9998,display:'flex',alignItems:'center',justifyContent:'center',transition:'transform 0.2s',transform:open?'rotate(45deg)':'none'}}>+</button>
  </>);
}

// -- SIDEBAR QUICK ADD (replaces navigation button) ----
function SidebarQuickAdd() {
  const [open,setOpen]=useState(false);
  const [text,setText]=useState('');
  const [pri,setPri]=useState('medium');
  const [due,setDue]=useState('');
  const [saving,setSaving]=useState(false);
  const [flash,setFlash]=useState('');
  const submit=async()=>{
    if(!text.trim())return;setSaving(true);
    try{await api.post('gda-action-items',{action:'create',title:text,status:'open',priority:pri,due:due||undefined,source:'Sidebar Quick Add'});
      setText('');setDue('');setPri('medium');setOpen(false);setFlash('Added!');setTimeout(()=>setFlash(''),2000);
    }catch(e){setFlash('Error');setTimeout(()=>setFlash(''),2000);}
    setSaving(false);
  };

  return (<div style={{position:'relative'}}>
    {flash&&<div style={{position:'absolute',bottom:42,left:0,right:0,textAlign:'center',fontSize:11,fontWeight:700,color:'#1a7a3a',padding:2}}>{flash}</div>}
    {open&&<div style={{position:'absolute',bottom:42,left:6,right:6,background:WHITE,border:'1px solid '+BORDER,borderRadius:8,padding:12,boxShadow:'0 -4px 20px rgba(0,0,0,0.1)',zIndex:100}}>
      <div style={{fontSize:12,fontWeight:700,color:NAVY,marginBottom:8}}>New Action Item</div>
      <input style={{...S.input,marginBottom:6,fontSize:11}} placeholder="What needs to be done?" value={text} onChange={e=>setText(e.target.value)} onKeyDown={e=>e.key==='Enter'&&submit()} autoFocus />
      <div style={{display:'flex',gap:4,marginBottom:6}}>{['high','medium','low'].map(p=>(<button key={p} onClick={()=>setPri(p)} style={{flex:1,padding:'3px 0',borderRadius:4,border:'1px solid '+(p===pri?ACCENT:BORDER),background:p===pri?ACCENT:'transparent',color:p===pri?WHITE:NAVY,fontSize:11,fontWeight:600,cursor:'pointer',textTransform:'capitalize'}}>{p}</button>))}</div>
      <input type="date" style={{...S.input,marginBottom:8,fontSize:11}} value={due} onChange={e=>setDue(e.target.value)} />
      <div style={{display:'flex',gap:4}}><button style={{...S.btn(),flex:1,fontSize:11,padding:'5px 0'}} onClick={submit} disabled={saving||!text.trim()}>{saving?'...':'Add'}</button><button style={{...S.btn('secondary'),fontSize:11,padding:'5px 8px'}} onClick={()=>setOpen(false)}>X</button></div>
    </div>}
    <button onClick={()=>setOpen(!open)} style={{display:'block',margin:'4px 12px',padding:'8px 0',background:ACCENT,color:'#fff',border:'none',borderRadius:8,textAlign:'center',fontSize:12,fontWeight:600,cursor:'pointer',width:'calc(100% - 24px)'}}>+ Action Item</button>
  </div>);
}

function SidebarHelp() {
  return (
    <div onClick={()=>{if(window._gdaNavigate) window._gdaNavigate("help");}} style={{margin:"4px 12px",padding:"8px 0",background:"#556B2F",color:"#fff",borderRadius:8,textAlign:"center",fontSize:12,fontWeight:600,cursor:"pointer",letterSpacing:"0.3px"}}>
      Help
    </div>
  );
}

function SidebarQuickRisk() {
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({title:'',severity:'HIGH',category:'',description:'',mitigation:''});
  const [saving, setSaving] = useState(false);
  const [flash, setFlash] = useState('');
  const submit = async () => {
    if (!form.title.trim()) return;
    setSaving(true);
    try {
      await api.post('gda-risk', {action:'create', title:form.title, severity:form.severity, category:form.category, description:form.description, mitigation:form.mitigation, status:'Active'});
      setForm({title:'',severity:'HIGH',category:'',description:'',mitigation:''});
      setOpen(false); setFlash('Risk added!'); setTimeout(() => setFlash(''), 2000);
    } catch(e) { setFlash('Error'); setTimeout(() => setFlash(''), 2000); }
    setSaving(false);
  };
  return (<div style={{position:'relative'}}>
    {flash && <div style={{position:'absolute',bottom:42,left:0,right:0,textAlign:'center',fontSize:11,fontWeight:700,color:'#DC2626',padding:2}}>{flash}</div>}
    {open && <div style={{position:'absolute',bottom:42,left:6,right:6,background:WHITE,border:'1px solid '+BORDER,borderRadius:8,padding:12,boxShadow:'0 -4px 20px rgba(0,0,0,0.1)',zIndex:100}}>
      <div style={{fontSize:12,fontWeight:700,color:NAVY,marginBottom:8}}>New Risk</div>
      <input style={{...S.input,marginBottom:6,fontSize:11}} placeholder="Risk title..." value={form.title} onChange={e=>setForm(p=>({...p,title:e.target.value}))} onKeyDown={e=>e.key==='Enter'&&submit()} autoFocus />
      <div style={{display:'flex',gap:4,marginBottom:6}}>{['CRITICAL','HIGH','MEDIUM','LOW'].map(s=>(<button key={s} onClick={()=>setForm(p=>({...p,severity:s}))} style={{flex:1,padding:'3px 0',borderRadius:4,border:'1px solid '+(s===form.severity?'#DC2626':BORDER),background:s===form.severity?'#DC2626':'transparent',color:s===form.severity?WHITE:NAVY,fontSize:8,fontWeight:600,cursor:'pointer'}}>{s}</button>))}</div>
      <input style={{...S.input,marginBottom:6,fontSize:11}} placeholder="Category (Budget, Technical, Schedule...)" value={form.category} onChange={e=>setForm(p=>({...p,category:e.target.value}))} />
      <textarea style={{...S.input,marginBottom:6,fontSize:11,minHeight:40,resize:'vertical'}} placeholder="Description..." value={form.description} onChange={e=>setForm(p=>({...p,description:e.target.value}))} />
      <textarea style={{...S.input,marginBottom:8,fontSize:11,minHeight:40,resize:'vertical'}} placeholder="Mitigation plan..." value={form.mitigation} onChange={e=>setForm(p=>({...p,mitigation:e.target.value}))} />
      <div style={{display:'flex',gap:4}}><button style={{flex:1,padding:'5px 0',background:'#DC2626',color:WHITE,border:'none',borderRadius:4,fontSize:11,fontWeight:600,cursor:'pointer'}} onClick={submit} disabled={saving||!form.title.trim()}>{saving?'...':'Add Risk'}</button><button style={{...S.btn('secondary'),fontSize:11,padding:'5px 8px'}} onClick={()=>setOpen(false)}>X</button></div>
    </div>}
    <button onClick={()=>setOpen(!open)} style={{display:'block',margin:'4px 12px',padding:'8px 0',background:'#DC2626',color:'#fff',border:'none',borderRadius:8,textAlign:'center',fontSize:12,fontWeight:600,cursor:'pointer',width:'calc(100% - 24px)'}}>+ Risk</button>
  </div>);
}

// ── DAILY SITREP ─────────────────────────────────────────────

// Extracted to components/pages/DailySitrepPage.jsx


// Extracted to components/pages/EmailDrafterPage.jsx

// Extracted to components/pages/DocRAGPage.jsx

// IDIQ & NDAA INTEL
// Extracted to components/pages/IdiqNdaaPage.jsx


// OPERATIONS DASHBOARD ─────────────────────────────────────
// Extracted to components/pages/OpsDashboardPage.jsx



// -- RISK REGISTER (S-076) ----
// Extracted to components/pages/RiskRegisterPage.jsx


// ── CAPTURE INTEL ─────────────────────────────────────────────
// Extracted to components/pages/CaptureIntelPage.jsx


// ── PREDICTIVE INTEL SECTION (inline in Launchpad) ───────────
function PredictiveIntel() {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.post('gda-predictive-intel', {action:'predictive'}, {signal:AbortSignal.timeout(40000)})
      .then(d => { setData(d); setLoading(false); })
      .catch(() => { setData({_fallback:true}); setLoading(false); });
  }, []);

  if (loading) return (
    <div style={{background:'#fff',border:'1px solid #E8ECF1',borderRadius:12,padding:24,marginTop:24}}>
      <div style={{display:'flex',alignItems:'center',gap:10,color:'#6B7280',fontSize:13}}><Spinner /><span>Generating predictive insights...</span></div>
    </div>
  );

  if (!data || data._fallback) return (
    <div style={{background:'#fff',border:'1px solid #E8ECF1',borderRadius:12,padding:24,marginTop:24}}>
      <div style={{fontSize:20,fontWeight:700,color:'#1B2A4A',marginBottom:8}}>Predictive Intelligence — Contract Opportunity Forecast</div>
      <div style={{fontSize:13,color:'#9CA3AF'}}>No predictive data available. Forecasts are generated from opportunity analysis and market signals.</div>
    </div>
  );

  const rfps = data.rfp_forecasts || data.agencies_likely_to_issue_rfps || data.rfp_forecast || [];
  const gaps = data.capture_gaps || data.emerging_capability_gaps || data.capability_gaps || [];
  const focus = data.recommended_actions || data.recommended_focus_areas || data.focus_areas || [];
  const compThreats = data.competitor_threats || [];
  const health = data.pipeline_health || null;
  const risks = data.risk_factors || data.risks || [];

  if (!rfps.length && !gaps.length && !focus.length && !risks.length) return (
    <div style={{background:'#fff',border:'1px solid #E8ECF1',borderRadius:12,padding:24,marginTop:24}}>
      <div style={{fontSize:20,fontWeight:700,color:'#1B2A4A',marginBottom:8}}>Predictive Intelligence — Contract Opportunity Forecast</div>
      <div style={{fontSize:13,color:'#9CA3AF'}}>No predictions available yet. Run OODA analyses and add opportunities to generate forecasts.</div>
    </div>
  );

  const probColor = (p) => {
    const n = parseFloat(String(p||'0').replace('%',''));
    return n >= 70 ? '#2F5C1F' : n >= 40 ? '#EAB308' : '#DC2626';
  };

  return (
    <div style={{marginTop:24}}>
      <div style={{display:'flex',justifyContent:'space-between',alignItems:'flex-start',marginBottom:16,flexWrap:'wrap',gap:8}}>
        <div>
          <div style={{fontSize:20,fontWeight:700,color:'#1B2A4A'}}>Predictive Intelligence — Contract Opportunity Forecast</div>
          <div style={{fontSize:12,color:'#6B7280',marginTop:2}}>AI-powered analysis of agencies likely to issue RFPs and emerging capability needs</div>
        </div>
        <div style={{fontSize:11,color:'#9CA3AF',fontStyle:'italic',maxWidth:280,textAlign:'right'}}>AI forecast based on platform data only — verify with SAM.gov</div>
      </div>

{health && <div style={{display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:12,marginBottom:20,background:'#F8FAFC',borderRadius:10,padding:'14px 18px',border:'1px solid #E8ECF1'}}>
        <div style={{textAlign:'center'}}><div style={{fontSize:10,fontWeight:700,color:'#6B7280',textTransform:'uppercase',letterSpacing:1}}>PURSUE</div><div style={{fontSize:20,fontWeight:700,color:'#2F5C1F'}}>{health.pursue_count||0}</div></div>
        <div style={{textAlign:'center'}}><div style={{fontSize:10,fontWeight:700,color:'#6B7280',textTransform:'uppercase',letterSpacing:1}}>EVALUATE</div><div style={{fontSize:20,fontWeight:700,color:'#D14A2A'}}>{health.evaluate_count||0}</div></div>
        <div style={{textAlign:'center'}}><div style={{fontSize:10,fontWeight:700,color:'#6B7280',textTransform:'uppercase',letterSpacing:1}}>PIPELINE</div><div style={{fontSize:20,fontWeight:700,color:'#1B2A4A'}}>${String(health.total_value_m||0)}M</div></div>
        <div style={{textAlign:'center'}}><div style={{fontSize:10,fontWeight:700,color:'#6B7280',textTransform:'uppercase',letterSpacing:1}}>CAPTURE %</div><div style={{fontSize:20,fontWeight:700,color:'#B06D32'}}>{health.capture_coverage_pct||0}%</div></div>
        {health.top_risk && <div style={{gridColumn:'1/-1',fontSize:11,color:'#DC2626',fontWeight:600,borderTop:'1px solid #E8ECF1',paddingTop:8,marginTop:4}}>⚠ Top Risk: {health.top_risk}</div>}
      </div>}

      {rfps.length > 0 && <div style={{marginBottom:24}}>
        <div style={{fontSize:12,fontWeight:700,color:'#D14A2A',textTransform:'uppercase',letterSpacing:'1px',marginBottom:12}}>Agencies Most Likely to Issue RFPs (Next 6 Months)</div>
        <div style={{display:'grid',gridTemplateColumns:'repeat(auto-fill,minmax(220px,1fr))',gap:12}}>
          {rfps.map((r,i) => (
            <div key={i} style={{background:'#fff',border:'1px solid #E8ECF1',borderRadius:10,padding:14}}>
              <div style={{fontSize:13,fontWeight:700,color:'#1B2A4A',marginBottom:8,lineHeight:1.3}}>{String(r.program||r.agency||r.name||'')}</div>
              <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:4}}>
                <span style={{fontSize:11,color:'#6B7280'}}>PROBABILITY</span>
                <span style={{fontSize:14,fontWeight:700,color:probColor(r.probability||r.pct||0)}}>{String(r.probability||r.pct||'—')}</span>
              </div>
              {(r.timeline||r.timeframe) && <div style={{display:'flex',justifyContent:'space-between',marginBottom:4}}>
                <span style={{fontSize:11,color:'#6B7280'}}>TIMELINE</span>
                <span style={{fontSize:11,color:'#1B2A4A',fontWeight:500}}>{String(r.timeline||r.timeframe)}</span>
              </div>}
              {(r.estimated_value||r.value) && <div style={{display:'flex',justifyContent:'space-between'}}>
                <span style={{fontSize:11,color:'#6B7280'}}>EST. VALUE</span>
                <span style={{fontSize:11,fontWeight:700,color:'#D14A2A'}}>{String(r.estimated_value||r.value)}</span>
              </div>}
            </div>
          ))}
        </div>
      </div>}

      {gaps.length > 0 && <div style={{marginBottom:24}}>
        <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:12}}>
          <div style={{fontSize:12,fontWeight:700,color:'#D14A2A',textTransform:'uppercase',letterSpacing:'1px'}}>Emerging Capability Gaps & Needs</div>
          <div style={{fontSize:11,color:'#9CA3AF',fontStyle:'italic'}}>AI analysis only — validate against agency documents</div>
        </div>
        <div style={{display:'grid',gridTemplateColumns:'repeat(auto-fill,minmax(280px,1fr))',gap:12}}>
          {gaps.map((g,i) => {
            const agencies = g.affected_agencies || g.agencies || [];
            return (
              <div key={i} style={{background:'#fff',border:'1px solid #E8ECF1',borderLeft:'3px solid #D14A2A',borderRadius:10,padding:14}}>
                <div style={{fontSize:13,fontWeight:700,color:'#1B2A4A',marginBottom:6}}>{String(g.capability||g.title||g.name||'')}</div>
                {g.description && <div style={{fontSize:12,color:'#555',lineHeight:1.5,marginBottom:8}}>{String(g.description)}</div>}
                {g.recent_activity && <div style={{fontSize:11,color:'#EAB308',marginBottom:6}}>⚡ {String(g.recent_activity)}</div>}
                {agencies.length>0 && <div style={{marginBottom:6}}>
                  <div style={{fontSize:11,color:'#9CA3AF',marginBottom:3}}>AFFECTED AGENCIES</div>
                  <div style={{display:'flex',gap:4,flexWrap:'wrap'}}>
                    {(Array.isArray(agencies)?agencies:[String(agencies)]).map((a,j)=><span key={j} style={{padding:'1px 6px',borderRadius:8,fontSize:11,border:'1px solid #32448A55',color:'#32448A',background:'#EFF6FF'}}>{typeof a==='string'?a:String(a)}</span>)}
                  </div>
                </div>}
                {g.eis_fit && <div style={{fontSize:11,color:'#2F5C1F'}}>✓ {String(g.eis_fit)}</div>}
              </div>
            );
          })}
        </div>
      </div>}

      {focus.length > 0 && <div style={{marginBottom:24}}>
        <div style={{fontSize:12,fontWeight:700,color:'#D14A2A',textTransform:'uppercase',letterSpacing:'1px',marginBottom:12}}>Recommended Focus Areas (Shipley Phase 3 Capture Planning)</div>
        <div style={{background:'#fff',border:'1px solid #E8ECF1',borderRadius:10,padding:16}}>
          {focus.map((f,i) => (
            <div key={i} style={{display:'flex',gap:10,padding:'8px 0',borderBottom:i<focus.length-1?'1px solid #F5F5F5':'none',alignItems:'flex-start'}}>
              <span style={{width:22,height:22,borderRadius:'50%',background:'#D14A2A',color:'#fff',fontSize:11,fontWeight:700,display:'flex',alignItems:'center',justifyContent:'center',flexShrink:0}}>{i+1}</span>
              <div style={{fontSize:13,color:'#1B2A4A',lineHeight:1.5}}>{typeof f==='string'?f:String(f.action||f.focus||f.text||JSON.stringify(f))}</div>
            </div>
          ))}
        </div>
      </div>}

      {risks.length > 0 && <div style={{marginBottom:8}}>
        <div style={{fontSize:12,fontWeight:700,color:'#DC2626',textTransform:'uppercase',letterSpacing:'1px',marginBottom:12}}>⚠ Risk Factors & Market Shifts</div>
        <div style={{display:'grid',gridTemplateColumns:'repeat(auto-fill,minmax(260px,1fr))',gap:12}}>
          {risks.map((r,i) => (
            <div key={i} style={{background:'#FEF2F2',border:'1px solid #FCA5A5',borderLeft:'3px solid #DC2626',borderRadius:10,padding:14}}>
              <div style={{fontSize:13,color:'#DC2626',lineHeight:1.5}}>{typeof r==='string'?r:String(r.risk||r.text||r.description||JSON.stringify(r))}</div>
            </div>
          ))}
        </div>
      </div>}
    </div>
  );
}


// ── COMPETITOR WATCHLIST ─────────────────────────────────────
// Extracted to components/pages/CompetitorWatchlistPage.jsx



// ── SITREP TRENDS ─────────────────────────────────────────────
// Extracted to components/pages/SitrepTrendsPage.jsx



// ── CAPTURE PLAN GENERATOR ───────────────────────────────────

function CaptureIntelEmbed() {
  return React.createElement(CaptureIntel, null);
}

var IT = {allocated_revenue_value:'Portion of total contract value allocated to your OU as revenue based on work share.',contract_revenue_value:'Annual revenue recognized from this contract in the current FY for AOP tracking.',total_contract_value:'Full ceiling value across all option years from SAM.gov or RFP.',pwin:'Probability of win (0-100%). Weighted: customer relationship, competitive position, past performance, solution fit, price, incumbency.',set_aside:'SBA set-aside designation determining eligible competitors. Key risk: size recertification.',naics:'North American Industry Classification System code determining SBA size standard.',period_of_performance:'Total contract duration including base and option years driving revenue forecasting.'};
function CpInfoIcon(props){var fld=props.field;var showInfo=props.showInfo;var setShowInfo=props.setShowInfo;var IT2=props.IT;var h=React.createElement;return h('span',{onClick:function(e){e.stopPropagation();setShowInfo(showInfo===fld?null:fld);},style:{cursor:'pointer',fontSize:13,color:'#93C5FD',marginLeft:4,fontWeight:700}},"\u2139\uFE0F",showInfo===fld&&h('div',{style:{position:'absolute',zIndex:100,background:'#1E293B',color:'#E2E8F0',padding:'8px 12px',borderRadius:6,fontSize:11,maxWidth:280,marginTop:4,boxShadow:'0 4px 12px rgba(0,0,0,0.3)',lineHeight:1.5}},IT2[fld]||''));}
function CpField(props){var lb=props.label,vl=props.val,k=props.k,ls=props.list,inf=props.info,ar=props.area;var sf2=props.sf;var sef=props.setEditingField;var si=props.showInfo;var ssi=props.setShowInfo;var IT2=props.IT;var h=React.createElement;var isEmpty=(vl===null||vl===undefined||vl===""||String(vl).trim()==="");var emptyStyle=isEmpty?{background:"#FEF3C7",borderColor:"#F59E0B"}:{};var normalize=function(v){if(k==="gda_allocation_m"){var s=String(v||"").replace(/[\\$,\\sMm]/g,"");return s;}return v;};return h('div',{style:{flex:1,position:'relative',marginBottom:6}},h('div',{style:{fontSize:10,color:'#6B7280',marginBottom:2,fontWeight:600,display:'flex',alignItems:'center'}},lb,inf&&h(CpInfoIcon,{field:k,showInfo:si,setShowInfo:ssi,IT:IT2})),ar?h('textarea',{key:'ta_'+k,style:Object.assign({},S.textarea,{height:60,resize:'vertical',fontSize:12},emptyStyle),defaultValue:vl||'',onFocus:function(){sef(k);},onBlur:function(e){sef(null);sf2(k,normalize(e.target.value));},onInput:function(e){sf2(k,e.target.value);}}):ls?h(React.Fragment,null,h('input',{key:'in_'+k,list:k+'-dl',style:Object.assign({},S.input,{fontSize:12},emptyStyle),defaultValue:vl||'',onFocus:function(){sef(k);},onBlur:function(e){sef(null);sf2(k,normalize(e.target.value));},onInput:function(e){sf2(k,e.target.value);}}),h('datalist',{id:k+'-dl'},ls.map(function(o){return h('option',{key:o,value:o});}))):h('input',{key:'in_'+k,style:Object.assign({},S.input,{fontSize:12},emptyStyle),defaultValue:vl||'',onBlur:function(e){sf2(k,normalize(e.target.value));},onInput:function(e){sf2(k,e.target.value);}}));}
function CapturePlan() {
  var PHASES = ['Go/No-Go','Interest','Qualify','Pursue','Solicitation','Proposal','Post-Submittal','Awaiting Approval','Award'];
  var PC = {'Go/No-Go':'#1B2A4A','Interest':'#1B2A4A','Qualify':'#5091A7','Pursue':'#5091A7','Solicitation':'#D14A2A','Proposal':'#D14A2A','Post-Submittal':'#B06D32','Awaiting Approval':'#1B2A4A','Award':'#2F5C1F','Loss':'#8B0000','Pass':'#6B7280'};
  var PD2 = {'Go/No-Go':'Strategic Fit Assessment','Interest':'Opportunity Discovery','Qualify':'Competitive Analysis & SWOT','Pursue':'Capture Strategy Development','Solicitation':'Bid/No-Bid Decision','Proposal':'Proposal Development','Post-Submittal':'Evaluation & Orals','Awaiting Approval':'Decision Pending','Award':'Transition & Execution'};

  var AGENCIES = ['SOCOM','TRADOC','PEO STRI','CYBERCOM','INSCOM','DISA','Army Futures Command','Army CECOM','Army CECOM / CPE ISW','AFLCMC','NAVAIR','NAVSEA','MDA','DHS','FAA','DIA','NGA','NSA','DARPA','DLA','Other'];
  var CTYPES = ['IDIQ','IDIQ TO','FFP','T&M','CPFF','CPAF','CPIF','BPA','RS3 TO','SHIELD TO','CIO-SP3 TO','eFAST TO','OASIS+ TO','Other'];
  var SAS = ['Unrestricted','Total Small Business','8(a)','8(a) Sole Source','SDVOSB','HUBZone','WOSB','EDWOSB','Other'];
  var DIVS = ['Envision','PD Systems','Riverstone','Envision, PD Systems','Envision, Riverstone','PD Systems, Riverstone','Envision, PD Systems, Riverstone'];
  var PRIS = ['Must-Win','High Priority','Low Priority'];
  var df = {opportunity:'',agency:'',contract_type:'',set_aside:'',naics:'',period_of_performance:'',incumbent:'',known_competitors:'',priority:'',codename:'',division_owners:'Envision',prime_company:'Envision Innovative Solutions',rfp_date:'',total_contract_value:'',allocated_revenue_value:'',gda_allocation_m:'',pwin:'',total_shaping_progress:'',idiq_vehicle:'',stage:'Go/No-Go',contract_revenue_value:'',notes:'',solicitation_number:'',eis_strengths:'',eis_weaknesses:'',swot_opportunities:'',swot_threats:''};
  var _s=useState,_e=useEffect; var _f=_s(df),form=_f[0],setForm=_f[1]; var _p=_s([]),plans=_p[0],setPlans=_p[1]; var _l=_s(false),loading=_l[0],setLoading=_l[1]; var _sv=_s(false),saving=_sv[0],setSaving=_sv[1]; var _t=_s(''),toast=_t[0],setToast=_t[1]; var _ap=_s(null),activePlan=_ap[0],setActivePlan=_ap[1]; var _pi=_s(null),planId=_pi[0],setPlanId=_pi[1]; var _v=_s('list'),view=_v[0],setView=_v[1]; var _ph=_s(0),activePhase=_ph[0],setActivePhase=_ph[1]; var _az=_s(false),analyzing=_az[0],setAnalyzing=_az[1]; var _si=_s(null),showInfo=_si[0],setShowInfo=_si[1]; var _ef=_s(null),editingField=_ef[0],setEditingField=_ef[1]; var _os=_s({}),openStages=_os[0],setOpenStages=_os[1];
  var setField=function(k,v){setForm(function(p){var o={};for(var x in p)o[x]=p[x];o[k]=v;return o;});};
  var showT=function(m){setToast(m);setTimeout(function(){setToast('');},4000);};
  var strip$=function(v){return typeof v==='string'?v.replace(/[$,]/g,''):String(v||'');};
  var fmt$=function(v){return formatDollar(v);};
  var toggleStage=function(s){setOpenStages(function(p){var o={};for(var x in p)o[x]=p[x];o[s]=!p[s];return o;});};
  var loadPlans=function(){setLoading(true);api.post('gda-capture-plan',{action:'list',limit:50}).then(function(d){setPlans(d.plans||d.data||[]);setLoading(false);}).catch(function(){setPlans([]);setLoading(false);});};
  _e(function(){loadPlans();},[]);
  var phaseIdx=PHASES.indexOf(form.stage)>=0?PHASES.indexOf(form.stage):0;
  var openPlan=function(row){var pd=(typeof row.plan_data==='object'&&row.plan_data)||{};try{if(typeof row.plan_data==='string')pd=JSON.parse(row.plan_data);}catch(e){}setPlanId(row.id);setActivePlan(pd);var f={};for(var k in df)f[k]=df[k];for(var k in pd){if(k in f&&typeof pd[k]==='string')f[k]=pd[k];}f.opportunity=row.opportunity||pd.opportunity_name||pd.codename||row.opp_title||'';f.agency=row.agency||pd.agency||'';f.pwin=pd.pwin?String(pd.pwin):f.pwin;f.incumbent=pd.incumbent&&typeof pd.incumbent==='object'?pd.incumbent.company||'':(typeof pd.incumbent==='string'?pd.incumbent:'');f.known_competitors=Array.isArray(pd.win_strategy&&pd.win_strategy.ghost_competitors)?pd.win_strategy.ghost_competitors.join(', '):pd.known_competitors||'';f.notes=pd.scope_summary||pd.notes||'';if(!f.codename&&row.opp_title)f.codename=row.opp_title;var stg=pd.stage||pd.capture_stage||'Go/No-Go';setForm(f);setActivePhase(PHASES.indexOf(stg)>=0?PHASES.indexOf(stg):0);setView('card');};
  var savePlan=function(silent){setSaving(true);var clean={};for(var k in form){var v=form[k];if(typeof v==='string'&&v.match(/^$[0-9,]+$/))clean[k]=v.replace(/[$,]/g,'');else clean[k]=v;}var planData={};for(var k in(activePlan||{}))planData[k]=(activePlan||{})[k];for(var k in clean)planData[k]=clean[k];planData.stage=PHASES[activePhase]||form.stage;var payload={action:'save',plan:planData,opportunity:form.opportunity,agency:form.agency,contract_value:strip$(form.total_contract_value),opp_title:form.codename||form.opportunity};if(planId)payload.plan_id=planId;api.post('gda-capture-plan',payload).then(function(res){if(res.id&&!planId)setPlanId(res.id);if(!silent)showT('Saved');loadPlans();setSaving(false);}).catch(function(){if(!silent)showT('Save failed');setSaving(false);});};
  var analyzePhase=function(){setAnalyzing(true);var pd={};for(var k in(activePlan||{}))pd[k]=(activePlan||{})[k];for(var k in form)pd[k]=form[k];api.post('gda-capture-plan',{action:'analyze_phase',phase:PHASES[activePhase],plan_id:planId,plan_data:pd}).then(function(d){if(d.analysis){setActivePlan(function(p){var oa=p&&p.ooda_analyses?{}:{};if(p&&p.ooda_analyses)for(var k in p.ooda_analyses)oa[k]=p.ooda_analyses[k];oa[PHASES[activePhase]]=d.analysis;var np={};for(var k in(p||{}))np[k]=(p||{})[k];np.ooda_analyses=oa;return np;});showT('Analysis complete');}setAnalyzing(false);}).catch(function(){showT('Analysis failed');setAnalyzing(false);});};
  var advancePhase=function(){if(activePhase<8){savePlan(true);setActivePhase(activePhase+1);setField('stage',PHASES[activePhase+1]);}};
  var deletePlan=function(id,e){e.stopPropagation();if(!window.confirm('Delete?'))return;api.post('gda-capture-plan',{action:'delete',plan_id:id}).then(function(){setPlans(function(p){return p.filter(function(r){return r.id!==id;});});}).catch(function(){});};
  function sf(k,v){setForm(function(p){var o={};for(var x in p)o[x]=p[x];o[k]=v;return o;});}
  function st2(m){setToast(m);setTimeout(function(){setToast('');},4000);}
  function strip$(v){return typeof v==='string'?v.replace(/[$,]/g,''):String(v||'');}
  function fmt$(v){return formatDollar(v);}
  function togS(s){setOpenStages(function(p){var o={};for(var x in p)o[x]=p[x];o[s]=!p[s];return o;});}
  function loadP(){setLoading(true);api.post('gda-capture-plan',{action:'list',limit:50}).then(function(d){setPlans(d.plans||d.data||[]);setLoading(false);}).catch(function(){setPlans([]);setLoading(false);});}
  _e(function(){loadP();},[]);
  var phIdx=PHASES.indexOf(form.stage)>=0?PHASES.indexOf(form.stage):0;
  function openPlan(row){var pd=(typeof row.plan_data==='object'&&row.plan_data)||{};try{if(typeof row.plan_data==='string')pd=JSON.parse(row.plan_data);}catch(e){}setPlanId(row.id);setActivePlan(pd);var f={};for(var k in df)f[k]=df[k];for(var k2 in pd){if(k2 in f&&typeof pd[k2]==='string')f[k2]=pd[k2];}f.opportunity=row.opportunity||pd.opportunity_name||pd.codename||row.opp_title||'';f.agency=row.agency||pd.agency||'';f.pwin=pd.pwin?String(pd.pwin):f.pwin;f.incumbent=pd.incumbent&&typeof pd.incumbent==='object'?pd.incumbent.company||'':(typeof pd.incumbent==='string'?pd.incumbent:'');f.known_competitors=Array.isArray(pd.win_strategy&&pd.win_strategy.ghost_competitors)?pd.win_strategy.ghost_competitors.join(', '):pd.known_competitors||'';f.notes=pd.scope_summary||pd.notes||'';if(!f.codename&&row.opp_title)f.codename=row.opp_title;var stg2=pd.stage||pd.capture_stage||'Go/No-Go';setForm(f);setActivePhase(PHASES.indexOf(stg2)>=0?PHASES.indexOf(stg2):0);setView('card');}
  function savePlan(silent){setSaving(true);var cl={};for(var k in form){var v=form[k];if(typeof v==='string'&&v.match(/^\$[0-9,]+$/))cl[k]=v.replace(/[$,]/g,'');else cl[k]=v;}var pd2={};for(var k3 in(activePlan||{}))pd2[k3]=(activePlan||{})[k3];for(var k4 in cl)pd2[k4]=cl[k4];pd2.stage=PHASES[activePhase]||form.stage;var pay={action:'save',plan:pd2,opportunity:form.opportunity,agency:form.agency,contract_value:strip$(form.total_contract_value),opp_title:form.codename||form.opportunity};if(planId)pay.plan_id=planId;api.post('gda-capture-plan',pay).then(function(res){if(res.id&&!planId)setPlanId(res.id);if(!silent)st2('Saved');loadP();setSaving(false);}).catch(function(){if(!silent)st2('Save failed');setSaving(false);});}
  function analyzePhase(){setAnalyzing(true);var pd3={};for(var k5 in(activePlan||{}))pd3[k5]=(activePlan||{})[k5];for(var k6 in form)pd3[k6]=form[k6];api.post('gda-capture-plan',{action:'analyze_phase',phase:PHASES[activePhase],plan_id:planId,plan_data:pd3}).then(function(d){if(d.analysis){setActivePlan(function(p){var oa=p&&p.ooda_analyses?{}:{};if(p&&p.ooda_analyses)for(var k7 in p.ooda_analyses)oa[k7]=p.ooda_analyses[k7];oa[PHASES[activePhase]]=d.analysis;var np={};for(var k8 in(p||{}))np[k8]=(p||{})[k8];np.ooda_analyses=oa;return np;});st2('Analysis complete');}setAnalyzing(false);}).catch(function(){st2('Analysis failed');setAnalyzing(false);});}
  function advPh(){if(activePhase<8){savePlan(true);setActivePhase(activePhase+1);sf('stage',PHASES[activePhase+1]);}}
  function delPlan(id,e){e.stopPropagation();if(!window.confirm('Delete?'))return;api.post('gda-capture-plan',{action:'delete',plan_id:id}).then(function(){setPlans(function(p){return p.filter(function(r){return r.id!==id;});});}).catch(function(){});}
  var h=React.createElement;
  var FP={sf:sf,setEditingField:setEditingField,showInfo:showInfo,setShowInfo:setShowInfo,IT:IT};


  function OodaSec(sp){return h('div',{style:{background:sp.color+'08',border:'1px solid '+sp.color+'30',borderRadius:8,padding:14,marginBottom:10}},h('div',{style:{fontSize:12,fontWeight:700,color:sp.color,marginBottom:8,textTransform:'uppercase',letterSpacing:0.5}},sp.title),sp.children);}
  function OodaPanel(props){var phase=props.phase;var ans=(activePlan&&activePlan.ooda_analyses)||{};var a=ans[phase];if(!a)return h('div',{style:{background:'#F8FAFC',border:'1px solid #E2E8F0',borderRadius:8,padding:20,textAlign:'center',marginBottom:16}},h('div',{style:{fontSize:13,color:'#6B7280',marginBottom:10}},'No OODA analysis for '+phase+' phase yet'),h('button',{onClick:analyzePhase,disabled:analyzing,style:{padding:'10px 24px',background:PC[phase]||NAVY,color:'#fff',border:'none',borderRadius:6,fontSize:13,fontWeight:700,cursor:'pointer'}},analyzing?'Analyzing...':'Analyze '+phase+' Phase'));return h('div',{style:{marginBottom:16}},h('div',{style:{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:10}},h('div',{style:{fontSize:14,fontWeight:700,color:NAVY}},'OODA Analysis'),h('div',{style:{display:'flex',gap:8,alignItems:'center'}},a.confidence&&h('span',{style:{fontSize:11,fontWeight:600,color:a.confidence>=70?'#16A34A':a.confidence>=40?'#D97706':'#DC2626',padding:'2px 8px',background:a.confidence>=70?'#ECFDF5':a.confidence>=40?'#FFFBEB':'#FEF2F2',borderRadius:10}},a.confidence+'% confidence'),h('button',{onClick:analyzePhase,disabled:analyzing,style:{padding:'4px 12px',background:PC[phase]||NAVY,color:'#fff',border:'none',borderRadius:4,fontSize:11,fontWeight:600,cursor:'pointer'}},analyzing?'...':'Re-Analyze'))),h(OodaSec,{title:(a.observe&&a.observe.title)||'Observe',color:'#0891B2'},a.observe&&a.observe.findings&&a.observe.findings.map(function(f,i){return h('div',{key:i,style:{fontSize:12,color:'#374151',marginBottom:3}},'\u2022 '+f);}),a.observe&&a.observe.data_gaps&&a.observe.data_gaps.length>0&&h('div',{style:{marginTop:6,fontSize:11,color:'#DC2626',fontWeight:600}},'Data Gaps: '+a.observe.data_gaps.join(', '))),h(OodaSec,{title:(a.orient&&a.orient.title)||'Orient',color:'#7C3AED'},h('div',{style:{fontSize:12,color:'#374151',lineHeight:1.6}},a.orient&&a.orient.assessment),a.orient&&a.orient.implications&&a.orient.implications.map(function(im,i){return h('div',{key:i,style:{fontSize:12,color:'#374151',marginTop:3}},'\u2022 '+im);})),h(OodaSec,{title:(a.decide&&a.decide.title)||'Decide',color:'#D97706'},h('div',{style:{fontSize:12,fontWeight:700,color:'#92400E',marginBottom:6}},a.decide&&a.decide.recommendation),a.decide&&a.decide.actions&&a.decide.actions.map(function(ac,i){return h('div',{key:i,style:{display:'flex',gap:8,fontSize:12,color:'#374151',marginBottom:3}},h('span',{style:{fontWeight:600,color:ac.priority==='HIGH'?'#DC2626':ac.priority==='MEDIUM'?'#D97706':'#6B7280'}},'['+ac.priority+']'),h('span',null,ac.action));})),h(OodaSec,{title:(a.act&&a.act.title)||'Act',color:'#16A34A'},a.act&&a.act.immediate&&a.act.immediate.length>0&&h('div',null,h('div',{style:{fontSize:10,fontWeight:700,color:'#16A34A',marginBottom:3}},'IMMEDIATE'),a.act.immediate.map(function(x,i){return h('div',{key:i,style:{fontSize:12,color:'#374151',marginBottom:2}},'\u2022 '+x);})),a.act&&a.act.short_term&&a.act.short_term.length>0&&h('div',{style:{marginTop:6}},h('div',{style:{fontSize:10,fontWeight:700,color:'#0891B2',marginBottom:3}},'SHORT-TERM'),a.act.short_term.map(function(x,i){return h('div',{key:i,style:{fontSize:12,color:'#374151',marginBottom:2}},'\u2022 '+x);}))),a.gate_criteria_met&&a.gate_criteria_met.length>0&&h('div',{style:{background:'#ECFDF5',border:'1px solid #86EFAC',borderRadius:6,padding:8,marginTop:8}},h('div',{style:{fontSize:10,fontWeight:700,color:'#16A34A',marginBottom:4}},'GATE CRITERIA MET'),a.gate_criteria_met.map(function(c,i){return h('div',{key:i,style:{fontSize:11,color:'#374151'}},'\u2713 '+c);})),a.gate_criteria_not_met&&a.gate_criteria_not_met.length>0&&h('div',{style:{background:'#FEF2F2',border:'1px solid #FCA5A5',borderRadius:6,padding:8,marginTop:6}},h('div',{style:{fontSize:10,fontWeight:700,color:'#DC2626',marginBottom:4}},'STILL NEEDED'),a.gate_criteria_not_met.map(function(c,i){return h('div',{key:i,style:{fontSize:11,color:'#374151'}},'\u2717 '+c);})));}
  function PhaseContent(props){var idx=props.idx;var phase=PHASES[idx];function Sec(sp){return h('div',{style:{background:WHITE,border:'1px solid '+BORDER,borderRadius:8,padding:16,marginBottom:12}},h('div',{style:{fontSize:13,fontWeight:700,color:NAVY,marginBottom:12,borderBottom:'1px solid #E8ECF1',paddingBottom:8}},sp.title),sp.children);}function g4(ch){return h('div',{style:{display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:8}},ch);}function g2(ch){return h('div',{style:{display:'grid',gridTemplateColumns:'1fr 1fr',gap:8}},ch);}function sb(lb,cl,ky){return h('div',{style:{background:cl+'10',border:'1px solid '+cl+'40',borderRadius:6,padding:10}},h('div',{style:{fontSize:11,color:cl,fontWeight:700,marginBottom:4}},lb),h('textarea',{style:Object.assign({},S.textarea,{height:80,resize:'vertical',fontSize:12,background:'transparent',border:'none'}),value:form[ky]||'',onChange:function(e){sf(ky,e.target.value);}}));}return h('div',null,h(OodaPanel,{phase:phase}),idx>=0&&h(Sec,{title:'Opportunity Details'},g4([h(CpField,Object.assign({key:'c',label:'Codename',val:form.codename,k:'codename'},FP)),h(CpField,Object.assign({key:'o',label:'Opportunity Name',val:form.opportunity,k:'opportunity'},FP)),h(CpField,Object.assign({key:'a',label:'Agency',val:form.agency,k:'agency',list:AGENCIES},FP)),h(CpField,Object.assign({key:'p',label:'Priority',val:form.priority,k:'priority',list:PRIS},FP))]),h('div',{style:{display:'grid',gridTemplateColumns:'repeat(5,1fr)',gap:8}},[h(CpField,Object.assign({key:'tv',label:'Total Contract Value',val:form.total_contract_value,k:'total_contract_value',info:true},FP)),h(CpField,Object.assign({key:'ar',label:'Allocated Revenue',val:form.allocated_revenue_value,k:'allocated_revenue_value',info:true},FP)),h(CpField,Object.assign({key:'gam',label:'Allocation $ (M)',val:form.gda_allocation_m,k:'gda_allocation_m',info:true},FP)),h(CpField,Object.assign({key:'cr',label:'Contract Revenue',val:form.contract_revenue_value,k:'contract_revenue_value',info:true},FP)),h(CpField,Object.assign({key:'rf',label:'RFP Date',val:form.rfp_date,k:'rfp_date'},FP))]),g4([h(CpField,Object.assign({key:'pw',label:'PWin %',val:form.pwin,k:'pwin',info:true},FP)),h(CpField,Object.assign({key:'ct',label:'Contract Type',val:form.contract_type,k:'contract_type',list:CTYPES},FP)),h(CpField,Object.assign({key:'sa',label:'Set-Aside',val:form.set_aside,k:'set_aside',info:true},FP)),h(CpField,Object.assign({key:'na',label:'NAICS',val:form.naics,k:'naics',info:true},FP))]),g4([h(CpField,Object.assign({key:'do',label:'Division Owners',val:form.division_owners,k:'division_owners',list:DIVS},FP)),h(CpField,Object.assign({key:'pc',label:'Prime Company',val:form.prime_company,k:'prime_company'},FP)),h(CpField,Object.assign({key:'iv',label:'IDIQ Vehicle',val:form.idiq_vehicle,k:'idiq_vehicle'},FP)),h(CpField,Object.assign({key:'pp',label:'Period of Performance',val:form.period_of_performance,k:'period_of_performance',info:true},FP))]),g4([h(CpField,Object.assign({key:'sn',label:'Solicitation #',val:form.solicitation_number,k:'solicitation_number'},FP)),h(CpField,Object.assign({key:'inc',label:'Incumbent',val:form.incumbent,k:'incumbent'},FP)),h(CpField,Object.assign({key:'sp',label:'Shaping Progress',val:form.total_shaping_progress,k:'total_shaping_progress'},FP)),h(CpField,Object.assign({key:'st',label:'Stage',val:PHASES[activePhase],k:'stage'},FP))])),idx>=1&&h(Sec,{title:'Scope & Notes'},h(CpField,Object.assign({label:'Scope Summary / Notes',val:form.notes,k:'notes',area:true},FP))),idx>=2&&h(Sec,{title:'SWOT Analysis'},g2([sb('STRENGTHS','#16A34A','eis_strengths'),sb('WEAKNESSES','#DC2626','eis_weaknesses')]),h('div',{style:{marginTop:8}},g2([sb('OPPORTUNITIES','#2563EB','swot_opportunities'),sb('THREATS','#D97706','swot_threats')])),h('div',{style:{marginTop:8}},h(CpField,Object.assign({label:'Known Competitors',val:form.known_competitors,k:'known_competitors'},FP)))),idx>=3&&activePlan&&activePlan.win_strategy&&h(Sec,{title:'Win Strategy'},h('div',{style:{fontSize:12,color:'#374151',lineHeight:1.6}},activePlan.win_strategy.primary_theme),activePlan.win_strategy.discriminators&&h('div',{style:{marginTop:6,fontSize:11,color:'#6B7280'}},h('strong',null,'Discriminators: '),activePlan.win_strategy.discriminators.join(' | '))),idx>=5&&activePlan&&activePlan.proposal_status&&h(Sec,{title:'Proposal Status'},h('div',{style:{fontSize:12,color:'#374151'}},'Phase: '+activePlan.proposal_status.current_phase),h('div',{style:{fontSize:12,color:'#374151',marginTop:4}},'Compliance: '+activePlan.proposal_status.compliance_matrix),activePlan.proposal_status.critical_fixes_before_submit&&activePlan.proposal_status.critical_fixes_before_submit.map(function(f,i){return h('div',{key:i,style:{display:'flex',gap:6,marginTop:4,fontSize:12}},h('span',{style:{color:f.status==='FIXED'?'#16A34A':'#DC2626',fontWeight:600}},f.status==='FIXED'?'\u2713':'\u2717'),h('span',{style:{color:'#374151'}},'['+f.severity+'] '+f.item));})));}
  if (view === 'list') {
    var pbs = {};
    var allSt = PHASES.concat(['Loss','Pass']);
    allSt.forEach(function(s) { pbs[s] = []; });
    plans.forEach(function(row) {
      var pd = (typeof row.plan_data === 'object' && row.plan_data) || {};
      try { if (typeof row.plan_data === 'string') pd = JSON.parse(row.plan_data); } catch(e) {}
      var st3 = pd.stage || (row.no_bid ? 'Pass' : 'Go/No-Go');
      if (!pbs[st3]) pbs[st3] = [];
      pbs[st3].push({id:row.id, opportunity:row.opportunity, agency:row.agency, contract_value:row.contract_value, opp_title:row.opp_title, plan_data:row.plan_data, pd:pd});
    });
    return h('div', {style:{}},
      h('div', {style:{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:16}},
        h('div', null,
          h('h2', {style:{fontSize:22,fontWeight:700,color:NAVY,margin:0}}, 'Capture Pipeline'),
          h('div', {style:{fontSize:12,color:'#6B7280'}}, 'Shipley Lifecycle Capture Management')
        ),
        h('button', {onClick:function(){setForm(df);setActivePlan(null);setPlanId(null);setActivePhase(0);setView('card');},style:{padding:'8px 20px',background:NAVY,color:'#fff',border:'none',borderRadius:6,fontSize:13,fontWeight:600,cursor:'pointer'}}, '+ New Opportunity')
      ),
      loading
        ? h('div', {style:{textAlign:'center',padding:40,color:'#6B7280'}}, 'Loading...')
        : h('div', {style:{display:'flex',flexDirection:'column',gap:6}},
            allSt.map(function(stg) {
              var rows = pbs[stg] || [];
              var sc2 = PC[stg] || '#6B7280';
              var isO = openStages[stg];
              return h('div', {key:stg, style:{background:WHITE,borderRadius:10,border:'1px solid '+BORDER,overflow:'hidden'}},
                h('div', {onClick:function(){togS(stg);}, style:{padding:'12px 18px',cursor:'pointer',display:'flex',justifyContent:'space-between',alignItems:'center',borderBottom:isO?'1px solid '+BORDER:'none'}},
                  h('div', {style:{display:'flex',gap:10,alignItems:'center'}},
                    h('span', {style:{color:'#6B7280',fontSize:12}}, isO ? '\u25BC' : '\u25B6'),
                    h('span', {style:{fontWeight:600,fontSize:14,color:NAVY}}, stg)
                  ),
                  h('div', {style:{display:'flex',gap:12,alignItems:'center'}},
                    h('span', {style:{background:sc2,color:'#fff',borderRadius:12,padding:'2px 10px',fontSize:11,fontWeight:600,minWidth:28,textAlign:'center',display:'inline-block'}}, rows.length),
                    h('span', {style:{fontSize:13,fontWeight:700,color:NAVY,minWidth:120,textAlign:'right'}}, formatDollar(rows.reduce(function(s,r){return s + (parseFloat(String((r.pd&&r.pd.total_contract_value)||r.contract_value||'0').replace(/[$,]/g,''))||0);},0)))
                  )
                ),
                isO && h('div', {style:{padding:rows.length ? '8px 16px 16px' : '8px 16px'}},
                  rows.length === 0
                    ? h('div', {style:{textAlign:'center',padding:'12px 0',color:'#9CA3AF',fontStyle:'italic',fontSize:12}}, 'No opportunities in this stage')
                    : rows.map(function(row2, i2) {
                        var pd4 = row2.pd;
                        return h('div', {key:row2.id||i2, onClick:function(){openPlan(row2);}, style:{display:'flex',alignItems:'center',gap:12,padding:'10px 12px',cursor:'pointer',borderRadius:6,marginBottom:4,border:'1px solid #F3F4F6',borderLeft:'3px solid '+sc2,background:'#FAFBFC'}},
                          h('div', {style:{flex:2,minWidth:0}},
                            h('div', {style:{fontSize:13,fontWeight:700,color:NAVY,overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}, pd4.codename || row2.opportunity || row2.opp_title || 'Untitled'),
                            h('div', {style:{fontSize:11,color:'#6B7280'}}, pd4.opportunity_name || row2.opp_title || '')
                          ),
                          h('div', {style:{flex:1,fontSize:12,color:'#6B7280'}}, pd4.division_owners || ''),
                          h('div', {style:{fontSize:13,fontWeight:700,color:NAVY,minWidth:80,textAlign:'right'}}, fmt$(pd4.total_contract_value || row2.contract_value)),
                          h('div', {style:{fontSize:12,color:Number(pd4.pwin)>=50?'#16A34A':Number(pd4.pwin)>0?'#D97706':'#9CA3AF',fontWeight:600,minWidth:50,textAlign:'right'}}, pd4.pwin ? pd4.pwin+'%' : '\u2014'),
                          h('div', {style:{fontSize:11,fontWeight:700,color:Number(pd4.gda_score)>=60?'#16A34A':Number(pd4.gda_score)>=40?'#D97706':'#9CA3AF',minWidth:40,textAlign:'right',padding:'2px 6px',background:Number(pd4.gda_score)>=60?'#ECFDF5':Number(pd4.gda_score)>=40?'#FFFBEB':'#F3F4F6',borderRadius:4}}, pd4.gda_score ? pd4.gda_score : '\u2014'),
                          h('button', {onClick:function(e){delPlan(row2.id,e);}, style:{padding:'3px 8px',background:'#FEF2F2',border:'1px solid #FCA5A5',borderRadius:4,color:'#DC2626',fontSize:10,fontWeight:600,cursor:'pointer'}}, '\u2715')
                        );
                      })
                )
              );
            })
          ),
      toast && h('div', {style:{position:'fixed',bottom:20,right:20,background:'#1B2A4A',color:'#fff',padding:'10px 20px',borderRadius:8,fontSize:13,zIndex:9999}}, toast)
    );
  }
  return h('div', {style:{}},
    h('div', {style:{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:12}},
      h('div', {style:{display:'flex',alignItems:'center',gap:10}},
        h('button', {onClick:function(){savePlan(true);setView('list');setActivePlan(null);setPlanId(null);}, style:{padding:'4px 12px',background:'#F3F4F6',border:'1px solid #D1D5DB',borderRadius:6,fontSize:12,cursor:'pointer'}}, '\u2190 Pipeline'),
        h('h2', {style:{fontSize:20,fontWeight:700,color:NAVY,margin:0}}, form.codename || form.opportunity || 'New Opportunity')
      ),
      h('div', {style:{display:'flex',gap:8}},
        h('button', {onClick:function(){savePlan(false);}, disabled:saving, style:{padding:'8px 16px',background:NAVY,color:'#fff',border:'none',borderRadius:6,fontSize:12,fontWeight:600,cursor:'pointer'}}, saving ? 'Saving...' : (planId ? 'Save' : 'Create')),
        activePhase < 8 && h('button', {onClick:advPh, style:{padding:'8px 16px',background:PC[PHASES[activePhase+1]]||'#16A34A',color:'#fff',border:'none',borderRadius:6,fontSize:12,fontWeight:600,cursor:'pointer'}}, 'Advance to ' + PHASES[activePhase+1])
      )
    ),
    h('div', {style:{display:'flex',gap:2,marginBottom:16,overflowX:'auto'}},
      PHASES.map(function(p, i) {
        return h('button', {key:p, onClick:function(){if(i<=phIdx||i<=activePhase+1){savePlan(true);setActivePhase(i);}}, style:{flex:1,padding:'8px 4px',background:i===activePhase?PC[p]:i<=phIdx?PC[p]+'20':'#F3F4F6',color:i===activePhase?'#fff':i<=phIdx?PC[p]:'#9CA3AF',border:'none',borderBottom:i===activePhase?'3px solid '+PC[p]:'3px solid transparent',fontSize:10,fontWeight:700,cursor:(i<=phIdx||i<=activePhase+1)?'pointer':'default',opacity:(i>phIdx&&i>activePhase+1)?0.4:1,whiteSpace:'nowrap',textTransform:'uppercase',letterSpacing:0.3}}, p);
      })
    ),
    h('div', {style:{fontSize:11,color:'#6B7280',marginBottom:12}}, PD2[PHASES[activePhase]]),
    h(PhaseContent, {idx:activePhase}),
    toast && h('div', {style:{position:'fixed',bottom:20,right:20,background:'#1B2A4A',color:'#fff',padding:'10px 20px',borderRadius:8,fontSize:13,zIndex:9999}}, toast)
  );
}
class ErrorBoundary extends React.Component {
  constructor(props) { super(props); this.state = { err: null }; }
  static getDerivedStateFromError(e) { return { err: e }; }
  componentDidCatch(e, info) { console.error("GDA ErrorBoundary:", e, info); }
  render() {
    if (this.state.err) return (
      <div style={{padding:40,fontFamily:"monospace",background:"#1a2744",color:"#ff6b35",minHeight:"100vh",display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center"}}>
        <div style={{fontSize:18,fontWeight:700,marginBottom:12}}>GDA COMMAND — RENDER ERROR</div>
        <div style={{fontSize:12,color:"#ccc",maxWidth:600,textAlign:"center",marginBottom:16}}>{this.state.err.message}</div>
        <button onClick={()=>this.setState({err:null})} style={{padding:"8px 20px",background:"#ff6b35",color:"white",border:"none",borderRadius:6,cursor:"pointer",fontWeight:600}}>Reload</button>
      </div>
    );
    return this.props.children;
  }
}

function PromptArchitect() {
  const [thoughts, setThoughts] = useState(['']);
  const [mode, setMode] = useState('workflow');
  const [context, setContext] = useState('');
  const [output, setOutput] = useState('');
  const [loading, setLoading] = useState(false);
  const [sessionId] = useState('pa-' + Date.now());
  const [historyOpen, setHistoryOpen] = useState(false);
  const [history, setHistory] = useState([]);
  const thoughtRefs = useRef([]);

  const addThought = (afterIdx) => {
    setThoughts(p => { const n = [...p]; n.splice((afterIdx != null ? afterIdx : p.length - 1) + 1, 0, ''); return n; });
    setTimeout(() => { const r = thoughtRefs.current[(afterIdx != null ? afterIdx : thoughts.length - 1) + 1]; if (r) r.focus(); }, 50);
  };
  const removeThought = (idx) => { if (thoughts.length <= 1) return; setThoughts(p => p.filter((_, i) => i !== idx)); };
  const updateThought = (idx, val) => { setThoughts(p => { const n = [...p]; n[idx] = val; return n; }); };
  const moveThought = (idx, dir) => {
    const ni = idx + dir;
    if (ni < 0 || ni >= thoughts.length) return;
    setThoughts(p => { const n = [...p]; const tmp = n[idx]; n[idx] = n[ni]; n[ni] = tmp; return n; });
  };

  const generate = async () => {
    const goal = thoughts.filter(t => t.trim()).join('\n');
    if (!goal || loading) return;
    setLoading(true);
    try {
      const d = await api.post('gda-prompt-architect', { goal, mode, context, session_id: sessionId });
      const result = d.response || d.output || JSON.stringify(d);
      setOutput(result);
      setHistory(p => [...p, { thoughts: [...thoughts], mode, context, output: result, ts: new Date().toLocaleTimeString() }]);
    } catch(e) { setOutput('Error: ' + (e.message || 'Generation failed')); }
    setLoading(false);
  };

  const copyOutput = () => { navigator.clipboard.writeText(output).catch(() => {}); };
  const refineOutput = () => { setContext(output); setOutput(''); };

  const MODES = [
    {id:'workflow', l:'Workflow Prompt'},
    {id:'system', l:'System Prompt'},
    {id:'analysis', l:'Analysis Prompt'},
    {id:'extraction', l:'Data Extraction'},
    {id:'scoring', l:'Scoring Rubric'}
  ];

  return React.createElement('div', {style:{}},
    React.createElement('div', {style:{marginBottom:20}},
      React.createElement('h2', {style:{fontSize:20,fontWeight:700,color:NAVY,margin:'0 0 4px'}}, 'Prompt Architect'),
      React.createElement('div', {style:{fontSize:12,color:'#6B7280'}}, 'Transform ideas into high-performance LLM prompts')
    ),

    // Mode selector
    React.createElement('div', {style:{marginBottom:16}},
      React.createElement('div', {style:{fontSize:12,fontWeight:600,color:NAVY,marginBottom:6}}, 'Mode'),
      React.createElement('div', {style:{display:'flex',gap:6,flexWrap:'wrap'}},
        MODES.map(md => React.createElement('button', {key:md.id, onClick:()=>setMode(md.id),
          style:{padding:'7px 14px',fontSize:12,fontWeight:mode===md.id?700:400,color:mode===md.id?'#fff':NAVY,background:mode===md.id?ACCENT:'#fff',border:'1px solid '+(mode===md.id?ACCENT:BORDER),borderRadius:6,cursor:'pointer'}
        }, md.l))
      )
    ),

    // Context
    React.createElement('div', {style:{marginBottom:16}},
      React.createElement('div', {style:{fontSize:12,fontWeight:600,color:NAVY,marginBottom:6}}, 'Context (optional)'),
      React.createElement('textarea', {value:context, onChange:e=>setContext(e.target.value),
        placeholder:'Paste background information, previous output to refine, or relevant context...',
        style:{width:'100%',padding:'10px 14px',border:'1px solid '+BORDER,borderRadius:8,fontSize:12,minHeight:60,resize:'vertical',fontFamily:'Inter,system-ui,sans-serif',color:NAVY,background:'rgba(26,39,68,0.03)'}
      })
    ),

    // Thoughts
    React.createElement('div', {style:{marginBottom:16}},
      React.createElement('div', {style:{fontSize:12,fontWeight:600,color:NAVY,marginBottom:6}}, 'Thoughts'),
      thoughts.map((t, idx) => React.createElement('div', {key:idx, style:{display:'flex',gap:6,alignItems:'center',marginBottom:6}},
        React.createElement('span', {style:{fontSize:11,color:'#9CA3AF',fontWeight:600,minWidth:20}}, (idx+1)+'.'),
        React.createElement('input', {
          ref: el => { thoughtRefs.current[idx] = el; },
          value:t, onChange:e=>updateThought(idx, e.target.value),
          onKeyDown: e => { if(e.key==='Enter'){e.preventDefault();addThought(idx);} },
          placeholder:'Enter a thought or requirement...',
          style:{flex:1,padding:'8px 12px',border:'1px solid '+BORDER,borderRadius:6,fontSize:12,color:NAVY,background:'#fff'}
        }),
        React.createElement('button', {onClick:()=>moveThought(idx,-1),disabled:idx===0,
          style:{padding:'4px 6px',border:'1px solid '+BORDER,borderRadius:4,cursor:idx>0?'pointer':'default',background:'#fff',color:idx>0?NAVY:'#D1D5DB',fontSize:11}
        }, String.fromCharCode(8593)),
        React.createElement('button', {onClick:()=>moveThought(idx,1),disabled:idx===thoughts.length-1,
          style:{padding:'4px 6px',border:'1px solid '+BORDER,borderRadius:4,cursor:idx<thoughts.length-1?'pointer':'default',background:'#fff',color:idx<thoughts.length-1?NAVY:'#D1D5DB',fontSize:11}
        }, String.fromCharCode(8595)),
        React.createElement('button', {onClick:()=>removeThought(idx),disabled:thoughts.length<=1,
          style:{padding:'4px 8px',border:'none',borderRadius:4,cursor:thoughts.length>1?'pointer':'default',background:'transparent',color:thoughts.length>1?'#DC2626':'#D1D5DB',fontSize:14,fontWeight:700}
        }, String.fromCharCode(215))
      )),
      React.createElement('button', {onClick:()=>addThought(),
        style:{padding:'8px 16px',border:'2px dashed '+ACCENT,borderRadius:8,background:'transparent',color:ACCENT,fontSize:12,fontWeight:700,cursor:'pointer',marginTop:4,width:'100%'}
      }, '+ Add Thought')
    ),

    // Generate + Reset buttons
    React.createElement('div', {style:{display:'flex',gap:10,marginBottom:20}},
      React.createElement('button', {onClick:generate, disabled:loading||!thoughts.some(t=>t.trim()),
        style:{flex:1,padding:'12px 20px',background:ACCENT,color:'#fff',border:'none',borderRadius:8,fontSize:14,fontWeight:700,cursor:'pointer',opacity:loading?0.6:1}
      }, loading ? 'Generating...' : 'Generate Prompt'),
      React.createElement('button', {onClick:function(){setThoughts(['']);setContext('');setMode('workflow');setOutput('');},
        style:{padding:'12px 20px',background:'transparent',color:NAVY,border:'1px solid '+BORDER,borderRadius:8,fontSize:14,fontWeight:600,cursor:'pointer'}
      }, 'Reset')
    ),

    // Output
    output && React.createElement('div', {style:{background:'#fff',border:'1px solid '+BORDER,borderRadius:12,padding:16,marginBottom:20}},
      React.createElement('div', {style:{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:10}},
        React.createElement('div', {style:{fontSize:13,fontWeight:700,color:NAVY}}, 'Generated Prompt'),
        React.createElement('div', {style:{display:'flex',gap:6}},
          React.createElement('button', {onClick:copyOutput,
            style:{padding:'6px 14px',border:'1px solid '+BORDER,borderRadius:6,background:'#fff',color:NAVY,fontSize:11,fontWeight:600,cursor:'pointer'}
          }, 'Copy'),
          React.createElement('button', {onClick:refineOutput,
            style:{padding:'6px 14px',border:'1px solid '+ACCENT,borderRadius:6,background:'transparent',color:ACCENT,fontSize:11,fontWeight:600,cursor:'pointer'}
          }, 'Refine')
        )
      ),
      React.createElement('div', {style:{background:'rgba(26,39,68,0.03)',borderRadius:8,padding:14,fontSize:12,lineHeight:1.7,whiteSpace:'pre-wrap',color:NAVY,maxHeight:400,overflowY:'auto',fontFamily:'monospace'}}, output)
    ),

    // History (collapsed by default per BL-046)
    history.length > 0 && React.createElement('div', {style:{border:'1px solid '+BORDER,borderRadius:10,overflow:'hidden'}},
      React.createElement('div', {onClick:()=>setHistoryOpen(!historyOpen),
        style:{padding:'10px 16px',cursor:'pointer',display:'flex',justifyContent:'space-between',alignItems:'center',background:historyOpen?'rgba(26,39,68,0.05)':'#fff'}
      },
        React.createElement('span', {style:{fontSize:13,fontWeight:600,color:NAVY}}, 'History ('+history.length+')'),
        React.createElement('span', {style:{fontSize:11,color:'#9CA3AF',transform:historyOpen?'rotate(90deg)':'rotate(0deg)',transition:'transform 0.2s'}}, String.fromCharCode(9654))
      ),
      historyOpen && React.createElement('div', {style:{padding:12,borderTop:'1px solid '+BORDER}},
        history.slice().reverse().map((h, i) => React.createElement('div', {key:i, style:{padding:'8px 0',borderBottom:i<history.length-1?'1px solid #F3F4F6':'none'}},
          React.createElement('div', {style:{display:'flex',justifyContent:'space-between',fontSize:11,color:'#9CA3AF',marginBottom:4}},
            React.createElement('span', null, h.mode + ' | ' + h.thoughts.filter(t=>t.trim()).length + ' thoughts'),
            React.createElement('span', null, h.ts)
          ),
          React.createElement('div', {style:{fontSize:12,color:NAVY,whiteSpace:'pre-wrap',maxHeight:80,overflow:'hidden',textOverflow:'ellipsis'}}, h.output.substring(0, 200) + (h.output.length > 200 ? '...' : ''))
        ))
      )
    )
  );
}

// -- MEETING NOTES (S-106) --
function MeetingNotes() {
  const [transcript, setTranscript] = useState('');
  const [title, setTitle] = useState('');
  const [attendees, setAttendees] = useState('');
  const [meetingType, setMeetingType] = useState('general');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null);
  const [history, setHistory] = useState([]);
  const [historyOpen, setHistoryOpen] = useState(false);

  const analyze = async () => {
    if (!transcript.trim()) return;
    setLoading(true); setResult(null);
    try {
      // Send to meeting-notes backend for storage
      await api.post('gda-meeting-notes', {
        transcript: transcript,
        meeting_title: title || 'Meeting Notes',
        attendees: attendees,
        meeting_type: meetingType
      });
      // Use AI agent to extract structured analysis
      const analysis = await api.post('gda-chat-v2', {
        message: 'Analyze this meeting transcript. Extract: 1) Key Decisions Made, 2) Action Items (with owner and deadline if mentioned), 3) Risks or Concerns Raised, 4) Follow-up Items, 5) Brief Summary (3 sentences). Return as structured sections with headers.\n\nMeeting: ' + (title || 'Untitled') + '\nAttendees: ' + (attendees || 'Not specified') + '\nType: ' + meetingType + '\n\nTRANSCRIPT:\n' + transcript,
        mode: 'analysis',
        session_id: 'mtg_' + Date.now()
      });
      var text = analysis.response || analysis.output || JSON.stringify(analysis);
      setResult(text);
      setHistory(p => [{title: title || 'Untitled', date: new Date().toLocaleString(), preview: text.substring(0, 100), full: text}, ...p]);
      try { fetch('/api/gda-action-history', {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'save',tab:'meeting-notes',action_type:'analyze',title:title||'Meeting Notes',input:{attendees,meetingType},output:{analysis:text.substring(0,2000)}})}); } catch(e){}
    } catch(e) { setResult('Error: ' + (e.message || 'Analysis failed. Try again.')); }
    setLoading(false);
  };

  const TYPES = [
    {id: 'general', label: 'General'},
    {id: 'bd_review', label: 'BD Review'},
    {id: 'capture', label: 'Capture Meeting'},
    {id: 'proposal', label: 'Proposal Review'},
    {id: 'leadership', label: 'Leadership Standup'},
    {id: 'client', label: 'Client Meeting'},
    {id: 'technical', label: 'Technical Review'}
  ];

  const reset = () => { setTranscript(''); setTitle(''); setAttendees(''); setMeetingType('general'); setResult(null); };

  return React.createElement('div', {style: {}},
    React.createElement(PageHeader, {title: 'Meeting Notes', sub: 'Paste meeting transcripts or notes for AI analysis and action item extraction'}),

    // Input form
    React.createElement('div', {style: {background: '#fff', border: '1px solid #E8ECF1', borderRadius: 10, padding: 20, marginBottom: 20}},
      React.createElement('div', {style: {display: 'grid', gridTemplateColumns: '2fr 1fr', gap: 12, marginBottom: 12}},
        React.createElement('div', null,
          React.createElement('div', {style: {fontSize: 12, fontWeight: 600, color: '#1B2A4A', marginBottom: 4}}, 'Meeting Title'),
          React.createElement('input', {value: title, onChange: function(e){setTitle(e.target.value);}, placeholder: 'e.g. Weekly BD Standup, SHIELD Capture Review', style: {width: '100%', padding: '8px 12px', border: '1px solid #D1D5DB', borderRadius: 6, fontSize: 12}})
        ),
        React.createElement('div', null,
          React.createElement('div', {style: {fontSize: 12, fontWeight: 600, color: '#1B2A4A', marginBottom: 4}}, 'Meeting Type'),
          React.createElement('select', {value: meetingType, onChange: function(e){setMeetingType(e.target.value);}, style: {width: '100%', padding: '8px 12px', border: '1px solid #D1D5DB', borderRadius: 6, fontSize: 12}},
            TYPES.map(function(t){return React.createElement('option', {key: t.id, value: t.id}, t.label);})
          )
        )
      ),
      React.createElement('div', {style: {marginBottom: 12}},
        React.createElement('div', {style: {fontSize: 12, fontWeight: 600, color: '#1B2A4A', marginBottom: 4}}, 'Attendees'),
        React.createElement('input', {value: attendees, onChange: function(e){setAttendees(e.target.value);}, placeholder: 'e.g. John, Mary, Sarah, COL Smith', style: {width: '100%', padding: '8px 12px', border: '1px solid #D1D5DB', borderRadius: 6, fontSize: 12}})
      ),
      React.createElement('div', {style: {marginBottom: 16}},
        React.createElement('div', {style: {fontSize: 12, fontWeight: 600, color: '#1B2A4A', marginBottom: 4}}, 'Transcript / Notes'),
        React.createElement('textarea', {value: transcript, onChange: function(e){setTranscript(e.target.value);}, placeholder: 'Paste meeting transcript, notes, or key discussion points here...\n\nThe AI will extract:\n- Decisions made\n- Action items with owners\n- Risks and concerns\n- Follow-up items\n- Summary', style: {width: '100%', minHeight: 200, padding: '12px', border: '1px solid #D1D5DB', borderRadius: 8, fontSize: 12, lineHeight: 1.6, resize: 'vertical', fontFamily: 'Inter, system-ui, sans-serif'}})
      ),
      React.createElement('div', {style: {display: 'flex', gap: 10}},
        React.createElement('button', {onClick: analyze, disabled: loading || !transcript.trim(),
          style: {flex: 1, padding: '12px 20px', background: '#CC5500', color: '#fff', border: 'none', borderRadius: 8, fontSize: 14, fontWeight: 700, cursor: 'pointer', opacity: loading ? 0.6 : 1}
        }, loading ? 'Analyzing...' : 'Analyze Meeting'),
        React.createElement('button', {onClick: reset,
          style: {padding: '12px 20px', background: 'transparent', color: '#007BFF', border: '1px solid #007BFF', borderRadius: 8, fontSize: 14, fontWeight: 600, cursor: 'pointer'}
        }, 'Reset')
      )
    ),

    // Results
    result && React.createElement('div', {style: {background: '#fff', border: '1px solid #E8ECF1', borderRadius: 10, padding: 20, marginBottom: 20}},
      React.createElement('div', {style: {display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12}},
        React.createElement('div', {style: {fontSize: 14, fontWeight: 700, color: '#1B2A4A'}}, 'Analysis Results'),
        React.createElement('div', {style: {display: 'flex', gap: 6}},
          React.createElement('button', {onClick: function(){navigator.clipboard.writeText(result).catch(function(){});},
            style: {padding: '5px 12px', border: '1px solid #E8ECF1', borderRadius: 6, background: '#fff', color: '#1B2A4A', fontSize: 11, fontWeight: 600, cursor: 'pointer'}
          }, 'Copy'),
          React.createElement('button', {onClick: async function(){
            var lines = result.split('\n').filter(function(l){return l.trim().length>5 && !l.startsWith('#') && !l.startsWith('---');});
            var actionLines = [];
            var inActions = false;
            lines.forEach(function(l){if(/action item/i.test(l)){inActions=true;return;} if(inActions && /^[-*\d]/.test(l.trim())) actionLines.push(l.replace(/^[-*\d\.\s]+/,'').trim());});
            if(!actionLines.length){alert('No action items detected in output.');return;}
            var pushed=0;
            for(var i=0;i<Math.min(actionLines.length,10);i++){try{await api.post('gda-action-items',{action:'create',title:actionLines[i],status:'open',priority:'medium',source:'Meeting Notes'});pushed++;}catch(e){}}
            alert('Pushed '+pushed+' action items.');
          }, style: {padding: '5px 12px', border: '1px solid #28A745', borderRadius: 6, background: '#28A745', color: '#fff', fontSize: 11, fontWeight: 600, cursor: 'pointer'}
          }, 'Push Action Items')
        )
      ),
      React.createElement('div', {style: {background: 'rgba(26,39,68,0.03)', borderRadius: 8, padding: 16, fontSize: 12, lineHeight: 1.7, whiteSpace: 'pre-wrap', color: '#1B2A4A', maxHeight: 500, overflowY: 'auto'}}, result)
    ),

    // History
    history.length > 0 && React.createElement('div', {style: {border: '1px solid #E8ECF1', borderRadius: 10, overflow: 'hidden'}},
      React.createElement('div', {onClick: function(){setHistoryOpen(!historyOpen);},
        style: {padding: '10px 16px', cursor: 'pointer', display: 'flex', justifyContent: 'space-between', alignItems: 'center', background: historyOpen ? 'rgba(26,39,68,0.05)' : '#fff'}
      },
        React.createElement('span', {style: {fontSize: 13, fontWeight: 600, color: '#1B2A4A'}}, 'Session History (' + history.length + ')'),
        React.createElement('span', {style: {fontSize: 11, color: '#9CA3AF'}}, historyOpen ? '\u25BC' : '\u25B6')
      ),
      historyOpen && React.createElement('div', {style: {padding: 12, borderTop: '1px solid #E8ECF1'}},
        history.map(function(h, i) {
          return React.createElement('div', {key: i, style: {padding: '8px 0', borderBottom: i < history.length - 1 ? '1px solid #F3F4F6' : 'none', cursor: 'pointer'}, onClick: function(){setResult(h.full);}},
            React.createElement('div', {style: {display: 'flex', justifyContent: 'space-between', fontSize: 12}},
              React.createElement('span', {style: {fontWeight: 600, color: '#1B2A4A'}}, h.title),
              React.createElement('span', {style: {color: '#9CA3AF', fontSize: 11}}, h.date)
            ),
            React.createElement('div', {style: {fontSize: 11, color: '#6B7280', marginTop: 2}}, h.preview + '...')
          );
        })
      )
    )
  );
}

// -- HELP TAB (S-094) --
function HelpPage() {
  const [question, setQuestion] = useState('');
  const [history, setHistory] = useState([]);
  const [loading, setLoading] = useState(false);
  const chatEnd = useRef(null);
  useEffect(() => { if (chatEnd.current) chatEnd.current.scrollIntoView({behavior:'smooth'}); }, [history]);
  const ask = async () => {
    const q = question.trim(); if (!q || loading) return;
    setHistory(p => [...p, {role:'user', text:q}]); setQuestion(''); setLoading(true);
    try {
      const d = await api.post('gda-chat-v2', {message: 'You are the GDA Command Help Assistant. IMPORTANT: You are READ-ONLY. You can ONLY answer questions about how to use the GDA Command platform. You CANNOT make changes, deploy code, modify workflows, edit files, or execute any actions. If asked to change anything, respond: I can only help you understand the platform. For changes, use the main AI Agent or ask Claude in your session. You have deep knowledge of the GDA Command platform: 88 n8n workflows, 20+ Postgres tables, React frontend, GovTribe MCP, Pinecone RAG. The platform is built for Georgetown Defense Analytics (GDA), a defense acquisition intelligence firm targeting $100M revenue with three OUs: Enable (Envision/EIS), Protect (Riverstone), Train (PD Systems). Target agencies: SOCOM, T2COM, INSCOM, CYBERCOM, DISA, INDOPACOM, MDA, FAA. Key vehicle: MDA SHIELD IDIQ. Help the user with any question about the platform, workflows, acquisition strategy, or how to use GDA Command features. Be specific and actionable. Question: ' + q});
      setHistory(p => [...p, {role:'ai', text: d.response || d.output || JSON.stringify(d)}]);
    } catch(e) { setHistory(p => [...p, {role:'ai', text:'Error: ' + (e.message || 'Failed')}]); }
    setLoading(false);
  };
  const QUICK = ['How do I run an OODA Loop analysis?','What workflows power the Daily SITREP?','How do I add a new IDIQ to monitor?','How does the Pwin Calculator scoring work?','What GovTribe saved searches are active?','How do I upload a doc for RAG queries?','Explain the capture plan process','What are the platform keyboard shortcuts?'];
  return React.createElement('div', null,
    React.createElement('div', {style:{display:'flex',alignItems:'center',gap:12,marginBottom:20}},
      React.createElement('div', {style:{width:40,height:40,borderRadius:'50%',background:'#556B2F',display:'flex',alignItems:'center',justifyContent:'center',color:'#fff',fontSize:18,fontWeight:700}}, '?'),
      React.createElement('div', null,
        React.createElement('h2', {style:{fontSize:20,fontWeight:700,color:'#556B2F',margin:0}}, 'GDA Command Help'),
        React.createElement('div', {style:{fontSize:12,color:'#6B7280'}}, 'Ask anything about the platform, workflows, or acquisition strategy')
      )
    ),
    React.createElement('div', {style:{background:'#fff',border:'1px solid #D1D5DB',borderRadius:12,padding:16,minHeight:350,maxHeight:500,overflowY:'auto',marginBottom:12}},
      history.length===0 && React.createElement('div', {style:{textAlign:'center',padding:'30px 20px'}},
        React.createElement('div', {style:{fontSize:14,fontWeight:600,color:'#556B2F',marginBottom:12}}, 'How can I help?'),
        React.createElement('div', {style:{display:'grid',gridTemplateColumns:'1fr 1fr',gap:8,maxWidth:500,margin:'0 auto'}},
          QUICK.map(function(q){return React.createElement('button',{key:q,onClick:function(){setQuestion(q);},
            style:{padding:'10px 12px',fontSize:11,border:'1px solid #D1D5DB',borderRadius:8,background:'#FAFBFC',cursor:'pointer',color:'#374151',textAlign:'left'}},q);})
        )
      ),
      history.map(function(msg,i){return React.createElement('div',{key:i,style:{display:'flex',gap:10,marginBottom:14,flexDirection:msg.role==='user'?'row-reverse':'row'}},
        React.createElement('div',{style:{width:30,height:30,borderRadius:'50%',background:msg.role==='user'?'#D14A2A':'#556B2F',color:'#fff',display:'flex',alignItems:'center',justifyContent:'center',fontSize:12,fontWeight:700,flexShrink:0}},msg.role==='user'?'S':'H'),
        React.createElement('div',{style:{background:msg.role==='user'?'#B06D3212':'#F0F4E8',border:'1px solid '+(msg.role==='user'?'#FED7AA':'#C5D6A0'),borderRadius:12,padding:'10px 14px',maxWidth:'80%',fontSize:12,lineHeight:1.7,whiteSpace:'pre-wrap'}},msg.text)
      );}),
      loading && React.createElement('div',{style:{display:'flex',gap:10}},
        React.createElement('div',{style:{width:30,height:30,borderRadius:'50%',background:'#556B2F',color:'#fff',display:'flex',alignItems:'center',justifyContent:'center',fontSize:12,fontWeight:700}},'H'),
        React.createElement('div',{style:{background:'#F0F4E8',border:'1px solid #C5D6A0',borderRadius:12,padding:'10px 14px',fontSize:12,color:'#6B7280'}},'Searching GDA knowledge base...')),
      React.createElement('div',{ref:chatEnd})
    ),
    React.createElement('div', {style:{display:'flex',gap:8}},
      React.createElement('input',{value:question,onChange:function(e){setQuestion(e.target.value);},onKeyDown:function(e){if(e.key==='Enter') ask();},
        placeholder:'Ask about GDA Command...',style:{flex:1,padding:'10px 14px',border:'1px solid #D1D5DB',borderRadius:8,fontSize:13}}),
      React.createElement('button',{onClick:ask,disabled:loading||!question.trim(),
        style:{background:'#556B2F',color:'#fff',border:'none',borderRadius:8,padding:'10px 22px',fontSize:13,fontWeight:600,cursor:'pointer',opacity:loading?0.5:1}},'Ask')
    )
  );
}



// === AOP TRACKER PAGE ===
var AopTrackerPage = function() {
  var h = React.createElement;
  // -- state --
  var _tab = useState("waterfall"); var tab = _tab[0]; var setTab = _tab[1];
  var _yt = useState("FY"); var yearType = _yt[0]; var setYearType = _yt[1];
  var _yn = useState("26"); var yearNum = _yn[0]; var setYearNum = _yn[1];
  var _mo = useState("ALL"); var month = _mo[0]; var setMonth = _mo[1];
  var _er = useState([]); var execRows = _er[0]; var setExecRows = _er[1];
  var _cr = useState([]); var captureRows = _cr[0]; var setCaptureRows = _cr[1];
  var _col = useState({}); var collapsed = _col[0]; var setCollapsed = _col[1];
  var _qe = useState(false); var showQEditor = _qe[0]; var setShowQEditor = _qe[1];
  var _ql = useState(null); var qLreOverride = _ql[0]; var setQLreOverride = _ql[1];
  var setQLreVal = function(qi,val){ setQLreOverride(function(p){ var base=p||[0,0,0,0]; var n=base.slice(); n[qi]=parseFloat(val)||0; return n; }); };
  var _qo = useState({}); var qOverrides = _qo[0]; var setQOverrides = _qo[1];
  var _ex = useState({}); var wfExpanded = _ex[0]; var setWfExpanded = _ex[1];
  var _nm = useState(null); var noteModal = _nm[0]; var setNoteModal = _nm[1];
  var _nt = useState(""); var noteText = _nt[0]; var setNoteText = _nt[1];

  // -- palette (light theme matching rest of app) --
  var X = {bg:"#f8fafc",cd:"#ffffff",bd:"rgba(26,39,68,0.1)",h:"#1a2744",t:"#4a5568",m:"#718096",bl:"#5091A7",gn:"#2F5C1F",rd:"#D14A2A",am:"#B06D32",nv:"#32448A"};
  var B = function(v) { if(!v||v===0) return "—"; return formatDollar(v*1e6); };
  var pctColor = function(v) { return v >= 0 ? X.gn : X.rd; };
  var fyLabel = yearType + yearNum;
  var FY_MONTHS = ["Oct","Nov","Dec","Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep"];
  var CY_MONTHS = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
  var mos = yearType === "FY" ? FY_MONTHS : CY_MONTHS;
  var STAGES = ["Go/No-Go","Interest","Qualify","Pursue","Solicitation","Proposal","Post-Submittal","Awaiting Approval","Award","Loss","Pass"];
  var AOP_T = {"26":42.8,"27":45.8,"28":49.0};
  var aopTarget = AOP_T[yearNum] || 42.8;

  // -- quarterly targets --
  var getQT = function() { var k=yearType+yearNum; if(qOverrides[k]) return qOverrides[k]; var q=aopTarget/4; return [q,q,q,q]; };
  var qTargets = getQT();
  var setQTarget = function(qi,val) { var k=yearType+yearNum; var cur=qOverrides[k]||[aopTarget/4,aopTarget/4,aopTarget/4,aopTarget/4]; var next=cur.slice(); next[qi]=parseFloat(val)||0; setQOverrides(function(p){var n={};for(var x in p)n[x]=p[x];n[k]=next;return n;}); };

  // ===================== SEED DATA =====================
  var FYS = ["FY25","FY26","FY27","FY28","FY29"];
  var AOP_FY = {"FY25":40.0,"FY26":42.8,"FY27":45.8,"FY28":49.0,"FY29":52.4};
  var WF_COLORS = ["#5091A7","#32448A","#B06D32","#2F5C1F","#D14A2A"];
  var _wfApi = useState(null); var wfApiData = _wfApi[0]; var setWfApiData = _wfApi[1];
  useEffect(function() {
    api.post('gda-dashboard-mega', {}).then(function(d) {
      if (d.contracts && d.contracts.length) {
        var mapped = d.contracts.map(function(c, i) {
          var fy = c.fy_revenue || {};
          return {id: c.id || i+1, name: c.name, client: c.client, piid: c.piid || '', idv: c.idv || '', naics: c.naics || '', type: c.type || 'CPFF', ceiling: parseFloat(c.ceiling) || 0, funded: parseFloat(c.funded) || 0, pop_start: c.pop_start || '', pop_end: c.pop_end || '', option_years: c.option_years || 0, options_exercised: c.options_exercised || 0, status: c.status || 'Active', pm: c.pm || 'TBD', cotr: c.cotr || 'TBD', employees: c.employees || 0, location: c.location || '', description: c.description || '', key_personnel: c.key_personnel || [], fy: {FY25: parseFloat(fy.FY25)||0, FY26: parseFloat(fy.FY26)||0, FY27: parseFloat(fy.FY27)||0, FY28: parseFloat(fy.FY28)||0, FY29: parseFloat(fy.FY29)||0}};
        });
        setWfApiData(mapped);
      }
    }).catch(function(){});
  }, []);

  // Real GovTribe data — pulled March 25, 2026
  // 4 RS3 (W15P7T19D0206) task orders + 1 OASIS+ (47QRAD20D3023)
  var wfContractsStatic = [
    {id:1,name:"IEW&S SETA",client:"PEO IEW&S / ACC-APG",piid:"W56KGY22F0028",idv:"RS3 (W15P7T19D0206)",naics:"541715",type:"CPFF",ceiling:26.9,funded:25.3,pop_start:"Feb 2022",pop_end:"Feb 2026",option_years:0,options_exercised:0,status:"Recompete",pm:"TBD",cotr:"TBD",employees:0,location:"Aberdeen Proving Ground, MD",description:"SETA services for PEO IEW&S \u2014 situational understanding and electronic warfare capabilities. Recompete solicitation RS3-25-0034 released. MUST-WIN priority.",key_personnel:["TBD (PM)"],fy:{"FY25":8.5,"FY26":2.1,"FY27":0,"FY28":0,"FY29":0}},
    {id:2,name:"STEP",client:"DEVCOM C5ISR / ACC-APG",piid:"W56KGU23F0016",idv:"RS3 (W15P7T19D0206)",naics:"541715",type:"Cost No Fee",ceiling:92.4,funded:54.5,pop_start:"Aug 2023",pop_end:"Apr 2026",option_years:0,options_exercised:0,status:"Active",pm:"TBD",cotr:"TBD",employees:0,location:"Aberdeen Proving Ground, MD",description:"Soldier Tactical/Expeditionary Power \u2014 generation, storage, management and distribution of power and energy for DEVCOM C5ISR.",key_personnel:["TBD (PM)"],fy:{"FY25":18.0,"FY26":4.5,"FY27":0,"FY28":0,"FY29":0}},
    {id:3,name:"PM MC Product Support",client:"PM Mission Command / GSA FAS",piid:"47QFMA23F0008",idv:"OASIS+ (47QRAD20D3023)",naics:"541330",type:"CPFF",ceiling:30.5,funded:11.2,pop_start:"Mar 2023",pop_end:"May 2028",option_years:0,options_exercised:0,status:"Active",pm:"TBD",cotr:"TBD",employees:0,location:"Aberdeen Proving Ground, MD",description:"PM Mission Command product support services. Only OASIS+ contract in current portfolio; all others are RS3 task orders.",key_personnel:["TBD (PM)"],fy:{"FY25":5.5,"FY26":6.1,"FY27":6.1,"FY28":6.1,"FY29":0}},
    {id:4,name:"C5ISR Sustaining Eng.",client:"DEVCOM C5ISR / ACC-APG",piid:"W15P7T21F0209",idv:"RS3 (W15P7T19D0206)",naics:"541715",type:"CPFF",ceiling:65.6,funded:4.3,pop_start:"Sep 2021",pop_end:"Jun 2026",option_years:0,options_exercised:0,status:"Active",pm:"TBD",cotr:"TBD",employees:0,location:"Aberdeen Proving Ground, MD",description:"Combat capabilities sustaining engineering support for DEVCOM C5ISR Center.",key_personnel:["TBD (PM)"],fy:{"FY25":2.8,"FY26":1.5,"FY27":0,"FY28":0,"FY29":0}},
    {id:5,name:"DEVCOM Eng. Support",client:"DEVCOM / ACC-APG",piid:"W56JSR23F0038",idv:"RS3 (W15P7T19D0206)",naics:"541715",type:"CPFF",ceiling:20.3,funded:5.3,pop_start:"May 2023",pop_end:"May 2028",option_years:0,options_exercised:0,status:"Active",pm:"TBD",cotr:"TBD",employees:0,location:"Adelphi, MD",description:"Engineering support services for DEVCOM. RS3 task order with execution through FY28.",key_personnel:["TBD (PM)"],fy:{"FY25":3.2,"FY26":4.1,"FY27":4.1,"FY28":4.1,"FY29":0}}
  ];

  var wfContracts = wfApiData || wfContractsStatic;
  // -- Execution seed data --
  useEffect(function() {
    setExecRows([
      {id:1,client:"PEO IEW&S",scope:"IEW&S SETA (ends Feb \u201926)",ceiling:2.1,funded:2.1,planned:2.1,revised:null,actual:0.9,ro_type:"Risk",ro_amt:0.3,notes:"Recompete RS3-25-0034. MUST-WIN."},
      {id:2,client:"DEVCOM C5ISR",scope:"STEP \u2014 tactical power (ends Apr \u201926)",ceiling:4.5,funded:4.5,planned:4.5,revised:null,actual:2.2,ro_type:"--",ro_amt:0,notes:""},
      {id:3,client:"PM Mission Command",scope:"PM MC product support (OASIS+)",ceiling:6.1,funded:6.1,planned:6.1,revised:null,actual:2.8,ro_type:"Opportunity",ro_amt:0.4,notes:"Option exercise expected Q3"},
      {id:4,client:"DEVCOM C5ISR",scope:"C5ISR sustaining eng. (ends Jun \u201926)",ceiling:1.5,funded:1.5,planned:1.5,revised:null,actual:0.6,ro_type:"Risk",ro_amt:0.2,notes:"Low obligation rate on ceiling"},
      {id:5,client:"DEVCOM",scope:"DEVCOM engineering support",ceiling:4.1,funded:4.1,planned:4.1,revised:null,actual:1.8,ro_type:"--",ro_amt:0,notes:""}
    ]);
    fetch("/api/gda-capture-plan",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({action:"list",limit:50})}).then(function(r){return r.json();}).then(function(d){var rows=d.plans||d.data||[];if(rows.length>0){var mapped=rows.map(function(r,i){var pd=typeof r.plan_data==="object"&&r.plan_data||{};try{typeof r.plan_data==="string"&&(pd=JSON.parse(r.plan_data));}catch(e){}return{id:r.id||i+1,client:r.agency||pd.agency||"Unknown",name:pd.codename||r.opportunity||"Untitled",stage:pd.stage||"Go/No-Go",amount:parseFloat(String(pd.total_contract_value||r.contract_value||"0").replace(/[$,]/g,""))/1e6||0,pwin:parseInt(pd.pwin)||0,rfi:pd.rfp_date||"",rfq:"",award:pd.stage==="Award"?"Awarded":"",notes:pd.priority||""};});setCaptureRows(mapped);}}).catch(function(){});
  }, [yearNum]);

  // ===================== COMPUTED VALUES =====================
  var computeRevised = function(r) {
    if (r.ro_type === "Risk") return r.planned - (r.ro_amt || 0);
    if (r.ro_type === "Opportunity") return r.planned + (r.ro_amt || 0);
    return r.planned;
  };

  var totalPlanned = execRows.reduce(function(s,r){return s+r.planned;},0);
  var totalActual = execRows.reduce(function(s,r){return s+r.actual;},0);
  var totalRevised = execRows.reduce(function(s,r){return s+computeRevised(r);},0);
  var totalRoAmt = execRows.reduce(function(s,r){
    if(r.ro_type==="Risk") return s - r.ro_amt;
    if(r.ro_type==="Opportunity") return s + r.ro_amt;
    return s;
  },0);
  var gapPlannedActual = totalActual - totalPlanned;
  var gapPlannedPct = totalPlanned > 0 ? (totalActual / totalPlanned - 1) * 100 : 0;
  var gapRevisedActual = totalActual - totalRevised; // base; overridden by LRE below
  var gapRevisedPct = totalRevised > 0 ? (totalActual / totalRevised - 1) * 100 : 0;
  var hasRevision = execRows.some(function(r){return r.ro_type !== "--";});
  // LRE: if user overrode quarterly LRE, use those values; otherwise auto-distribute totalRevised across quarters
  var qLre = qLreOverride || [totalRevised/4, totalRevised/4, totalRevised/4, totalRevised/4];
  var totalLRE = qLre.reduce(function(a,b){return a+b;},0);
  // Override gap calcs with LRE
  gapRevisedActual = totalActual - totalLRE;
  gapRevisedPct = totalLRE > 0 ? (totalActual / totalLRE - 1) * 100 : 0;
  hasRevision = hasRevision || (qLreOverride !== null);
  var ytdActual = totalActual;
  var qActuals = [ytdActual, 0, 0, 0];

  // ===================== HELPERS =====================
  var toggle = function(key) { setCollapsed(function(p){var n={};for(var k in p)n[k]=p[k];n[key]=!p[key];return n;}); };
  var isOpen = function(key) { return collapsed[key] === true; };

  var Section = function(title, key, children, count, value, ac) {
    return h("div",{style:{background:X.cd,borderRadius:8,border:"1px solid "+X.bd,marginBottom:6,overflow:"hidden",borderLeft:ac?"4px solid "+ac:"1px solid "+X.bd}},
      h("div",{onClick:function(){toggle(key);},style:{padding:"10px 16px",cursor:"pointer",display:"flex",justifyContent:"space-between",alignItems:"center",borderBottom:isOpen(key)?"1px solid "+X.bd:"none"}},
        h("div",{style:{display:"flex",gap:10,alignItems:"center"}},
          h("span",{style:{color:X.t,fontSize:12,transition:"transform 0.2s",transform:isOpen(key)?"rotate(90deg)":"rotate(0deg)"}},"\u25B6"),
          h("span",{style:{fontWeight:700,fontSize:13,color:X.h}},title)
        ),
        h("div",{style:{display:"flex",alignItems:"center",gap:12,minWidth:140,justifyContent:"flex-end"}},
          count !== undefined ? h("span",{style:{background:X.nv+"22",color:X.nv,borderRadius:12,padding:"1px 8px",fontSize:11,fontWeight:600,minWidth:24,textAlign:"center"}},count) : null,
          value ? h("span",{style:{fontSize:12,fontWeight:600,color:X.nv,minWidth:70,textAlign:"right"}},value) : null
        )
      ),
      isOpen(key) ? h("div",{style:{padding:16}},children) : null
    );
  };

  // KPI box helper
  // solid=false: white bg, colored top border + colored text
  // solid=true: solid color bg, white text
  var kpi = function(label, value, sub, accentColor, solid) {
    var ac = accentColor || X.bl;
    if (solid) {
      return h("div",{style:{background:ac,borderRadius:10,padding:"14px 16px",border:"none",flex:"1 1 160px",minWidth:140,textAlign:"center"}},
        h("div",{style:{fontSize:11,color:"rgba(255,255,255,0.8)",textTransform:"uppercase",letterSpacing:1.2,marginBottom:5,fontWeight:600}},label),
        h("div",{style:{fontSize:22,fontWeight:700,color:"#fff",lineHeight:1.1}},value),
        sub ? h("div",{style:{fontSize:11,color:"rgba(255,255,255,0.7)",marginTop:4}},sub) : null
      );
    }
    return h("div",{style:{background:X.cd,borderRadius:10,padding:"14px 16px",border:"1px solid "+X.bd,borderTop:"3px solid "+ac,flex:"1 1 160px",minWidth:140,textAlign:"center"}},
      h("div",{style:{fontSize:11,color:X.t,textTransform:"uppercase",letterSpacing:1.2,marginBottom:5,fontWeight:600}},label),
      h("div",{style:{fontSize:22,fontWeight:700,color:ac,lineHeight:1.1}},value),
      sub ? h("div",{style:{fontSize:11,color:X.m,marginTop:4}},sub) : null
    );
  };

  var shipBar = function(label, target, actual) {
    var p = target > 0 ? Math.min((actual / target) * 100, 100) : 0;
    var ok = actual >= target;
    return h("div",{style:{marginBottom:12}},
      h("div",{style:{display:"flex",justifyContent:"space-between",fontSize:11,color:X.t,marginBottom:4}},
        h("span",{style:{fontWeight:500}},label),
        h("span",null,B(actual)+" / "+B(target)+(ok?" \u2713":""))
      ),
      h("div",{style:{height:22,background:X.bg,borderRadius:5,overflow:"hidden",border:"1px solid "+X.bd}},
        h("div",{style:{height:"100%",width:p+"%",background:ok?X.gn:X.rd,borderRadius:4,transition:"width 0.5s ease"}})
      )
    );
  };

  // Year/month selector
  var yearSelector = function() {
    return h("div",{style:{display:"flex",gap:16,alignItems:"center",flexWrap:"wrap"}},
      h("div",{style:{display:"flex",gap:4}},
        ["FY","CY"].map(function(t){return h("button",{key:t,onClick:function(){setYearType(t);},style:{padding:"6px 14px",borderRadius:6,border:"1px solid "+(yearType===t?X.rd:X.bd),background:yearType===t?X.rd:"#fff",color:yearType===t?"#fff":X.t,cursor:"pointer",fontWeight:600,fontSize:12}},t);})
      ),
      h("div",{style:{display:"flex",gap:4}},
        ["26","27","28"].map(function(y){return h("button",{key:y,onClick:function(){setYearNum(y);},style:{padding:"6px 14px",borderRadius:6,border:"1px solid "+(yearNum===y?X.rd:X.bd),background:yearNum===y?X.rd:"#fff",color:yearNum===y?"#fff":X.t,cursor:"pointer",fontWeight:600,fontSize:12}},yearType+y);})
      ),
      (tab==="execution"||tab==="capture") ? h("select",{value:month,onChange:function(e){setMonth(e.target.value);},style:{padding:"6px 12px",borderRadius:6,border:"1px solid "+X.bd,background:X.cd,color:X.h,fontSize:12}},
        h("option",{value:"ALL"},"All Months"),
        mos.map(function(m){return h("option",{key:m,value:m},m);})
      ) : null
    );
  };

  // ===================== TAB: CONTRACT WATERFALL =====================
  var waterfallTab = function() {
    var wfTotals = {};
    var wfGaps = {};
    FYS.forEach(function(fy) {
      wfTotals[fy] = wfContracts.reduce(function(s, c) { return s + (c.fy[fy] || 0); }, 0);
      wfGaps[fy] = wfTotals[fy] - AOP_FY[fy];
    });
    var maxBar = 0;
    FYS.forEach(function(fy) { if (wfTotals[fy] > maxBar) maxBar = wfTotals[fy]; if (AOP_FY[fy] > maxBar) maxBar = AOP_FY[fy]; });
    maxBar = maxBar * 1.15;
    var totalCeiling = wfContracts.reduce(function(s,c){return s+c.ceiling;},0);
    var totalEmployees = 278; // EIS:80 + PDS:178 + Riverstone:20
    var barH = 220;

    var toggleWfExp = function(id) { setWfExpanded(function(p){var n={};for(var k in p)n[k]=p[k];n[id]=!p[id];return n;}); };

    var statusBadge = function(st) {
      var colors = {Active:X.gn,Ending:X.am,Capture:X.nv};
      return h("span",{style:{background:colors[st]||X.nv,color:"#fff",borderRadius:12,padding:"2px 0",fontSize:11,fontWeight:600,display:"inline-block",width:80,textAlign:"center"}},st);
    };

    var popBarFn = function(c) {
      var start = new Date(c.pop_start+" 1"); var end = new Date(c.pop_end+" 1"); var now = new Date();
      var pct = Math.min(Math.max((now-start)/(end-start)*100,0),100);
      return h("div",{style:{marginTop:12}},
        h("div",{style:{fontSize:11,color:X.t,fontWeight:600,marginBottom:6}},"Period of Performance"),
        h("div",{style:{display:"flex",justifyContent:"space-between",fontSize:11,color:X.t,marginBottom:3}},h("span",null,c.pop_start),h("span",null,Math.round(pct)+"% elapsed"),h("span",null,c.pop_end)),
        h("div",{style:{height:8,background:X.bg,borderRadius:4,overflow:"hidden",border:"1px solid "+X.bd}},h("div",{style:{height:"100%",width:pct+"%",background:pct>85?X.rd:pct>60?X.am:X.bl,borderRadius:3}}))
      );
    };

    var fundBar = function(c) {
      var pct = c.ceiling>0?Math.min(c.funded/c.ceiling*100,100):0;
      return h("div",{style:{marginTop:12}},
        h("div",{style:{fontSize:11,color:X.t,fontWeight:600,marginBottom:6}},"Funding Status"),
        h("div",{style:{display:"flex",justifyContent:"space-between",fontSize:11,color:X.t,marginBottom:3}},h("span",null,"Funded: "+B(c.funded)),h("span",null,Math.round(pct)+"% of ceiling"),h("span",null,"Ceiling: "+B(c.ceiling))),
        h("div",{style:{height:8,background:X.bg,borderRadius:4,overflow:"hidden",border:"1px solid "+X.bd}},h("div",{style:{height:"100%",width:pct+"%",background:X.gn,borderRadius:3}}))
      );
    };

    var wTable = h("div",{style:{background:X.cd,borderRadius:10,border:"1px solid "+X.bd,marginBottom:20,overflow:"hidden"}},
      h("div",{style:{padding:"12px 18px",borderBottom:"1px solid "+X.bd}},h("span",{style:{fontWeight:600,fontSize:14,color:X.h}},"Contract Revenue by Fiscal Year ($M)")),
      h("div",{style:{overflowX:"auto"}},
        h("table",{style:{width:"100%",borderCollapse:"collapse",minWidth:700}},
          h("thead",null,
            h("tr",{style:{borderBottom:"2px solid "+X.bd}},
              h("th",{style:{padding:"10px 12px",textAlign:"left",color:X.t,fontWeight:600,fontSize:11,textTransform:"uppercase",minWidth:200}},"Contract"),
              h("th",{style:{padding:"10px 12px",textAlign:"left",color:X.t,fontWeight:600,fontSize:11,textTransform:"uppercase",minWidth:70}},"Status"),
              FYS.map(function(fy){return h("th",{key:fy,style:{padding:"10px 12px",textAlign:"right",color:X.t,fontWeight:600,fontSize:11,textTransform:"uppercase",minWidth:75}},fy);})
            )
          ),
          h("tbody",null,
            wfContracts.map(function(c,ci){
              return h("tr",{key:c.id,style:{borderBottom:"1px solid "+X.bd}},
                h("td",{style:{padding:"8px 12px",fontSize:11}},
                  h("div",{style:{display:"flex",alignItems:"center",gap:8}},
                    h("span",{style:{width:10,height:10,borderRadius:2,background:WF_COLORS[ci%WF_COLORS.length],flexShrink:0}}),
                    h("div",null,h("div",{style:{fontWeight:600,color:X.h}},c.name),h("div",{style:{fontSize:11,color:X.m}},c.client))
                  )
                ),
                h("td",{style:{padding:"8px 12px",fontSize:11}},statusBadge(c.status)),
                FYS.map(function(fy){var v=c.fy[fy]||0;return h("td",{key:fy,style:{padding:"8px 12px",textAlign:"right",fontSize:11,fontWeight:v>0?600:400,color:v>0?X.h:X.m,fontFamily:"monospace"}},v>0?"$"+v.toFixed(1)+"M":"\u2014");})
              );
            }),
            h("tr",{key:"total",style:{borderTop:"2px solid "+X.bl,background:"rgba(26,39,68,0.04)"}},
              h("td",{colSpan:2,style:{padding:"10px 12px",fontWeight:700,color:X.h,fontSize:12}},"TOTAL PROJECTED"),
              FYS.map(function(fy){return h("td",{key:fy,style:{padding:"10px 12px",textAlign:"right",fontWeight:700,color:X.bl,fontSize:12,fontFamily:"monospace"}},"$"+wfTotals[fy].toFixed(1)+"M");})
            ),
            h("tr",{key:"aop",style:{background:"rgba(209,74,42,0.05)"}},
              h("td",{colSpan:2,style:{padding:"10px 12px",fontWeight:700,color:X.rd,fontSize:12}},"AOP TARGET (7% YoY)"),
              FYS.map(function(fy){return h("td",{key:fy,style:{padding:"10px 12px",textAlign:"right",fontWeight:700,color:X.rd,fontSize:12,fontFamily:"monospace"}},"$"+AOP_FY[fy].toFixed(1)+"M");})
            ),
            h("tr",{key:"gap",style:{borderTop:"2px solid "+X.bd}},
              h("td",{colSpan:2,style:{padding:"10px 12px",fontWeight:700,color:X.h,fontSize:12}},"GAP (+/\u2212)"),
              FYS.map(function(fy){var g=wfGaps[fy];return h("td",{key:fy,style:{padding:"10px 12px",textAlign:"right",fontWeight:700,color:g>=0?X.gn:X.rd,fontSize:12,fontFamily:"monospace"}},(g>=0?"+$":"-$")+Math.abs(g).toFixed(1)+"M");})
            )
          )
        )
      )
    );

    // KPIs
    var wfKpis = h("div",{style:{display:"flex",gap:12,flexWrap:"wrap",marginBottom:20,justifyContent:"center"}},
      kpi("Active Contracts",wfContracts.filter(function(c){return c.status==="Active";}).length,wfContracts.length+" total incl. capture"),
      kpi("Total Ceiling",B(totalCeiling),"All vehicles"),
      kpi("FY26 Gap",(wfGaps["FY26"]>=0?"+":"")+B(Math.abs(wfGaps["FY26"])),"vs $42.8M target",wfGaps["FY26"]>=0?X.gn:X.rd),
      kpi("FY28 Gap",(wfGaps["FY28"]>=0?"+":"")+B(Math.abs(wfGaps["FY28"])),"vs $49.0M target",wfGaps["FY28"]>=0?X.gn:X.rd),
      kpi("Employees",totalEmployees,"EIS 80 + PDS 178 + Riverstone 20")
    );

    // Detail cards
    var cards = wfContracts.map(function(c,ci) {
      var isExp = wfExpanded[c.id];
      var hdr = h("div",{onClick:function(){toggleWfExp(c.id);},style:{padding:"14px 18px",cursor:"pointer",display:"flex",justifyContent:"space-between",alignItems:"center"}},
        h("div",{style:{display:"flex",gap:12,alignItems:"center",flex:1}},
          h("span",{style:{color:X.t,fontSize:12,transform:isExp?"rotate(90deg)":"rotate(0deg)",transition:"transform 0.2s"}},"\u25B6"),
          h("span",{style:{width:10,height:10,borderRadius:2,background:WF_COLORS[ci%WF_COLORS.length],flexShrink:0}}),
          h("div",null,h("div",{style:{fontWeight:600,fontSize:13,color:X.h}},c.name),h("div",{style:{fontSize:11,color:X.t,marginTop:1}},c.client+" \u2022 "+c.piid))
        ),
        h("div",{style:{display:"flex",gap:24,alignItems:"flex-start"}},
          h("div",{style:{textAlign:"center",minWidth:80}},h("div",{style:{fontSize:11,color:X.t,textTransform:"uppercase",marginBottom:4}},"Status"),statusBadge(c.status)),
          h("div",{style:{textAlign:"center",minWidth:70}},h("div",{style:{fontSize:11,color:X.t,textTransform:"uppercase",marginBottom:4}},"Ceiling"),h("div",{style:{fontSize:14,fontWeight:700,color:X.bl}},B(c.ceiling))),
          h("div",{style:{textAlign:"center",minWidth:60}},h("div",{style:{fontSize:11,color:X.t,textTransform:"uppercase",marginBottom:4}},"FY26"),h("div",{style:{fontSize:14,fontWeight:700,color:c.fy["FY26"]>0?X.gn:X.m}},c.fy["FY26"]>0?B(c.fy["FY26"]):"\u2014"))
        )
      );
      var dRows = [["Contract Type",c.type],["NAICS",c.naics],["IDV Vehicle",c.idv||"Standalone"],["Location",c.location],["Option Years",c.options_exercised+"/"+c.option_years+" exercised"],["Program Manager",c.pm],["COTR/COR",c.cotr]];
      var det = h("div",{style:{padding:"0 18px 18px",borderTop:"1px solid "+X.bd}},
        h("div",{style:{display:"grid",gridTemplateColumns:"1fr 1fr",gap:20,marginTop:14}},
          h("div",null,
            h("div",{style:{fontSize:11,color:X.t,marginBottom:6,fontWeight:600,textTransform:"uppercase",letterSpacing:0.8}},"Contract Details"),
            h("table",{style:{width:"100%",fontSize:11}},h("tbody",null,dRows.map(function(row){return h("tr",{key:row[0]},h("td",{style:{padding:"3px 6px 3px 0",color:X.m,fontWeight:500,whiteSpace:"nowrap",width:110}},row[0]),h("td",{style:{padding:"3px 0",color:X.h}},row[1]));})))
          ),
          h("div",null,
            h("div",{style:{fontSize:11,color:X.t,marginBottom:6,fontWeight:600,textTransform:"uppercase",letterSpacing:0.8}},"Description"),
            h("div",{style:{fontSize:11,color:X.m,lineHeight:1.5,marginBottom:12}},c.description),
            h("div",{style:{fontSize:11,color:X.t,marginBottom:6,fontWeight:600,textTransform:"uppercase",letterSpacing:0.8}},"Key Personnel"),
            h("div",null,c.key_personnel.map(function(p,i){return h("div",{key:i,style:{fontSize:11,color:X.h,padding:"1px 0"}},"\u2022 "+p);}))
          )
        ),
        fundBar(c),
        popBarFn(c)
      );
      return h("div",{key:c.id,style:{background:X.cd,borderRadius:10,border:"1px solid "+X.bd,marginBottom:8,overflow:"hidden"}},hdr,isExp?det:null);
    });

    return h("div",null, wfKpis, wTable, h("div",{style:{fontSize:14,fontWeight:600,color:X.h,marginBottom:12,marginTop:8}},"Contract Details"), h("div",null,cards));
  };

  // ===================== TAB: AOP EXECUTION =====================
  var executionTab = function() {
    // ---- 10 KPI BOXES (2 rows x 5) ----
    // Active path gets solid boxes. Inactive path = white bg, colored text.
    // No revision: plan path is active (3-5 solid). Revision: revised path is active (8-10 solid).
    var gpaSign = gapPlannedActual >= 0 ? "" : "-";
    var gpaPctSign = gapPlannedPct >= 0 ? "" : "-";
    var roSign = totalRoAmt >= 0 ? "" : "-";
    var roPctVal = (totalRoAmt/aopTarget)*100;
    var roPctSign = roPctVal >= 0 ? "" : "-";
    var graSign = gapRevisedActual >= 0 ? "" : "-";
    var graPctSign = gapRevisedPct >= 0 ? "" : "-";

    var planDir = gapPlannedActual >= 0 ? X.gn : X.rd;
    var revDir = gapRevisedActual >= 0 ? X.gn : X.rd;
    var roColor = totalRoAmt >= 0 ? X.gn : X.rd;
    var planSolid = !hasRevision;
    var revSolid = hasRevision;
    var revisedColor = revDir;

    var row1 = h("div",{style:{display:"flex",gap:10,flexWrap:"wrap",marginBottom:10}},
      kpi("AOP Target",B(aopTarget),fyLabel+" / 7% YoY",X.gn,true),
      kpi("YTD Actuals",B(ytdActual),Math.round(ytdActual/aopTarget*100)+"% of AOP",X.gn,true),
      kpi("Planned Execution",B(totalPlanned),"Full Year",planDir,planSolid),
      kpi("Gap: Plan vs Actual",gpaSign+B(Math.abs(gapPlannedActual)),gapPlannedActual>=0?"Favorable":"Unfavorable",planDir,planSolid),
      kpi("Gap: Plan vs Actual",gpaPctSign+Math.abs(gapPlannedPct).toFixed(1)+"%",gapPlannedActual>=0?"Over plan":"Under plan",planDir,planSolid)
    );
    var row2 = h("div",{style:{display:"flex",gap:10,flexWrap:"wrap",marginBottom:24}},
      kpi("R&O $",roSign+B(Math.abs(totalRoAmt)),totalRoAmt>=0?"Net opportunity":"Net risk",roColor),
      kpi("R&O %",roPctSign+Math.abs(roPctVal).toFixed(1)+"%","% of AOP",roColor),
      kpi("Latest Revised Estimate",B(totalLRE),"Full Year (LRE)",revDir,revSolid),
      kpi("Gap: Revised vs Actual",graSign+B(Math.abs(gapRevisedActual)),gapRevisedActual>=0?"Favorable":"Unfavorable",revDir,revSolid),
      kpi("Gap: Revised vs Actual",graPctSign+Math.abs(gapRevisedPct).toFixed(1)+"%",gapRevisedActual>=0?"Over revised":"Under revised",revDir,revSolid)
    );

    // ---- QUARTERLY DETAIL + CHART ----
    var qDetail = h("div",{style:{background:X.cd,borderRadius:10,border:"1px solid "+X.bd,overflow:"hidden"}},
      h("div",{style:{padding:"12px 18px",display:"flex",justifyContent:"space-between",alignItems:"center",borderBottom:"1px solid "+X.bd}},
        h("span",{style:{fontWeight:600,fontSize:14,color:X.h}},"Quarterly Detail"),
        h("span",{onClick:function(){setShowQEditor(!showQEditor);},style:{cursor:"pointer",fontSize:16,color:showQEditor?X.bl:X.t},title:"Edit quarterly targets"},"\u2699")
      ),
      h("div",{style:{padding:16}},
        h("table",{style:{width:"100%",borderCollapse:"collapse",fontSize:12}},
          h("thead",null,h("tr",{style:{borderBottom:"2px solid "+X.bd}},
            ["Q","Target","Plan","Actual","LRE","Plan vs Actual","% Over/Under"].map(function(hd){return h("th",{key:hd,style:{padding:"8px 8px",textAlign:"center",color:X.t,fontWeight:600,fontSize:11,textTransform:"uppercase"}},hd);})
          )),
          h("tbody",null,
            [0,1,2,3].map(function(qi) {
              var qt = qTargets[qi]; var qa = qActuals[qi]||0; var qPlan = qt; var gap = qa - qPlan; var pct = qPlan>0?((qa/qPlan-1)*100):0; var qlVal = qLre[qi]||0;
              return h("tr",{key:qi,style:{borderBottom:"1px solid "+X.bd}},
                h("td",{style:{padding:"8px 8px",fontWeight:600,color:X.h,textAlign:"center"}},"Q"+(qi+1)),
                h("td",{style:{padding:"8px 8px",color:X.bl,textAlign:"center"}},showQEditor?h("input",{type:"number",step:"0.1",value:qt.toFixed(1),onChange:function(e){setQTarget(qi,e.target.value);},style:{width:65,background:"rgba(26,39,68,0.05)",color:X.h,border:"1px solid "+X.bd,borderRadius:4,padding:"2px 6px",fontSize:12}}):B(qt)),
                h("td",{style:{padding:"8px 8px",color:X.t,textAlign:"center"}},B(qPlan)),
                h("td",{style:{padding:"8px 8px",color:qa>0?X.gn:X.m,textAlign:"center"}},qa>0?B(qa):"--"),
                h("td",{style:{padding:"8px 8px",textAlign:"center"}},h("input",{type:"number",step:"0.1",value:qlVal,onChange:function(e){setQLreVal(qi,e.target.value);},style:{width:65,background:"rgba(26,39,68,0.05)",color:X.h,border:"1px solid "+X.bd,borderRadius:4,padding:"2px 6px",fontSize:12,textAlign:"center"}})),
                h("td",{style:{padding:"8px 8px",color:gap>=0?X.gn:X.rd,fontWeight:600,textAlign:"center"}},(gap>=0?"+":"")+B(Math.abs(gap))),
                h("td",{style:{padding:"8px 8px",color:pct>=0?X.gn:X.rd,fontWeight:600,textAlign:"center"}},pct.toFixed(1)+"%")
              );
            }),
            h("tr",{key:"tot",style:{borderTop:"2px solid "+X.bl,background:"rgba(26,39,68,0.04)"}},
              h("td",{style:{padding:"8px 8px",fontWeight:700,color:X.h,textAlign:"center"}},"Total"),
              h("td",{style:{padding:"8px 8px",fontWeight:700,color:X.bl,textAlign:"center"}},B(qTargets.reduce(function(a,b){return a+b;},0))),
              h("td",{style:{padding:"8px 8px",fontWeight:700,color:X.t,textAlign:"center"}},B(totalPlanned)),
              h("td",{style:{padding:"8px 8px",fontWeight:700,color:X.gn,textAlign:"center"}},B(ytdActual)),
              h("td",{style:{padding:"8px 8px",fontWeight:700,color:X.bl,textAlign:"center"}},B(totalLRE)),
              h("td",{colSpan:2})
            )
          )
        )
      )
    );

    // Revenue chart
    var maxV = Math.max.apply(null, qTargets.concat([ytdActual])) || 1;
    var qChart = h("div",{style:{background:X.cd,borderRadius:10,border:"1px solid "+X.bd,overflow:"hidden"}},
      h("div",{style:{padding:"12px 18px",borderBottom:"1px solid "+X.bd}},h("span",{style:{fontWeight:600,fontSize:14,color:X.h}},"Revenue vs Target")),
      h("div",{style:{padding:16,height:200}},
        h("div",{style:{display:"flex",alignItems:"flex-end",height:170,gap:8,padding:"0 10px"}},
          [0,1,2,3].map(function(qi) {
            var qt=qTargets[qi];var qa=qActuals[qi]||0;
            return h("div",{key:qi,style:{flex:1,display:"flex",flexDirection:"column",alignItems:"center",gap:4}},
              h("div",{style:{width:"100%",display:"flex",gap:2,alignItems:"flex-end",justifyContent:"center",height:140}},
                h("div",{style:{width:"38%",height:Math.max(8,130*(qt/maxV)),background:X.bl,borderRadius:"4px 4px 0 0",opacity:0.5}}),
                h("div",{style:{width:"38%",height:Math.max(2,130*(qa/maxV)),background:X.gn,borderRadius:"4px 4px 0 0"}})
              ),
              h("div",{style:{fontSize:11,color:X.t,fontWeight:600}},"Q"+(qi+1))
            );
          })
        ),
        h("div",{style:{display:"flex",gap:16,justifyContent:"center",marginTop:8,fontSize:11}},
          h("span",{style:{color:X.bl}},"\u25A0 Target"),
          h("span",{style:{color:X.gn}},"\u25A0 Actual")
        )
      )
    );

    // ---- EXECUTION TABLE (Part 4) ----
    var updateRow = function(id, field, val) {
      setExecRows(function(prev) { return prev.map(function(r) { if (r.id !== id) return r; var n = {}; for (var k in r) n[k] = r[k]; n[field] = val; return n; }); });
    };

    var execTable = Section("Current Execution " + fyLabel, "exec-contracts",
      h("div",{style:{overflowX:"auto"}},
        h("table",{style:{width:"100%",borderCollapse:"collapse",fontSize:11,minWidth:1200}},
          h("thead",null,h("tr",{style:{borderBottom:"2px solid "+X.bd}},
            ["#","Client","Scope","Ceiling","Funded","Planned","Latest Revised Est.","Actual","Burn +/- Plan","Burn %","R&O","R&O $","Notes"].map(function(hd){
              return h("th",{key:hd,style:{padding:"8px 5px",textAlign:"left",color:X.t,fontWeight:600,fontSize:11,textTransform:"uppercase",whiteSpace:"nowrap"}},hd);
            })
          )),
          h("tbody",null,
            execRows.map(function(r, i) {
              var rev = computeRevised(r);
              var burnRef = rev;
              var burnGap = r.actual - burnRef;
              var burnPct = burnRef > 0 ? Math.round(r.actual / burnRef * 100) : 0;
              var arrowColor = rev > r.planned ? X.gn : rev < r.planned ? X.rd : X.m;
              return h("tr",{key:r.id,style:{borderBottom:"1px solid "+X.bd}},
                h("td",{style:{padding:"8px 5px",color:X.m}},i+1),
                h("td",{style:{padding:"8px 5px",fontWeight:600,color:X.h,whiteSpace:"nowrap"}},r.client),
                h("td",{style:{padding:"8px 5px",color:X.t,maxWidth:120,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}},r.scope),
                h("td",{style:{padding:"8px 5px",color:X.bl}},B(r.ceiling)),
                h("td",{style:{padding:"8px 5px",color:X.bl}},B(r.funded)),
                h("td",{style:{padding:"8px 5px",color:X.t}},B(r.planned)),
                h("td",{style:{padding:"8px 5px",color:arrowColor,fontWeight:600,whiteSpace:"nowrap",fontSize:11}},
                  r.ro_type === "--" ? "NA" : B(r.planned)+" \u2192 "+B(rev)
                ),
                h("td",{style:{padding:"8px 5px",color:r.actual>0?X.gn:X.m}},r.actual>0?B(r.actual):"--"),
                h("td",{style:{padding:"8px 5px",color:pctColor(burnGap),fontWeight:600}},B(Math.abs(burnGap))),
                h("td",{style:{padding:"8px 5px",color:pctColor(burnGap)}},burnPct+"%"),
                h("td",{style:{padding:"8px 5px"}},
                  h("select",{value:r.ro_type,onChange:function(e){updateRow(r.id,"ro_type",e.target.value);if(e.target.value==="--")updateRow(r.id,"ro_amt",0);},style:{background:"rgba(26,39,68,0.05)",color:X.h,border:"1px solid "+X.bd,borderRadius:4,padding:"2px 3px",fontSize:11,width:70}},
                    h("option",{value:"--"},"\u2014"),h("option",{value:"Risk"},"Risk"),h("option",{value:"Opportunity"},"Opportunity")
                  )
                ),
                h("td",{style:{padding:"8px 5px"}},
                  r.ro_type !== "--" ? h("input",{type:"number",step:"0.1",value:r.ro_amt,onChange:function(e){updateRow(r.id,"ro_amt",parseFloat(e.target.value)||0);},style:{width:55,background:"rgba(26,39,68,0.05)",color:X.h,border:"1px solid "+X.bd,borderRadius:4,padding:"2px 4px",fontSize:11}}) : h("span",{style:{color:X.m,fontSize:11}},"\u2014")
                ),
                h("td",{style:{padding:"8px 5px"}},
                  r.notes ? h("span",{style:{fontSize:11,color:X.t,cursor:"pointer"},onClick:function(){setNoteModal(r.id);setNoteText(r.notes);},title:r.notes},"\u270E "+r.notes.substring(0,15)+(r.notes.length>15?"...":""))
                  : h("button",{onClick:function(){setNoteModal(r.id);setNoteText("");},style:{background:"transparent",border:"1px solid "+X.bd,borderRadius:4,color:X.bl,fontSize:11,padding:"2px 6px",cursor:"pointer"}},"+Note")
                )
              );
            }),
            h("tr",{key:"tot",style:{borderTop:"2px solid "+X.bl,background:"rgba(26,39,68,0.04)"}},
              h("td",{colSpan:3,style:{padding:"10px 5px",fontWeight:700,color:X.h,fontSize:11}},"TOTALS"),
              h("td",{style:{padding:"10px 5px",fontWeight:700,color:X.bl,fontSize:11}},B(execRows.reduce(function(s,r){return s+r.ceiling;},0))),
              h("td",{style:{padding:"10px 5px",fontWeight:700,color:X.bl,fontSize:11}},B(execRows.reduce(function(s,r){return s+r.funded;},0))),
              h("td",{style:{padding:"10px 5px",fontWeight:700,color:X.t,fontSize:11}},B(totalPlanned)),
              h("td",{style:{padding:"10px 5px",fontWeight:700,color:revisedColor,fontSize:11}},B(totalLRE)),
              h("td",{style:{padding:"10px 5px",fontWeight:700,color:X.gn,fontSize:11}},B(totalActual)),
              h("td",{colSpan:5})
            )
          )
        )
      ),
      execRows.length
    );

    // ---- BACKLOG SECTION (Part 5) ----
    var startFunded = execRows.reduce(function(s,r){return s+r.funded;},0);
    var startUnfunded = execRows.reduce(function(s,r){return s+(r.ceiling-r.funded);},0);
    var executedBL = totalActual;
    var revisedBL = totalLRE;
    var blMax = Math.max(startFunded,startUnfunded,executedBL,revisedBL,1);

    var blBox = function(lbl,val,sub,pos) {
      return h("div",{style:{background:X.cd,borderRadius:10,padding:"14px 16px",border:"1px solid "+X.bd,textAlign:"center",gridArea:pos}},
        h("div",{style:{fontSize:11,color:X.t,textTransform:"uppercase",letterSpacing:1,marginBottom:5,fontWeight:500}},lbl),
        h("div",{style:{fontSize:20,fontWeight:700,color:X.h,lineHeight:1.1}},B(val)),
        sub ? h("div",{style:{fontSize:11,color:X.m,marginTop:4}},sub) : null
      );
    };

    var blBarItem = function(lbl,val,color) {
      var ht = blMax>0?Math.max(8,(val/blMax)*140):8;
      return h("div",{style:{flex:1,display:"flex",flexDirection:"column",alignItems:"center",gap:4}},
        h("div",{style:{fontSize:11,color:X.t,fontWeight:600}},B(val)),
        h("div",{style:{width:"60%",height:ht,background:color,borderRadius:"4px 4px 0 0"}}),
        h("div",{style:{fontSize:11,color:X.t,marginTop:2}},lbl)
      );
    };

    var backlogSection = h("div",{style:{background:X.cd,borderRadius:10,border:"1px solid "+X.bd,marginBottom:16,overflow:"hidden"}},
      h("div",{style:{padding:"12px 18px",display:"flex",alignItems:"center",gap:10,borderBottom:"1px solid "+X.bd}},
        h("span",{style:{fontWeight:600,fontSize:14,color:X.h}},"Backlog"),
        h("span",{style:{fontSize:14,color:X.t}},"\u2699")
      ),
      h("div",{style:{padding:20,display:"grid",gridTemplateColumns:"1fr 2fr 1fr",gridTemplateRows:"auto auto",gap:16,gridTemplateAreas:"'tl chart tr' 'bl chart br'"}},
        blBox("Starting Year Unfunded Backlog",startUnfunded,"Unfunded ceiling","tl"),
        blBox("Executed Backlog",executedBL,(executedBL-startFunded>=0?"+":"")+B(Math.abs(executedBL-startFunded))+" vs funded","tr"),
        h("div",{style:{gridArea:"chart",background:X.bg,borderRadius:10,border:"1px solid "+X.bd,padding:16,display:"flex",alignItems:"flex-end",justifyContent:"center",gap:12,minHeight:180}},
          blBarItem("Funded",startFunded,X.bl),
          blBarItem("Unfunded",startUnfunded,X.nv),
          blBarItem("Executed",executedBL,X.gn),
          blBarItem("Revised",revisedBL,X.am)
        ),
        blBox("Starting Year Funded Backlog",startFunded,"Funded amount","bl"),
        blBox("Revised Backlog",revisedBL,(revisedBL-startFunded>=0?"+":"")+B(Math.abs(revisedBL-startFunded))+" vs funded","br")
      )
    );

    // ---- NOTE MODAL ----
    var modal = noteModal !== null ? h("div",{style:{position:"fixed",top:0,left:0,right:0,bottom:0,background:"rgba(0,0,0,0.6)",zIndex:9999,display:"flex",alignItems:"center",justifyContent:"center"},onClick:function(){setNoteModal(null);}},
      h("div",{style:{background:X.cd,borderRadius:12,border:"1px solid "+X.bd,padding:24,width:400,maxWidth:"90%"},onClick:function(e){e.stopPropagation();}},
        h("div",{style:{fontSize:14,fontWeight:600,color:X.h,marginBottom:12}},"Contract Note"),
        h("textarea",{value:noteText,onChange:function(e){setNoteText(e.target.value);},style:{width:"100%",height:100,background:"rgba(26,39,68,0.05)",color:X.h,border:"1px solid "+X.bd,borderRadius:8,padding:10,fontSize:12,resize:"vertical"}}),
        h("div",{style:{display:"flex",gap:8,marginTop:12,justifyContent:"flex-end"}},
          h("button",{onClick:function(){setNoteModal(null);},style:{padding:"6px 16px",borderRadius:6,border:"1px solid "+X.bd,background:"transparent",color:X.t,cursor:"pointer",fontSize:12}},"Cancel"),
          h("button",{onClick:function(){updateRow(noteModal,"notes",noteText);setNoteModal(null);},style:{padding:"6px 16px",borderRadius:6,border:"none",background:X.rd,color:"#fff",cursor:"pointer",fontSize:12,fontWeight:600}},"Save")
        )
      )
    ) : null;

    return h("div",null, row1, row2,
      h("div",{style:{display:"grid",gridTemplateColumns:"1fr 1fr",gap:16,marginBottom:24}},qDetail,qChart),
      backlogSection,
      execTable,
      modal
    );
  };

  // ===================== TAB: AOP CAPTURE =====================
  var pipeline = captureRows.reduce(function(s,r){return s+(r.amount||0);},0);
  var weighted = captureRows.reduce(function(s,r){return s+((r.amount||0)*(r.pwin||0)/100);},0);
  var qualified = captureRows.filter(function(r){return ["Qualify","Pursue","Solicitation","Proposal","Post-Submittal","Awaiting Approval"].indexOf(r.stage)>=0;}).reduce(function(s,r){return s+(r.amount||0);},0);
  var activeCapture = captureRows.filter(function(r){return ["Pursue","Solicitation","Proposal","Post-Submittal"].indexOf(r.stage)>=0;}).reduce(function(s,r){return s+(r.amount||0);},0);
  var bnp = captureRows.filter(function(r){return r.stage==="Proposal";}).reduce(function(s,r){return s+(r.amount||0);},0);
  var wins = captureRows.filter(function(r){return r.stage==="Award";}).reduce(function(s,r){return s+(r.amount||0);},0);
  var losses = captureRows.filter(function(r){return r.stage==="Loss"||r.stage==="Pass";}).reduce(function(s,r){return s+(r.amount||0);},0);
  var PWIN_OPTS = ["0-25","26-50","51-80","80-100"];
  var newBizGap = Math.round(aopTarget*0.07*10)/10;

  var STC = {"Go/No-Go":"#1a2744","Interest":"#1a2744","Qualify":"#5091A7","Pursue":"#5091A7","Solicitation":"#B06D32","Proposal":"#D14A2A","Post-Submittal":"#D14A2A","Awaiting Approval":"#32448A","Award":"#2F5C1F","Loss":"#DC2626","Pass":"#6B7280"};
  var stageTable = function(stage,showFull) {
    var rows = captureRows.filter(function(r){return r.stage===stage;});
    var cols = showFull ? ["#","Client","Name","Stage","Amount","Pwin","Weighted","RFI","RFQ","Award"] : ["#","Client","Name","Stage","Amount","Notes"];
    var stgTotal=rows.reduce(function(s,r){return s+(r.amount||0);},0); return Section(stage, "cap-"+stage,
      h("div",{style:{overflowX:"auto"}},
        h("table",{style:{width:"100%",borderCollapse:"collapse",fontSize:11,minWidth:showFull?800:500}},
          h("thead",null,h("tr",{style:{borderBottom:"2px solid "+X.bd}},
            cols.map(function(c){return h("th",{key:c,style:{padding:"8px 6px",textAlign:"left",color:X.t,fontWeight:600,fontSize:11,textTransform:"uppercase"}},c);})
          )),
          h("tbody",null,
            rows.length === 0
            ? h("tr",null,h("td",{colSpan:cols.length,style:{padding:"12px 6px",color:X.m,textAlign:"center",fontStyle:"italic"}},"No opportunities in this stage"))
            : rows.map(function(r,i) {
              return h("tr",{key:r.id,style:{borderBottom:"1px solid "+X.bd}},
                h("td",{style:{padding:"8px 6px",color:X.m}},i+1),
                h("td",{style:{padding:"8px 6px",color:X.t}},r.client),
                h("td",{style:{padding:"8px 6px",fontWeight:600,color:X.h}},r.name),
                h("td",{style:{padding:"8px 6px"}},
                  h("select",{value:r.stage,onChange:function(e){var ns=e.target.value;setCaptureRows(function(p){return p.map(function(x){return x.id===r.id?Object.assign({},x,{stage:ns}):x;});});fetch("/api/gda-capture-plan",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({action:"save",plan_id:r.id,plan:{stage:ns}})}).catch(function(){});},style:{background:"rgba(26,39,68,0.05)",color:X.h,border:"1px solid "+X.bd,borderRadius:4,padding:"2px 4px",fontSize:11}},
                    STAGES.map(function(s){return h("option",{key:s,value:s},s);})
                  )
                ),
                h("td",{style:{padding:"8px 6px",color:X.bl}},B(r.amount)),
                showFull ? h("td",{key:"pw",style:{padding:"8px 6px"}},
                  h("select",{value:r.pwin,onChange:function(e){var v=parseInt(e.target.value);setCaptureRows(function(p){return p.map(function(x){return x.id===r.id?Object.assign({},x,{pwin:v}):x;});});},style:{background:"rgba(26,39,68,0.05)",color:X.h,border:"1px solid "+X.bd,borderRadius:4,padding:"2px 4px",fontSize:11}},
                    PWIN_OPTS.map(function(o){return h("option",{key:o,value:parseInt(o.split("-")[0])},o+"%");})
                  )
                ) : null,
                showFull ? h("td",{key:"wt",style:{padding:"8px 6px",color:X.am,fontWeight:600}},B(r.amount*(r.pwin||0)/100)) : null,
                showFull ? h("td",{key:"rfi",style:{padding:"8px 6px",color:X.t}},r.rfi||"--") : null,
                showFull ? h("td",{key:"rfq",style:{padding:"8px 6px",color:X.t}},r.rfq||"--") : null,
                showFull ? h("td",{key:"aw",style:{padding:"8px 6px",color:X.t}},r.award||"--") : null,
                !showFull ? h("td",{key:"nt",style:{padding:"8px 6px",color:X.t}},r.notes||"--") : null
              );
            })
          )
        )
      ),
      rows.length, B(stgTotal), STC[stage]||"#1a2744"
    );
  };

  var captureTab = function() {
    // -- KPI row 1: Shipley coverage metrics --
    var kpiRow1 = h("div",{style:{display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:12,marginBottom:16}},
      kpi("Total Qualified (5x)",B(qualified),"Target: "+B(aopTarget*5),qualified>=aopTarget*5?X.gn:X.am),
      kpi("Active Capture (3x)",B(activeCapture),"Target: "+B(aopTarget*3),activeCapture>=aopTarget*3?X.gn:X.am),
      kpi("B&P (1.5-2x)",B(bnp),"Target: "+B(aopTarget*1.5),bnp>=aopTarget*1.5?X.gn:X.rd),
      kpi("Pwin-Weighted (>=1x)",B(weighted),"Target: "+B(aopTarget),weighted>=aopTarget?X.gn:X.rd)
    );
    // -- KPI row 2: Performance + targets --
    var kpiRow2 = h("div",{style:{display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:12,marginBottom:24}},
      kpi("Actual Wins",B(wins),wins>0?"YTD":"None yet",X.gn),
      kpi("Actual Losses",B(losses),losses>0?"YTD":"None yet",X.rd),
      kpi("AOP Target",B(aopTarget),fyLabel,X.bl),
      kpi("New Biz Gap",B(newBizGap)+"/yr","7% YoY delta",X.rd)
    );
    // -- Pipeline Progress: 4 bars per spec --
    var pipelineCard = h("div",{style:{background:X.cd,borderRadius:10,padding:18,border:"1px solid "+X.bd,marginBottom:24}},
      h("div",{style:{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:16}},
        h("span",{style:{fontSize:14,fontWeight:600,color:X.h}},"Pipeline Progress"),
        h("span",{style:{fontSize:12,color:X.m}},B(pipeline)+" total pipeline / "+captureRows.length+" opportunities")
      ),
      shipBar("Total Qualified (5x) — "+B(aopTarget*5)+" target",aopTarget*5,qualified),
      shipBar("Active Capture (3x) — "+B(aopTarget*3)+" target",aopTarget*3,activeCapture),
      shipBar("B&P (1.5-2x) — "+B(aopTarget*1.5)+" target",aopTarget*1.5,bnp),
      shipBar("Pwin-Weighted (>=1x) — "+B(aopTarget)+" target",aopTarget,weighted)
    );
    return h("div",null,
      h("div",{style:{fontSize:13,fontWeight:600,color:X.t,textTransform:"uppercase",letterSpacing:1,marginBottom:12}},"Shipley Pipeline Coverage"),
      kpiRow1, kpiRow2, pipelineCard,
      stageTable("Go/No-Go",true),stageTable("Interest",true),stageTable("Qualify",true),stageTable("Pursue",true),stageTable("Solicitation",true),stageTable("Proposal",true),stageTable("Post-Submittal",true),stageTable("Awaiting Approval",true),stageTable("Award",false),stageTable("Loss",false),stageTable("Pass",false)
    );
  };

  // ===================== TAB: DEFINITIONS =====================
  var p2Tab = function() {
  var P2 = {
    ytd_rev: 5200000, ytd_exp: 4300000, ytd_profit: 900000, ytd_margin: 17.3,
    funded_backlog: 23400000, dso: 42,
    income: {
      ptd: {rev:1040000,dl:520000,odl:104000,mat:31200,travel:10400,sub:52000,odc:15600,total_dc:733200,oh:166400,ga:78000,fee:62400,total_cost:1040000,profit:0},
      ytd: {rev:5200000,dl:2600000,odl:520000,mat:156000,travel:52000,sub:260000,odc:78000,total_dc:3666000,oh:832000,ga:390000,fee:312000,total_cost:5200000,profit:0},
      ctd: {rev:38200000,dl:19100000,odl:3820000,mat:1146000,travel:382000,sub:1910000,odc:573000,total_dc:26931000,oh:6112000,ga:2866000,fee:2291000,total_cost:38200000,profit:0}
    },
    contracts: [
      {name:"IEW&S SETA",pm:"Seffernick",type:"CPFF",rev:2800000,cost:2380000,profit:420000,margin:15.0,backlog:8400000,status:"green"},
      {name:"STEP",pm:"TBD",type:"CPFF",rev:0,cost:0,profit:0,margin:0,backlog:0,status:"yellow"},
      {name:"CSIA",pm:"TBD",type:"T&M",rev:450000,cost:405000,profit:45000,margin:10.0,backlog:2100000,status:"yellow"},
      {name:"PdM M2S2",pm:"TBD",type:"CPFF",rev:0,cost:0,profit:0,margin:0,backlog:0,status:"red"},
      {name:"MSCoE C2",pm:"TBD",type:"T&M",rev:280000,cost:252000,profit:28000,margin:10.0,backlog:1200000,status:"green"},
      {name:"OASIS+ VTE",pm:"TBD",type:"FFP",rev:0,cost:0,profit:0,margin:0,backlog:0,status:"yellow"},
      {name:"OASIS+ ARNG",pm:"TBD",type:"FFP",rev:0,cost:0,profit:0,margin:0,backlog:0,status:"yellow"},
      {name:"OASIS+ Fires",pm:"TBD",type:"T&M",rev:0,cost:0,profit:0,margin:0,backlog:0,status:"yellow"},
      {name:"SEWP VI",pm:"TBD",type:"GWAC",rev:0,cost:0,profit:0,margin:0,backlog:0,status:"yellow"},
      {name:"Mobile Tours",pm:"TBD",type:"FFP",rev:0,cost:0,profit:0,margin:0,backlog:0,status:"yellow"},
      {name:"BLM Instructional",pm:"TBD",type:"FFP",rev:0,cost:0,profit:0,margin:0,backlog:0,status:"yellow"},
      {name:"Smartphone App",pm:"TBD",type:"FFP",rev:180000,cost:153000,profit:27000,margin:15.0,backlog:800000,status:"green"},
      {name:"360 VR",pm:"TBD",type:"FFP",rev:0,cost:0,profit:0,margin:0,backlog:0,status:"yellow"},
      {name:"Data Env IT",pm:"TBD",type:"T&M",rev:320000,cost:288000,profit:32000,margin:10.0,backlog:1400000,status:"green"},
      {name:"EMODS",pm:"TBD",type:"T&M",rev:210000,cost:189000,profit:21000,margin:10.0,backlog:900000,status:"green"},
      {name:"FORCE",pm:"TBD",type:"IDIQ",rev:960000,cost:816000,profit:144000,margin:15.0,backlog:4200000,status:"green"},
      {name:"MAPS",pm:"TBD",type:"IDIQ",rev:0,cost:0,profit:0,margin:0,backlog:0,status:"red"}
    ]
  };
  var fmtK = formatDollar;
  var dot = function(s){return h("span",{style:{display:"inline-block",width:8,height:8,borderRadius:"50%",background:s==="green"?"#16A34A":s==="yellow"?"#D97706":"#DC2626",marginRight:6}});};
  return h("div",null,
    h("div",{style:{fontSize:13,fontWeight:600,color:X.t,textTransform:"uppercase",letterSpacing:1,marginBottom:12}},"Feb 2026 Financial Summary Package (P2)"),
    h("div",{style:{display:"grid",gridTemplateColumns:"repeat(6,1fr)",gap:12,marginBottom:24}},
      kpi("YTD Revenue",fmtK(P2.ytd_rev),"5 months",X.bl),
      kpi("YTD Expenses",fmtK(P2.ytd_exp),"direct + indirect",X.am),
      kpi("YTD Profit",fmtK(P2.ytd_profit),"operating",P2.ytd_profit>0?X.gn:X.rd),
      kpi("YTD Margin",P2.ytd_margin.toFixed(1)+"%","EBIT/Rev",P2.ytd_margin>10?X.gn:X.rd),
      kpi("Funded Backlog",fmtK(P2.funded_backlog),"obligated",X.bl),
      kpi("DSO",P2.dso+" days","collection",P2.dso<45?X.gn:X.am)
    ),
    Section("Income Statement (PTD / YTD / CTD)","p2-income",
      h("table",{style:{width:"100%",borderCollapse:"collapse",fontSize:11}},
        h("thead",null,h("tr",{style:{borderBottom:"2px solid "+X.bd}},
          h("th",{style:{padding:"8px 6px",textAlign:"left",color:X.t,fontWeight:600}},"Line Item"),
          h("th",{style:{padding:"8px 6px",textAlign:"right",color:X.t,fontWeight:600}},"PTD (Feb)"),
          h("th",{style:{padding:"8px 6px",textAlign:"right",color:X.t,fontWeight:600}},"YTD"),
          h("th",{style:{padding:"8px 6px",textAlign:"right",color:X.t,fontWeight:600}},"CTD")
        )),
        h("tbody",null,
          [["Revenue","rev"],["Direct Labor","dl"],["ODL","odl"],["Materials","mat"],["Travel","travel"],["Subcontracts","sub"],["ODC","odc"],["Total Direct","total_dc"],["Overhead","oh"],["G&A","ga"],["Fee","fee"],["Total Cost","total_cost"],["Profit","profit"]].map(function(r){
            var bold = r[1]==="rev"||r[1]==="total_dc"||r[1]==="total_cost"||r[1]==="profit";
            return h("tr",{key:r[1],style:{borderBottom:"1px solid "+X.bd,fontWeight:bold?600:400}},
              h("td",{style:{padding:"6px",color:X.h}},r[0]),
              h("td",{style:{padding:"6px",textAlign:"right",color:X.m}},fmtK(P2.income.ptd[r[1]])),
              h("td",{style:{padding:"6px",textAlign:"right",color:X.m}},fmtK(P2.income.ytd[r[1]])),
              h("td",{style:{padding:"6px",textAlign:"right",color:X.m}},fmtK(P2.income.ctd[r[1]]))
            );
          })
        )
      ), 13
    ),
    Section("Contract P&L (17 Contracts)","p2-contracts",
      h("table",{style:{width:"100%",borderCollapse:"collapse",fontSize:11}},
        h("thead",null,h("tr",{style:{borderBottom:"2px solid "+X.bd}},
          h("th",{style:{padding:"8px 6px",textAlign:"left",color:X.t,fontWeight:600}},""),
          h("th",{style:{padding:"8px 6px",textAlign:"left",color:X.t,fontWeight:600}},"Contract"),
          h("th",{style:{padding:"8px 6px",textAlign:"left",color:X.t,fontWeight:600}},"PM"),
          h("th",{style:{padding:"8px 6px",textAlign:"left",color:X.t,fontWeight:600}},"Type"),
          h("th",{style:{padding:"8px 6px",textAlign:"right",color:X.t,fontWeight:600}},"Revenue"),
          h("th",{style:{padding:"8px 6px",textAlign:"right",color:X.t,fontWeight:600}},"Cost"),
          h("th",{style:{padding:"8px 6px",textAlign:"right",color:X.t,fontWeight:600}},"Profit"),
          h("th",{style:{padding:"8px 6px",textAlign:"right",color:X.t,fontWeight:600}},"Margin"),
          h("th",{style:{padding:"8px 6px",textAlign:"right",color:X.t,fontWeight:600}},"Backlog")
        )),
        h("tbody",null,P2.contracts.sort(function(a,b){return b.profit-a.profit;}).map(function(c){
          return h("tr",{key:c.name,style:{borderBottom:"1px solid "+X.bd}},
            h("td",{style:{padding:"6px"}},dot(c.status)),
            h("td",{style:{padding:"6px",fontWeight:600,color:X.h}},c.name),
            h("td",{style:{padding:"6px",color:X.m}},c.pm),
            h("td",{style:{padding:"6px",color:X.t}},c.type),
            h("td",{style:{padding:"6px",textAlign:"right",color:X.bl}},fmtK(c.rev)),
            h("td",{style:{padding:"6px",textAlign:"right",color:X.m}},fmtK(c.cost)),
            h("td",{style:{padding:"6px",textAlign:"right",color:c.profit>0?X.gn:c.profit<0?X.rd:X.m,fontWeight:600}},fmtK(c.profit)),
            h("td",{style:{padding:"6px",textAlign:"right",color:c.margin>12?X.gn:c.margin>0?X.am:X.m}},c.margin.toFixed(1)+"%"),
            h("td",{style:{padding:"6px",textAlign:"right",color:X.bl}},fmtK(c.backlog))
          );
        }))
      ), P2.contracts.length
    )
  );
};

  var definitionsTab = function() {
    var sources = [
      ["FAR (Federal Acquisition Regulation)","https://www.acquisition.gov/far"],
      ["DAU Glossary","https://www.dau.edu/glossary"],
      ["DCAA Contract Audit Manual (DCAAM 7640.1)","https://www.dcaa.mil/"],
      ["CAS (Cost Accounting Standards)","https://www.whitehouse.gov/omb/casb/"],
      ["FAR Part 31 \u2014 Contract Cost Principles","https://www.acquisition.gov/far/part-31"],
      ["FAR Part 16 \u2014 Types of Contracts","https://www.acquisition.gov/far/part-16"],
      ["DFARS (Defense FAR Supplement)","https://www.acquisition.gov/dfars"],
      ["OMB Circular A-122 / 2 CFR 200","https://www.ecfr.gov/current/title-2/subtitle-A/chapter-II/part-200"],
      ["Deltek Costpoint B&P Module","https://www.deltek.com/en/products/project-erp/costpoint"],
      ["AICPA Audit Guide: Government Contracts","https://www.aicpa.org/"],
      ["NCMA (National Contract Management Association)","https://www.ncmahq.org/"],
      ["Shipley Business Development Lifecycle","https://www.shipleywins.com/"],
      ["PMBOK Guide (PMI)","https://www.pmi.org/pmbok-guide-standards"],
      ["GAO Bid Protest Decisions","https://www.gao.gov/legal/bid-protests"],
      ["SAM.gov (System for Award Management)","https://sam.gov/"]
    ];

    var CATS = [
      {name:"FINANCIAL PLANNING & BUDGETING",terms:[
        ["Annual Operating Plan (AOP)","The organization-level revenue and cost budget for a fiscal year, typically aligned to contract execution forecasts and indirect rate structures.","Deltek Costpoint B&P Module"],
        ["AOP Target","The specific revenue target set for an operating unit within the AOP, usually expressed as total execution dollars for the fiscal year.","Internal Planning"],
        ["YTD Actuals","Year-to-date billed or recognized revenue across all contracts in the operating unit.","GAAP / Deltek Costpoint"],
        ["Planned Execution","The original forecast of contract revenue expected to be executed (billed) during the fiscal year.","Internal Planning"],
        ["Latest Revised Estimate (LRE)","Updated execution forecast incorporating R&Os, funding changes, and scope modifications since original plan.","DCAA / EVM"],
        ["Fiscal Year (FY)","The federal government fiscal year running October 1 through September 30.","FAR 2.101"],
        ["Calendar Year (CY)","Standard January 1 through December 31 calendar year, sometimes used for commercial contracts.","General"],
        ["Revenue Recognition","The accounting process of recording revenue when earned, per ASC 606 or contract-specific milestones.","AICPA / ASC 606"],
        ["Burn Rate","The rate at which contract funding is being consumed, typically expressed as monthly or quarterly spend.","Internal Planning"],
        ["Year-over-Year (YoY) Growth","Percentage increase in revenue target compared to prior fiscal year. Envision target: 7%.","Internal Planning"],
        ["Funded Backlog","The dollar value of contract work that has been funded by the government but not yet executed.","DCAA"],
        ["Unfunded Backlog","The dollar value of contract ceiling not yet funded, representing potential future revenue if exercised.","DCAA"]
      ]},
      {name:"CONTRACT TYPES & PRICING",terms:[
        ["Cost-Plus-Fixed-Fee (CPFF)","Contract where government reimburses allowable costs plus a fixed fee. Most common in DoD services.","FAR 16.306"],
        ["Cost-Plus-Incentive-Fee (CPIF)","Cost-reimbursement contract with incentive fee tied to cost, schedule, or performance targets.","FAR 16.405"],
        ["Firm-Fixed-Price (FFP)","Contract with a fixed price regardless of actual costs. Contractor bears full cost risk.","FAR 16.202"],
        ["Time-and-Materials (T&M)","Contract paying fixed hourly rates plus materials at cost. Used when scope is uncertain.","FAR 16.601"],
        ["IDIQ (Indefinite Delivery/Indefinite Quantity)","Contract vehicle with minimum/maximum quantities; task orders issued as work is identified.","FAR 16.504"],
        ["Task Order","Individual work order issued under an IDIQ or multiple-award contract vehicle.","FAR 16.505"],
        ["Contract Ceiling","Maximum dollar value that can be billed under a contract including all options.","FAR 16.301"],
        ["Period of Performance (PoP)","The defined timeframe during which contract work must be performed and billed.","FAR 11.4"]
      ]},
      {name:"COST STRUCTURE & RATES",terms:[
        ["Direct Labor","Labor costs directly attributable to a specific contract, billed at approved rates.","CAS 418"],
        ["Indirect Costs","Costs not directly tied to one contract: overhead, G&A, fringe benefits.","FAR 31.203"],
        ["Overhead Rate","Percentage applied to direct costs to cover indirect operational expenses (facilities, IT, etc.).","CAS 418"],
        ["G&A Rate","General & Administrative rate applied to total cost input to cover corporate-level expenses.","CAS 410"],
        ["Fringe Benefits Rate","Rate covering employee benefits: health insurance, retirement, PTO, payroll taxes.","FAR 31.205-6"],
        ["Wrap Rate","Fully-loaded labor rate including base salary + fringe + overhead + G&A + fee.","DCAA"],
        ["Forward Pricing Rate Agreement (FPRA)","Pre-negotiated indirect rates with DCAA for use in proposals.","FAR 42.1701"],
        ["Incurred Cost Submission (ICS)","Annual submission of actual indirect rates to DCAA for audit and rate adjustment.","FAR 42.708"],
        ["Uncompensated Overtime","Hours worked beyond 40/week not billed to government; reduces effective labor rate.","FAR 37.115"],
        ["Material Handling Rate","Indirect rate applied to direct material purchases to cover procurement overhead.","CAS 411"],
        ["Fee / Profit","Contractor compensation above costs, negotiated per FAR 15.404-4 weighted guidelines.","FAR 15.404-4"],
        ["Cost Allowability","Whether a cost is reimbursable under government contract per FAR Part 31 criteria.","FAR 31.201-2"],
        ["Cost Allocability","Whether a cost can be assigned to a specific contract based on benefit received.","CAS 402"]
      ]},
      {name:"CONTRACT EXECUTION & ADMINISTRATION",terms:[
        ["Contracting Officer (CO/KO)","Government official with authority to enter, modify, and terminate contracts.","FAR 1.602"],
        ["Contracting Officer Representative (COR)","Government designee who monitors contractor performance on behalf of the CO.","FAR 1.604"],
        ["Program Manager (PM)","Contractor lead responsible for overall contract execution, staffing, and delivery.","Internal"],
        ["Contract Modification","Bilateral or unilateral change to contract terms, scope, funding, or ceiling.","FAR 43.103"],
        ["Option Year","Pre-priced contract extension period that the government may exercise.","FAR 17.207"],
        ["Level of Effort (LOE)","Contract measured by hours/FTEs rather than deliverables. Common in SETA.","FAR 16.306"],
        ["Earned Value Management (EVM)","Performance measurement system comparing planned work, earned work, and actual costs.","DFARS 234.201"],
        ["Invoice / Billing","Monthly submission of costs incurred for government reimbursement on cost-type contracts.","FAR 32.905"],
        ["Funding Obligation","Government commitment of appropriated funds to a specific contract or task order.","FAR 32.702"],
        ["Stop Work Order","Government directive to temporarily halt contract performance, often due to funding gaps.","FAR 42.1303"],
        ["SETA (Systems Engineering & Technical Assistance)","Advisory & assistance services supporting government program offices. Non-inherently governmental.","DFARS 237.104"],
        ["Contract Data Requirements List (CDRL)","List of deliverable data items required under a contract.","DI-MGMT-80368"]
      ]},
      {name:"REGULATORY & COMPLIANCE",terms:[
        ["FAR (Federal Acquisition Regulation)","Primary body of rules governing federal government acquisitions.","FAR 1.101"],
        ["DFARS","Defense Federal Acquisition Regulation Supplement, additional rules for DoD contracts.","DFARS 201.1"],
        ["CAS (Cost Accounting Standards)","19 standards governing cost measurement, assignment, and allocation on government contracts.","CAS 401-420"],
        ["DCAA (Defense Contract Audit Agency)","DoD agency that audits contractor cost representations and indirect rate structures.","10 USC 3841"],
        ["Truth in Negotiations Act (TINA)","Requires certified cost or pricing data for contracts above threshold ($2M).","10 USC 3702"],
        ["Service Contract Act (SCA)","Requires minimum wages and benefits for service employees on government contracts.","41 USC 6701"],
        ["Organizational Conflict of Interest (OCI)","Situation where contractor has unfair competitive advantage or impaired objectivity.","FAR 9.5"],
        ["Contractor Performance Assessment (CPARS)","Government system for evaluating and recording contractor past performance.","FAR 42.15"],
        ["System for Award Management (SAM)","Federal database where contractors register and maintain eligibility for awards.","FAR 4.1102"],
        ["Small Business Subcontracting Plan","Required plan for large businesses to subcontract to small, disadvantaged, WOSB firms.","FAR 19.702"]
      ]},
      {name:"BUSINESS DEVELOPMENT & CAPTURE",terms:[
        ["Pwin (Probability of Win)","Assessed likelihood of winning a competitive pursuit, scored 0-100%.","Shipley"],
        ["Capture Plan","Structured plan to position for and win a specific opportunity, per Shipley methodology.","Shipley"],
        ["Gate Review","Decision point in capture process where leadership evaluates bid/no-bid or pursue/drop.","Shipley"],
        ["Price to Win (PTW)","Estimated price point needed to beat competitors while maintaining acceptable margins.","Shipley"],
        ["Past Performance","Contractor track record on prior contracts, evaluated via CPARS and proposals.","FAR 15.305"],
        ["Teaming Agreement","Formal agreement between companies to jointly pursue and perform on a contract.","General"],
        ["B&P (Bid & Proposal)","Internal costs of preparing proposals for government opportunities. Recovered via indirect rates.","FAR 31.205-18"],
        ["Pipeline Coverage","Ratio of total qualified opportunities to AOP target. Shipley recommends 3-5x.","Shipley"]
      ]},
      {name:"RISK & OPPORTUNITY MANAGEMENT",terms:[
        ["Risk","A potential future event that would negatively impact contract revenue or execution.","PMBOK"],
        ["Opportunity","A potential future event that would positively increase contract revenue or scope.","PMBOK"],
        ["R&O (Risk & Opportunity)","Combined assessment of risks and opportunities affecting revenue forecast.","Internal Planning"],
        ["Risk Register","Formal tracking document listing identified risks, likelihood, impact, and mitigations.","PMBOK"],
        ["Risk Mitigation","Actions taken to reduce the probability or impact of an identified risk.","PMBOK"],
        ["Risk Burn-Down","Progressive reduction of risk exposure as mitigation actions take effect over time.","PMBOK"],
        ["Management Reserve","Budget set aside for unknown unknowns, not allocated to specific contract tasks.","EVM / PMBOK"],
        ["Contingency","Budget set aside for identified risks, allocated based on probability and impact assessment.","PMBOK"],
        ["Schedule Risk","Risk of delays in contract performance milestones or deliverable timelines.","PMBOK"],
        ["Funding Risk","Risk that government will not obligate planned funding levels for a contract period.","FAR 32.7"],
        ["Staffing Risk","Risk of inability to recruit, retain, or clear personnel needed for contract performance.","Internal"],
        ["Recompete Risk","Risk of losing an incumbent contract during competitive re-procurement.","Internal"],
        ["Protest Risk","Risk that a competitor files a GAO or Court of Federal Claims bid protest.","GAO"],
        ["Scope Creep","Uncontrolled expansion of contract work beyond original scope without corresponding funding.","PMBOK"],
        ["Stop Work Risk","Risk of government-directed work stoppage due to funding gaps or continuing resolution.","FAR 42.1303"],
        ["Subcontractor Risk","Risk from subcontractor performance, financial stability, or compliance failures.","FAR 44.2"],
        ["Compliance Risk","Risk of non-compliance with FAR, DFARS, CAS, or other regulatory requirements.","FAR / DFARS"],
        ["Transition Risk","Risk during contract startup or handover period where performance may be degraded.","Internal"]
      ]}
    ];

    return h("div",null,
      // Sources table
      h("div",{style:{background:X.cd,borderRadius:10,border:"1px solid "+X.bd,marginBottom:20,overflow:"hidden"}},
        h("div",{style:{padding:"12px 18px",borderBottom:"1px solid "+X.bd}},h("span",{style:{fontWeight:600,fontSize:14,color:X.h}},"Sources ("+sources.length+")")),
        h("div",{style:{padding:16,overflowX:"auto"}},
          h("table",{style:{width:"100%",borderCollapse:"collapse",fontSize:11}},
            h("thead",null,h("tr",{style:{borderBottom:"2px solid "+X.bd}},
              h("th",{style:{padding:"8px 10px",textAlign:"left",color:X.t,fontWeight:600,fontSize:11,textTransform:"uppercase"}},"Source"),
              h("th",{style:{padding:"8px 10px",textAlign:"left",color:X.t,fontWeight:600,fontSize:11,textTransform:"uppercase"}},"URL")
            )),
            h("tbody",null,sources.map(function(s){
              return h("tr",{key:s[0],style:{borderBottom:"1px solid "+X.bd}},
                h("td",{style:{padding:"6px 10px",color:X.h,fontWeight:500}},s[0]),
                h("td",{style:{padding:"6px 10px"}},h("a",{href:s[1],target:"_blank",rel:"noopener noreferrer",style:{color:X.bl,textDecoration:"none",fontSize:11}},s[1]))
              );
            }))
          )
        )
      ),
      // Definitions by category
      CATS.map(function(cat) {
        var key = "def-"+cat.name;
        return Section(cat.name+" ("+cat.terms.length+")", key,
          h("table",{style:{width:"100%",borderCollapse:"collapse",fontSize:11}},
            h("thead",null,h("tr",{style:{borderBottom:"2px solid "+X.bd}},
              h("th",{style:{padding:"8px 8px",textAlign:"left",color:X.t,fontWeight:600,fontSize:11,textTransform:"uppercase",width:"20%"}},"Term"),
              h("th",{style:{padding:"8px 8px",textAlign:"left",color:X.t,fontWeight:600,fontSize:11,textTransform:"uppercase",width:"55%"}},"Definition"),
              h("th",{style:{padding:"8px 8px",textAlign:"left",color:X.t,fontWeight:600,fontSize:11,textTransform:"uppercase",width:"25%"}},"Source")
            )),
            h("tbody",null,cat.terms.map(function(t){
              return h("tr",{key:t[0],style:{borderBottom:"1px solid "+X.bd}},
                h("td",{style:{padding:"6px 8px",color:X.h,fontWeight:600,verticalAlign:"top"}},t[0]),
                h("td",{style:{padding:"6px 8px",color:X.m,lineHeight:1.5}},t[1]),
                h("td",{style:{padding:"6px 8px",color:X.t,fontSize:11}},t[2])
              );
            }))
          ),
          cat.terms.length
        );
      })
    );
  };

  // ===================== MAIN RENDER =====================
  var TABS = ["waterfall","execution","capture","p2","definitions"];
  var TAB_LABELS = {"waterfall":"Contract Waterfall","execution":"AOP Execution","capture":"AOP Capture","p2":"P2 Financials","definitions":"Definitions"};

  return h("div",{style:{}},
    // Tab toggle + year selector
    h("div",{style:{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:20,flexWrap:"wrap",gap:12}},
      h("div",{style:{display:"flex",gap:4}},
h("button",{onClick:function(){
  var payload = {action:"analyze_financials",data:{ytd_rev:5200000,ytd_exp:4300000,ytd_profit:900000,margin:17.3,funded_backlog:23400000,contracts:17}};
  fetch("/api/gda-ai-chat",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(payload)}).then(function(r){return r.json();}).then(function(d){alert(d.response||d.text||"Analysis complete");}).catch(function(e){alert("Error: "+e.message);});
},style:{padding:"8px 16px",background:"#1B2A4A",color:"#fff",border:"none",borderRadius:6,fontSize:12,fontWeight:700,cursor:"pointer",marginRight:12}},"AI Analyze"),
                TABS.map(function(t) {
          return h("button",{key:t,onClick:function(){setTab(t);if(t==='capture'){fetch('/api/gda-capture-plan',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'list',limit:50})}).then(function(r){return r.json();}).then(function(d){var rows=d.plans||d.data||[];if(rows.length>0){var mapped=rows.map(function(r,i){var pd=typeof r.plan_data==='object'&&r.plan_data||{};try{typeof r.plan_data==='string'&&(pd=JSON.parse(r.plan_data));}catch(e){}return{id:r.id||i+1,client:r.agency||pd.agency||'Unknown',name:pd.codename||r.opportunity||'Untitled',stage:pd.stage||'Go/No-Go',amount:parseFloat(String(pd.total_contract_value||r.contract_value||'0').replace(/[$,]/g,''))/1e6||0,pwin:parseInt(pd.pwin)||0,rfi:pd.rfp_date||'',rfq:'',award:pd.stage==='Award'?'Awarded':'',notes:pd.priority||''};});setCaptureRows(mapped);}}).catch(function(){});}},style:{padding:"10px 20px",borderRadius:8,border:"1px solid "+(tab===t?X.rd:X.bd),background:tab===t?X.rd:"#fff",color:tab===t?"#fff":X.t,cursor:"pointer",fontWeight:700,fontSize:12,textTransform:"uppercase",letterSpacing:0.5}},TAB_LABELS[t]);
        })
      ),
      tab !== "definitions" ? yearSelector() : null
    ),
    // Title
    h("div",{style:{marginBottom:20}},
      h("h2",{style:{fontSize:22,fontWeight:700,color:X.h,margin:0}},TAB_LABELS[tab]+" \u2014 "+(tab==="definitions"?"Reference":fyLabel)),
      h("div",{style:{fontSize:12,color:X.m,marginTop:4}},"Envision Innovative Solutions (OU3) \u2014 7% YoY Growth Target")
    ),
    // Tab content
    tab === "waterfall" ? waterfallTab() : null,
    tab === "execution" ? executionTab() : null,
    tab === "capture" ? captureTab() : null,
    tab === "p2" ? p2Tab() : null,
    tab === "definitions" ? definitionsTab() : null
  );
};
// === END AOP TRACKER ===




































// Action History Component (inline for App.jsx scope)
function ActionHistory({tab}) {
  var _h = React.useState([]); var items = _h[0]; var setItems = _h[1];
  var _o = React.useState(false); var open = _o[0]; var setOpen = _o[1];
  var _l = React.useState(false); var loading = _l[0]; var setLoading = _l[1];
  var _e = React.useState(null); var expanded = _e[0]; var setExpanded = _e[1];
  var load = function() { setLoading(true); api.post('gda-action-history',{action:'list',tab:tab,limit:20}).then(function(d){setItems(d.data||[]);setLoading(false);}).catch(function(){setItems([]);setLoading(false);}); };
  React.useEffect(function(){ if(open && items.length===0) load(); },[open]);
  var fmtDate = function(d) { if(!d)return''; var dt=new Date(d); var diff=Math.round((Date.now()-dt)/60000); if(diff<1)return'Just now'; if(diff<60)return diff+'m ago'; if(diff<1440)return Math.round(diff/60)+'h ago'; return dt.toLocaleDateString(); };
  return React.createElement('div',{style:{background:'#fff',border:'1px solid #e0e0e0',borderRadius:8,marginBottom:6,overflow:'hidden',marginTop:8,borderLeft:'4px solid #1a2744'}},
    React.createElement('div',{onClick:function(){setOpen(!open);},style:{display:'flex',justifyContent:'space-between',alignItems:'center',padding:'12px 20px',cursor:'pointer'}},
      React.createElement('h3',{style:{fontSize:16,fontWeight:700,color:'#1B2A4A',margin:0}},(open?'▼ ':'▶ ')+'History'),
      React.createElement('span',{style:{fontSize:11,color:'#9CA3AF'}},items.length>0?items.length+' saved':'Click to load')
    ),
    open && React.createElement('div',{style:{padding:'0 20px 16px',borderTop:'1px solid #E8ECF1'}},
      loading ? React.createElement('div',{style:{textAlign:'center',padding:16,fontSize:12,color:'#6B7280'}},'Loading...')
      : items.length===0 ? React.createElement('div',{style:{textAlign:'center',padding:16,fontSize:12,color:'#9CA3AF'}},'No saved actions yet.')
      : React.createElement('div',{style:{display:'flex',flexDirection:'column',gap:6,marginTop:10}},
          items.map(function(item){
            return React.createElement('div',{key:item.id,style:{padding:'10px 14px',background:'#FAFBFC',borderRadius:8,borderLeft:'3px solid #D14A2A',cursor:'pointer'},onClick:function(){setExpanded(expanded===item.id?null:item.id);}},
              React.createElement('div',{style:{display:'flex',justifyContent:'space-between',alignItems:'center'}},
                React.createElement('div',{style:{fontSize:13,fontWeight:600,color:'#1B2A4A'}},item.title||item.action_type||'Action'),
                React.createElement('span',{style:{fontSize:10,color:'#9CA3AF'}},fmtDate(item.created_at))
              ),
              React.createElement('div',{style:{fontSize:11,color:'#6B7280',marginTop:2}},item.action_type),
              expanded===item.id && item.output_data && React.createElement('div',{style:{marginTop:8,padding:'8px 10px',background:'#F0F4FF',borderRadius:6,fontSize:11,color:'#374151',maxHeight:200,overflow:'auto',whiteSpace:'pre-wrap'}},
                typeof item.output_data==='string'?item.output_data:JSON.stringify(item.output_data,null,2).substring(0,1000))
            );
          })
        )
    )
  );
}
// ── DAILY BRIEF (S-133) ────────────────────────────────────
function DailyBrief() {
  var _brief = useState(null); var brief = _brief[0]; var setBrief = _brief[1];
  var _loading = useState(false); var loading = _loading[0]; var setLoading = _loading[1];
  var _error = useState(null); var error = _error[0]; var setError = _error[1];
  var API = '/api';
  var fetchBrief = function() {
    setLoading(true); setError(null);
    fetch(API + '/gda-morning-briefing', { method:'GET', headers:{'Content-Type':'application/json'} })
      .then(function(r){return r.json();})
      .then(function(d){ setBrief(d.briefing || d); setLoading(false); })
      .catch(function(e){ setError(e.message); setLoading(false); });
  };
  useEffect(function(){ fetchBrief(); },[]);
  var S = { card:{background:'#fff',border:'1px solid #E8ECF1',borderRadius:10,padding:'18px 20px',marginBottom:14}, h2:{margin:'0 0 16px',color:'#1B2A4A',fontSize:22,fontWeight:700}, h3:{margin:'0 0 10px',color:'#1B2A4A',fontSize:15,fontWeight:600}, sub:{fontSize:12,color:'#6B7280',marginBottom:8}, pill:function(c){return{display:'inline-block',padding:'2px 10px',borderRadius:12,fontSize:11,fontWeight:600,color:'#fff',background:c,marginRight:6};}, link:{color:'#2563EB',fontSize:12,cursor:'pointer',fontWeight:600} };
  if (loading) return React.createElement('div',{style:{padding:24,textAlign:'center',color:'#6B7280'}},'Generating Morning Brief...');
  if (error) return React.createElement('div',{style:{padding:24}},React.createElement('div',{style:{color:'#DC2626',marginBottom:12}},'Error: '+error),React.createElement('button',{onClick:fetchBrief,style:{padding:'8px 16px',background:'#1B2A4A',color:'#fff',border:'none',borderRadius:6,cursor:'pointer'}},'Retry'));
  if (!brief) return React.createElement('div',{style:{padding:24,color:'#6B7280'}},'No briefing data available.');
  return React.createElement('div',{style:{padding:24,fontFamily:'Inter,sans-serif',maxWidth:960}},
    React.createElement('div',{style:{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:20}},
      React.createElement('div',null,React.createElement('div',{style:S.h2},'\u2600\ufe0f Morning Intelligence Brief'),React.createElement('div',{style:S.sub},brief.generated_at ? new Date(brief.generated_at).toLocaleDateString('en-US',{weekday:'long',year:'numeric',month:'long',day:'numeric'}) : new Date().toLocaleDateString())),
      React.createElement('div',{style:{display:'flex',gap:8}},React.createElement('button',{onClick:fetchBrief,style:{padding:'8px 16px',background:'#1B2A4A',color:'#fff',border:'none',borderRadius:6,cursor:'pointer',fontSize:12}},'\u21bb Refresh'),React.createElement('button',{onClick:function(){setLoading(true);setError(null);fetch('/api/gda-morning-briefing',{method:'GET',headers:{'Content-Type':'application/json'}}).then(function(r){return r.json();}).then(function(d){setBrief(d.briefing||d);setLoading(false);}).catch(function(e){setError(e.message);setLoading(false);});},style:{padding:'8px 16px',background:'#D14A2A',color:'#fff',border:'none',borderRadius:6,cursor:'pointer',fontSize:12}},'✨ Generate Fresh'))
    ),
    React.createElement('div',{style:{...S.card,whiteSpace:'pre-wrap',fontSize:13,color:'#374151',lineHeight:1.7,fontFamily:'Inter,sans-serif'}},
      (brief.briefing||'').split('\n').map(function(line,i){
        if(/^\*\*(.+)\*\*$/.test(line.trim())) return React.createElement('div',{key:i,style:{fontWeight:700,fontSize:14,color:'#1B2A4A',marginTop:14,marginBottom:4}},line.trim().replace(/\*\*/g,''));
        if(/^#+\s/.test(line)) return React.createElement('div',{key:i,style:{fontWeight:700,fontSize:14,color:'#1B2A4A',marginTop:14,marginBottom:4}},line.replace(/^#+\s/,''));
        if(line.trim()==='') return React.createElement('div',{key:i,style:{height:6}});
        return React.createElement('div',{key:i,style:{marginBottom:2}},line);
      })
    )
  );
}
// === SEMANTIC SEARCH BAR ===
function SemanticSearchBar() {
  var h = React.createElement;
  var _q = useState(''); var query = _q[0]; var setQuery = _q[1];
  var _r = useState([]); var results = _r[0]; var setResults = _r[1];
  var _l = useState(false); var loading = _l[0]; var setLoading = _l[1];
  var _o = useState(false); var open = _o[0]; var setOpen = _o[1];
  var timer = React.useRef(null);
  var doSearch = function(q) {
    if (!q || q.length < 3) { setResults([]); return; }
    setLoading(true);
    fetch('/api/gda-semantic-search', {
      method: 'POST', headers: {'Content-Type':'application/json'},
      body: JSON.stringify({query: q, limit: 8, threshold: 0.35})
    }).then(function(r){return r.json();}).then(function(d){
      setResults(d.results || []);
      setLoading(false);
    }).catch(function(){ setLoading(false); });
  };
  var onChange = function(e) {
    var v = e.target.value; setQuery(v); setOpen(true);
    if (timer.current) clearTimeout(timer.current);
    timer.current = setTimeout(function(){ doSearch(v); }, 400);
  };
  var simColor = function(s) { var v=parseFloat(s); return v>0.6?'#2F5C1F':v>0.45?'#B06D32':'#718096'; };
  var typeIcon = function(t) { return t==='capture_plan'?'\ud83d\udcCB':'\ud83d\udcC4'; };
  return h('div', {style:{position:'relative',width:'100%',maxWidth:480}},
    h('div',{style:{display:'flex',alignItems:'center',background:'#fff',border:'1px solid #E2E8F0',borderRadius:8,padding:'0 12px',boxShadow:'0 1px 3px rgba(0,0,0,0.06)'}},
      h('span',{style:{color:'#94A3B8',fontSize:14,marginRight:8}},'\ud83d\udd0d'),
      h('input',{value:query,onChange:onChange,onFocus:function(){if(results.length)setOpen(true);},onBlur:function(){setTimeout(function(){setOpen(false);},200);},placeholder:'Semantic search across 700+ opps & capture plans...',style:{flex:1,border:'none',outline:'none',padding:'10px 0',fontSize:13,color:'#1a2744',background:'transparent'}}),
      loading && h('span',{style:{fontSize:11,color:'#94A3B8'}},'...')
    ),
    open && results.length > 0 && h('div',{style:{position:'absolute',top:'100%',left:0,right:0,background:'#fff',border:'1px solid #E2E8F0',borderRadius:8,marginTop:4,maxHeight:360,overflowY:'auto',boxShadow:'0 8px 24px rgba(0,0,0,0.12)',zIndex:999}},
      results.map(function(r,i){
        return h('div',{key:i,onClick:function(){
          if(r.source_type==='opportunity' && r.source_id){
            window.gdaNav = window.gdaNav || {}; window.gdaNav.oppTarget = {id:parseInt(r.source_id),title:r.title};
            if(window._gdaNavigate) window._gdaNavigate('opp-tracker');
          }
          setOpen(false);
        },style:{padding:'10px 14px',borderBottom:'1px solid #F1F5F9',cursor:'pointer',display:'flex',gap:10,alignItems:'flex-start'}},
          h('span',{style:{fontSize:16,flexShrink:0,marginTop:2}},typeIcon(r.source_type)),
          h('div',{style:{flex:1,minWidth:0}},
            h('div',{style:{fontSize:12,fontWeight:600,color:'#1a2744',overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}},r.title||'Untitled'),
            h('div',{style:{fontSize:11,color:'#718096',marginTop:2,overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}},r.text ? r.text.substring(0,80) : '')
          ),
          h('div',{style:{textAlign:'right',flexShrink:0}},
            h('div',{style:{fontSize:11,fontWeight:700,color:simColor(r.similarity)}},Math.round(parseFloat(r.similarity)*100)+'%'),
            h('div',{style:{fontSize:10,color:'#94A3B8',marginTop:1}},r.source_type==='capture_plan'?'Capture':'Opp')
          )
        );
      })
    )
  );
}

const PAGES = {
  "daily-brief": DailyBrief,
  // REMOVED: 'opp-search': React.memo(OppSearch),
  launchpad: React.memo(Launchpad),
  'opp-tracker': React.memo(OppTracker),
  ooda: React.memo(OodaLoop),
  'red-team': React.memo(RedTeam),
  'comp-intel': React.memo(CompIntel),
  'intel-feed': React.memo(IntelFeedPage),
  'doc-hub': React.memo(DocumentHub),
  presentations: React.memo(Presentations),
  directions: React.memo(Directions),
  risk: React.memo(RiskRegister),
  'ai-agent': React.memo(AIAgent),
  actions: React.memo(ActionItems),
  sitrep: React.memo(DailySitrep),
  email: React.memo(EmailDrafter),
  'doc-rag': React.memo(DocRAG),
  ops: React.memo(OpsDashboard),
  'competitor-watchlist': React.memo(CompetitorWatchlist),
  'pwin-calculator': React.memo(PwinCalculator),
  'capture-plan': React.memo(CapturePlan),
  'deep-research': React.memo(DeepResearch),
  'proposal-factory': React.memo(ProposalFactory),
  'compliance-matrix': React.memo(ComplianceMatrix),
  'relationship-tracker': React.memo(RelationshipTracker),
  'win-loss': React.memo(WinLossDB),
  'platform-health': React.memo(PlatformHealth),
  'qa-center': React.memo(QACenter),
  'prompt-architect': React.memo(PromptArchitect),
  'help': React.memo(HelpPage),
    'bid-strategy': BidStrategy,
    'aop-tracker': AopTrackerPage,
    'meeting-notes': MeetingNotes,
};

var _gdaContext = { lastOodaTarget: null, lastOodaResult: null, selectedOpp: null, recentActions: [] };
window._gdaContext = _gdaContext;
window._gdaUpdateContext = function(key, value) { window._gdaContext[key] = value; };



// ===== FLOATING CHAT WIDGET =====
const ChatWidget = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState([
    { role: 'assistant', text: 'GDA AI online. Toggle mode above. Upload docs for Red Team analysis.' }
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [chatMode, setChatMode] = useState('gda');
  const messagesEndRef = useRef(null);
  const fileInputRef = useRef(null);
  const fileRef = useRef(null);
  const scrollToBottom = () => { messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' }); };
  useEffect(() => { scrollToBottom(); }, [messages]);

  const parseReply = (data) => {
    if (!data) return 'No response';
    if (typeof data === 'string') {
      try { const p = JSON.parse(data); return p.response || p.reply || p.Summary || data; } catch(e) { return data; }
    }
    if (data.reply) return data.reply;
    if (data.response) {
      if (typeof data.response === 'string') {
        try { const p = JSON.parse(data.response); return p.response || p.Summary || data.response; } catch(e) { return data.response; }
      }
      return JSON.stringify(data.response);
    }
    return data.output || data.Summary || JSON.stringify(data);
  };

  const sendMessage = async () => {
    if (!input.trim() || loading) return;
    const userMsg = input.trim();
    setInput('');
    setMessages(prev => [...prev, { role: 'user', text: userMsg }]);
    setLoading(true);
    try {
      const resp = await api.post('gda-chat-v2', {
        message: userMsg,
        session_id: 'gda-chat-v2-' + Date.now(),
        mode: chatMode === 'general' ? 'general-chat' : 'general'
      });
      setMessages(prev => [...prev, { role: 'assistant', text: parseReply(resp) }]);
    } catch (err) {
      setMessages(prev => [...prev, { role: 'assistant', text: 'Error ' + (err?.response?.status || '') + ': ' + (err.message || 'Failed') }]);
    }
    setLoading(false);
  };

  const handleFile = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setMessages(prev => [...prev, { role: 'user', text: '\ud83d\udcc4 ' + file.name }]);
    setLoading(true);
    try {
      const text = await file.text();
      const resp = await api.post('gda-red-team', { rfp_text: text, filename: file.name });
      const d = resp.data;
      let reply = d?.analysis || d?.response || d?.reply || (typeof d === 'string' ? d : JSON.stringify(d, null, 2));
      if (typeof reply === 'object') reply = JSON.stringify(reply, null, 2);
      setMessages(prev => [...prev, { role: 'assistant', text: '\ud83d\udea9 RED TEAM\n\n' + reply }]);
    } catch (err) {
      setMessages(prev => [...prev, { role: 'assistant', text: 'Upload error: ' + (err.message || 'Failed') }]);
    }
    setLoading(false);
    if (fileRef.current) fileRef.current.value = '';
  };

  const handleKeyDown = (e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendMessage(); } };

  if (!isOpen) return (
    <div onClick={() => setIsOpen(true)} style={{
      position:'fixed',bottom:24,right:24,zIndex:99999,width:60,height:60,borderRadius:'50%',
      background:'linear-gradient(135deg,#D14A2A,#B06D32)',display:'flex',alignItems:'center',
      justifyContent:'center',cursor:'pointer',boxShadow:'0 4px 20px rgba(0,0,0,0.3)',
      transition:'transform 0.2s',color:'#fff',fontSize:28
    }} onMouseEnter={e=>e.currentTarget.style.transform='scale(1.1)'}
       onMouseLeave={e=>e.currentTarget.style.transform='scale(1)'}>
      &#x1F4AC;
    </div>
  );

  return (
    <div style={{position:'fixed',bottom:24,right:24,zIndex:99999,width:420,height:580,borderRadius:16,
      background:'#1a1a2e',border:'1px solid #333',display:'flex',flexDirection:'column',
      boxShadow:'0 8px 40px rgba(0,0,0,0.5)',overflow:'hidden'}}>
      <div style={{padding:'10px 16px',background:'linear-gradient(135deg,#D14A2A,#B06D32)',
        display:'flex',justifyContent:'space-between',alignItems:'center'}}>
        <div style={{display:'flex',alignItems:'center',gap:8}}>
          <span style={{color:'#fff',fontWeight:700,fontSize:14}}>GDA AI</span>
          <div style={{display:'flex',background:'rgba(0,0,0,0.3)',borderRadius:6,overflow:'hidden'}}>
            <div onClick={()=>setChatMode('gda')} style={{padding:'3px 10px',fontSize:11,cursor:'pointer',
              color:'#fff',fontWeight:chatMode==='gda'?700:400,
              background:chatMode==='gda'?'rgba(255,255,255,0.2)':'transparent'}}>GDA</div>
            <div onClick={()=>setChatMode('general')} style={{padding:'3px 10px',fontSize:11,cursor:'pointer',
              color:'#fff',fontWeight:chatMode==='general'?700:400,
              background:chatMode==='general'?'rgba(255,255,255,0.2)':'transparent'}}>General</div>
          </div>
        </div>
        <span onClick={()=>setIsOpen(false)} style={{color:'#fff',cursor:'pointer',fontSize:20,opacity:0.8}}>&times;</span>
      </div>
      <div style={{flex:1,overflowY:'auto',padding:14,display:'flex',flexDirection:'column',gap:10}}>
        {messages.map((m,i) => (
          <div key={i} style={{alignSelf:m.role==='user'?'flex-end':'flex-start',maxWidth:'85%',
            padding:'10px 14px',borderRadius:12,
            background:m.role==='user'?'#D14A2A':'#2a2a4a',
            color:'#fff',fontSize:13,lineHeight:1.5,whiteSpace:'pre-wrap',wordBreak:'break-word'}}>{m.text}</div>
        ))}
        {loading && <div style={{alignSelf:'flex-start',padding:'10px 14px',borderRadius:12,
          background:'#2a2a4a',color:'#888',fontSize:13}}>Thinking...</div>}
        <div ref={messagesEndRef}/>
      </div>
      <div style={{padding:10,borderTop:'1px solid #333',display:'flex',gap:6,background:'#1a1a2e',alignItems:'center'}}>
        <input type="file" ref={fileRef} onChange={handleFile} style={{display:'none'}} accept=".txt,.pdf,.doc,.docx,.csv,.json,.md"/>
        <div onClick={()=>fileRef.current?.click()} style={{width:36,height:36,borderRadius:8,
          background:'#2a2a4a',display:'flex',alignItems:'center',justifyContent:'center',
          cursor:'pointer',flexShrink:0,fontSize:16}} title="Upload document">&#x1F4CE;</div>
        <input value={input} onChange={e=>setInput(e.target.value)} onKeyDown={handleKeyDown}
          placeholder={chatMode==='gda'?'Ask GDA AI...':'Ask anything...'}
          style={{flex:1,padding:'9px 12px',borderRadius:8,border:'1px solid #444',
            background:'#0d0d1a',color:'#fff',fontSize:13,outline:'none'}}/>
        <button onClick={sendMessage} disabled={loading} style={{padding:'9px 16px',borderRadius:8,
          border:'none',background:loading?'#666':'#D14A2A',color:'#fff',
          cursor:loading?'not-allowed':'pointer',fontWeight:600,fontSize:13,flexShrink:0}}>Send</button>
      </div>
    </div>
  );
};
// ===== END FLOATING CHAT WIDGET =====


export default function App() {
  var _expired = React.useState(false); var sessionExpired = _expired[0]; var setSessionExpired = _expired[1];
  React.useEffect(function() {
    var timeout;
    var resetTimer = function() { clearTimeout(timeout); timeout = setTimeout(function() { setSessionExpired(true); }, 30 * 60 * 1000); };
    window.addEventListener('mousemove', resetTimer);
    window.addEventListener('keydown', resetTimer);
    window.addEventListener('click', resetTimer);
    resetTimer();
    return function() { clearTimeout(timeout); window.removeEventListener('mousemove', resetTimer); window.removeEventListener('keydown', resetTimer); window.removeEventListener('click', resetTimer); };
  }, []);
  if (sessionExpired) {
    return React.createElement('div', {style:{display:'flex',flexDirection:'column',alignItems:'center',justifyContent:'center',height:'100vh',background:'#1B2A4A',color:'#fff'}},
      React.createElement('div', {style:{fontSize:48,marginBottom:16}}, '\u1F512'),
      React.createElement('h1', {style:{fontSize:28,marginBottom:16,fontFamily:FONT}}, 'Session Expired'),
      React.createElement('p', {style:{fontSize:14,color:'#9CA3AF',marginBottom:24}}, 'Your session has timed out due to 30 minutes of inactivity.'),
      React.createElement('button', {onClick:function(){setSessionExpired(false);}, style:{background:'#D14A2A',color:'#fff',border:'none',padding:'12px 32px',borderRadius:8,fontSize:14,cursor:'pointer',fontWeight:600}}, 'Resume Session')
    );
  }
  const [page, setPage] = useState('launchpad');
  const [visited,setVisited]=useState(()=>new Set(['launchpad']));
  const navigate=useCallback((p)=>{window.history.pushState({page:p},'','#'+p);setPage(p);setVisited(v=>{const n=new Set(v);n.add(p);return n;});},[]); 
  React.useEffect(()=>{window._gdaNavigate=navigate;},[navigate]);

  React.useEffect(function() {
    function handlePop(e) {
      if (e.state && e.state.page) {
        setPage(e.state.page);
        setVisited(function(v) { var n = new Set(v); n.add(e.state.page); return n; });
      }
    }
    window.addEventListener('popstate', handlePop);
    var hash = window.location.hash.replace('#', '') || 'launchpad';
    window.history.replaceState({ page: hash }, '', '#' + hash);
    if (hash !== 'launchpad') { setPage(hash); setVisited(function(v) { var n = new Set(v); n.add(hash); return n; }); }
    return function() { window.removeEventListener('popstate', handlePop); };
  }, []);

  const now = new Date();
  const dateStr = now.toLocaleDateString('en-US', { weekday:'short', month:'short', day:'numeric', year:'numeric' });

  return (
    <ErrorBoundary>
      <style>{css}</style>
      <div style={S.app}>
        {/* Header */}
        <div style={S.header}>
          <div style={{flex:1}}>
            <div style={S.headerTitle}>GDA Command Center</div>
            <div style={S.headerSub}><a href="https://envision-is.com" target="_blank" rel="noopener noreferrer" style={{color:ACCENT,textDecoration:'none',fontWeight:600}}>ENVISION</a>{" \u00b7 "}<a href="https://pd-sys.net" target="_blank" rel="noopener noreferrer" style={{color:ACCENT,textDecoration:'none',fontWeight:600}}>PD SYSTEMS</a>{" \u00b7 "}<a href="https://riverstonesolutions.com" target="_blank" rel="noopener noreferrer" style={{color:ACCENT,textDecoration:'none',fontWeight:600}}>RIVERSTONE</a></div>
          </div>
          <div style={{flex:2,display:'flex',alignItems:'center',justifyContent:'center',gap:24,position:'relative'}}>
            <div style={{textAlign:'center'}}><div style={{fontSize:10,fontWeight:600,color:'#6B7280',letterSpacing:1,textTransform:'uppercase'}}>ORDERS</div><div style={{fontSize:16,fontWeight:700,color:'#1B2A4A'}}>$42.8M</div></div>
            <div style={{width:1,height:28,background:'#E5E7EB'}}></div>
            <div style={{textAlign:'center'}}><div style={{fontSize:10,fontWeight:600,color:'#6B7280',letterSpacing:1,textTransform:'uppercase'}}>SALES</div><div style={{fontSize:16,fontWeight:700,color:'#1B2A4A'}}>$5.2M</div></div>
            <div style={{width:1,height:28,background:'#E5E7EB'}}></div>
            <div style={{textAlign:'center'}}><div style={{fontSize:10,fontWeight:600,color:'#6B7280',letterSpacing:1,textTransform:'uppercase'}}>EBIT</div><div style={{fontSize:16,fontWeight:700,color:'#2F5C1F'}}>$0.9M</div></div>
            <div style={{width:1,height:28,background:'#E5E7EB'}}></div>
            <div style={{textAlign:'center'}}><div style={{fontSize:10,fontWeight:600,color:'#6B7280',letterSpacing:1,textTransform:'uppercase'}}>ROS</div><div style={{fontSize:16,fontWeight:700,color:'#2F5C1F'}}>{(0.9/5.2*100).toFixed(1)+'%'}</div></div>
            <div style={{width:1,height:28,background:'#E5E7EB'}}></div>
            <div style={{textAlign:'center'}}><div style={{fontSize:10,fontWeight:600,color:'#6B7280',letterSpacing:1,textTransform:'uppercase'}}>FUNDED BACKLOG</div><div style={{fontSize:16,fontWeight:700,color:'#1B2A4A'}}>$23.4M</div></div>
            <div style={{width:1,height:28,background:'#E5E7EB'}}></div>
            <div style={{textAlign:'center',position:'relative'}}><div style={{fontSize:10,fontWeight:600,color:'#6B7280',letterSpacing:1,textTransform:'uppercase'}}>BACKLOG</div><span style={{position:'absolute',top:0,right:-18,display:'inline-flex',alignItems:'center',justifyContent:'center',width:13,height:13,borderRadius:'50%',background:'#3B82F6',color:'#FFFFFF',fontSize:7,fontWeight:700,cursor:'pointer'}} onClick={function(e){e.stopPropagation();var el=document.getElementById('kpi-help-tip');if(el)el.style.display=el.style.display==='none'?'block':'none';}}>i</span><div style={{fontSize:16,fontWeight:700,color:'#1B2A4A'}}>$78.1M</div></div>
            <div id="kpi-help-tip" style={{display:'none',position:'absolute',top:'100%',left:'50%',transform:'translateX(-50%)',marginTop:8,width:520,background:'#FFFFFF',border:'1px solid #E5E7EB',borderRadius:8,boxShadow:'0 4px 12px rgba(0,0,0,0.1)',padding:16,zIndex:999,fontSize:11,color:'#374151',lineHeight:'1.5'}}>
              <div style={{fontWeight:700,fontSize:12,color:'#1B2A4A',marginBottom:8,borderBottom:'1px solid #E5E7EB',paddingBottom:6}}>KPI Definitions</div>
              <div style={{marginBottom:8}}><span style={{fontWeight:700,color:'#1B2A4A'}}>ORDERS:</span> The total value of new contract awards, task orders, and option exercises booked during a given period. Orders represent future revenue commitments and are the primary indicator of business development performance.</div>
              <div style={{marginBottom:8}}><span style={{fontWeight:700,color:'#1B2A4A'}}>SALES:</span> Revenue recognized for work actually performed and billed during a given period. Sales reflect current execution against the backlog of orders and are the top-line measure of operational output.</div>
              <div style={{marginBottom:8}}><span style={{fontWeight:700,color:'#1B2A4A'}}>EBIT:</span> Earnings Before Interest and Taxes, calculated as revenue minus all direct and indirect operating costs but before financing costs and tax obligations. EBIT isolates core operating profitability from capital structure and tax decisions.</div>
              <div><span style={{fontWeight:700,color:'#1B2A4A'}}>ROS:</span> Return on Sales, calculated as EBIT divided by Sales and expressed as a percentage. ROS measures how efficiently a company converts revenue into operating profit, with higher percentages indicating stronger pricing power, cost discipline, or favorable contract mix.</div>
              <div style={{marginBottom:8}}><span style={{fontWeight:700,color:'#1B2A4A'}}>FUNDED BACKLOG:</span> The portion of total contract backlog for which funding has been obligated by the government. Funded backlog represents near-term revenue certainty and is the primary predictor of short-term sales performance.</div>
              <div><span style={{fontWeight:700,color:'#1B2A4A'}}>BACKLOG:</span> The total unexecuted value of all active contracts, including both funded and unfunded portions. Backlog represents the full pipeline of committed future revenue and is the primary measure of long-term business sustainability.</div>
            </div>
          </div>
          <div style={{flex:1,display:'flex',alignItems:'center',justifyContent:'flex-end',gap:12}}>{React.createElement(SemanticSearchBar)}<span style={{fontSize:12,color:'#6B7280',whiteSpace:'nowrap'}}>{dateStr}</span></div>
        </div>

        {/* Body */}
        <div style={S.body}>
          <div style={S.sidebar}>
            {NAV_ITEMS.map((item, idx) => (
              item.type === 'divider'
                ? <div key={'div-'+idx} style={{padding: item.label ? '12px 16px 4px' : '4px 0', fontSize:11, fontWeight:600, color:'#9CA3AF', textTransform:'uppercase', letterSpacing:1, borderTop: idx > 0 ? '1px solid #E5E7EB' : 'none', marginTop: idx > 0 ? 8 : 0}}>{item.label}</div>
                : <div key={item.id} style={S.sidebarItem(page===item.id)} onClick={()=>navigate(item.id)}>
                    <span>{item.icon}</span><span>{item.label}</span>
                  </div>
            ))}
            <SidebarQuickAdd />
            <SidebarHelp />
            <SidebarQuickRisk />
          </div>

          {/* Main Content */}
          <div style={S.main}>
            {Object.entries(PAGES).map(([id,PC])=>visited.has(id)?<div key={id} style={page===id?{}:{display:'none'}}><PC/>{['sitrep','email','ooda','compliance-matrix','pwin-calculator','comp-intel','competitor-watchlist','risk','doc-rag','capture-plan','red-team','intel-feed','meeting-notes','bid-strategy','presentations','doc-hub','prompt-architect','ai-agent','actions','aop-tracker','financial-bible','deep-research','proposal-factory'].includes(id) && page===id ? React.createElement(ActionHistory,{tab:id}) : null}</div>:null)}
          </div>
        </div>
      </div>
    <ChatWidget />
    </ErrorBoundary>
  );
}

