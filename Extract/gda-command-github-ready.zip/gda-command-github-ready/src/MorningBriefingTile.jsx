import React, { useEffect, useState } from 'react';

function MorningBriefingTile() {
  const [data, setData] = useState(null);
  const [err, setErr] = useState(null);
  const [loading, setLoading] = useState(true);

  const load = async () => {
    setLoading(true);
    setErr(null);
    try {
      const res = await fetch('/api/gda-morning-briefing', {
        method: 'GET',
        headers: { 'Content-Type': 'application/json' },
      });
      if (!res.ok) throw new Error('HTTP ' + res.status);
      const json = await res.json();
      if (!json.ok || !json.briefing) throw new Error('No briefing yet');
      setData(json.briefing);
    } catch (e) {
      setErr(e.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); }, []);

  const renderBriefing = (text) => {
    if (!text) return null;
    return text.split('\n').filter(Boolean).map((line, i) => {
      const parts = line.split(/(\*\*[^*]+\*\*)/g);
      return (
        <p key={i} style={{ margin: '0.25rem 0', lineHeight: 1.5 }}>
          {parts.map((p, j) =>
            p.startsWith('**') && p.endsWith('**')
              ? <strong key={j}>{p.slice(2, -2)}</strong>
              : <span key={j}>{p}</span>
          )}
        </p>
      );
    });
  };

  const formatWhen = (iso) => {
    if (!iso) return '';
    const d = new Date(iso);
    return d.toLocaleString('en-US', {
      month: 'short', day: 'numeric',
      hour: 'numeric', minute: '2-digit',
      timeZone: 'America/New_York',
    }) + ' ET';
  };

  return (
    <div style={{
      background: '#fff',
      borderRadius: '8px',
      padding: '1.25rem',
      boxShadow: '0 1px 3px rgba(0,0,0,0.08)',
      border: '1px solid #e5e7eb',
      marginBottom: '1rem',
    }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: '0.75rem' }}>
        <h3 style={{ margin: 0, fontSize: '1.05rem', fontWeight: 600, color: '#111827' }}>
          Morning Intel Briefing
        </h3>
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
          {data && data.generated_at && (
            <span style={{ fontSize: '0.75rem', color: '#6b7280' }}>
              {formatWhen(data.generated_at)}
            </span>
          )}
          <button
            onClick={load}
            disabled={loading}
            style={{
              fontSize: '0.7rem', padding: '0.2rem 0.5rem',
              background: '#f3f4f6', border: '1px solid #d1d5db',
              borderRadius: '4px', cursor: loading ? 'wait' : 'pointer',
            }}
          >
            {loading ? '...' : 'Refresh'}
          </button>
        </div>
      </div>
      {loading && !data && (
        <div style={{ color: '#9ca3af', fontSize: '0.875rem' }}>Loading briefing...</div>
      )}
      {err && (
        <div style={{ color: '#dc2626', fontSize: '0.875rem' }}>
          {err === 'No briefing yet'
            ? 'No briefing yet - first run is at 6:00 AM ET.'
            : 'Error: ' + err}
        </div>
      )}
      {data && !err && (
        <div style={{ fontSize: '0.875rem', color: '#374151' }}>
          {renderBriefing(data.briefing)}
        </div>
      )}
    </div>
  );
}

export default MorningBriefingTile;
