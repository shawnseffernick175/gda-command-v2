#!/usr/bin/env python3
import sys
f='/opt/gda-command/src/App.jsx'
code=open(f).read()
o=code
code=code.replace("const total=items.length,open=items.filter(i=>(i.status||'open')==='open').length,done=items.filter(i=>i.status==='done').length,overdue=items.filter(i=>(i.status||'open')==='open'","const total=items.length,open=items.filter(i=>(i.status||'open').toLowerCase()==='open').length,done=items.filter(i=>(i.status||'').toLowerCase()==='done').length,overdue=items.filter(i=>(i.status||'open').toLowerCase()==='open'")
code=code.replace("status:item.status==='open'?'done':'open'","status:(item.status||'open').toLowerCase()==='open'?'done':'open'")
code=code.replace("{item.title||item.text}<","{item.item||item.title||item.text||'Untitled'}<")
code=code.replace("{it.title||it.text}<","{it.item||it.title||it.text||'Untitled'}<")
code=code.replace("checked={item.status==='done'}","checked={(item.status||'').toLowerCase()==='done'}")
code=code.replace("var isOD=(item.status||'open')==='open'","var isOD=(item.status||'open').toLowerCase()==='open'")
code=code.replace("textDecoration:item.status==='done'","textDecoration:(item.status||'').toLowerCase()==='done'")
code=code.replace("color:item.status==='done'","color:(item.status||'').toLowerCase()==='done'")
code=code.replace("col==='open'?(i.status||'open')==='open':col==='done'?i.status==='done':(i.status||'')==='in-progress'","col==='open'?(i.status||'open').toLowerCase()==='open':col==='done'?(i.status||'').toLowerCase()==='done':(i.status||'').toLowerCase()==='in-progress'")
code=code.replace("""<a href={o.sam_url || (o.noticeId ? 'https://sam.gov/opp/'+o.noticeId+'/view' : o.solicitation ? 'https://sam.gov/opp/'+o.solicitation+'/view' : 'https://sam.gov/search/?index=opp')} title={o.sam_url||o.noticeId ? 'View on SAM.gov' : o.solicitation ? 'SAM.gov Sol: '+o.solicitation : 'Search SAM.gov for: '+o.name} target='_blank' rel='noopener noreferrer' style={{color:ACCENT,textDecoration:'none',cursor:'pointer'}}>{o.name}</a>""","<span style={{color:ACCENT,fontWeight:600}}>{o.name}</span>")
code=code.replace("{topic.url?<SourceTag url={topic.url} label='Source' />:<SourceTag url='https://sam.gov/search/?index=opp' label='SAM.gov' />}","{topic.url&&<SourceTag url={topic.url} label='Source' />}")
code=code.replace("""            <GlobalActionFab currentPage={page} onNavigate={navigate} />
          </div>""","          </div>")
OS="""          <div style={S.sidebar}>
            {NAV.LAUNCHPAD.map(item => (
              <div key={item.id} style={S.sidebarItem(page===item.id)} onClick={()=>navigate(item.id)}>
                <span>{item.icon}</span><span>{item.label}</span>
              </div>
            ))}
            <div style={{...S.sidebarGroup, marginTop:8}}>Program Management</div>
            {NAV.PM.map(item => (
              <div key={item.id} style={S.sidebarItem(page===item.id)} onClick={()=>navigate(item.id)}>
                <span>{item.icon}</span><span>{item.label}</span>
              </div>
            ))}
            <div style={{...S.sidebarGroup, marginTop:8}}>Business Development</div>
            {NAV.BD.map(item => (
              <div key={item.id} style={S.sidebarItem(page===item.id)} onClick={()=>navigate(item.id)}>
                <span>{item.icon}</span><span>{item.label}</span>
              </div>
            ))}
            <div style={{...S.sidebarGroup, marginTop:8}}>Admin</div>
            {NAV.ADMIN.map(item => (
              <div key={item.id} style={S.sidebarItem(page===item.id)} onClick={()=>navigate(item.id)}>
                <span>{item.icon}</span><span>{item.label}</span>{item.locked && <span style={{marginLeft:'auto',fontSize:10,opacity:0.4}}>\ud83d\udd12</span>}
              </div>
            ))}
          </div>"""
NS="""          <div style={{...S.sidebar, display:'flex', flexDirection:'column', padding:0}}>
            <div style={{flex:1, overflow:'auto', padding:'10px 0'}}>
            {NAV.LAUNCHPAD.map(item => (
              <div key={item.id} style={S.sidebarItem(page===item.id)} onClick={()=>navigate(item.id)}>
                <span>{item.icon}</span><span>{item.label}</span>
              </div>
            ))}
            <div style={{...S.sidebarGroup, marginTop:8}}>Program Management</div>
            {NAV.PM.map(item => (
              <div key={item.id} style={S.sidebarItem(page===item.id)} onClick={()=>navigate(item.id)}>
                <span>{item.icon}</span><span>{item.label}</span>
              </div>
            ))}
            <div style={{...S.sidebarGroup, marginTop:8}}>Business Development</div>
            {NAV.BD.map(item => (
              <div key={item.id} style={S.sidebarItem(page===item.id)} onClick={()=>navigate(item.id)}>
                <span>{item.icon}</span><span>{item.label}</span>
              </div>
            ))}
            <div style={{...S.sidebarGroup, marginTop:8}}>Admin</div>
            {NAV.ADMIN.map(item => (
              <div key={item.id} style={S.sidebarItem(page===item.id)} onClick={()=>navigate(item.id)}>
                <span>{item.icon}</span><span>{item.label}</span>{item.locked && <span style={{marginLeft:'auto',fontSize:10,opacity:0.4}}>\ud83d\udd12</span>}
              </div>
            ))}
            </div>
            <button onClick={()=>navigate('actions')} style={{margin:'0 10px 10px', padding:'10px 0', background:ACCENT, color:WHITE, border:'none', borderRadius:6, fontSize:12, fontWeight:700, cursor:'pointer', letterSpacing:'0.3px'}}>Action Items</button>
          </div>"""
code=code.replace(OS,NS)
code=code.replace("    { id:'target',           label:'Target Agencies',         icon:'\ud83c\udfdb\ufe0f' },","    { id:'target',           label:'Target Agencies',         icon:'\ud83c\udfdb\ufe0f' },\n    { id:'idiq',             label:'IDIQ On-Ramp',            icon:'\ud83d\udd17' },")
code=code.replace("  target: React.memo(TargetAgencies),","  target: React.memo(TargetAgencies),\n  idiq: React.memo(IdiqOnRamp),")
ID="""// IDIQ ON-RAMP SEARCH
function IdiqOnRamp() {
  const [results,setResults]=useState([]);const [loading,setLoading]=useState(false);
  const [query,setQuery]=useState('');const [error,setError]=useState('');
  const TERMS=['on-ramp','off-ramp','task order','IDIQ add','IDIQ on-ramp','multiple award'];
  const search=async(term)=>{const q=term||query.trim();if(!q)return;setLoading(true);setError('');try{const d=await api.post('gda-ai-agent',{message:'Search for IDIQ on-ramp opportunities matching: "'+q+'". Return JSON array with fields: title, agency, naics, vehicle, deadline, link, value.'});let p=[];try{const r=d.response||d.output||JSON.stringify(d);const m=r.match(/\\[[\\s\\S]*\\]/);if(m)p=JSON.parse(m[0]);}catch{}if(p.length>0)setResults(p);else{setResults([]);setError('No results. Raw: '+(d.response||d.output||'').substring(0,300));}}catch(e){setError('Failed: '+e.message);setResults([]);}setLoading(false);};
  return (<div><PageHeader title="IDIQ On-Ramp Search" sub="Find on-ramp, off-ramp, and task order opportunities" />
    <div style={S.card}><div style={{fontSize:11,fontWeight:700,color:NAVY,marginBottom:8}}>Quick Search</div>
      <div style={{display:'flex',gap:6,flexWrap:'wrap',marginBottom:12}}>{TERMS.map(t=><button key={t} onClick={()=>{setQuery(t);search(t);}} style={S.btn('secondary',true)}>{t}</button>)}</div>
      <div style={{display:'flex',gap:8}}><input style={{...S.input,flex:1}} value={query} onChange={e=>setQuery(e.target.value)} onKeyDown={e=>e.key==='Enter'&&search()} placeholder="Search IDIQ on-ramp opportunities..." /><button style={S.btn()} onClick={()=>search()} disabled={loading}>{loading?'Searching...':'Search'}</button></div></div>
    {error&&<Alert type="error" msg={error}/>}
    {loading&&<div style={{textAlign:'center',padding:20}}><Spinner/><div style={{fontSize:11,color:'#888',marginTop:8}}>Searching... 30-60s</div></div>}
    {results.length>0&&<div style={S.card}><div style={S.cardTitle}>{results.length} On-Ramp Opportunities</div>
      <table style={S.table}><thead><tr><th style={S.th}>Opportunity</th><th style={S.th}>Agency</th><th style={S.th}>Vehicle</th><th style={S.th}>NAICS</th><th style={S.th}>Value</th><th style={S.th}>Deadline</th></tr></thead>
      <tbody>{results.map((r,i)=><tr key={i}><td style={{...S.td,fontWeight:600,color:NAVY}}>{r.link?<a href={r.link} target="_blank" rel="noopener noreferrer" style={{color:ACCENT,textDecoration:'none'}}>{r.title||'Untitled'}</a>:(r.title||'Untitled')}</td><td style={S.td}>{r.agency||'\u2014'}</td><td style={S.td}>{r.vehicle||'\u2014'}</td><td style={S.td}>{r.naics||'\u2014'}</td><td style={{...S.td,fontWeight:600}}>{r.value||'\u2014'}</td><td style={S.td}>{r.deadline||'\u2014'}</td></tr>)}</tbody></table></div>}
    {!loading&&results.length===0&&!error&&<Empty msg="Click a quick term or search above"/>}
  </div>);
}

// OPERATIONS DASHBOARD"""
code=code.replace("// \u2500\u2500 OPERATIONS DASHBOARD",ID)
CH="""      </div>);})}</div>)}
    {/* Charts */}
    {items.length>0&&<div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:14,marginTop:18}}>
      <div style={S.card}><div style={S.cardTitle}>Items by Status</div>
        <ResponsiveContainer width="100%" height={220}><PieChart><Pie data={[{name:'Open',value:open},{name:'Done',value:done},{name:'Overdue',value:overdue}].filter(d=>d.value>0)} cx="50%" cy="50%" outerRadius={75} dataKey="value" label={e=>e.name+': '+e.value} labelLine={false}>{[ACCENT,'#22a06b','#e53935'].map((c,i)=><Cell key={i} fill={c}/>)}</Pie><Tooltip contentStyle={{fontSize:11,borderRadius:6}}/></PieChart></ResponsiveContainer></div>
      <div style={S.card}><div style={S.cardTitle}>Created per Week</div>
        <ResponsiveContainer width="100%" height={220}><BarChart data={(()=>{const w={};items.forEach(it=>{const d=it.created_at?new Date(it.created_at):new Date();const wk=new Date(d);wk.setDate(wk.getDate()-wk.getDay());const k=wk.toLocaleDateString('en-US',{month:'short',day:'numeric'});w[k]=(w[k]||0)+1;});return Object.entries(w).slice(-8).map(([wk,c])=>({week:wk,count:c}));})()}><XAxis dataKey="week" tick={{fontSize:10,fill:NAVY}}/><YAxis tick={{fontSize:10,fill:'#888'}} allowDecimals={false}/><Tooltip contentStyle={{fontSize:11,borderRadius:6}}/><Bar dataKey="count" fill={ACCENT} radius={[4,4,0,0]}/></BarChart></ResponsiveContainer></div>
    </div>}
  </div>);
}

// -- GLOBAL ACTION FAB"""
code=code.replace("      </div>);})}</div>)}\n  </div>);\n}\n\n// -- GLOBAL ACTION FAB",CH)
if code==o:print("ERROR: No changes!");sys.exit(1)
open(f,'w').write(code)
print(f"PATCHED: {code.count(chr(10))+1} lines, Idiq={code.count('IdiqOnRamp')}, toLC={code.count('toLowerCase')}, sam={code.count('sam.gov')}")