import sys
f='/opt/gda-command/src/App.jsx'
code=open(f).read()
# Fix 1: Add IDIQ to NAV.BD - insert line after Target Agencies
lines=code.split('\n')
new_lines=[]
for line in lines:
    new_lines.append(line)
    if "id:'target'" in line and 'Target Agencies' in line:
        new_lines.append("    { id:'idiq',             label:'IDIQ On-Ramp',            icon:'" + chr(0x1F517) + "' },")
code='\n'.join(new_lines)
# Fix 2: Add Action Items button at bottom of sidebar - insert before {/* Main Content */}
code=code.replace(
    '          {/* Main Content */}',
    '            <button onClick={()=>navigate(\'actions\')} style={{margin:\'0 10px 10px\', padding:\'10px 0\', background:ACCENT, color:WHITE, border:\'none\', borderRadius:6, fontSize:12, fontWeight:700, cursor:\'pointer\'}}>Action Items</button>\n          {/* Main Content */}'
)
open(f,'w').write(code)
n=code.count('\n')+1
print(f"DONE: {n} lines, idiq_nav={'idiq' in code[:code.find('ADMIN')]}, action_btn={'Action Items</button>' in code}")
