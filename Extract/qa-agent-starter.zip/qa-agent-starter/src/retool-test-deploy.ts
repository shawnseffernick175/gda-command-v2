import { timedCheck, writeJsonArtifact } from "./artifacts.js";
import { env, requireEnv } from "./env.js";

async function run(): Promise<void> {
  const result = await timedCheck("retool-deploy", "retool-test-deploy", "Dry-run deploy the current Retool source-control commit.", async () => {
    const baseUrl = requireEnv("retoolBaseUrl", "Set RETOOL_BASE_URL in .env.");
    const apiKey = requireEnv("retoolTestDeployApiKey", "Set RETOOL_TEST_DEPLOY_API_KEY in .env.");
    const commitSha = requireEnv("commitSha", "Set COMMIT_SHA in .env or CI.");

    const url = `${baseUrl.replace(/\/$/, "")}/api/v2/source_control/test_deploy`;
    const response = await fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`
      },
      body: JSON.stringify({
        deploy_params: {
          commit_sha: commitSha
        }
      })
    });

    const rawText = await response.text();
    let json: unknown;
    try {
      json = rawText ? JSON.parse(rawText) : {};
    } catch {
      json = { rawText };
    }
    const artifact = writeJsonArtifact("logs/retool-test-deploy.json", {
      url,
      status: response.status,
      body: json
    });

    if (!response.ok) {
      throw new Error(`Retool test deploy request failed with HTTP ${response.status}.`);
    }

    const success = Boolean((json as { data?: { success?: boolean } }).data?.success);
    if (!success) {
      throw new Error(`Retool test deploy did not report success. See ${artifact}`);
    }

    return {
      status: "passed",
      details: json,
      artifacts: [artifact]
    };
  });

  writeJsonArtifact("logs/retool-deploy-results.json", [result]);
  console.log(JSON.stringify(result, null, 2));
  if (result.status === "failed") process.exit(1);
}

run().catch((error) => {
  console.error(error);
  process.exit(1);
});
