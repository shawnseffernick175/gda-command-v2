import AjvModule from "ajv";
import { ensureArtifactDirs, timedCheck, writeJsonArtifact, type CheckResult } from "./artifacts.js";
import { loadContracts, loadTestCases } from "./config.js";
import { env, replaceTokens, requireEnv } from "./env.js";

function getWebhookAuthHeaders(): Record<string, string> {
  const headers: Record<string, string> = {};

  if (env.n8nWebhookBasicUser && env.n8nWebhookBasicPassword) {
    const token = Buffer.from(`${env.n8nWebhookBasicUser}:${env.n8nWebhookBasicPassword}`).toString("base64");
    headers.Authorization = `Basic ${token}`;
  }

  if (env.n8nWebhookAuthHeaderName && env.n8nWebhookAuthHeaderValue) {
    headers[env.n8nWebhookAuthHeaderName] = env.n8nWebhookAuthHeaderValue;
  }

  return headers;
}

async function run(): Promise<CheckResult[]> {
  ensureArtifactDirs();
  const testCases = loadTestCases();
  const contracts = loadContracts();
  const Ajv = AjvModule.default ?? AjvModule;
  const ajv = new Ajv({ allErrors: true });
  const runId = `n8n-${new Date().toISOString().replaceAll(/[:.]/g, "-")}`;
  const baseUrl = requireEnv("n8nBaseUrl", "Set N8N_BASE_URL in .env.");

  const results: CheckResult[] = [];

  for (const rawCase of testCases.n8n) {
    const testCase = replaceTokens(rawCase, runId);
    results.push(
      await timedCheck("n8n", testCase.name, testCase.description, async () => {
        if (!testCase.enabled) return { status: "skipped" };

        const url = `${baseUrl.replace(/\/$/, "")}${testCase.webhookPath.startsWith("/") ? "" : "/"}${testCase.webhookPath}`;
        const response = await fetch(url, {
          method: testCase.method,
          headers: {
            ...getWebhookAuthHeaders(),
            ...(testCase.headers ?? {})
          },
          body: testCase.body === undefined || testCase.method === "GET" ? undefined : JSON.stringify(testCase.body)
        });

        const text = await response.text();
        let json: unknown = undefined;
        try {
          json = text ? JSON.parse(text) : undefined;
        } catch {
          json = { rawText: text };
        }

        const artifact = writeJsonArtifact(`logs/${testCase.name}-response.json`, {
          url,
          status: response.status,
          headers: Object.fromEntries(response.headers.entries()),
          body: json
        });

        if (response.status !== testCase.expectedStatus) {
          throw new Error(`Expected HTTP ${testCase.expectedStatus}, got ${response.status}. Response saved to ${artifact}`);
        }

        if (testCase.responseSchemaName) {
          const schema = contracts[testCase.responseSchemaName];
          if (!schema) throw new Error(`Unknown response schema: ${testCase.responseSchemaName}`);
          const validate = ajv.compile(schema);
          const valid = validate(json);
          if (!valid) {
            throw new Error(`Response schema validation failed: ${JSON.stringify(validate.errors, null, 2)}`);
          }
        }

        return {
          status: "passed",
          details: {
            status: response.status,
            responseSchemaName: testCase.responseSchemaName
          },
          artifacts: [artifact]
        };
      })
    );
  }

  writeJsonArtifact("logs/n8n-results.json", results);
  return results;
}

run()
  .then((results) => {
    const failed = results.filter((result) => result.status === "failed");
    console.log(JSON.stringify(results, null, 2));
    if (failed.length > 0) process.exit(1);
  })
  .catch((error) => {
    console.error(error);
    process.exit(1);
  });
