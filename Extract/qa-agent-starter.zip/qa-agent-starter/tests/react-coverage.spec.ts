import fs from "node:fs";
import path from "node:path";
import { expect, test } from "@playwright/test";
import { artifactPath, writeJsonArtifact, writeTextArtifact } from "../src/artifacts.js";

const launchpadUrl = process.env.REACT_BASE_URL ?? "https://gda.csr-llc.tech/#launchpad";

const sidebarModules = [
  "Launchpad",
  "AI Agent Chat",
  "Daily SITREP",
  "Morning Brief",
  "Intel Feed",
  "Deep Research",
  "Meeting Notes",
  "Competitive Intel",
  "Bid Strategy",
  "OODA Loop",
  "Opportunity Tracker",
  "Pwin Calculator",
  "Capture Plan",
  "Compliance Matrix",
  "Document Hub & PPT",
  "Email Drafter",
  "Proposal Review",
  "Proposal Factory",
  "Risk Register",
  "Financial Bible",
  "Platform Health",
  "Platform Guide",
  "Prompt Architect"
];

type ApiEvent = {
  module: string;
  method: string;
  url: string;
  status?: number;
  error?: string;
};

type ConsoleEvent = {
  module: string;
  type: string;
  text: string;
  url?: string;
};

type ModuleResult = {
  module: string;
  status: "passed" | "failed";
  hash: string;
  headings: string[];
  buttons: string[];
  inputs: string[];
  apiErrors: ApiEvent[];
  consoleErrors: ConsoleEvent[];
  issues: string[];
};

function normalizeText(values: string[]): string[] {
  return [...new Set(values.map((value) => value.replace(/\s+/g, " ").trim()).filter(Boolean))];
}

function isCriticalConsoleMessage(text: string): boolean {
  return /failed to load resource|uncaught|runtime error|application error|authorization data is wrong/i.test(text);
}

function renderMarkdown(results: ModuleResult[]): string {
  const failed = results.filter((result) => result.status === "failed");
  const lines = [
    "# React Coverage Crawl",
    "",
    `- Modules checked: ${results.length}`,
    `- Passed: ${results.length - failed.length}`,
    `- Failed: ${failed.length}`,
    "",
    "## Module Results",
    "",
    "| Module | Status | Hash | Headings | Issues |",
    "|---|---:|---|---|---|"
  ];

  for (const result of results) {
    const headings = result.headings.slice(0, 4).join("<br>");
    const issues = result.issues.length > 0 ? result.issues.join("<br>") : "None";
    lines.push(`| ${result.module} | ${result.status} | \`${result.hash || "(none)"}\` | ${headings || "None"} | ${issues} |`);
  }

  if (failed.length > 0) {
    lines.push("", "## Failed Details", "");
    for (const result of failed) {
      lines.push(`### ${result.module}`, "");
      for (const issue of result.issues) lines.push(`- ${issue}`);
      for (const apiError of result.apiErrors) {
        lines.push(`- API ${apiError.method} ${apiError.url} ${apiError.status ?? apiError.error ?? ""}`.trim());
      }
      for (const consoleError of result.consoleErrors) {
        lines.push(`- Console ${consoleError.type}: ${consoleError.text}`);
      }
      lines.push("");
    }
  }

  return `${lines.join("\n")}\n`;
}

test.describe("React app coverage crawl", () => {
  test("walks every sidebar module and checks for broken loads", async ({ page }) => {
    test.setTimeout(180_000);

    let currentModule = "Initial load";
    const apiEvents: ApiEvent[] = [];
    const consoleEvents: ConsoleEvent[] = [];

    page.on("response", (response) => {
      const url = response.url();
      if (!url.includes("/api/")) return;
      if (response.status() < 400) return;
      apiEvents.push({
        module: currentModule,
        method: response.request().method(),
        url,
        status: response.status()
      });
    });

    page.on("requestfailed", (request) => {
      const url = request.url();
      if (!url.includes("/api/")) return;
      apiEvents.push({
        module: currentModule,
        method: request.method(),
        url,
        error: request.failure()?.errorText ?? "request failed"
      });
    });

    page.on("console", (message) => {
      if (!["error", "warning"].includes(message.type())) return;
      const text = message.text();
      if (!isCriticalConsoleMessage(text)) return;
      consoleEvents.push({
        module: currentModule,
        type: message.type(),
        text,
        url: message.location().url
      });
    });

    await page.goto(launchpadUrl, { waitUntil: "domcontentloaded", timeout: 60_000 });
    await expect(page.getByRole("heading", { name: "Command Center" })).toBeVisible({ timeout: 30_000 });

    const results: ModuleResult[] = [];

    for (const moduleName of sidebarModules) {
      currentModule = moduleName;
      const apiStart = apiEvents.length;
      const consoleStart = consoleEvents.length;
      const issues: string[] = [];

      const navItem = page.getByText(moduleName, { exact: true }).first();
      const navCount = await navItem.count();
      if (navCount === 0) {
        results.push({
          module: moduleName,
          status: "failed",
          hash: page.url().split("#")[1] ?? "",
          headings: [],
          buttons: [],
          inputs: [],
          apiErrors: [],
          consoleErrors: [],
          issues: [`Sidebar item not found: ${moduleName}`]
        });
        continue;
      }

      await navItem.scrollIntoViewIfNeeded();
      await navItem.click({ timeout: 15_000 });
      await page.waitForLoadState("domcontentloaded", { timeout: 15_000 }).catch(() => undefined);
      await page.waitForTimeout(1_250);

      const bodyText = await page.locator("body").innerText({ timeout: 10_000 }).catch(() => "");
      const headings = normalizeText(await page.locator("h1,h2,h3").allInnerTexts().catch(() => []));
      const buttons = normalizeText(await page.locator("button").allInnerTexts().catch(() => []));
      const inputs = normalizeText(
        await page
          .locator("input, textarea, select")
          .evaluateAll((elements) =>
            elements.map((element) => {
              const input = element as HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement;
              return input.getAttribute("placeholder") ?? input.getAttribute("aria-label") ?? input.name ?? input.tagName;
            })
          )
          .catch(() => [])
      );

      const moduleApiErrors = apiEvents.slice(apiStart);
      const moduleConsoleErrors = consoleEvents.slice(consoleStart);

      if (bodyText.trim().length < 100) issues.push("Page body looked blank or nearly blank after navigation.");
      if (/failed to load|authorization data is wrong|cannot get \/|application error/i.test(bodyText)) {
        issues.push("Visible error text found on the page.");
      }
      if (moduleApiErrors.length > 0) issues.push(`${moduleApiErrors.length} failed API request(s).`);
      if (moduleConsoleErrors.length > 0) issues.push(`${moduleConsoleErrors.length} critical console error(s).`);

      results.push({
        module: moduleName,
        status: issues.length > 0 ? "failed" : "passed",
        hash: page.url().split("#")[1] ?? "",
        headings,
        buttons: buttons.slice(0, 25),
        inputs: inputs.slice(0, 25),
        apiErrors: moduleApiErrors,
        consoleErrors: moduleConsoleErrors,
        issues
      });
    }

    const jsonPath = writeJsonArtifact("logs/react-coverage-results.json", {
      launchpadUrl,
      checkedAt: new Date().toISOString(),
      modulesChecked: sidebarModules.length,
      passed: results.filter((result) => result.status === "passed").length,
      failed: results.filter((result) => result.status === "failed").length,
      results
    });
    const markdownPath = writeTextArtifact("reports/react-coverage-report.md", renderMarkdown(results));

    const screenshotsDir = artifactPath("screenshots");
    fs.mkdirSync(screenshotsDir, { recursive: true });
    await page.screenshot({ path: path.join(screenshotsDir, "react-coverage-final-page.png"), fullPage: true });

    test.info().attach("react-coverage-results", { path: jsonPath, contentType: "application/json" });
    test.info().attach("react-coverage-report", { path: markdownPath, contentType: "text/markdown" });

    const failed = results.filter((result) => result.status === "failed");
    expect(failed, `${failed.length} React module(s) failed coverage crawl. See artifacts/reports/react-coverage-report.md`).toEqual([]);
  });
});
