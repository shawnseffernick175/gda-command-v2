# React Coverage Crawl

- Modules checked: 23
- Passed: 19
- Failed: 4

## Module Results

| Module | Status | Hash | Headings | Issues |
|---|---:|---|---|---|
| Launchpad | passed | `launchpad` | Command Center<br>Market Analysisⓘ<br>Upcoming Deadlines<br>Top 10 Opportunities by GDA Score | None |
| AI Agent Chat | passed | `ai-agent` | Command Center<br>Market Analysisⓘ<br>Upcoming Deadlines<br>Top 10 Opportunities by GDA Score | None |
| Daily SITREP | passed | `sitrep` | Command Center<br>Market Analysisⓘ<br>Upcoming Deadlines<br>Top 10 Opportunities by GDA Score | None |
| Morning Brief | passed | `daily-brief` | Command Center<br>Market Analysisⓘ<br>Upcoming Deadlines<br>Top 10 Opportunities by GDA Score | None |
| Intel Feed | passed | `intel-feed` | Command Center<br>Market Analysisⓘ<br>Upcoming Deadlines<br>Top 10 Opportunities by GDA Score | None |
| Deep Research | failed | `deep-research` | Command Center<br>Market Analysisⓘ<br>Upcoming Deadlines<br>Top 10 Opportunities by GDA Score | 1 critical console error(s). |
| Meeting Notes | failed | `meeting-notes` | Command Center<br>Market Analysisⓘ<br>Upcoming Deadlines<br>Top 10 Opportunities by GDA Score | 1 failed API request(s). |
| Competitive Intel | passed | `comp-intel` | Command Center<br>Market Analysisⓘ<br>Upcoming Deadlines<br>Top 10 Opportunities by GDA Score | None |
| Bid Strategy | passed | `bid-strategy` | Command Center<br>Market Analysisⓘ<br>Upcoming Deadlines<br>Top 10 Opportunities by GDA Score | None |
| OODA Loop | passed | `ooda` | Command Center<br>Market Analysisⓘ<br>Upcoming Deadlines<br>Top 10 Opportunities by GDA Score | None |
| Opportunity Tracker | passed | `opp-tracker` | Command Center<br>Market Analysisⓘ<br>Upcoming Deadlines<br>Top 10 Opportunities by GDA Score | None |
| Pwin Calculator | passed | `pwin-calculator` | Command Center<br>Market Analysisⓘ<br>Upcoming Deadlines<br>Top 10 Opportunities by GDA Score | None |
| Capture Plan | passed | `capture-plan` | Command Center<br>Market Analysisⓘ<br>Upcoming Deadlines<br>Top 10 Opportunities by GDA Score | None |
| Compliance Matrix | passed | `compliance-matrix` | Command Center<br>Market Analysisⓘ<br>Upcoming Deadlines<br>Top 10 Opportunities by GDA Score | None |
| Document Hub & PPT | passed | `doc-hub` | Command Center<br>Market Analysisⓘ<br>Upcoming Deadlines<br>Top 10 Opportunities by GDA Score | None |
| Email Drafter | passed | `email` | Command Center<br>Market Analysisⓘ<br>Upcoming Deadlines<br>Top 10 Opportunities by GDA Score | None |
| Proposal Review | passed | `red-team` | Command Center<br>Market Analysisⓘ<br>Upcoming Deadlines<br>Top 10 Opportunities by GDA Score | None |
| Proposal Factory | failed | `proposal-factory` | Command Center<br>Market Analysisⓘ<br>Upcoming Deadlines<br>Top 10 Opportunities by GDA Score | 1 critical console error(s). |
| Risk Register | passed | `risk` | Command Center<br>Market Analysisⓘ<br>Upcoming Deadlines<br>Top 10 Opportunities by GDA Score | None |
| Financial Bible | failed | `aop-tracker` | Command Center<br>Market Analysisⓘ<br>Upcoming Deadlines<br>Top 10 Opportunities by GDA Score | 1 critical console error(s). |
| Platform Health | passed | `platform-health` | Command Center<br>Market Analysisⓘ<br>Upcoming Deadlines<br>Top 10 Opportunities by GDA Score | None |
| Platform Guide | passed | `directions` | Command Center<br>Market Analysisⓘ<br>Upcoming Deadlines<br>Top 10 Opportunities by GDA Score | None |
| Prompt Architect | passed | `prompt-architect` | Command Center<br>Market Analysisⓘ<br>Upcoming Deadlines<br>Top 10 Opportunities by GDA Score | None |

## Failed Details

### Deep Research

- 1 critical console error(s).
- Console error: Failed to load resource: the server responded with a status of 403 ()

### Meeting Notes

- 1 failed API request(s).
- API POST https://gda.csr-llc.tech/api/gda-action-history net::ERR_ABORTED

### Proposal Factory

- 1 critical console error(s).
- Console error: Failed to load resource: the server responded with a status of 403 ()

### Financial Bible

- 1 critical console error(s).
- Console error: Failed to load resource: the server responded with a status of 403 ()

