# QA Agent Report

## Overall status
Needs review

## Summary
The deterministic reporter reviewed 3 artifact file(s). 0 file(s) contain failure or error signals, and 2 file(s) contain passing signals.

## Failed or suspicious artifacts
- No explicit failure artifacts found.

## Passing artifacts
- /home/user/workspace/qa-agent-starter/artifacts/logs/gda-launchpad-smoke-browser-diagnostics.json
- /home/user/workspace/qa-agent-starter/artifacts/logs/playwright-results.json

## Recommended next steps
- Open the failed or suspicious artifact files first.
- Review browser diagnostics for console errors and failed network requests.
- Review n8n response artifacts for HTTP status mismatches or schema validation failures.
- Configure AI_PROVIDER and AI_API_KEY to enable root-cause analysis in natural language.

## AI reviewer status
AI review was not enabled. Set AI_PROVIDER=openai or AI_PROVIDER=anthropic and provide AI_API_KEY to generate a richer diagnosis.
