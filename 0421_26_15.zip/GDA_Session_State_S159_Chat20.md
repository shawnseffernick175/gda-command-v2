# GDA Command Platform — Session State
**Last Updated:** S-159 Chat 20 — April 21, 2026
**Operator:** Shawn Seffernick, President, Envision Innovative Solutions (OU3)

---

## Pre-Flight (Every Chat)
1. `tool_search("n8n")` — load MCP
2. Read project files (Session State, Master Build)
3. **RR-38 and RR-28 are FROZEN** — do not touch ever

---

## FIRST ACTION NEXT CHAT

Continue backlog top-down. S-1/2/3 are pending next 6am briefing run — headlines column is live, no action needed unless run hasn't fired. Next priority:

| Priority | Item | Notes |
|---|---|---|
| Med | **S-1/2/3 verify** | At next session, SSH-check if gda_morning_briefings has a row with headlines populated (any non-null headlines column). If yes, wire dashboard-mega world_news/market_signals items to include url from headlines[]. If not yet run, skip and proceed. |
| Med | **S-5** | Opps/Risks in SITREP duplicate Launchpad data. Either remove those sections or differentiate framing (SITREP shows >30d pipeline, Launchpad shows <30d). |
| Med | **I-2** | Intel Feed history blank — SSH-read IntelFeedPage.jsx, find history data source, trace back to workflow |
| Med | **D-2** | Deep Research history empty — check q9YWVQCwnJGqmrO7, find history endpoint |
| Med | **C-1 to C-6** | Comp Intel tab — card expand bug, no AI narrative, static data, missing agencies |
| Med | **N-1** | Merge Wargame + Incumbent + Teaming → single Bid Strategy tab |
| Med | **O-2, O-7** | Opp Tracker sub-rows; NDAA placeholder |
| Med | **P-1** | Platform smoke test |

---

## Deploy Webhook Auth Note (RR-44)
Temp patch `authentication` to `none` on Webhook node → fire → restore to `headerAuth`.

---

## Platform State

| Item | Status |
|---|---|
| Active workflows | ~152 |
| Frontend (gda.csr-llc.tech) | LIVE |
| GDA.api.dashboard-mega | ACTIVE — 11 nodes, 1hr cache, SITREP world_news/market_signals/govt_intel/acquisition_news populated |
| GDA.intel.morning-briefing-v1 | ACTIVE — 16 nodes, data-learn wire LIVE, headlines jsonb column WIRED (S-159 C20) |
| GDA.api.daily-actions | ACTIVE — 17 nodes, L-10 filter LIVE (no-cap + <30d excluded) |
| GDA.api.pwin-calculator | ACTIVE — loads learned weights from DB |
| GDA.api.win-loss-db | ACTIVE — auto-posts W/L to feedback-collector |
| GDA.api.capture-plan | ACTIVE — 23 nodes, RR-42 FIXED |
| GDA.cron.recompete-early-warning | ACTIVE — daily 7am ET |
| GDA.cron.win-rate-weekly-digest | ACTIVE — Mondays 8am ET |
| GDA.cron.idiq-task-order-alert | ACTIVE — daily 8am ET |
| GDA.cron.capture-opp-sync | ACTIVE — RR-38 fix + Auto-Pass Overdue, nightly 2am ET |
| GDA.api.platform-health | ACTIVE |
| GDA.api.bd-activity-log | ACTIVE |
| GDA.api.teaming-scorer | ACTIVE |
| GDA.cron.capture-milestone-alerts | ACTIVE — daily 9am ET |
| GDA.auto.feedback-collector | ACTIVE |
| GDA.cron.learning-engine | ACTIVE — nightly 3am ET |
| GDA.agent.opp-classifier | ACTIVE — 6 nodes, feedback wire LIVE |
| GDA.api.launchpad-funnel | ACTIVE — L-5 FIXED, 6 captureStages confirmed live |

---

## Key Workflow IDs

| Workflow | ID |
|---|---|
| GDA.dev.deploy | 8GnGxnBL9TJjj1i2 |
| GDA.bot.telegram-chat | 1ItrrFxGI3L43Pdv |
| GDA.api.daily-actions | C7Bh7KcAl1IgSTRr |
| GDA.api.ooda-loop 2 | pkPpMhiz8IdRy7To |
| GDA.intel.morning-briefing-v1 | YIvCdrOgF1LGmFNL |
| GDA.api.launchpad-funnel | vaRzM1Jl6HcXjuxs |
| GDA.api.dashboard-mega | UYGJPu7N5YZblvEU |
| GDA.api.opp-tracker 2 | SEJLE89wZa1yfQyB |
| GDA.api.capture-plan | QgperN6cuOpfnb09 |
| GDA.sched.opp-refresh | PeLGDqgLAsEh5Gsd |
| GDA.research.deep-research | q9YWVQCwnJGqmrO7 |
| GDA.auto.gist-update | djgOV2vX3PIv9cvm |
| GDA.api.aop-tracker | P8AfP8P84xi33auD |
| GDA.api.win-loss-db | SpU3znFHHABYNmb9 |
| GDA.cron.recompete-early-warning | MtcQwAgm1zHYXNfB |
| GDA.cron.win-rate-weekly-digest | ZuQkz1HrMONclkFm |
| GDA.cron.idiq-task-order-alert | DeSN1t1swXX14xTc |
| GDA.cron.capture-opp-sync | 0E3lCtWt2rdJlMPY |
| GDA.api.platform-health | UBgoJGxZro834RbT |
| GDA.api.bd-activity-log | 9qrsria0fy719T98 |
| GDA.api.teaming-scorer | jQvgX6SD1RhARG3F |
| GDA.cron.capture-milestone-alerts | Kk7O8Bw2FOe41M9l |
| GDA.auto.feedback-collector | aCrxoe1rCuIbsnC4 |
| GDA.cron.learning-engine | fZpqchmmPnqAmiMq |
| GDA.api.pwin-calculator | 81m1Zl9xjM6L8HQb |
| GDA.agent.opp-classifier | hWCP9NLXxtCOrppu |
| GDA.auto.incumbent-enrichment | oYwPpPdNCixRKItz |
| GDA.util.ssh-read-file | IcD4K740vpWSIuaZ |

---

## Infrastructure

| Resource | Detail |
|---|---|
| Frontend source | /opt/gda-command/src/App.jsx |
| Deploy webhook | POST https://n8n.csr-llc.tech/webhook/gda-deploy |
| Deploy auth | Header: x-gda-auth: gda-deploy-2026-secure |
| Deploy MCP pattern | Temp set Webhook auth to none → fire → restore headerAuth |
| SSH webhook (read) | POST https://n8n.csr-llc.tech/webhook/ssh-read-file |
| SSH auth | Header: x-gda-key: gda-api-2026-secure |
| SSH exec workflow | IcD4K740vpWSIuaZ |
| Postgres cred | HwronxMmGY5XDGEt |
| VPS | 187.77.206.105 |
| n8n | https://n8n.csr-llc.tech (v2.37.1) |
| Frontend | https://gda.csr-llc.tech |
| MCP | https://mcp.csr-llc.tech/mcp |
| Feedback endpoint | POST https://n8n.csr-llc.tech/webhook/gda-feedback |
| Data-learn endpoint | POST https://n8n.csr-llc.tech/webhook/gda-data-learn |

---

## Learning System

| Component | Status |
|---|---|
| gda_feedback + gda_learned_weights tables | LIVE — seeded with 12 Shipley weights |
| gda_learning_log table | LIVE |
| feedback-collector | ACTIVE |
| learning-engine | ACTIVE — nightly 3am ET |
| pwin-calculator | UPDATED — loads learned weights |
| win-loss-db | UPDATED — auto-posts W/L to feedback |
| daily-actions | UPDATED — posts action counts to feedback |
| morning-briefing → data-learn | LIVE — node dl-01 |
| opp-classifier → feedback | LIVE — node oc-06 |

---

## Open Debt

| ID | Sev | Summary |
|---|---|---|
| S-1 | MED | PENDING NEXT RUN — headlines column live, populates at next 6am briefing. Then wire dashboard-mega to use headlines[].url for source links. |
| S-2 | MED | PENDING NEXT RUN — same fix as S-1 |
| S-3 | MED | PENDING NEXT RUN — same fix as S-1 |
| S-5 | MED | Opps/Risks cards duplicate Launchpad — structural fix needed |
| I-2 | MED | Intel Feed history blank |
| D-2 | MED | Deep Research history empty |
| C-1 to C-6 | MED | Comp Intel: card expand, AI narrative, static data, missing agencies |
| N-1 | MED | Merge Wargame + Incumbent + Teaming → Bid Strategy tab |
| O-2, O-7 | MED | Opp Tracker sub-rows missing columns; NDAA Intel placeholder |
| P-1 | MED | Platform smoke test — never run |
| O-3, O-5, O-6 | Low | Opp Tracker cleanup |
| RR-43 | Low | Bot dual-routing double-fire — fix when telegram-chat next touched |
| RR-44 | Low | n8n_test_workflow 403 on headerAuth — workaround documented |
| RR-36 | Med | Chrome MCP cross-origin — workaround in place |
| RR-38 | FROZEN | Do not touch |
| RR-28 | FROZEN | Do not touch |

---

## Rules

- Claude executes everything via MCP. Never tell Shawn to manually do things.
- RR-38 and RR-28 are FROZEN. Do not touch.
- Show broken vs fixed BEFORE deploying (R-SR-04).
- Spot-check 2 items before any batch operation (R-SR-13).
- End every session: overwrite these 3 project files with updated versions.
- DevOps report is CONDITIONAL — only for major fix waves. Most sessions skip it.
- Bot rollback: n8n_workflow_versions(mode=rollback, workflowId=1ItrrFxGI3L43Pdv) to v4

---

## Schema (Canonical)

- `gda_intelligence_log` time column: **timestamp** (created_at also present)
- Allocation revenue: `gda_capture_plans.plan_data->>'allocated_revenue_value'` (JSONB canonical key)
- `opp-tracker 2` and `ooda-loop 2` are LIVE CANONICAL — do not delete
- Anthropic API: direct HTTP with $env.ANTHROPIC_API_KEY. LangChain cred d92MU0tRK7bEGV83 is BROKEN.
- `gda_mega_cache` — id=1 singleton, 60min TTL
- `gda_feedback` event_types: win, loss, pwin_outcome, opp_label_correction, action_completed, actions_generated, opp_classified, briefing_sent
- `gda_learned_weights` keys: pwin.* (6), briefing.* (3), actions.* (3) — 12 total
- capture-plan Postgres nodes use `queryValues` arrays — queryReplacement fully removed S-158 Chat 2
- `gda_capture_plans.plan_data->>'stage'` — all 98 rows populated
- `gda_incumbent_log` — fully populated, all opps resolved
- TCV in plan_data is sparse; alloc_revenue_value is the real pipeline signal
- DB name is `n8n` (not `gda`) — docker exec psql -U n8n -d n8n
- `gda_capture_plans` active stages: Go/No-Go (77), Interest (8), Post-Submittal (3), Pursue (3), Qualify (2), Proposal (2)
- capture-opp-sync: Flag Orphaned Plans is now a Code node (no DB write) — RR-38 compliant
- DailySitrep now calls gda-dashboard-mega (not gda-daily-sitrep). Reads data.sitrep for all sections.
- dashboard-mega sitrep fields: world_news, market_signals, govt_intel, acquisition_news, bluf, critical_actions, pipeline_status, top_news, summary, strategic_synthesis
- `gda_morning_briefings` schema (7 cols): id, briefing (text), model, input_tokens, output_tokens, generated_at (timestamptz), headlines (jsonb)
- `gda_morning_briefings.headlines` — jsonb array of {title, url, source, pubDate, summary} per RSS item — populated from S-159 C20 onward
