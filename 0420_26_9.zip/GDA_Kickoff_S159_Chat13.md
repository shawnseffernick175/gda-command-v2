# GDA Command Platform — S-159 Chat 13 Kickoff

**Last session:** S-159 Chat 12, April 21, 2026
**Status:** O-1 CLOSED. A-1 CLOSED. S-7 CLOSED.

---

## Pre-Flight
1. `tool_search("n8n")` — load MCP
2. Read this file
3. RR-38 and RR-28 FROZEN

---

## FIRST ACTION NEXT SESSION

### AN-1 — Real Analysis: Incumbent, Win Themes (HIGH)

GDA.api.chat-simple and the deep research system have no structured incumbent analysis. The AI agent can't answer "who is the incumbent on X" or "what themes do we win on." 

Plan:
- Check gda_capture_plans for incumbent_analysis field population rate
- Check gda_deep_research table for usable incumbent data
- Wire incumbent + win-theme data into AI agent context snapshot

---

## Context from This Session
- O-1 CLOSED: All three APIs now use `stage NOT IN ('No-Bid','Cancelled','No-Go','Lost','Won')` — consistent 205 opps / $2.30B / 103 pursuing
- A-1 CLOSED: chat-simple now injects live DB snapshot (opps, pursue, top plans, deadlines) into every Claude call
- S-7 CLOSED: Morning Brief Merge mode → append; parser → 72h + fallback. Test id=16: 2909 tokens confirms real data
- Morning brief now generates daily with real RSS. Next: add SAM.gov key if available

## Full Backlog
See GDA_Master_Build_v159c12.xlsx — Backlog tab.

## Key Notes
- Correct auth header: `x-gda-key: gda-api-2026-secure`
- Postgres inline template rule (typeVersion 2.5/2.6): `{{ $json.field }}` inline — never queryValues/queryReplacement
- Switch node broken — use IF or Code
- LangChain cred d92MU0tRK7bEGV83 BROKEN — use direct HTTP + $env.ANTHROPIC_API_KEY
- contract_value in gda_capture_plans: TEXT, 57 rows use xM format — always CASE WHEN ILIKE '%M' cast
- Docker Postgres DB name: `n8n`
- RR-44 pattern: set Webhook auth to none → fire → restore headerAuth
