# GDA Command Platform — Session S-204 Kickoff
**Date:** Next session after 2026-05-05  
**Platform version:** v203 (post S-203)  
**Operator:** Claude Sonnet 4.6  
**President:** Shawn Seffernick, EIS / GDA OU3

---

## Mandatory Session Open Protocol

1. `tool_search("n8n")` — load MCP context  
2. Check this kickoff for carry-forward queue  
3. Open with top priority item — do not ask Shawn what to work on

---

## Platform State at Session Open

| Component | State | Note |
|---|---|---|
| `n8n-envision-gda-frontend-1` | UP | Restarted S-203 — monitor stability |
| `gda.csr-llc.tech` | LIVE | All 3 routes 200 |
| Launchpad API (`GDA.api.launchpad`) | LIVE | 103 PURSUE / 70 EVALUATE / $2.3B pipeline |
| Pipeline API (`GDA.api.pipeline`) | LIVE | 100-row sortable table |
| `gda_feedback` | 8 rows | Seeded S-203 — learning engine unblocked |
| `gda_learned_weights` | 12 rows | Calibration pending 11:00 UTC run |
| Learning engine (`fZpqchmmPnqAmiMq`) | UNBLOCKED | Will run at 11:00 UTC — verify output |

---

## Auth / Keys (Canonical — Do Not Change)

| Key | Value |
|---|---|
| Primary API key (header: x-gda-key) | `gda-api-2027-AWqjhbxDYNcyV1mr` |
| Deploy key (body: deploy_key) | `gda-deploy-2027-AWqjhbxDYNcyV1mr` |
| Webhook auth cred (general/SSH) | `1pNPY36DDz49OtKL` |
| Webhook auth cred (chat/deploy) | `fTrhOzBkjS1s67bm` |

---

## S-204 Priority Queue

### P1 — Verify Learning Engine Calibration
- Check `gda_learned_weights` table after next 11:00 UTC cron run
- Verify `current_weight` values updated (were 0/null at S-203 close)
- Workflow: `fZpqchmmPnqAmiMq` — DO NOT modify internals, only verify
- If weights populated: confirm `GDA.api.launchpad` analysis_status updates
- SQL to verify:
  ```sql
  SELECT factor_name, current_weight, updated_at 
  FROM gda_learned_weights 
  ORDER BY current_weight DESC;
  ```

### P2 — Rebuild Gist Update Workflow
- `t85atQIzsTajgUre` no longer exists
- New workflow: `GDA.util.gist-update`
- Must accept POST with auth, write session state to GitHub Gist
- GitHub Gist PAT credential: `sKJFLNzetK86JnvO`
- Wire into `8GnGxnBL9TJjj1i2` Notify Gist node (currently calls dead URL)

### P3 — Fix Deploy Workflow SSH Expression Bug (HP-DEPLOY)
- `8GnGxnBL9TJjj1i2` SSH Write Files and SSH Build nodes have command expressions that don't serialize via MCP
- Root cause: `parameters.command` is stored as n8n expression `={{ $json.script }}` internally, not in the `parameters` object the MCP API returns
- Fix options:
  a) Open n8n UI → verify/restore command expressions on both SSH nodes
  b) Replace with a single SSH node that runs the full script inline (simpler)
- Until fixed: all VPS operations must use `IcD4K740vpWSIuaZ` (ssh-read-file) via `python3 -c`

### P4 — AN-1 Auto-Surface in Launchpad
- `GDA.intel.an1-incumbent-win-themes` (`yMo7WrELV8JVOi2M`) is live and wired into agentic-chat
- Wire outputs into `GDA.api.launchpad` Build Response node
- Surface as `analysis` field with top 3 incumbent themes for the top PURSUE opp
- Keep honest empty state if AN-1 hasn't run on that opp

### P5 — S-164-01: Retool Launchpad KPI Binding
- `gdacommand.retool.com` Launchpad shows $0 pipeline
- Frontend-only Retool fix — check binding against `GDA.api.launchpad` response shape
- API returns `kpis.weighted_pipeline_raw` (numeric) and `kpis.weighted_pipeline` (formatted string)

---

## Platform Hard Rules (Unchanged)

- **Switch nodes broken platform-wide** — use IF or Code nodes
- **Postgres typeVersion 2.5/2.6** — inline `{{ $json.field }}` only; no `queryValues` arrays
- **LangChain cred `d92MU0tRK7bEGV83` is dead** — use HTTP Request with `$env.ANTHROPIC_API_KEY`
- **SAM.gov has no API** — never build/invoke a SAM API
- **Frozen workflows: `1G4gw4N7DFtVZKF7` / `NQmaj5nu4TBQxBgD`** — DO NOT TOUCH
- **`MJapg8dGkvEzLn0K`** — canonical ingest — DO NOT TOUCH
- **`docker compose up -d n8n`** — FORBIDDEN from within n8n
- **RR-38 and RR-28** — RESOLVED/CLOSED, do not reference as frozen
- **N8N_ENCRYPTION_KEY** — must be persisted in `/root/n8n-envision/.env`. Never paste in chat. Recovery: `docker exec n8n-envision-n8n-1 env | grep -i "encryption|api_key" >> /root/n8n-envision/.env`

---

## Key Workflow IDs

| Workflow | ID |
|---|---|
| GDA.dev.deploy | `8GnGxnBL9TJjj1i2` |
| GDA.util.ssh-read-file | `IcD4K740vpWSIuaZ` |
| GDA.api.launchpad | `GrbSQxeJs7ag6zXx` |
| GDA.api.pipeline | `f4PLgyzEu0tj3R5Y` |
| GDA.cron.learning-engine | `fZpqchmmPnqAmiMq` |
| GDA.cron.fast-track-ingest | `MJapg8dGkvEzLn0K` |
| GDA.intel.an1-incumbent-win-themes | `yMo7WrELV8JVOi2M` |
| GDA.api.agentic-chat | `jalin8peBLddjsEa` |
| GDA.error.handler | `2Swf6LP9AzFjHFYU` |
| GDA.oneshot.seed-feedback-s203 | `gBCN4PXeAdjZa3xI` (INACTIVE — do not reactivate) |

---

## S-203 What Was Done (Do Not Redo)

- nginx.conf: all empty proxy_set_header values fixed; x-gda-key injected on launchpad + pipeline routes  
- Container `n8n-envision-gda-frontend-1` restarted and running  
- GDALaunchpad.jsx: TITLE6/ATTEWTION/CONMAND typos fixed; built and deployed  
- `gda_feedback`: 8 rows seeded (pursue×5, stage_prog×2, evaluate×1, pass×1) using real opp IDs  
- All 3 SPA routes confirmed 200; Launchpad API confirmed returning real data  

---

*Session S-203 closed ~02:00 UTC 2026-05-05. Next session opens with P1: verify learning engine calibration.*
