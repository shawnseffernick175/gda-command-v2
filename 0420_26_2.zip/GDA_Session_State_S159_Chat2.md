# GDA Command Platform — Session State
**Last Updated:** S-159 Chat 2 — April 20, 2026
**Operator:** Shawn Seffernick, President, Envision Innovative Solutions (OU3)

---

## Pre-Flight (Every Chat)
1. `tool_search("n8n")` — load MCP
2. Read this file
3. **RR-38 and RR-28 are FROZEN** — do not touch ever

---

## FIRST ACTION NEXT CHAT

RR-57-B1 is the top open item (Med): capture-plan list API needs to JOIN opp tracker gda_label so the Pass tab populates correctly. Fix is in List Plans node of QgperN6cuOpfnb09.

Ask Shawn if he wants that fix or has new items.

---

## CRITICAL: App.jsx encoding rule
**Always write App.jsx with UTF-8 encoding.** The file was corrupted previously by a latin-1 write that mangled non-ASCII chars. All patches must use `encoding='utf-8'` when writing.

## Deploy Webhook Auth Note (RR-44)
Temp patch `authentication` to `none` on Webhook node → fire test → restore to `headerAuth`.

---

## Platform State

| Item | Status |
|---|---|
| Active workflows | ~151 |
| Frontend (gda.csr-llc.tech) | LIVE — commit fb58c8c |
| GDA.api.capture-plan | ACTIVE — 23 nodes, RR-42+RR-55 FIXED, RR-56 FIXED |
| GDA.api.opp-tracker 2 | ACTIVE — hierarchy FIXED, stage update FIXED, Unassigned L3 FIXED |
| GDA.cron.auto-capture-plan | ACTIVE — queryReplacement removed |
| GDA.intel.morning-briefing-v1 | ACTIVE — 16 nodes |
| GDA.api.daily-actions | ACTIVE — 17 nodes |
| GDA.api.pwin-calculator | ACTIVE — LIMIT hardcoded 100 |
| GDA.api.win-loss-db | ACTIVE — numeric fix + direct HTTP analyze |
| GDA.api.dashboard-mega | ACTIVE — 1hr cache |
| All cron workflows | ACTIVE |
| GDA.auto.feedback-collector | ACTIVE |
| GDA.cron.learning-engine | ACTIVE — nightly 3am ET |
| GDA.agent.opp-classifier | ACTIVE — feedback wire LIVE |

---

## Key Workflow IDs

| Workflow | ID |
|---|---|
| GDA.dev.deploy | 8GnGxnBL9TJjj1i2 |
| GDA.bot.telegram-chat | 1ItrrFxGI3L43Pdv |
| GDA.api.daily-actions | C7Bh7KcAl1IgSTRr |
| GDA.api.ooda-loop 2 | pkPpMhiz8IdRy7To |
| GDA.intel.morning-briefing-v1 | YIvCdrOgF1LGmFNL |
| GDA.api.dashboard-mega | UYGJPu7N5YZblvEU |
| GDA.api.opp-tracker 2 | SEJLE89wZa1yfQyB |
| GDA.api.capture-plan | QgperN6cuOpfnb09 |
| GDA.api.win-loss-db | SpU3znFHHABYNmb9 |
| GDA.api.pwin-calculator | 81m1Zl9xjM6L8HQb |
| GDA.agent.opp-classifier | hWCP9NLXxtCOrppu |
| GDA.cron.auto-capture-plan | 7gERqvfD6THg1gWf |
| GDA.api.prompt-architect | HyNQ5Ma2OLlCyJhv |
| GDA.util.ssh-read-file | IcD4K740vpWSIuaZ |
| GDA.cron.learning-engine | fZpqchmmPnqAmiMq |
| GDA.auto.feedback-collector | aCrxoe1rCuIbsnC4 |
| GDA.cron.recompete-early-warning | MtcQwAgm1zHYXNfB |
| GDA.cron.idiq-task-order-alert | DeSN1t1swXX14xTc |
| GDA.cron.capture-opp-sync | 0E3lCtWt2rdJlMPY |
| GDA.api.platform-health | UBgoJGxZro834RbT |
| GDA.api.bd-activity-log | 9qrsria0fy719T98 |
| GDA.api.teaming-scorer | jQvgX6SD1RhARG3F |
| GDA.cron.capture-milestone-alerts | Kk7O8Bw2FOe41M9l |

---

## Infrastructure

| Resource | Detail |
|---|---|
| Frontend source | /opt/gda-command/src/App.jsx |
| App.jsx encoding | **UTF-8 always** — latin-1 corrupts the file |
| App.jsx backup | /opt/gda-command/src/App.jsx.bak-s158-kpi (418KB, Apr 11) — use if corrupted |
| Deploy webhook | POST https://n8n.csr-llc.tech/webhook/gda-deploy |
| Deploy auth | Header: x-gda-auth: gda-deploy-2026-secure |
| Deploy MCP pattern | Temp set Webhook auth to none → fire → restore headerAuth |
| SSH webhook | POST https://n8n.csr-llc.tech/webhook/ssh-read-file (IcD4K740vpWSIuaZ) |
| SSH auth | headerAuth — temp to none for MCP use, always restore |
| Postgres cred | HwronxMmGY5XDGEt |
| n8n | https://n8n.csr-llc.tech (v2.37.1) |
| Frontend | https://gda.csr-llc.tech |

---

## Open Debt

| ID | Sev | Summary |
|---|---|---|
| RR-57-B1 | Med | Pass tab — capture-plan List Plans node needs JOIN to gda_opportunity_tracker on opp_id to pull gda_label. Frontend check for row.no_bid in place; API side returns false until fixed. |
| RR-57-B2 | Low | Sidebar dropdowns — no code bug found. Retest post-deploy. |
| RR-36 | Med | Chrome MCP cross-origin — workaround in place |
| RR-43 | Low | Bot dual-routing double-fire |
| RR-44 | Low | n8n_test_workflow 403 on headerAuth |
| RR-38 | FROZEN | Do not touch |
| RR-28 | FROZEN | Do not touch |

---

## Rules

- Claude executes everything via MCP. Never tell Shawn to manually do things.
- RR-38 and RR-28 are FROZEN. Do not touch.
- Show broken vs fixed BEFORE deploying (R-SR-04).
- End every session: overwrite these 3 project files with updated versions.
- Bot rollback: n8n_workflow_versions(mode=rollback, workflowId=1ItrrFxGI3L43Pdv) to v4

---

## Schema (Canonical)

- Anthropic API: direct HTTP with $env.ANTHROPIC_API_KEY — LangChain cred d92MU0tRK7bEGV83 BROKEN
- Postgres inline template rule: ALL Postgres nodes via MCP use `{{ $json.field }}` inline — never queryValues/queryReplacement at typeVersion 2.5/2.6
- Switch node is broken — use IF or Code node for routing
- capture-plan: all Postgres nodes inline template (RR-42 + RR-55)
- opp-tracker 2 Update Stage PG: inline `'{{ $json.stage }}'` / `{{ $json.opp_id }}`
- pwin-calculator List Scores: hardcoded LIMIT 100
- win-loss-db: always parseFloat() for numeric columns
- Agency hierarchy: L1=DoW/DHS/VA etc, L2=Army/Navy/AF etc, L3=PEO/command — inferCommand() final fallback now 'Other' not 'Unassigned'
- App.jsx CapturePlan: card display reads pd4.codename || row2.opportunity || row2.opp_title || 'Untitled'
- App.jsx openPlan(): reads row.opp_title as fallback; maps pd.capture_stage; handles pwin/incumbent as string or object
- gda_mega_cache: id=1 singleton, 60min TTL
- `gda_feedback` event_types: win, loss, pwin_outcome, opp_label_correction, action_completed, actions_generated, opp_classified, briefing_sent
