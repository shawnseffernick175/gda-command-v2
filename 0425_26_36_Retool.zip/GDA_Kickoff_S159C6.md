# GDA Command Platform — S-159 Chat 6 Kickoff
**Date:** Next session after 2026-04-26
**Operator:** Shawn Seffernick, President, Envision Innovative Solutions (OU3)
**Mode:** Pure-MCP

---

## Pre-Flight Checklist
1. `tool_search("n8n")` — load MCP toolset
2. Read this file
3. **RR-38 and RR-28 are FROZEN** — do not touch under any circumstances

---

## FIRST ACTION NEXT CHAT

Check for new items from Shawn. Default if none: **D-002** — wire 6 Retool pages to correct Postgres tables.

---

## Key Credentials (Current)

| Resource | Value |
|---|---|
| API key (all webhooks) | `gda-api-2026-f584dae2` |
| Deploy key | `gda-deploy-2026-34a11f91` |
| Webhook header | `x-gda-key` |
| Credential ID | `fTrhOzBkjS1s67bm` |

---

## Platform State at S-159 Chat 5 Close

| Item | Status |
|---|---|
| Active workflows | ~155 |
| Frontend | LIVE — all /api routes 200 |
| React /api proxy | FIXED — nginx x-gda-key updated |
| Retool | LIVE — 20/25 pages PASS |

---

## Open Debt

| ID | Sev | Summary |
|---|---|---|
| D-002 | P2 | Retool: 6 pages showing Retool demo data instead of gda_* tables — Meeting Notes (gda_meeting_notes), Competitive Intel (gda_competitor_intel), Compliance Matrix, Document Hub, Proposal Review, Risk Register (gda_risk_register) |
| RR-36 | Med | Chrome MCP cross-origin — workaround in place |
| RR-43 | Low | Bot dual-routing — fix when telegram-chat next touched |
| RR-44 | Low | n8n_test_workflow 403 on headerAuth — workaround documented |
| RR-38 | FROZEN | Do not touch |
| RR-28 | FROZEN | Do not touch |

---

## D-002 Detail

Six Retool pages have their data tables bound to a Retool demo/users resource. The correct tables are:
- **Meeting Notes** → `gda_meeting_notes` (id, title, meeting_date, attendees, meeting_type, notes, created_at)
- **Competitive Intel** → `gda_competitor_intel` (id, competitor_name, agency, contract_vehicle, incumbent, strengths, weaknesses, updated_at)
- **Compliance Matrix** → no dedicated table yet — needs `gda_compliance_items` or repurpose existing
- **Document Hub** → no dedicated table yet — needs `gda_proposal_sections` or new table
- **Proposal Review** → `gda_proposal_sections` (id, opportunity_id, section_type, content, updated_at)
- **Risk Register** → `gda_risk_register` (id, opportunity_id, risk_description, likelihood, impact, mitigation, status, created_at)

Approach: open each page in Retool editor, swap the data source from the demo resource to GDA Postgres, write the correct SQL query.

---

## Platform Rules
- Claude executes everything via MCP. Never tell Shawn to manually do things.
- RR-38 and RR-28 are FROZEN.
- All webhooks: `x-gda-key` header only.
- Postgres: inline `{{ }}` expressions — no queryValues arrays, no queryReplacement.
- Switch node broken — use IF nodes.
- LangChain cred `d92MU0tRK7bEGV83` BROKEN — use direct HTTP with `$env.ANTHROPIC_API_KEY`.
- headerAuth test pattern: temp none → fire → restore (RR-44).
- nginx.conf for React frontend: /root/gda-frontend/nginx.conf (bind-mounted).
- Deploy webhook: x-gda-key + x-gda-auth both required.
- End every session with R-SR-09.

---

*— GDA Command Platform S-159 Chat 6 Kickoff —*
