# GDA Command Platform — Session State
**Last Updated:** S-159 Chat 1 — April 25, 2026
**Operator:** Shawn Seffernick, President, Envision Innovative Solutions (OU3)

---

## Pre-Flight (Every Chat)
1. `tool_search("n8n")` — load MCP
2. Read this file
3. **RR-38 and RR-28 are FROZEN** — do not touch ever

---

## FIRST ACTION NEXT CHAT

Check for new items from Shawn. If none, proceed to S-159 Hardening Queue — next item is **Item 5 completion** (6 remaining cron workflows: ZuQkz1HrMONclkFm, DeSN1t1swXX14xTc, 0E3lCtWt2rdJlMPY, fZpqchmmPnqAmiMq, Kk7O8Bw2FOe41M9l, uQ5cZ97cCrx5iIXk). Then Items 6, 7, 8 in order.

---

## S-159 Hardening Queue Status

| Item | Status | Next Action |
|---|---|---|
| Item 1 — SSH Read Auth | DONE | — |
| Item 2 — API Key Audit | CLEAN | — |
| Item 3 — SSH Allowlist | PRE-DONE | — |
| Item 4 — Retention Audit | CLEAN | — |
| Item 5 — Error Handler Coverage | PARTIAL | Check 6 remaining cron workflows (see above) |
| Item 6 — Key Rotation | QUEUED | Generate new keys, update cred + App.jsx + hardcoded refs |
| Item 7 — nginx Rate Limiting | QUEUED | SSH to VPS, add limit_req_zone 30r/m |
| Item 8 — Final PG Audit | QUEUED | Scan all workflows; skip QgperN6cuOpfnb09 + uQ5cZ97cCrx5iIXk |

---

## Deploy Webhook Auth Note (RR-44)
Temp patch `authentication` to `none` on both Webhook and Read Webhook nodes → fire → restore to `headerAuth`.

---

## Platform State

| Item | Status |
|---|---|
| Active workflows | ~155 |
| Frontend (gda.csr-llc.tech) | LIVE |
| GDA.util.ssh-read-file | ACTIVE — headerAuth LIVE, versionCounter 415 |
| GDA.api.dashboard-mega | ACTIVE — 10 nodes, 1hr cache |
| GDA.intel.morning-briefing-v1 | ACTIVE — 16 nodes, data-learn wire LIVE, Test Webhook headerAuth |
| GDA.api.daily-actions | ACTIVE — 17 nodes |
| GDA.api.pwin-calculator | ACTIVE — loads learned weights from DB |
| GDA.api.win-loss-db | ACTIVE — auto-posts W/L to feedback-collector |
| GDA.api.capture-plan | ACTIVE — 23 nodes, RR-42 FIXED |
| GDA.cron.recompete-early-warning | ACTIVE — daily 7am ET, errorWorkflow confirmed |
| GDA.cron.win-rate-weekly-digest | ACTIVE — Mondays 8am ET, errorWorkflow NOT YET verified |
| GDA.cron.idiq-task-order-alert | ACTIVE — daily 8am ET, errorWorkflow NOT YET verified |
| GDA.cron.capture-opp-sync | ACTIVE — nightly 2am ET, errorWorkflow NOT YET verified |
| GDA.api.platform-health | ACTIVE |
| GDA.api.bd-activity-log | ACTIVE |
| GDA.api.teaming-scorer | ACTIVE |
| GDA.cron.capture-milestone-alerts | ACTIVE — daily 9am ET, errorWorkflow NOT YET verified |
| GDA.auto.feedback-collector | ACTIVE |
| GDA.cron.learning-engine | ACTIVE — nightly 3am ET, errorWorkflow NOT YET verified |
| GDA.agent.opp-classifier | ACTIVE — 6 nodes, feedback wire LIVE |
| GDA.api.morning-briefing | ACTIVE — Briefing Webhook headerAuth |
| GDA.enrichment.capture-plan-cards | ACTIVE — Webhook headerAuth |
| GDA.util.smoke-test | ACTIVE — Webhook Trigger headerAuth |

---

## Key Workflow IDs

| Workflow | ID |
|---|---|
| GDA.dev.deploy | 8GnGxnBL9TJjj1i2 |
| GDA.bot.telegram-chat | 1ItrrFxGI3L43Pdv |
| GDA.api.daily-actions | C7Bh7KcAl1IgSTRr |
| GDA.api.ooda-loop 2 | pkPpMhiz8IdRy7To |
| GDA.intel.morning-briefing-v1 | YIvCdrOgF1LGmFNL |
| GDA.api.launchpad-funnel | vaRzM1Jl6HcXjuxs |
| GDA.api.dashboard-mega | UYGJPu7N5YZblvEU |
| GDA.api.opp-tracker 2 | SEJLE89wZa1yfQyB |
| GDA.api.capture-plan | QgperN6cuOpfnb09 |
| GDA.sched.opp-refresh | PeLGDqgLAsEh5Gsd |
| GDA.research.deep-research | q9YWVQCwnJGqmrO7 |
| GDA.auto.gist-update | djgOV2vX3PIv9cvm |
| GDA.api.aop-tracker | P8AfP8P84xi33auD |
| GDA.api.win-loss-db | SpU3znFHHABYNmb9 |
| GDA.cron.recompete-early-warning | MtcQwAgm1zHYXNfB |
| GDA.cron.win-rate-weekly-digest | ZuQkz1HrMONclkFm |
| GDA.cron.idiq-task-order-alert | DeSN1t1swXX14xTc |
| GDA.cron.capture-opp-sync | 0E3lCtWt2rdJlMPY |
| GDA.api.platform-health | UBgoJGxZro834RbT |
| GDA.api.bd-activity-log | 9qrsria0fy719T98 |
| GDA.api.teaming-scorer | jQvgX6SD1RhARG3F |
| GDA.cron.capture-milestone-alerts | Kk7O8Bw2FOe41M9l |
| GDA.auto.feedback-collector | aCrxoe1rCuIbsnC4 |
| GDA.cron.learning-engine | fZpqchmmPnqAmiMq |
| GDA.api.pwin-calculator | 81m1Zl9xjM6L8HQb |
| GDA.agent.opp-classifier | hWCP9NLXxtCOrppu |
| GDA.util.ssh-read-file | IcD4K740vpWSIuaZ |
| GDA.api.morning-briefing | 0zVPgmYsvcqhyyo6 |
| GDA.enrichment.capture-plan-cards | 4szS4FHP1pW1PiG8 |
| GDA.util.smoke-test | zPT6cd33TmJa7SZX |
| Error handler workflow | 2Swf6LP9AzFjHFYU |

---

## Infrastructure

| Resource | Detail |
|---|---|
| Frontend source | /opt/gda-command/src/App.jsx |
| Deploy webhook | POST https://n8n.csr-llc.tech/webhook/gda-deploy |
| Deploy auth | Header: x-gda-auth: gda-deploy-2026-secure |
| Deploy MCP pattern | Temp set Webhook + Read Webhook auth to none → fire → restore headerAuth |
| SSH webhook (read) | POST https://n8n.csr-llc.tech/webhook/gda-read |
| SSH auth | Header: x-gda-key: gda-api-2026-secure |
| SSH read workflow | IcD4K740vpWSIuaZ — NOW headerAuth protected |
| Postgres cred | HwronxMmGY5XDGEt |
| VPS | 187.77.206.105 |
| n8n | https://n8n.csr-llc.tech (v2.37.1) |
| Frontend | https://gda.csr-llc.tech |
| MCP | https://mcp.csr-llc.tech/mcp |
| Feedback endpoint | POST https://n8n.csr-llc.tech/webhook/gda-feedback |
| Data-learn endpoint | POST https://n8n.csr-llc.tech/webhook/gda-data-learn |

---

## Learning System

| Component | Status |
|---|---|
| gda_feedback + gda_learned_weights tables | LIVE — seeded with 12 Shipley weights |
| gda_learning_log table | LIVE |
| feedback-collector | ACTIVE |
| learning-engine | ACTIVE — nightly 3am ET |
| pwin-calculator | UPDATED — loads learned weights |
| win-loss-db | UPDATED — auto-posts W/L to feedback |
| daily-actions | UPDATED — posts action counts to feedback |
| morning-briefing → data-learn | LIVE — node dl-01 |
| opp-classifier → feedback | LIVE — node oc-06 |

---

## Open Debt

| ID | Sev | Summary |
|---|---|---|
| HARDEN-5 | Med | Error handler coverage — 6 cron workflows not yet verified |
| HARDEN-6 | Med | Webhook key rotation — keys in service since launch |
| HARDEN-7 | Med | nginx rate limiting — no rate limit on /webhook/ |
| HARDEN-8 | Low | Final Postgres queryReplacement audit |
| RR-42 | CLOSED | capture-plan: 4 queryReplacement nodes → queryValues. Fixed S-158 Chat 2 |
| RR-49 | CLOSED | Both feedback wires complete |
| RR-36 | Med | Chrome MCP cross-origin — workaround in place |
| RR-43 | Low | Bot dual-routing double-fire — fix when telegram-chat next touched |
| RR-44 | Low | n8n_test_workflow 403 on headerAuth — workaround documented |
| RR-38 | FROZEN | Do not touch |
| RR-28 | FROZEN | Do not touch |

---

## Rules

- Claude executes everything via MCP. Never tell Shawn to manually do things.
- RR-38 and RR-28 are FROZEN. Do not touch.
- Show broken vs fixed BEFORE deploying (R-SR-04).
- Spot-check 2 items before any batch operation (R-SR-13).
- End every session: overwrite these 3 project files with updated versions.
- DevOps report is CONDITIONAL — only for major fix waves. Most sessions skip it.
- Bot rollback: n8n_workflow_versions(mode=rollback, workflowId=1ItrrFxGI3L43Pdv) to v4

---

## Schema (Canonical)

- `gda_intelligence_log` time column: **timestamp** (created_at also present)
- Allocation revenue: `gda_capture_plans.plan_data->>'allocated_revenue'` (JSONB, dollars)
- `opp-tracker 2` and `ooda-loop 2` are LIVE CANONICAL — do not delete
- Anthropic API: direct HTTP with $env.ANTHROPIC_API_KEY. LangChain cred d92MU0tRK7bEGV83 is BROKEN.
- `gda_mega_cache` — id=1 singleton, 60min TTL
- `gda_feedback` event_types: win, loss, pwin_outcome, opp_label_correction, action_completed, actions_generated, opp_classified, briefing_sent
- `gda_learned_weights` keys: pwin.* (6), briefing.* (3), actions.* (3) — 12 total
- capture-plan Postgres nodes use `queryValues` arrays — queryReplacement fully removed S-158 Chat 2
- Postgres queryValues/queryReplacement serialization bug: at typeVersion 2.5/2.6, n8n MCP API strips options.queryValues at runtime — use inline n8n template expressions in query string instead
- Switch node broken across all typeVersions — use IF nodes (n8n-nodes-base.if, typeVersion 2.2) or Code node routing
