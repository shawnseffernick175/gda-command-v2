# GDA Command Platform — S-159 Chat 2 Kickoff
**Date:** Next session after 2026-04-25  
**Operator:** Shawn Seffernick, President, Envision Innovative Solutions (OU3)  
**Mode:** Pure-MCP  
**Session Series:** Security Hardening Plan execution

---

## Pre-Flight Checklist
1. `tool_search("n8n")` — load MCP toolset
2. Read this file
3. **RR-38 and RR-28 are FROZEN** — do not touch under any circumstances

---

## FIRST ACTION NEXT CHAT

**Check for new items from Shawn.** If none, proceed to the S-159 Hardening Queue below.

---

## S-159 Hardening Queue (Priority Order)

### Item 5 (PARTIAL → Complete) — Error Handler Coverage
**6 remaining cron workflows to check:**

| Workflow ID | Name |
|---|---|
| ZuQkz1HrMONclkFm | GDA.cron.win-rate-weekly-digest |
| DeSN1t1swXX14xTc | GDA.cron.idiq-task-order-alert |
| 0E3lCtWt2rdJlMPY | GDA.cron.capture-opp-sync |
| fZpqchmmPnqAmiMq | GDA.cron.learning-engine |
| Kk7O8Bw2FOe41M9l | GDA.cron.capture-milestone-alerts |
| uQ5cZ97cCrx5iIXk | (unknown name — verify via n8n_get_workflow) |

**Target errorWorkflow:** `2Swf6LP9AzFjHFYU`  
**Action:** For any missing errorWorkflow: `n8n_update_partial_workflow` with `updateSettings` op to set `errorWorkflow: "2Swf6LP9AzFjHFYU"`.  
**Also:** Inspect `2Swf6LP9AzFjHFYU` itself — confirm it sends Telegram message with workflow name and error message. If not, add that node.

---

### Item 6 — Webhook Key Rotation
**Risk:** Keys `gda-api-2026-secure` and `gda-deploy-2026-secure` in service since launch, appear in multiple session transcripts.

**Steps:**
1. SSH to VPS via `IcD4K740vpWSIuaZ`: `python3 -c "import secrets; print(secrets.token_hex(4))"` twice
2. Build new keys: `gda-api-2026-[hex8]` and `gda-deploy-2026-[hex8]`
3. Update credential `fTrhOzBkjS1s67bm` (GDA Webhook Auth) with new deploy key
4. Read App.jsx via deploy workflow — find all occurrences of `gda-api-2026-secure`, replace with new API key
5. Search all workflows for hardcoded `gda-api-2026-secure` in node parameters (Auth Check / Auth Guard Code nodes) — update each
6. Build and deploy via `8GnGxnBL9TJjj1i2`
7. Update session state doc with new key values

---

### Item 7 — nginx Rate Limiting
**Risk:** No rate limiting on webhook endpoints — accidental loops or brute force could take the server down.

**Steps (via SSH workflow IcD4K740vpWSIuaZ):**
1. Read nginx config: `cat /etc/nginx/sites-available/n8n` (or `cat /etc/nginx/nginx.conf`)
2. Add to `http {}` block: `limit_req_zone $binary_remote_addr zone=gda_webhooks:10m rate=30r/m;`
3. Add to `location /webhook/ {}` block: `limit_req zone=gda_webhooks burst=10 nodelay;`
4. Test: `nginx -t`
5. If clean: `nginx -s reload`
6. Verify normal call still returns 200

---

### Item 8 — Final Postgres queryReplacement Audit
**Risk:** Any remaining `queryReplacement` nodes will silently fail with comma-containing data (agency names, JSON blobs).

**Steps:**
1. Run `n8n_audit_instance` with `customChecks: ["hardcoded_secrets"]` — look for Postgres node references
2. List all active workflows; for each workflow check parameters for `queryReplacement` key
3. **Skip known-clean:** `QgperN6cuOpfnb09` (RR-42 fixed S-158 Chat 2) and `uQ5cZ97cCrx5iIXk` (C-25)
4. For any found: convert to `queryValues` pattern using `$1, $2` positional params
5. Trigger affected workflow manually with test data; confirm clean execution

---

## Platform State at S-159 Chat 1 Close

| Item | Status |
|---|---|
| Active workflows | ~155 |
| Frontend (gda.csr-llc.tech) | LIVE |
| SSH Read (IcD4K740vpWSIuaZ) | NOW SECURED — headerAuth, versionCounter 415 |
| All public webhooks | 4 bonus endpoints locked to headerAuth |
| capture-plan | ACTIVE — 23 nodes, RR-42 FIXED |
| Learning system | FULLY WIRED |
| Hardening Items 1-4 | COMPLETE (Items 2, 3, 4 were already clean/pre-done) |
| Hardening Item 5 | PARTIAL — 6 cron workflows remain |
| Hardening Items 6-8 | QUEUED |

---

## Key Credentials / IDs (unchanged)

| Resource | Value |
|---|---|
| GDA Webhook Auth | `fTrhOzBkjS1s67bm` — `x-gda-key: gda-api-2026-secure` |
| VPS Root SSH | `VqYFb1aRGJa8UfBc` |
| Postgres | `HwronxMmGY5XDGEt` |
| SSH Read workflow | `IcD4K740vpWSIuaZ` |
| Deploy workflow | `8GnGxnBL9TJjj1i2` |
| Error handler workflow | `2Swf6LP9AzFjHFYU` |
| Frozen workflows | `RR-38`, `RR-28` — DO NOT TOUCH |

---

## Platform Rules (carry-forward)
- Claude executes everything via MCP. Never tell Shawn to manually do things.
- RR-38 and RR-28 are FROZEN. Do not touch.
- Show broken vs fixed BEFORE deploying (R-SR-04).
- Postgres queryValues pattern only — no queryReplacement anywhere.
- Switch node broken — use IF nodes or Code node routing instead.
- LangChain cred `d92MU0tRK7bEGV83` is BROKEN — Anthropic API: direct HTTP with `$env.ANTHROPIC_API_KEY` only.
- App.jsx must always be written with UTF-8 encoding. Backup: `/opt/gda-command/src/App.jsx.bak-s158-kpi`.
- headerAuth webhook test pattern: temp set to `none` → fire → restore to `headerAuth` (RR-44).
- End every session with R-SR-09: DevOps Report (conditional), Session Delta DOCX, Master Build XLSX, Kickoff MD.

---

*— GDA Command Platform S-159 Chat 2 Kickoff —*
