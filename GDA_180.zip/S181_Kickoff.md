# S-181 SESSION KICKOFF
**GDA Command Platform | EIS / GDA OU3 | Shawn Seffernick**
**Generated: 2026-05-01 (S-180 Close)**

---

## MANDATORY FIRST ACTION
```
tool_search("n8n")   ← load MCP before ANY other action
```

---

## CARRY-FORWARD STATUS
- R-SR-09 artifacts from S-180: COMPLETE (Session Delta DOCX, DevOps Report DOCX, Master Build XLSX v4.180, this Kickoff MD)
- AN-1 COMPLETE: capture-plan AI agent now has 7 EIS win themes + 5-segment incumbent intelligence seeded into both generate and analyze_phase flows
- MCP-AUTH PARTIAL: capture-plan Auth Check + Bidi Sync updated to 2027 key; MCP server config itself not yet updated

---

## S-181 PRIORITY QUEUE (Execute in Order)

| Rank | ID | Priority | Description |
|------|----|----------|-------------|
| 1 | **MCP-AUTH** | 🟡 MED | Update MCP server config (mcp.csr-llc.tech) to use rotated key (gda-api-2027-AWqjhbxDYNcyV1mr) so internal webhook calls work without auth bypass pattern |
| 2 | **SSH-KEY** | 🟡 MED | Restore SSH key-based auth to VPS — password prompt on every call is unacceptable friction |

---

## PLATFORM SNAPSHOT (entering S-181)

| Component | Status |
|-----------|--------|
| n8n | OPERATIONAL (2.49.0) |
| Frontend (gda.csr-llc.tech) | OPERATIONAL |
| Postgres | OPERATIONAL |
| Traefik | OPERATIONAL — rate limiting active |
| Gist-update (PoOofuf0OgaYJCBN) | OPERATIONAL |
| capture-plan AI agent | UPGRADED — EIS win themes + incumbent intel live (v404) |
| MCP Server | ⚠️ PARTIAL — internal config key not updated |
| SSH auth | ⚠️ Password-based only |

---

## AN-1 DETAILS (for reference)

**What was done:**
- `Build Capture Prompt` (cp-04): Complete rewrite — now sends full Shipley-framed prompt to Claude with:
  - 7 EIS win themes (incumbency, C5ISR depth, Army culture, SB agility, IC IT crossover, Shipley process, SECRET FCL)
  - 5-segment incumbent intelligence keyed on agency string (pm_mission_command, army_c5isr, signals_intel, ic_it, default)
  - Agency opportunity context with fit scores from DB
  - Past capture plan summaries from DB
  - Lessons learned from DB
  - Structured JSON output schema including `competitive_assessment` with `likely_incumbent`, `known_competitors`, `eis_advantage`, `price_position`
- `Build Phase Prompt` (cp-ap): EIS identity + win themes prepended to every OODA analysis call
- Auth Check: Added 2027 key (backward compat with old keys preserved)
- Bidi Sync: Updated to 2027 key in header + body

---

## CANONICAL KEYS (post S-178 rotation)

```
x-gda-key:     gda-api-2027-AWqjhbxDYNcyV1mr
deploy-key:    gda-deploy-2027-a4zslQ79hn9A9UIi
GDA Webhook Auth cred ID: 1pNPY36DDz49OtKL
GitHub Gist PAT cred ID:  sKJFLNzetK86JnvO
```

---

## STANDING HARD RULES (never break)
- **Switch node** → broken platform-wide → use IF or Code nodes
- **LangChain cred `d92MU0tRK7bEGV83`** → permanently broken → use HTTP + `$env.ANTHROPIC_API_KEY`
- **Postgres typeVersion 2.5/2.6** → inline `{{ $json.field }}` in SQL only
- **App.jsx / GDALaunchpad.jsx source** → lives as base64 in gist → edit gist, redeploy
- **n8n container restart** → never `docker compose up -d n8n` from within n8n
- **N8N_ENCRYPTION_KEY** → must persist in `/root/n8n-envision/.env`
- **MCP test trigger** → does NOT pass x-gda-key → use temporary auth bypass pattern
- **RR-38, RR-28** → FROZEN
- **nginx.conf** → mounted volume, cannot docker cp — edit on host, restart container

---

## KEY IDs (quick reference)
```
Dashboard-Mega:    UYGJPu7N5YZblvEU
SSH Exec:          IcD4K740vpWSIuaZ
Deploy:            8GnGxnBL9TJjj1i2
Gist-update:       PoOofuf0OgaYJCBN
Morning Briefing:  YIvCdrOgF1LGmFNL
Briefing API:      0zVPgmYsvcqhyyo6
Capture-Plan:      QgperN6cuOpfnb09  ← v404, AN-1 complete
GDA Webhook Cred:  1pNPY36DDz49OtKL
GitHub Gist PAT:   sKJFLNzetK86JnvO
VPS Root SSH:      VqYFb1aRGJa8UfBc
Postgres:          HwronxMmGY5XDGEt
```

---

## SESSION PROTOCOL REMINDER
- Do not interrogate. Do not run in circles. Do not contradict prior sessions.
- If Shawn says "continue" / "go" / anything ambiguous → execute top item from queue above.
- Close every session with R-SR-09 (4 artifacts).
- AUTONOMY RULE: Claude executes everything via MCP. Never ask Shawn to manually edit files.

---
*S-181 Kickoff | GDA Command Platform | EIS / GDA OU3 | CONFIDENTIAL*
