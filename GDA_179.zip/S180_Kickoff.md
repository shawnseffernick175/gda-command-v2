# S-180 SESSION KICKOFF
**GDA Command Platform | EIS / GDA OU3 | Shawn Seffernick**
**Generated: 2026-05-01 (S-179 Close)**

---

## MANDATORY FIRST ACTION
```
tool_search("n8n")   ← load MCP before ANY other action
```

---

## CARRY-FORWARD STATUS
- R-SR-09 artifacts from S-179: COMPLETE (Session Delta DOCX, DevOps Report DOCX, Master Build XLSX v4.179, this Kickoff MD)
- HP-7 CONFIRMED DONE: Traefik rate limiting active (30r/m avg, 50 burst)
- GIST-RBL DONE: PoOofuf0OgaYJCBN operational
- S-164-01 DONE: Opportunities loading — nginx.conf key patched
- Key rotation sweep complete: 124 workflows updated, nginx.conf patched, dist bundles patched

---

## S-180 PRIORITY QUEUE (Execute in Order)

| Rank | ID | Priority | Description |
|------|----|----------|-------------|
| 1 | **AN-1** | 🟡 MED | Incumbent analysis + win themes seeded into AI agent |
| 2 | **MCP-AUTH** | 🟡 MED | Update MCP server config to use rotated key (gda-api-2027-AWqjhbxDYNcyV1mr) so internal webhook calls work without auth bypass |
| 3 | **SSH-KEY** | 🟡 MED | Restore SSH key-based auth to VPS — password prompt on every call is unacceptable friction |

---

## PLATFORM SNAPSHOT (entering S-180)

| Component | Status |
|-----------|--------|
| n8n | OPERATIONAL (2.49.0) |
| Frontend (gda.csr-llc.tech) | OPERATIONAL — opps loading |
| Postgres | OPERATIONAL |
| Traefik | OPERATIONAL — rate limiting active |
| Gist-update | OPERATIONAL |
| MCP Server | ⚠️ PARTIAL — auth key not updated |
| SSH auth | ⚠️ Password-based only — key auth lost |

---

## CANONICAL KEYS (post S-178 rotation)

```
x-gda-key:     gda-api-2027-AWqjhbxDYNcyV1mr
deploy-key:    gda-deploy-2027-a4zslQ79hn9A9UIi
GDA Webhook Auth cred ID: 1pNPY36DDz49OtKL
GitHub Gist PAT cred ID:  sKJFLNzetK86JnvO
```

---

## STANDING HARD RULES (never break)
- **Switch node** → broken platform-wide → use IF or Code nodes
- **LangChain cred `d92MU0tRK7bEGV83`** → permanently broken → use HTTP + `$env.ANTHROPIC_API_KEY`
- **Postgres typeVersion 2.5/2.6** → inline `{{ $json.field }}` in SQL only
- **App.jsx / GDALaunchpad.jsx source** → lives as base64 in gist → edit gist, redeploy
- **n8n container restart** → never `docker compose up -d n8n` from within n8n
- **N8N_ENCRYPTION_KEY** → must persist in `/root/n8n-envision/.env`
- **MCP test trigger** → does NOT pass x-gda-key header → use temporary auth bypass pattern
- **RR-38, RR-28** → FROZEN
- **nginx.conf** → mounted volume, cannot docker cp — edit on host, restart container

---

## KEY IDs (quick reference)
```
Dashboard-Mega:    UYGJPu7N5YZblvEU
SSH Exec:          IcD4K740vpWSIuaZ
Deploy:            8GnGxnBL9TJjj1i2
Gist-update:       PoOofuf0OgaYJCBN
Morning Briefing:  YIvCdrOgF1LGmFNL
Briefing API:      0zVPgmYsvcqhyyo6
Capture-Plan:      QgperN6cuOpfnb09
GDA Webhook Cred:  1pNPY36DDz49OtKL  ← NEW post-rotation
GitHub Gist PAT:   sKJFLNzetK86JnvO
VPS Root SSH:      VqYFb1aRGJa8UfBc
Postgres:          HwronxMmGY5XDGEt
```

---

## SESSION PROTOCOL REMINDER
- Do not interrogate. Do not run in circles. Do not contradict prior sessions.
- If Shawn says "continue" / "go" / anything ambiguous → execute top item from queue above.
- Close every session with R-SR-09 (4 artifacts).
- MCP check: if n8n tool calls time out, report blocked and proceed to next executable item.
- AUTONOMY RULE: Claude executes everything via MCP. Never ask Shawn to manually edit files, paste code, or navigate UIs for anything Claude can do autonomously.

---
*S-180 Kickoff | GDA Command Platform | EIS / GDA OU3 | CONFIDENTIAL*
