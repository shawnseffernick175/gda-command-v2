# S-195 Kickoff — GDA Command Platform
**Date:** Next session after May 2, 2026
**Operator:** Claude (Anthropic)
**Platform:** GDA OU3 / Envision Innovative Solutions

---

## Session Open Protocol (MANDATORY)
1. `tool_search("n8n")` — load MCP context
2. Read this file
3. Execute top item from queue below without interrogating

---

## Platform State at S-194 Close
| Component | State |
|---|---|
| VPS 187.77.206.105 | ONLINE — stable |
| n8n.csr-llc.tech | ONLINE — 156+ active workflows |
| gda.csr-llc.tech | LIVE — React SPA 23 pages |
| API Gateway | PARTIAL — systemd active :8788, nginx NOT wired (NGINX-01) |
| AN-1 Win Themes | ACTIVE — yMo7WrELV8JVOi2M |
| QA fix-runner | ACTIVE — aAVitXXjGWaP7bb2 (confirmed S-194) |
| Gist session-update | ACTIVE — 4bhVvKvVgLXcX6AZ |
| Block D Audit | COMPLETE — 6/6 workflows verified, 2 fixed |
| North Star | ~93% |

---

## Block D Final Verdicts (DO NOT RE-AUDIT)
| Workflow | ID | Verdict |
|---|---|---|
| weekly-comp-scan | uQ5cZ97cCrx5iIXk | FIXED — Auth Guard patched in comp-intel 2 |
| morning-briefing-v1 | YIvCdrOgF1LGmFNL | VERIFIED — data-learn key fixed, briefing operational |
| nightly-fy-revenue-calc | EGQzp92GxbjTJ03X | VERIFIED |
| data-retention | LzjiBI80aDAZgDIp | VERIFIED |
| e2e-gemini-report | BLS36QTOznJ8mJlC | VERIFIED |
| dept-opp-sweep | JRnWGEH9cesb8f3w | VERIFIED |

---

## S-195 Priority Queue

### **RANK 1 — Block A: nginx /api/ Proxy (NGINX-01) — HIGHEST VALUE UNBLOCK**
The API gateway process is running on localhost:8788 but nginx is not proxying /api/ to it.
This unblocks Block B (React auth_key cleanup) and Block C-3 (QA Center rewire).

```
Steps via SSH workflow (IcD4K740vpWSIuaZ, header x-gda-key: gda-api-2027-AWqjhbxDYNcyV1mr):

A-1: systemctl is-active gda-gateway  →  must return "active"
A-2: curl 127.0.0.1:8788/health       →  must return webhookConfigured:true, apiConfigured:true
A-3: Write nginx location block:
     location /api/ {
       proxy_pass http://127.0.0.1:8788;
       proxy_set_header Host $host;
       proxy_set_header X-Real-IP $remote_addr;
       proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
       proxy_set_header X-Forwarded-Proto $scheme;
     }
A-4: nginx -t && systemctl reload nginx
A-5: curl https://gda.csr-llc.tech/api/health  →  HTTP 200 with JSON envelope
```

### **RANK 2 — Block B: Strip auth_key from 5 React Pages (after A-5 passes)**
```
Pages to patch in /opt/gda-command/src/App.jsx:
- IdiqOnRampPage
- IncumbentAnalysisPage
- BlackHatPage
- WargamePage
- TeamingFinderPage

Remove: auth_key: gda-api-2026-f584dae2 (or any variant) from POST request bodies.
Gateway adds the key server-side — pages must send nothing.
Build + deploy after patch: workflow 8GnGxnBL9TJjj1i2
```

### **RANK 3 — AN-1 DB Seeding**
```
1. SSH: SELECT count(*) FROM gda_win_loss_db
2. SELECT opportunity_title, agency, stage, contract_value 
   FROM gda_opportunity_tracker WHERE stage = 'Won' LIMIT 10
3. INSERT 5-10 wins into gda_win_loss_db with:
   - incumbent_displaced, win_themes, agency, contract_value fields
4. Re-trigger AN-1 (yMo7WrELV8JVOi2M) and verify richer analysis in Telegram
```

### **RANK 4 — Block E Hardening**
```
HP-4: Check saveDataSuccessExecution on all 156 workflows — flag any storing 'all' on success
HP-5: Confirm errorWorkflow: 2Swf6LP9AzFjHFYU set on all 6 remaining cron workflows
HP-7: SSH: add limit_req_zone + limit_req to nginx.conf
```

---

## Key Credentials (S-194 canonical — unchanged)
```
x-gda-key:                gda-api-2027-AWqjhbxDYNcyV1mr
GDA Webhook Auth cred:    fTrhOzBkjS1s67bm  (primary)
GDA Webhook Auth cred:    1pNPY36DDz49OtKL  (alternate)
VPS SSH Key cred:         NKOxLo5F81sRNPua
Telegram cred:            Jr8OOsZqc9DarQE6  (GDA Telegram Bot)
Postgres cred:            HwronxMmGY5XDGEt  (GDA Postgres)
GitHub Gist PAT:          sKJFLNzetK86JnvO
QA Agent key:             qa-agent-test-2026-adlkjfn7987-srkigio-99-eatshit
```

## Key Workflow IDs (S-194 additions/changes)
```
AN-1 Win Themes:          yMo7WrELV8JVOi2M  (ACTIVE)
QA fix-runner:            aAVitXXjGWaP7bb2  (ACTIVE — confirmed S-194)
Gist session-update:      4bhVvKvVgLXcX6AZ  (ACTIVE)
SSH Exec:                 IcD4K740vpWSIuaZ
Deploy:                   8GnGxnBL9TJjj1i2
Dashboard-mega:           UYGJPu7N5YZblvEU
opp-tracker 2:            SEJLE89wZa1yfQyB  (CANONICAL)
ooda-loop 2:              pkPpMhiz8IdRy7To  (CANONICAL)
Morning briefing:         YIvCdrOgF1LGmFNL  (VERIFIED — Block D)
comp-intel 2:             geW4zw6lvkkizF82  (Auth Guard patched S-194)
weekly-comp-scan:         uQ5cZ97cCrx5iIXk  (FIXED S-194)
```

## Hard Rules (S-194 canonical)
- Switch node → broken → use IF or Code nodes
- LangChain cred d92MU0tRK7bEGV83 → permanently broken → HTTP + $env.ANTHROPIC_API_KEY
- Postgres typeVersion 2.5/2.6 → inline `{{ $json.field }}` in SQL; no queryValues; dollar-quoting for JSON strings
- App.jsx writes → UTF-8 only; backup at /opt/gda-command/src/App.jsx.bak-s158-kpi
- Deploy: vite build → cp -r dist/. /root/gda-frontend/dist/ → docker exec nginx -s reload
- N8N_ENCRYPTION_KEY → must persist in /root/n8n-envision/.env
- SSH Guard allows: bash -c, python3, cat, grep, sed, tee, tail, find, ls, systemctl, curl, nginx
- Code nodes: use native fetch() — never $helpers.httpRequest (CODE-01)
- RR-38 and RR-28 are RESOLVED — do not reference as frozen
- Bulk MCP ops: throttle to ~20 workflows/batch, 30s pause between batches
- Canonical opp table: gda_opportunity_tracker; PURSUE label: gda_label = 'PURSUE'
- Canonical active pipeline: stage NOT IN ('No-Bid','Cancelled','No-Go','Lost','Won')
- Top-level defense department: Department of War (not Department of Defense)
- MCP prefix: fuck-this-shit: for all n8n management calls

---

## North Star Gap (post S-194)
| Remaining | Effort |
|---|------|
| Block A: nginx /api/ proxy | S-195 Rank 1 — SSH write, 15 min |
| Block B: React auth_key (5 pages) | S-195 Rank 2 — after A |
| AN-1 DB Seeding | S-195 Rank 3 — SQL inserts |
| Block E Hardening | S-195 Rank 4 — audit + config |

Platform is ~93% of North Star. Block A alone will push to ~96%.

---
*Generated by R-SR-09 close protocol at end of S-194 — May 2, 2026*
