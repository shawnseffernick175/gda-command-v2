# GDA Command Platform — Session S-159 Chat 31 Kickoff
**Prepared:** April 22, 2026 16:10 UTC  
**Next Session:** S-159 Chat 31  
**Build:** v157.30

---

## FIRST ACTION NEXT CHAT
`tool_search("n8n")` → read this file → **RR-38 and RR-28 are FROZEN**

Then fire the smoke test immediately:
```
GET https://n8n.csr-llc.tech/webhook/gda-smoke-test
```
(no auth required — interpret results, confirm PASS or diagnose DEGRADED)

---

## Top Priority Queue

### 🟡 TOP — P-1-B: Verify dashboard-mega body
- Smoke test returned `body_snippet: "{}"` for dashboard-mega
- Likely a fullResponse serialization artifact — body is the parsed JSON object, snippet showed `{}` because the snippet logic stringified a nested object key
- Direct verify: POST to `gda-dashboard-mega` with `x-gda-key` and confirm non-empty payload
- Est: 15 min

### 🟡 NEXT — Validate smoke test clean run
- Re-fire smoke test with 90s timeout applied
- Expect: 5/5 PASS (opp-tracker, dashboard-mega, daily-actions, morning-briefing, capture-plan)
- If daily-actions still times out at 90s → increase or accept as SLOW_OK permanently

### 🟢 LOW — RR-57-B2: Sidebar dropdown retest
- Ask Shawn if new items exist before defaulting to this

---

## What Changed This Session (S-159 C30)

| Fix | Detail |
|---|---|
| P-1 COMPLETE | GDA.util.smoke-test (zPT6cd33TmJa7SZX) LIVE. 8 nodes: Webhook → 5 sequential HTTP Request nodes → Aggregate Code → Respond. First run confirmed 4/5 endpoints healthy. daily-actions SLOW (AI latency, expected). 90s timeout applied. |
| Platform sandbox documented | n8n v2.37.1 Code node sandbox blocks all network APIs. HTTP Request nodes only for egress. |
| Webhook paths confirmed | opp-tracker: POST gda-opp-tracker. dashboard-mega: POST gda-dashboard-mega. daily-actions: POST gda-daily-actions. |

---

## Platform State

| Item | Status |
|---|---|
| Active workflows | ~152 |
| Frontend | LIVE — gda.csr-llc.tech |
| GDA.util.smoke-test | ACTIVE — zPT6cd33TmJa7SZX |
| GDA.api.opp-tracker 2 | CONFIRMED HEALTHY |
| GDA.api.dashboard-mega | CONFIRMED HEALTHY (body snippet verify pending) |
| GDA.api.daily-actions | CONFIRMED HEALTHY (AI latency expected) |
| GDA.intel.morning-briefing-v1 | CONFIRMED HEALTHY — ID 18 live |
| GDA.api.capture-plan | CONFIRMED HEALTHY |

---

## Key Workflow IDs

| Workflow | ID |
|---|---|
| GDA.util.smoke-test | zPT6cd33TmJa7SZX |
| GDA.dev.deploy | 8GnGxnBL9TJjj1i2 |
| GDA.util.ssh-read-file | IcD4K740vpWSIuaZ |
| GDA.api.opp-tracker 2 | SEJLE89wZa1yfQyB |
| GDA.api.dashboard-mega | UYGJPu7N5YZblvEU |
| GDA.api.daily-actions | C7Bh7KcAl1IgSTRr |
| GDA.intel.morning-briefing-v1 | YIvCdrOgF1LGmFNL |
| GDA.api.capture-plan | QgperN6cuOpfnb09 |
| GDA.bot.telegram-chat | 1ItrrFxGI3L43Pdv |

---

## Open Debt

| ID | Sev | Summary |
|---|---|---|
| P-1-B | Low | Verify dashboard-mega body in smoke test — next action |
| RR-57-B2 | Low | Sidebar dropdown retest — ask Shawn first |
| RR-36 | Med | Chrome MCP cross-origin workaround in place |
| RR-43 | Low | Bot dual-routing fix pending |
| RR-44 | Low | headerAuth test workaround documented |
| RR-38 | FROZEN | Do not touch |
| RR-28 | FROZEN | Do not touch |

---

## Platform Rules (Standing)

- Claude executes everything via MCP. Never tell Shawn to manually do things.
- RR-38 and RR-28 are FROZEN
- Postgres nodes: queryValues arrays only, never queryReplacement or string interpolation
- Bot rollback: n8n_workflow_versions(mode=rollback, workflowId=1ItrrFxGI3L43Pdv) to v4
- App.jsx is ~413KB — use base64 patch script pattern for all edits
- Switch node is broken — use IF nodes or Code nodes for routing
- LangChain cred d92MU0tRK7bEGV83 BROKEN — use direct HTTP with $env.ANTHROPIC_API_KEY
- **NEW: Code node sandbox blocks all network APIs (fetch, https, $http) — use HTTP Request nodes for all egress**

---

## Infrastructure

| Resource | Detail |
|---|---|
| Frontend source | /opt/gda-command/src/App.jsx |
| Deploy webhook | POST https://n8n.csr-llc.tech/webhook/gda-deploy |
| Deploy auth | Header: x-gda-auth: gda-deploy-2026-secure |
| SSH webhook (read) | POST https://n8n.csr-llc.tech/webhook/gda-read |
| SSH auth | Header: x-gda-key: gda-api-2026-secure |
| Postgres cred | HwronxMmGY5XDGEt |
| Telegram bot cred | Jr8OOsZqc9DarQE6 |
| VPS SSH cred | VqYFb1aRGJa8UfBc |
| Smoke test | GET https://n8n.csr-llc.tech/webhook/gda-smoke-test (no auth) |
