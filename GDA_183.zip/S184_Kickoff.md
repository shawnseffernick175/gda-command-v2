# S-184 SESSION KICKOFF
**GDA Command Platform | EIS / GDA OU3 | Shawn Seffernick**
**Generated: 2026-05-01 (S-183 Close)**

---

## MANDATORY FIRST ACTION
```
tool_search("n8n")   ← load MCP before ANY other action
```

---

## CARRY-FORWARD STATUS
- R-SR-09 artifacts from S-183: COMPLETE (Session Delta DOCX, DevOps Report DOCX, Master Build XLSX v4.183, this Kickoff MD)
- BLOCK A COMPLETE: Gateway live on 0.0.0.0:8788. nginx bridge corrected. React dist rebuilt and deployed.
- BLOCK B COMPLETE: React source confirmed clean — no hardcoded keys.
- BLOCK C-1/C-2 COMPLETE: fix-runner activated, health ok:true, mode:dry-run.
- OPEN: SSH workflow IcD4K740vpWSIuaZ has auth=none from session work — **restore headerAuth at session open.**

---

## S-184 PRIORITY QUEUE (Execute in Order)

| Rank | ID | Priority | Description |
|------|----|----------|-------------|
| 1 | **DEBT-JWT** | 🔴 BLOCKING | Generate fresh n8n API key → n8n UI → Settings → API → Create Key → paste into `/opt/gda-api-gateway-v1/.env` as `N8N_API_KEY` → `systemctl restart gda-gateway` → verify `/api/failures/latest` returns 200 |
| 2 | **SSH-AUTH** | 🔴 IMMEDIATE | Restore `authentication: headerAuth` on IcD4K740vpWSIuaZ Webhook node (currently `none` from S-183 session work) |
| 3 | **C-3** | 🟡 HIGH | Wire QA Center React page to gateway `/api/qa/health`. Currently QACenterPage.jsx calls `/api/gda-platform-health` etc. directly via n8n proxy — reroute health checks through the gateway unified endpoint |
| 4 | **C-4/C-5** | 🟡 HIGH | Run agent-runner inventory `{action:inventory_workflows}` and `{action:test_react_used_workflows}` — baseline all 156 workflows |
| 5 | **D-*** | 🟢 MED | Rescue Map 6-workflow live audit: weekly-comp-scan, morning-briefing-v1, nightly-fy-revenue-calc, data-retention, e2e-gemini-report, dept-opp-sweep |

---

## PLATFORM SNAPSHOT (entering S-184)

| Component | Status |
|-----------|--------|
| n8n | OPERATIONAL (2.49.0) |
| Frontend (gda.csr-llc.tech) | OPERATIONAL — S-183 build |
| API Gateway (gda-gateway) | OPERATIONAL — 0.0.0.0:8788, 6/8 QA checks pass |
| Gateway failures endpoint | ❌ BLOCKED — JWT 401 (DEBT-JWT) |
| QA Center React page | LIVE in source + dist |
| fix-runner (aAVitXXjGWaP7bb2) | ACTIVE — dry-run |
| agent-runner (TxcPdvx2Ld9rE9er) | ACTIVE |
| Postgres | OPERATIONAL |
| Traefik | OPERATIONAL — rate limiting active |
| Gist-update (PoOofuf0OgaYJCBN) | OPERATIONAL |
| capture-plan AI agent | UPGRADED — v404, AN-1 complete |
| MCP Server | ✅ OPERATIONAL — 2027 key active |
| SSH auth on IcD4K740vpWSIuaZ | ⚠️ NONE — must restore headerAuth |

---

## CANONICAL KEYS (post S-178/S-181 rotation)

```
x-gda-key:     gda-api-2027-AWqjhbxDYNcyV1mr
deploy-key:    gda-deploy-2027-a4zslQ79hn9A9UIi
GDA Webhook Auth cred ID: 1pNPY36DDz49OtKL
GitHub Gist PAT cred ID:  sKJFLNzetK86JnvO
VPS SSH Key cred ID:      NKOxLo5F81sRNPua   ← CANONICAL (ed25519)
Postgres cred ID:         HwronxMmGY5XDGEt
```

---

## GATEWAY CONFIG (post S-183)

```
Service:       gda-gateway (systemd, enabled)
Listens:       0.0.0.0:8788
WorkingDir:    /opt/gda-api-gateway-v1/
EnvFile:       /opt/gda-api-gateway-v1/.env
N8N_BASE_URL:  https://n8n.csr-llc.tech
N8N_API_BASE:  https://n8n.csr-llc.tech/api/v1
N8N_API_KEY:   ⚠️ INVALID — rotate via n8n UI
nginx bridge:  172.18.0.1 (corrected S-183)
```

---

## STANDING HARD RULES (never break)
- **Switch node** → broken platform-wide → use IF or Code nodes
- **LangChain cred `d92MU0tRK7bEGV83`** → permanently broken → use HTTP + `$env.ANTHROPIC_API_KEY`
- **Postgres typeVersion 2.5/2.6** → inline `{{ $json.field }}` in SQL only
- **App.jsx / GDALaunchpad.jsx source** → canonical at /opt/gda-command/src/ → edit source, vite build, cp dist, restart container
- **n8n container restart** → never `docker compose up -d n8n` from within n8n
- **N8N_ENCRYPTION_KEY** → must persist in `/root/n8n-envision/.env`
- **MCP test trigger** → does NOT pass x-gda-key → use temporary auth bypass pattern if needed
- **RR-38, RR-28** → RESOLVED — do not reference as frozen
- **nginx.conf** → mounted volume at /root/gda-frontend/nginx.conf → edit on host, restart container

---

## KEY IDs (quick reference)
```
Dashboard-Mega:    UYGJPu7N5YZblvEU
SSH Exec:          IcD4K740vpWSIuaZ   ← ⚠️ restore headerAuth first
Deploy:            8GnGxnBL9TJjj1i2
Gist-update:       PoOofuf0OgaYJCBN
Morning Briefing:  YIvCdrOgF1LGmFNL
Briefing API:      0zVPgmYsvcqhyyo6
Capture-Plan:      QgperN6cuOpfnb09
agent-runner:      TxcPdvx2Ld9rE9er
fix-runner:        aAVitXXjGWaP7bb2
GDA Webhook Cred:  1pNPY36DDz49OtKL
GitHub Gist PAT:   sKJFLNzetK86JnvO
VPS SSH Key:       NKOxLo5F81sRNPua
Postgres:          HwronxMmGY5XDGEt
MCP Proxy:         8r0ss5z6X3i0yuqi
```

---

## SESSION PROTOCOL REMINDER
- Do not interrogate. Do not run in circles. Do not contradict prior sessions.
- If Shawn says "continue" / "go" / anything ambiguous → execute top item from queue above.
- Close every session with R-SR-09 (4 artifacts).
- AUTONOMY RULE: Claude executes everything via MCP. Never ask Shawn to manually edit files.

---
*S-184 Kickoff | GDA Command Platform | EIS / GDA OU3 | CONFIDENTIAL*
