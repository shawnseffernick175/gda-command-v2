# GDA Command Platform — Session State
**Last Updated:** S-158 Chat 3 — April 13, 2026
**Operator:** Shawn Seffernick, President, Envision Innovative Solutions (OU3)
**Surgery:** Monday April 14, 2026 at 10am

---

## Pre-Flight (Every Chat)
1. `tool_search("n8n")` — load MCP
2. Read this file
3. **RR-38 and RR-28 are FROZEN** — do not touch ever

---

## FIRST ACTION NEXT CHAT

All debt resolved. No open items except frozen/Low. Ask Shawn what the next queue looks like post-surgery. RR-43 (bot dual-routing) only if touching telegram-chat for another reason.

---

## Deploy Webhook Auth Note (RR-44)
Temp patch `authentication` to `none` on Webhook node → fire test → restore to `headerAuth`.
Known: n8n_test_workflow returns HTTP 200 with empty body for workflows using `respondToWebhook` — this is normal. Check execution log for true status.

---

## Platform State

| Item | Status |
|---|---|
| Active workflows | ~151 |
| Frontend (gda.csr-llc.tech) | LIVE |
| GDA.api.dashboard-mega | ACTIVE — 10 nodes, 1hr cache |
| GDA.intel.morning-briefing-v1 | ACTIVE — 16 nodes, data-learn wire LIVE |
| GDA.api.daily-actions | ACTIVE — 17 nodes |
| GDA.api.pwin-calculator | ACTIVE — List Scores FIXED (LIMIT $1 → hardcoded 100) |
| GDA.api.win-loss-db | ACTIVE — number types FIXED, analyze action FIXED (LangChain → direct HTTP) |
| GDA.api.capture-plan | ACTIVE — 23 nodes, RR-42 FIXED |
| GDA.api.opp-tracker 2 | ACTIVE — 13 nodes, hierarchy FIXED, stage update FIXED |
| GDA.cron.recompete-early-warning | ACTIVE — daily 7am ET |
| GDA.cron.win-rate-weekly-digest | ACTIVE — Mondays 8am ET |
| GDA.cron.idiq-task-order-alert | ACTIVE — daily 8am ET |
| GDA.cron.capture-opp-sync | ACTIVE — nightly 2am ET |
| GDA.api.platform-health | ACTIVE |
| GDA.api.bd-activity-log | ACTIVE |
| GDA.api.teaming-scorer | ACTIVE |
| GDA.cron.capture-milestone-alerts | ACTIVE — daily 9am ET |
| GDA.auto.feedback-collector | ACTIVE |
| GDA.cron.learning-engine | ACTIVE — nightly 3am ET |
| GDA.agent.opp-classifier | ACTIVE — 6 nodes, feedback wire LIVE |

---

## Key Workflow IDs

| Workflow | ID |
|---|---|
| GDA.dev.deploy | 8GnGxnBL9TJjj1i2 |
| GDA.bot.telegram-chat | 1ItrrFxGI3L43Pdv |
| GDA.api.daily-actions | C7Bh7KcAl1IgSTRr |
| GDA.api.ooda-loop 2 | pkPpMhiz8IdRy7To |
| GDA.intel.morning-briefing-v1 | YIvCdrOgF1LGmFNL |
| GDA.api.launchpad-funnel | vaRzM1Jl6HcXjuxs |
| GDA.api.dashboard-mega | UYGJPu7N5YZblvEU |
| GDA.api.opp-tracker 2 | SEJLE89wZa1yfQyB |
| GDA.api.capture-plan | QgperN6cuOpfnb09 |
| GDA.sched.opp-refresh | PeLGDqgLAsEh5Gsd |
| GDA.research.deep-research | q9YWVQCwnJGqmrO7 |
| GDA.auto.gist-update | djgOV2vX3PIv9cvm |
| GDA.api.aop-tracker | P8AfP8P84xi33auD |
| GDA.api.win-loss-db | SpU3znFHHABYNmb9 |
| GDA.cron.recompete-early-warning | MtcQwAgm1zHYXNfB |
| GDA.cron.win-rate-weekly-digest | ZuQkz1HrMONclkFm |
| GDA.cron.idiq-task-order-alert | DeSN1t1swXX14xTc |
| GDA.cron.capture-opp-sync | 0E3lCtWt2rdJlMPY |
| GDA.api.platform-health | UBgoJGxZro834RbT |
| GDA.api.bd-activity-log | 9qrsria0fy719T98 |
| GDA.api.teaming-scorer | jQvgX6SD1RhARG3F |
| GDA.cron.capture-milestone-alerts | Kk7O8Bw2FOe41M9l |
| GDA.auto.feedback-collector | aCrxoe1rCuIbsnC4 |
| GDA.cron.learning-engine | fZpqchmmPnqAmiMq |
| GDA.api.pwin-calculator | 81m1Zl9xjM6L8HQb |
| GDA.agent.opp-classifier | hWCP9NLXxtCOrppu |

---

## Infrastructure

| Resource | Detail |
|---|---|
| Frontend source | /opt/gda-command/src/App.jsx |
| Deploy webhook | POST https://n8n.csr-llc.tech/webhook/gda-deploy |
| Deploy auth | Header: x-gda-auth: gda-deploy-2026-secure |
| Deploy MCP pattern | Temp set Webhook auth to none → fire → restore headerAuth |
| SSH webhook (read) | POST https://n8n.csr-llc.tech/webhook/gda-read |
| SSH auth | Header: x-gda-key: gda-api-2026-secure |
| Postgres cred | HwronxMmGY5XDGEt |
| VPS | 187.77.206.105 |
| n8n | https://n8n.csr-llc.tech (v2.37.1) |
| Frontend | https://gda.csr-llc.tech |
| MCP | https://mcp.csr-llc.tech/mcp |
| Feedback endpoint | POST https://n8n.csr-llc.tech/webhook/gda-feedback |
| Data-learn endpoint | POST https://n8n.csr-llc.tech/webhook/gda-data-learn |

---

## Learning System

| Component | Status |
|---|---|
| gda_feedback + gda_learned_weights tables | LIVE — seeded with 12 Shipley weights |
| gda_learning_log table | LIVE |
| feedback-collector | ACTIVE |
| learning-engine | ACTIVE — nightly 3am ET |
| pwin-calculator | UPDATED — loads learned weights |
| win-loss-db | UPDATED — auto-posts W/L to feedback, analyze fixed to direct HTTP |
| daily-actions | UPDATED — posts action counts to feedback |
| morning-briefing → data-learn | LIVE — node dl-01 |
| opp-classifier → feedback | LIVE — node oc-06 |

---

## Open Debt

| ID | Sev | Summary |
|---|---|---|
| RR-42 | CLOSED | capture-plan: 4 queryReplacement → queryValues. Fixed S-158 Chat 2 |
| RR-49 | CLOSED | Both feedback wires complete |
| RR-50 | CLOSED | opp-tracker stage update $2 param error. Fixed S-158 Chat 3 |
| RR-51 | CLOSED | Agency hierarchy flat/fragmented. Fixed S-158 Chat 3 |
| RR-52 | CLOSED | pwin-calculator List Scores LIMIT $1 param error. Fixed S-158 Chat 3 |
| RR-53 | CLOSED | win-loss-db numeric fields returned as strings. Fixed S-158 Chat 3 |
| RR-54 | CLOSED | win-loss-db analyze: broken LangChain cred. Fixed S-158 Chat 3 → direct HTTP |
| RR-36 | Med | Chrome MCP cross-origin — workaround in place |
| RR-43 | Low | Bot dual-routing double-fire — fix when telegram-chat next touched |
| RR-44 | Low | n8n_test_workflow 403 on headerAuth — workaround documented |
| RR-38 | FROZEN | Do not touch |
| RR-28 | FROZEN | Do not touch |

---

## Rules

- Claude executes everything via MCP. Never tell Shawn to manually do things.
- RR-38 and RR-28 are FROZEN. Do not touch.
- Show broken vs fixed BEFORE deploying (R-SR-04).
- Spot-check 2 items before any batch operation (R-SR-13).
- End every session: overwrite these 3 project files with updated versions.
- DevOps report is CONDITIONAL — only for major fix waves. Most sessions skip it.
- Bot rollback: n8n_workflow_versions(mode=rollback, workflowId=1ItrrFxGI3L43Pdv) to v4

---

## Schema (Canonical)

- `gda_intelligence_log` time column: **timestamp** (created_at also present)
- Allocation revenue: `gda_capture_plans.plan_data->>'allocated_revenue'` (JSONB, dollars)
- `opp-tracker 2` and `ooda-loop 2` are LIVE CANONICAL — do not delete
- Anthropic API: direct HTTP with $env.ANTHROPIC_API_KEY. LangChain cred d92MU0tRK7bEGV83 is BROKEN — never use it
- `gda_mega_cache` — id=1 singleton, 60min TTL
- `gda_feedback` event_types: win, loss, pwin_outcome, opp_label_correction, action_completed, actions_generated, opp_classified, briefing_sent
- `gda_learned_weights` keys: pwin.* (6), briefing.* (3), actions.* (3) — 12 total
- capture-plan Postgres nodes use `queryValues` arrays — queryReplacement fully removed S-158 Chat 2
- opp-tracker 2 Update Stage PG: inline template `'{{ $json.stage }}'` / `{{ $json.opp_id }}` — queryValues broken at typeVersion 2.5/2.6 via MCP
- pwin-calculator List Scores: hardcoded LIMIT 100 — queryValues broken at typeVersion 2.5 via MCP
- win-loss-db numeric columns (contract_value, winning_price, our_price): Postgres returns as strings — always parseFloat() in response builder
- Agency hierarchy: getLevel1/2/3 in Format Response. L1=top dept (DoW, DHS, VA etc). L2=branch (Army/Navy/AF/DISA/DLA etc). L3=command/PEO. Department of War = all former DoD.
