# GDA Command Platform

## S-158 Chat 3 Session Delta

**April 13, 2026 | Operator: Shawn Seffernick | Mode: Pure-MCP**

---

### 1. What Happened This Session

| # | Item | Result |
|---|---|---|
| 1 | Agency hierarchy audit | FOUND — all DoD sub-agencies (DISA, Army, Navy, Air Force, DLA, MDA, NGA, etc.) rendering as separate flat top-level cards. Root cause: `dept` field read raw from DB, not derived from agency string. |
| 2 | Hierarchy fix — opp-tracker 2 / Format Response | Rewrote Format Response JS with canonical getLevel1/getLevel2/getLevel3 + cleanAgencyName. All DoD → Department of War. Branches (Army/Navy/AF/DISA/DLA/etc) = Level 2. Commands/PEOs = Level 3. LIVE. |
| 3 | Department cards fix | Top Departments cards now show: Department of War (351 opps, $3.28B), Department of Veterans Affairs (27 opps), HHS (13 opps), DHS (7 opps), HUD (2 opps), Commerce (1 opp). No longer splitting DoW into 20+ fragments. LIVE. |
| 4 | Stage update bug — RR-50 | FOUND during E2E test — Update Stage PG throwing "there is no parameter $2". Root cause: queryValues under options not serialized at Postgres typeVersion 2.5/2.6 via MCP API. |
| 5 | RR-50 fix | Switched Update Stage PG to inline template expression: `UPDATE...SET stage = '{{ $json.stage }}' WHERE id = {{ $json.opp_id }}`. Tested — PASSING. LIVE. |
| 6 | E2E test results | opp-tracker read ✅ | department grouping ✅ | hierarchy L1/L2/L3 ✅ | stage update ✅ | capture-plan list (50 plans) ✅ | auth restored all 3 webhooks ✅ |
| 7 | Auth restored | opp-tracker 2, capture-plan, daily-actions — all back to headerAuth. |

---

### 2. RR-50 Fix Detail

| Field | Detail |
|---|---|
| **Workflow** | GDA.api.opp-tracker 2 (SEJLE89wZa1yfQyB) |
| **Root cause** | Postgres typeVersion 2.5/2.6 — `options.queryValues` is not serialized via MCP API. Execution shows `options: {}` at runtime regardless of what's set. |
| **Fix** | Switched to inline n8n template expression in query string: `SET stage = '{{ $json.stage }}' WHERE id = {{ $json.opp_id }}` |
| **Note for future** | Do NOT use queryValues on Postgres nodes via MCP for opp-tracker. Use inline `{{ }}` expressions or Code node instead. |
| **Verified** | Execution success confirmed — returns `{status: 'ok'}` |

---

### 3. RR-51 Fix Detail (Hierarchy)

| Field | Detail |
|---|---|
| **Workflow** | GDA.api.opp-tracker 2 — Format Response node |
| **Root cause** | `byDept` was keyed on raw `row.dept` from DB. DB contains stale/raw GovTribe dept strings (e.g. "Department of Defense", "Department of the Navy") creating separate cards for each. |
| **Fix** | All grouping now uses `getLevel1(rawAgency)` — derived from agency string, not DB dept field. All military/defense agencies → "Department of War". Civilian agencies (VA, DHS, HHS, etc.) → their correct top-level dept. |
| **Canonical Hierarchy** | L1: Department of War / DHS / VA / etc. → L2: Army / Navy / Air Force / DISA / DLA / MDA / NGA / USTRANSCOM / USSOCOM / etc. → L3: PEO STRI / NAVSUP / AFLCMC / USMC / etc. |

---

### 4. Platform State at Close

| Item | Value |
|---|---|
| Active workflows | ~151 |
| Frontend | LIVE |
| opp-tracker 2 | ACTIVE — 13 nodes, hierarchy FIXED, stage update FIXED |
| capture-plan | ACTIVE — 23 nodes, RR-42 fixed (prior session) |
| Learning system | FULLY WIRED |
| All webhook auth | RESTORED — headerAuth on all 3 tested workflows |

---

### 5. Open Debt

| ID | Sev | Summary |
|---|---|---|
| RR-50 | CLOSED | opp-tracker stage update $2 param error — fixed S-158 Chat 3 |
| RR-51 | CLOSED | Agency hierarchy flat/fragmented — fixed S-158 Chat 3 |
| RR-36 | Med | Chrome MCP cross-origin — workaround in place |
| RR-43 | Low | Bot dual-routing double-fire — fix when telegram-chat next touched |
| RR-44 | Low | n8n_test_workflow 403 on headerAuth — workaround documented |
| RR-38 | FROZEN | Do not touch until Shawn personally releases |
| RR-28 | FROZEN | Do not touch until Shawn personally releases |

*— End of S-158 Chat 3 Delta —*
