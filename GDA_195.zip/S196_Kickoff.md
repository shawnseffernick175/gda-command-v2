# S-196 Kickoff — GDA Command Platform
**Date:** Next session after May 4, 2026
**Operator:** Claude (Anthropic)
**Platform:** GDA OU3 / Envision Innovative Solutions

---

## Session Open Protocol (MANDATORY)
1. `tool_search("n8n")` — load MCP context
2. Read this file
3. Execute top item from queue below without interrogating

---

## Platform State at S-195 Close
| Component | State |
|---|---|
| VPS 187.77.206.105 | ONLINE — stable |
| n8n.csr-llc.tech | ONLINE — 156+ active workflows |
| gda.csr-llc.tech | LIVE — React SPA 23 pages, all routing PASS |
| API Gateway | LIVE — systemd active :8788, nginx /api/ wired to 172.18.0.1:8788 |
| NGINX-01 | RESOLVED — verified S-195 (was already done prior session) |
| Block B (auth_key) | RESOLVED — verified S-195 (all 5 pages clean) |
| Coverage 403s | RESOLVED — Deep Research, Capture Plan, Action History all 200 |
| AN-1 Win Themes | ACTIVE — yMo7WrELV8JVOi2M |
| QA fix-runner | ACTIVE — aAVitXXjGWaP7bb2 |
| Gist session-update | ACTIVE — 4bhVvKvVgLXcX6AZ |
| North Star | ~96%+ |

---

## S-196 Priority Queue

### **RANK 1 — AN-1 DB Seeding**
```
1. SSH: SELECT count(*) FROM gda_win_loss_db
2. SELECT opportunity_title, agency, stage, contract_value
   FROM gda_opportunity_tracker WHERE stage = 'Won' LIMIT 10
3. INSERT 5-10 wins into gda_win_loss_db with:
   - incumbent_displaced, win_themes, agency, contract_value fields
4. Re-trigger AN-1 (yMo7WrELV8JVOi2M) and verify richer analysis in Telegram
```

### **RANK 2 — Block E Hardening**
```
HP-4: Check saveDataSuccessExecution on all 156 workflows — flag any storing 'all' on success
HP-5: Confirm errorWorkflow: 2Swf6LP9AzFjHFYU set on all 6 remaining cron workflows
HP-7: SSH: add limit_req_zone + limit_req to nginx.conf (already partially done — verify completeness)
```

### **RANK 3 — React Coverage Re-run**
```
Run coverage report against live app now that gateway is confirmed wired.
Expected result: 23/23 passing (was 19/23 in April 27 stale report).
Confirm Intel Feed, Deep Research, Proposal Factory, Financial Bible pages are clean.
```

---

## DO NOT RE-AUDIT (Block D — CLOSED)
| Workflow | ID | Verdict |
|---|---|---|
| weekly-comp-scan | uQ5cZ97cCrx5iIXk | FIXED |
| morning-briefing-v1 | YIvCdrOgF1LGmFNL | VERIFIED |
| nightly-fy-revenue-calc | EGQzp92GxbjTJ03X | VERIFIED |
| data-retention | LzjiBI80aDAZgDIp | VERIFIED |
| e2e-gemini-report | BLS36QTOznJ8mJlC | VERIFIED |
| dept-opp-sweep | JRnWGEH9cesb8f3w | VERIFIED |

---

## Key Credentials (S-195 canonical — unchanged)
```
x-gda-key:                gda-api-2027-AWqjhbxDYNcyV1mr
GDA Webhook Auth cred:    fTrhOzBkjS1s67bm  (primary)
GDA Webhook Auth cred:    1pNPY36DDz49OtKL  (alternate — SSH workflow uses this)
VPS SSH Key cred:         NKOxLo5F81sRNPua
Telegram cred:            Jr8OOsZqc9DarQE6  (GDA Telegram Bot)
Postgres cred:            HwronxMmGY5XDGEt  (GDA Postgres)
GitHub Gist PAT:          sKJFLNzetK86JnvO
QA Agent key:             qa-agent-test-2026-adlkjfn7987-srkigio-99-eatshit
```

## Key Workflow IDs (S-195 — no changes)
```
AN-1 Win Themes:          yMo7WrELV8JVOi2M  (ACTIVE)
QA fix-runner:            aAVitXXjGWaP7bb2  (ACTIVE)
Gist session-update:      4bhVvKvVgLXcX6AZ  (ACTIVE)
SSH Exec:                 IcD4K740vpWSIuaZ   (versionCounter 685)
Deploy:                   8GnGxnBL9TJjj1i2
Dashboard-mega:           UYGJPu7N5YZblvEU
opp-tracker 2:            SEJLE89wZa1yfQyB   (CANONICAL)
ooda-loop 2:              pkPpMhiz8IdRy7To   (CANONICAL)
Morning briefing:         YIvCdrOgF1LGmFNL   (VERIFIED — Block D)
comp-intel 2:             geW4zw6lvkkizF82   (Auth Guard patched S-194)
weekly-comp-scan:         uQ5cZ97cCrx5iIXk   (FIXED S-194)
```

## Hard Rules (S-195 canonical — unchanged)
- Switch node → broken → use IF or Code nodes
- LangChain cred d92MU0tRK7bEGV83 → permanently broken → HTTP + $env.ANTHROPIC_API_KEY
- Postgres typeVersion 2.5/2.6 → inline `{{ $json.field }}` in SQL; no queryValues
- App.jsx writes → UTF-8 only; backup at /opt/gda-command/src/App.jsx.bak-s158-kpi
- Deploy: vite build → cp -r dist/. /root/gda-frontend/dist/ → docker exec nginx -s reload
- N8N_ENCRYPTION_KEY → must persist in /root/n8n-envision/.env
- SSH Guard allows: bash -c, python3, cat, grep, sed, tee, tail, find, ls, systemctl, curl, nginx
- Code nodes: use native fetch() — never $helpers.httpRequest (CODE-01)
- RR-38 and RR-28 are RESOLVED — do not reference as frozen
- Canonical opp table: gda_opportunity_tracker; PURSUE label: gda_label = 'PURSUE'
- Canonical active pipeline: stage NOT IN ('No-Bid','Cancelled','No-Go','Lost','Won')
- Top-level defense department: Department of War (not Department of Defense)
- MCP prefix: fuck-this-shit: for all n8n management calls

---

## North Star Gap (post S-195)
| Remaining | Effort |
|---|------|
| AN-1 DB Seeding | S-196 Rank 1 — SQL inserts + Telegram verify |
| Block E Hardening | S-196 Rank 2 — audit + config |
| React Coverage Re-run | S-196 Rank 3 — confirm 23/23 |

Platform is ~96%+ of North Star. AN-1 DB seeding is the only substantive functional gap.

---
*Generated by R-SR-09 close protocol at end of S-195 — May 4, 2026*
