# GDA Command Platform — Session S-159 Chat 28 Kickoff
**Prepared:** April 22, 2026 13:35 UTC  
**Next Session:** S-159 Chat 28  
**Build:** v157.27

---

## FIRST ACTION NEXT CHAT
`tool_search("n8n")` → read this file → **RR-38 and RR-28 are FROZEN**.

---

## Top Priority Queue

### 🟢 TOP — D-2: DeepResearchPage saveAction Injection
- **Path:** `/opt/gda-command/src/components/pages/DeepResearchPage.jsx`
- **Task:** Inject `saveAction` hook to persist deep research results to DB
- **Access:** ssh-read-file now supports `{"path": "..."}` — UNBLOCKED
- **SSH read workflow:** `IcD4K740vpWSIuaZ`

### 🟢 READY — O-2: OppTracker Sub-rows
- **Workflow:** `SEJLE89wZa1yfQyB`
- **Fields:** `incumbent_analysis`, `likely_competitors`, `eligible_vehicles`
- **Task:** Expandable row component in React frontend
- **Est:** 4 hours

### 🟡 MEDIUM — P-1: Platform Smoke Test
- Create n8n workflow testing key API endpoints
- Est: 2 hours

---

## What Changed This Session (S-159 C27)

| Fix | Detail |
|---|---|
| N-1 COMPLETE | BidStrategyPage.jsx created. 3-tab nav (Wargame/Incumbent/Teaming). 4 App.jsx patches applied. Vite build 6.45s. DEPLOY_COMPLETE. |
| App.jsx | 412,691 bytes (was 413,041). Imports, nav, PAGES, ActionHistory all patched. |

---

## Deploy Pattern (confirmed working)

Fire via `n8n_test_workflow` to `IcD4K740vpWSIuaZ` (ssh-read-file):
```json
{"cmd": "printf '%s' '<b64>' | base64 -d > /tmp/p.py && python3 /tmp/p.py && rm /tmp/p.py && cd /opt/gda-command && printf '/* /index.html 200' > public/_redirects && PATH=/root/.nvm/versions/node/v20.20.0/bin:$PATH npm run build 2>&1 | tail -8 && cp -r dist/. /root/gda-frontend/dist/ && docker restart n8n-envision-gda-frontend-1 && echo DEPLOY_COMPLETE"}
```
**Note:** `printf '%s' '<b64>'` avoids `echo` single-quote issues. b64 must have no single quotes (always true for base64 output).

---

## Platform State

| Item | Status |
|---|---|
| Active workflows | ~151 |
| Frontend | LIVE — gda.csr-llc.tech |
| Bid Strategy tab | LIVE — Wargame / Incumbent Analysis / Teaming Finder |
| GDA.util.ssh-read-file | ACTIVE — path fallback FIXED |
| GDA.cron.weekly-comp-scan | ACTIVE — Save Intel queryValues FIXED |
| GDA.dev.deploy | ACTIVE — HEALTHY |
| Morning briefing | LIVE — YIvCdrOgF1LGmFNL |

---

## Key Workflow IDs

| Workflow | ID |
|---|---|
| GDA.dev.deploy | 8GnGxnBL9TJjj1i2 |
| GDA.util.ssh-read-file | IcD4K740vpWSIuaZ |
| GDA.api.opp-tracker 2 | SEJLE89wZa1yfQyB |
| GDA.intel.morning-briefing-v1 | YIvCdrOgF1LGmFNL |
| GDA.api.capture-plan | QgperN6cuOpfnb09 |
| GDA.bot.telegram-chat | 1ItrrFxGI3L43Pdv |

---

## Open Debt

| ID | Sev | Summary |
|---|---|---|
| D-2 | Ready | DeepResearchPage saveAction — next priority |
| O-2 | Ready | OppTracker sub-rows |
| P-1 | Med | Platform smoke test |
| RR-36 | Med | Chrome MCP cross-origin workaround in place |
| RR-43 | Low | Bot dual-routing fix pending |
| RR-44 | Low | headerAuth test workaround documented |
| RR-38 | FROZEN | Do not touch |
| RR-28 | FROZEN | Do not touch |

---

## Rules

- Claude executes everything via MCP. Never tell Shawn to manually do things.
- RR-38 and RR-28 are FROZEN
- Postgres nodes: queryValues arrays only, never string interpolation
- Bot rollback: n8n_workflow_versions(mode=rollback, workflowId=1ItrrFxGI3L43Pdv) to v4
- App.jsx is ~413KB — use base64 patch script pattern for all edits
