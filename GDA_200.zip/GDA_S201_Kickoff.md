# GDA Command Platform — S-201 Session Kickoff

**Generated:** 2026-05-04 | **Preceding Session:** S-200 | **Platform:** GDA Command v200

---

## Session State at Handoff

| Item | Value |
|------|-------|
| North Star | **100% DECLARED** (frozen exceptions: RR-38, RR-28) |
| Active Workflows | ~155 |
| Fast Track Signals | 41 |
| Win/Loss Records | 10 (8W / 2L) |
| Learning Engine | REPAIRED — first calibration will run tonight (7AM ET nightly cron) |
| Auth Key | gda-api-2027-AWqjhbxDYNcyV1mr |
| Deploy Key | gda-deploy-2027-AWqjhbxDYNcyV1mr |
| Webhook Auth Cred ID | 1pNPY36DDz49OtKL |

---

## Mandatory Session Open Protocol

1. `tool_search("n8n")` — load MCP
2. Check learning engine last execution: `fZpqchmmPnqAmiMq` — confirm calibration fired and weights updated
3. Check `gda_learned_weights` for briefing.*/actions.* keys (should appear after first calibration)
4. Load this kickoff file and the GDA_199.zip state if provided

---

## S-201 Priority Queue (carry-forward from S-200)

| Priority | ID | Task | Notes |
|----------|----|------|-------|
| 1 | HP-6 | Verify webhook key rotation propagated to all consumers | Keys rotated S-197; confirm no stale references in App.jsx or other callers |
| 2 | HP-7 | nginx rate limiting via SSH | Use IcD4K740vpWSIuaZ SSH utility; `bash -c` is in allowed prefix list |
| 3 | AN-1 | Incumbent analysis & win themes for AI agent | Workflow yMo7WrELV8JVOi2M exists; verify it's wired to agentic-chat |
| 4 | S-164-01 | Retool Launchpad KPI binding mismatch | Frontend-side only; gdacommand.retool.com binding fix |
| 5 | DEBT-01 | Archive duplicate fast-track-ingest bU3PjkpSuVZP8Zue | Stale 11-node version; canonical is MJapg8dGkvEzLn0K |

---

## Post-S-200 Learning Engine Status Check

On S-201 open, verify the nightly calibration actually ran by checking:
- Last execution of `fZpqchmmPnqAmiMq` (should be > May 4 2026, status=success, duration >> 43ms)
- `gda_learned_weights` updated_at timestamps should be current
- 12 total weight keys expected post-calibration (6 pwin + 3 briefing + 3 actions)

---

## Platform Architecture Reminders

- **Switch node is broken platform-wide** — use IF or Code nodes for routing
- **Postgres typeVersion 2.5/2.6** — inline `{{ $json.field }}` only; no queryValues arrays
- **LangChain cred d92MU0tRK7bEGV83 is dead** — all Anthropic calls use direct HTTP Request with `$env.ANTHROPIC_API_KEY`
- **App.jsx canonical backup** — `/opt/gda-command/src/App.jsx.bak-s158-kpi`
- **SSH workflow RR-44 pattern** — patch auth→none, fire, restore headerAuth
- **gda_learned_weights schema** — `id, weight_key, weight_value, confidence, source, notes, updated_at`
- **gda_intelligence_log schema** — `id, timestamp, source, agency, finding, category, priority`

---

## Frozen Items (Do Not Touch Without Shawn Authorization)

- **RR-38** — FROZEN
- **RR-28** — FROZEN
- **Workflow 1G4gw4N7DFtVZKF7** — FROZEN (not in instance)
- **Workflow NQmaj5nu4TBQxBgD** — FROZEN (not in instance)

---

*End of S-201 Kickoff*
