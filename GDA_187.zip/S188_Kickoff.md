# S-188 Kickoff — GDA Command Platform
**Date:** Next session after May 2, 2026
**Operator:** Claude (Anthropic)
**Platform:** GDA OU3 / Envision Innovative Solutions

---

## Session Open Protocol (MANDATORY)
1. `tool_search("n8n")` — load MCP context
2. `tool_search("fuck this shit n8n test workflow")` — load test/execute tools
3. Read this file
4. Execute top item from queue below without interrogating

---

## Current Platform Health
| Component | State |
|---|---|
| VPS 187.77.206.105 | ONLINE |
| n8n.csr-llc.tech | ACTIVE — 156 workflows |
| gda.csr-llc.tech | **LIVE** — React SPA 23 pages, App.jsx 418KB |
| API Gateway nginx | **WIRED S-187** — /api/ → 172.18.0.1:8788. Public /api/health → 200 ✓ |
| fix-runner | **ACTIVE** — aAVitXXjGWaP7bb2, health {ok:true, dry-run} verified |
| agent-runner | ACTIVE — TxcPdvx2Ld9rE9er |
| SSH Exec Workflow | ACTIVE — `IcD4K740vpWSIuaZ`, headerAuth restored |

---

## S-188 Priority Queue

### **RANK 1 — Block C-3: Wire QA Center to Gateway**
QACenterPage currently calls n8n direct. Reroute to /api/qa/health.
1. `bash -c 'grep -n "n8n.csr-llc.tech\|QACenter\|qa" /opt/gda-command/src/App.jsx | head -30'`
2. Identify the QACenterPage component fetch call
3. Replace direct n8n URL with `/api/qa/health` or `/api/qa/`
4. Build + deploy: `python3 -c "import subprocess; r=subprocess.run(['bash','-c','cd /opt/gda-command && PATH=/root/.nvm/versions/node/v20.20.0/bin:$PATH node_modules/.bin/vite build && cp -r dist/. /root/gda-frontend/dist/ && docker restart n8n-envision-gda-frontend-1 && echo DEPLOY_COMPLETE'], capture_output=True, text=True, timeout=120); print(r.stdout[-500:]); print(r.stderr[-200:])"`
5. Verify: `curl -s https://gda.csr-llc.tech/api/qa/health` → {ok:true}

### **RANK 2 — Block C-4/C-5: QA Agent Inventory + React Tests**
1. Patch fix-runner/agent-runner auth if needed (RR-44 pattern, but fix-runner has NO auth currently)
2. Fire agent-runner: `{action: "inventory_workflows"}` → confirms 156 workflows visible
3. Fire agent-runner: `{action: "test_react_used_workflows"}` → no 403s expected now that /api/ routes through gateway

### **RANK 3 — Block D: Rescue Map Audit**
Verify each of 6 claimed-fixed workflows with a live test execution:
| Workflow | ID | Method |
|---|---|---|
| weekly-comp-scan | uQ5cZ97cCrx5iIXk | Manual trigger → check executions |
| morning-briefing-v1 | YIvCdrOgF1LGmFNL | Trigger → confirm 200 |
| nightly-fy-revenue-calc | EGQzp92GxbjTJ03X | Trigger → confirm cache table |
| data-retention | LzjiBI80aDAZgDIp | Trigger → confirm no column error |
| e2e-gemini-report | BLS36QTOznJ8mJlC | Inspect structure for hardcoded key |
| dept-opp-sweep | JRnWGEH9cesb8f3w | Trigger → confirm 200 |

### **RANK 4 — Block E Hardening**
- HP-5: Set errorWorkflow: 2Swf6LP9AzFjHFYU on remaining 6 cron workflows
- HP-4: Execution retention audit — flag saveDataSuccessExecution=all on high-volume workflows
- HP-7: nginx rate limiting via bash -c 'docker exec ...' for container nginx config

---

## Key Credentials (S-187 canonical)
```
x-gda-key:              gda-api-2027-AWqjhbxDYNcyV1mr
GDA Webhook Auth cred:  1pNPY36DDz49OtKL
VPS SSH Key cred:       NKOxLo5F81sRNPua
Postgres cred:          HwronxMmGY5XDGEt
N8N_API_KEY (gateway):  oLzHLHvhX7AzK9m1
GDA_QA_FIX_MODE:        dry-run (write actions blocked until set to enabled)
GDA_QA_N8N_API_KEY:     NOT SET — set in n8n env to enable fix-runner write actions
```

## Key Workflow IDs
```
SSH Exec:       IcD4K740vpWSIuaZ
Deploy:         8GnGxnBL9TJjj1i2
Dashboard:      UYGJPu7N5YZblvEU
agent-runner:   TxcPdvx2Ld9rE9er
fix-runner:     aAVitXXjGWaP7bb2  (ACTIVE, health OK)
Morning brief:  YIvCdrOgF1LGmFNL
Capture-plan:   QgperN6cuOpfnb09
```

## Hard Rules (unchanged + S-187 additions)
- Switch node → broken → use IF or Code nodes
- LangChain cred `d92MU0tRK7bEGV83` → permanently broken → use HTTP + `$env.ANTHROPIC_API_KEY`
- Postgres typeVersion 2.5/2.6 → inline `{{ $json.field }}` in SQL only, no queryValues
- App.jsx writes → UTF-8 only; backup at `/opt/gda-command/src/App.jsx.bak-s158-kpi`
- Deploy sequence: `vite build → cp -r dist/. /root/gda-frontend/dist/` (note: `dist/.`)
- N8N_ENCRYPTION_KEY → must persist in `/root/n8n-envision/.env`
- MCP data parameter: hard truncation at ~3840 chars
- Code node cannot use `require('fs')` — use SSH workflow + python3 subprocess
- Long SSH commands: use `python3 -c "import subprocess..."` with capture_output=True for synchronous stdout
- Always use `fuck-this-shit:` prefix for n8n management calls
- **S-187 NEW:** nginx config inside gda-frontend is bind-mounted from `/root/gda-frontend/nginx.conf` on host. `docker cp` fails (device busy). Write to host path, then `docker exec nginx -s reload`.
- **S-187 NEW:** UFW blocks Docker bridge traffic. If adding new internal service ports, add: `ufw allow from 172.18.0.0/16 to any port <PORT>` and `ufw allow from 172.16.0.0/12 to any port <PORT>`.
- **S-187 NEW:** Gateway IP from inside Docker containers is `172.18.0.1` (n8n_default bridge gateway).
- `n8n:n8n_test_workflow` loads from session init and may time out on `n8n:` prefix. If it fails, use `fuck this shit:n8n_test_workflow` or confirm it was loaded at session start.

---
*Generated by R-SR-09 close protocol at end of S-187 — May 2, 2026*
