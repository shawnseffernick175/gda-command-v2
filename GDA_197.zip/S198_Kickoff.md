# S-198 Kickoff — GDA Command Platform
**Date:** Next session after May 4, 2026
**Operator:** Claude (Anthropic)
**Platform:** GDA OU3 / Envision Innovative Solutions

---

## Session Open Protocol (MANDATORY)
1. `tool_search("n8n")` — load MCP context
2. Read this file
3. Execute top item from queue below without interrogating

---

## Platform State at S-197 Close
| Component | State |
|---|---|
| VPS 187.77.206.105 | ONLINE — stable |
| n8n.csr-llc.tech | ONLINE — 165 active workflows |
| gda.csr-llc.tech | LIVE — React SPA 24 routes, all routing PASS |
| API Gateway | LIVE — systemd active :8788, 3 new Fast Track routes |
| gda-frontend container | RESTORED — nginx crash fixed S-197 |
| gda_learned_weights | CREATED S-197 — 6 factors seeded from AN-1 |
| Fast Track Phase 1 | LIVE — DB schema + n8n workflow + gateway routes + React page |
| pwin-calculator | Now reads learned weights from gda_learned_weights |
| North Star | ~98% |

---

## S-198 Priority Queue

### **RANK 1 — morning-briefing 500 investigation**
```
GDA.api.morning-briefing webhook returns HTTP 500 per QA health check.
Investigate: check last execution error, compare against morning-briefing-v1 (YIvCdrOgF1LGmFNL).
GDA.intel.morning-briefing-v1 (Telegram cron) is separate and verified working.
Fix the API endpoint or quarantine it and update QA health check.
```

### **RANK 2 — Fast Track signal enrichment (real sources)**
```
Current 25 signals seeded from gda-intel (internal pipeline).
Add GovTribe and SAM pre-solicitation signal ingest.
Create GDA.cron.fast-track-ingest workflow (cron, reads GovTribe/SAM, upserts ft_opportunity_signal).
Target: formal + pre-solicitation sources with real due dates, NAICS, and estimated values.
```

### **RANK 3 — Fast Track launchpad tile**
```
Add Fast Track tile to GDALaunchpad.jsx widget grid.
Link: /fast-track. Color: #aa44ff (latent purple).
Label: FAST TRACK. Position: after existing tiles.
Build and deploy via deploy workflow 8GnGxnBL9TJjj1i2.
```

### **RANK 4 — Fast Track sources action**
```
GDA.api.fast-track-needs currently stubs /api/fast-track/sources when sources action not matched.
Add sources action branch to fast-track-needs n8n workflow (ID: l6X3n5paaIqMKWxB).
Query: SELECT * FROM ft_signal_source WHERE active = true ORDER BY band, name.
Update gateway route fasttrack.js to pass action: 'sources'.
```

### **RANK 5 — HP-6: webhook key rotation**
```
Rotate: gda-api-2026-secure → gda-api-2027-AWqjhbxDYNcyV1mr (already in use since S-196)
Rotate: gda-deploy-2026-secure → new key
Update n8n credential fTrhOzBkjS1s67bm with new key values.
Patch App.jsx if it has any hardcoded references.
Verify no workflows break.
```

### **RANK 6 — learning engine verification**
```
Verify GDA.cron.learning-engine (fZpqchmmPnqAmiMq) is actively recalibrating gda_learned_weights.
Check last 3 executions for success.
Confirm it reads from gda_win_loss_db (8 Won / 2 Lost) and updates weights.
If broken: patch the calibration logic.
```

### **RANK 7 — North Star 100%**
```
Confirm all remaining open items closed.
Generate final platform health report.
Target: 100% North Star with Fast Track counted as new operational module.
```

---

## DO NOT RE-AUDIT (Block D — CLOSED)
| Workflow | ID | Verdict |
|---|---|---|
| weekly-comp-scan | uQ5cZ97cCrx5iIXk | FIXED |
| morning-briefing-v1 | YIvCdrOgF1LGmFNL | VERIFIED |
| nightly-fy-revenue-calc | EGQzp92GxbjTJ03X | VERIFIED |
| data-retention | LzjiBI80aDAZgDIp | VERIFIED |
| e2e-gemini-report | BLS36QTOznJ8mJlC | VERIFIED |
| dept-opp-sweep | JRnWGEH9cesb8f3w | VERIFIED |

---

## Key Credentials (S-197 canonical — unchanged)
```
x-gda-key:                gda-api-2027-AWqjhbxDYNcyV1mr
GDA Webhook Auth cred:    fTrhOzBkjS1s67bm  (primary)
GDA Webhook Auth cred:    1pNPY36DDz49OtKL  (alternate — SSH workflow uses this)
VPS SSH Key cred:         NKOxLo5F81sRNPua
Telegram cred:            Jr8OOsZqc9DarQE6  (GDA Telegram Bot)
Postgres cred:            HwronxMmGY5XDGEt  (GDA Postgres)
GitHub Gist PAT:          sKJFLNzetK86JnvO
QA Agent key:             qa-agent-test-2026-adlkjfn7987-srkigio-99-eatshit
```

## Key Workflow IDs (S-197 additions)
```
Fast Track needs:         l6X3n5paaIqMKWxB  (NEW S-197 — ACTIVE)
AN-1 Win Themes:          yMo7WrELV8JVOi2M  (ACTIVE)
QA fix-runner:            aAVitXXjGWaP7bb2  (ACTIVE)
Gist session-update:      4bhVvKvVgLXcX6AZ  (ACTIVE)
SSH Exec:                 IcD4K740vpWSIuaZ
Deploy:                   8GnGxnBL9TJjj1i2
Dashboard-mega:           UYGJPu7N5YZblvEU
opp-tracker 2:            SEJLE89wZa1yfQyB   (CANONICAL)
ooda-loop 2:              pkPpMhiz8IdRy7To   (CANONICAL)
Morning briefing:         YIvCdrOgF1LGmFNL   (VERIFIED — Block D)
pwin-calculator:          81m1Zl9xjM6L8HQb   (NOW READS gda_learned_weights)
learning-engine:          fZpqchmmPnqAmiMq   (verify S-198)
```

## DB State (S-197 canonical)
```
gda_win_loss_db:          8 Won / 2 Lost
gda_opportunity_tracker:  1344 rows
gda_learned_weights:      CREATED S-197 — 6 pwin factors (weights sum to 1.00)
ft_signal_source:         CREATED S-197 — 9 source records
ft_opportunity_signal:    CREATED S-197 — 25 signals seeded from active pipeline
ft_need_tag:              CREATED S-197 — empty, ready for enrichment
ft_need_view:             CREATED S-197 — normalized read view
```

## Hard Rules (S-197 canonical — unchanged)
- Switch node → broken → use IF or Code nodes
- LangChain cred d92MU0tRK7bEGV83 → permanently broken → HTTP + $env.ANTHROPIC_API_KEY
- Postgres typeVersion 2.5/2.6 → inline `{{ $json.field }}` in SQL; no queryValues
- App.jsx writes → UTF-8 only; backup at /opt/gda-command/src/App.jsx.bak-s158-kpi
- Deploy: vite build → cp -r dist/. /root/gda-frontend/dist/ → docker exec nginx -s reload
- N8N_ENCRYPTION_KEY → must persist in /root/n8n-envision/.env
- SSH Guard allows: bash -c, python3, cat, grep, sed, tee, tail, find, ls, systemctl, curl, nginx
- Code nodes: use native fetch() — never $helpers.httpRequest (CODE-01)
- RR-38 and RR-28 are RESOLVED — do not reference as frozen
- Canonical opp table: gda_opportunity_tracker; PURSUE label: gda_label = 'PURSUE'
- Canonical active pipeline: stage NOT IN ('No-Bid','Cancelled','No-Go','Lost','Won')
- Top-level defense department: Department of War (not Department of Defense)
- MCP prefix: fuck-this-shit: for all n8n management calls
- SSH bulk inserts: use base64 Python script pattern (heredoc unreliable in bash -c)
- Postgres ARRAY syntax: ARRAY['a','b'] not {a,b} when passing via psql -c argument
- nginx.conf restart: use `docker compose up -d gda-frontend` from /root/n8n-envision/
- Fast Track DB: ft_signal_source, ft_opportunity_signal, ft_need_tag, ft_need_view (all S-197)
- Fast Track workflow: GDA.api.fast-track-needs (l6X3n5paaIqMKWxB) — webhook path: gda-fast-track

---

## North Star Gap (post S-197)
| Remaining | Effort | S-198 Rank |
|---|---|---|
| morning-briefing 500 fix | Low | 1 |
| Fast Track real source ingest | Med | 2 |
| Fast Track launchpad tile | Low | 3 |
| Fast Track sources action | Low | 4 |
| HP-6 key rotation | Med | 5 |
| Learning engine verification | Low | 6 |
| North Star 100% closure | Low | 7 |

Platform is ~98% of North Star. Fast Track Phase 1 is live as a read-only module. All Block E hardening complete.

---
*Generated by R-SR-09 close protocol at end of S-197 — May 4, 2026*
