# GDA Command Platform — S-162 Kickoff
**Prepared:** S-161 Close | April 23, 2026
**Last Session:** S-161 — HP-9 complete. Full Hardening Plan finished. No hardening debt remains.
**Operator:** Shawn Seffernick, President, EIS/GDA OU3

---

## Pre-Flight (Every Chat)
1. `tool_search("n8n")` — load MCP
2. Read this file
3. **RR-38 and RR-28 are FROZEN** — do not touch ever

---

## FIRST ACTION NEXT CHAT

All hardening complete. No default queue item. Ask Shawn what S-162 work looks like — he may have new items or feature work to resume.

Remaining low-priority open debt:
- **RR-43** (Low) — bot dual-routing fix — only if touching telegram-chat anyway
- **RR-36** (Med) — Chrome MCP cross-origin — only if Chrome MCP session available

---

## Platform State

| Item | Status |
|---|---|
| Active workflows | ~155 |
| Frontend (gda.csr-llc.tech) | LIVE — rebuilt S-160 with rotated API key |
| GDA.api.dashboard-mega | ACTIVE — saveDataSuccessExecution: none |
| GDA.intel.morning-briefing-v1 | ACTIVE — saveDataSuccessExecution: none |
| GDA.api.opp-tracker 2 | ACTIVE — saveDataSuccessExecution: none |
| GDA.api.capture-plan | ACTIVE — RR-42 CLEAN |
| GDA.util.ssh-read-file | ACTIVE — headerAuth LOCKED |
| All 7 cron workflows | errorWorkflow: 2Swf6LP9AzFjHFYU |
| Traefik rate limiting | ACTIVE — 30r/s avg, burst 10 |
| docker-compose.yml | CLEAN — no plaintext API keys |
| /root/n8n-envision/.env | LIVE — ANTHROPIC_API_KEY + N8N_API_KEY (mode 600) |
| Hardening Plan | ALL 9 ITEMS COMPLETE |

---

## Current Keys

| Key | Value |
|---|---|
| API key (App.jsx + SSH read header) | `gda-api-2026-8ced0b75` |
| Deploy webhook key | `gda-deploy-2026-412ae367` |
| SSH read webhook auth | `x-gda-key: gda-api-2026-8ced0b75` |
| Deploy webhook auth | `x-gda-auth: gda-deploy-2026-412ae367` |
| n8n webhook cred | `fTrhOzBkjS1s67bm` (GDA Webhook Auth) |

---

## Key Workflow IDs

| Workflow | ID |
|---|---|
| GDA.dev.deploy | 8GnGxnBL9TJjj1i2 |
| GDA.bot.telegram-chat | 1ItrrFxGI3L43Pdv |
| GDA.api.daily-actions | C7Bh7KcAl1IgSTRr |
| GDA.api.ooda-loop 2 | pkPpMhiz8IdRy7To |
| GDA.intel.morning-briefing-v1 | YIvCdrOgF1LGmFNL |
| GDA.api.launchpad-funnel | vaRzM1Jl6HcXjuxs |
| GDA.api.dashboard-mega | UYGJPu7N5YZblvEU |
| GDA.api.opp-tracker 2 | SEJLE89wZa1yfQyB |
| GDA.api.capture-plan | QgperN6cuOpfnb09 |
| GDA.api.morning-briefing (read) | 0zVPgmYsvcqhyyo6 |
| GDA.auto.gist-update | djgOV2vX3PIv9cvm |
| GDA.api.aop-tracker | P8AfP8P84xi33auD |
| GDA.api.win-loss-db | SpU3znFHHABYNmb9 |
| GDA.cron.recompete-early-warning | MtcQwAgm1zHYXNfB |
| GDA.cron.win-rate-weekly-digest | ZuQkz1HrMONclkFm |
| GDA.cron.idiq-task-order-alert | DeSN1t1swXX14xTc |
| GDA.cron.capture-opp-sync | 0E3lCtWt2rdJlMPY |
| GDA.api.platform-health | UBgoJGxZro834RbT |
| GDA.api.bd-activity-log | 9qrsria0fy719T98 |
| GDA.api.teaming-scorer | jQvgX6SD1RhARG3F |
| GDA.cron.capture-milestone-alerts | Kk7O8Bw2FOe41M9l |
| GDA.auto.feedback-collector | aCrxoe1rCuIbsnC4 |
| GDA.cron.learning-engine | fZpqchmmPnqAmiMq |
| GDA.api.pwin-calculator | 81m1Zl9xjM6L8HQb |
| GDA.agent.opp-classifier | hWCP9NLXxtCOrppu |
| GDA.util.ssh-read-file | IcD4K740vpWSIuaZ |
| GDA.error.handler | 2Swf6LP9AzFjHFYU |
| GDA.cron.weekly-comp-scan | uQ5cZ97cCrx5iIXk |

---

## Infrastructure

| Resource | Detail |
|---|---|
| Frontend source | /opt/gda-command/src/App.jsx |
| App.jsx canonical backup | /opt/gda-command/src/App.jsx.bak-hp6 |
| Vite binary | /opt/gda-command/node_modules/.bin/vite |
| Deploy sequence | vite build → cp -r dist/. /root/gda-frontend/dist/ |
| Node.js path | /root/.nvm/versions/node/v20.20.0/bin |
| Compose file | /root/n8n-envision/docker-compose.yml |
| Env file | /root/n8n-envision/.env (mode 600) |
| Deploy webhook | POST https://n8n.csr-llc.tech/webhook/gda-deploy |
| Deploy auth | Header: x-gda-auth: gda-deploy-2026-412ae367 |
| SSH read webhook | POST https://n8n.csr-llc.tech/webhook/gda-read |
| SSH auth | Header: x-gda-key: gda-api-2026-8ced0b75 |
| Postgres cred | HwronxMmGY5XDGEt |
| VPS | 187.77.206.105 |
| n8n | https://n8n.csr-llc.tech (v2.47.14) |
| Frontend | https://gda.csr-llc.tech |
| MCP | https://mcp.csr-llc.tech/mcp |
| SSH workflow cred | VqYFb1aRGJa8UfBc |
| Webhook Auth cred | fTrhOzBkjS1s67bm (GDA Webhook Auth) |
| Feedback endpoint | POST https://n8n.csr-llc.tech/webhook/gda-feedback |
| Data-learn endpoint | POST https://n8n.csr-llc.tech/webhook/gda-data-learn |

---

## Open Debt

| ID | Sev | Summary |
|---|---|---|
| RR-36 | Med | Chrome MCP cross-origin — workaround in place |
| RR-43 | Low | Bot dual-routing — fix when telegram-chat next touched |
| RR-44 | Low | Webhook headerAuth 403 in test tool — workaround documented |
| RR-38 | FROZEN | Do not touch |
| RR-28 | FROZEN | Do not touch |

---

## Rules

- Claude executes everything via MCP. Never tell Shawn to manually do things.
- RR-38 and RR-28 are FROZEN. Do not touch.
- SSH auth: always atomic — disable → fire → restore in same sequence. Never leave open.
- Show broken vs fixed BEFORE deploying (R-SR-04).
- End every session: overwrite these project files with updated versions.
- Bot rollback: n8n_workflow_versions(mode=rollback, workflowId=1ItrrFxGI3L43Pdv) to v4

---

## Schema (Canonical)

- `gda_intelligence_log` time column: **timestamp** (created_at also present)
- Allocation revenue: `gda_capture_plans.plan_data->>'allocated_revenue'` (JSONB, dollars)
- `opp-tracker 2` and `ooda-loop 2` are LIVE CANONICAL — do not delete
- Anthropic API: direct HTTP with `$env.ANTHROPIC_API_KEY`. LangChain cred d92MU0tRK7bEGV83 is BROKEN.
- `gda_mega_cache` — id=1 singleton, 60min TTL
- `gda_feedback` event_types: win, loss, pwin_outcome, opp_label_correction, action_completed, actions_generated, opp_classified, briefing_sent
- `gda_learned_weights` keys: pwin.* (6), briefing.* (3), actions.* (3) — 12 total
- capture-plan Postgres nodes use `queryValues` arrays — queryReplacement fully removed S-158 Chat 2
- **Critical Postgres rule:** typeVersion 2.5/2.6 — inline template expressions only, never queryValues arrays
- **Switch node is broken** — use IF nodes or Code nodes
- **App.jsx** must always be written UTF-8
- **Vite build:** use local binary, not global `vite`
- **Traefik** is the reverse proxy — rate limiting via Docker Compose labels
- **Department of War** is correct top-level defense dept name
