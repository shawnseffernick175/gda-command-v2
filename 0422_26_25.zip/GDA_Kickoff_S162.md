# GDA Command Platform — S-162 Kickoff
**Prepared:** S-161 close | April 22, 2026
**Next operator:** Shawn Seffernick, EIS/GDA OU3

---

## Pre-Flight (Every Chat)
1. `tool_search("n8n")` — load MCP
2. Read this file
3. RR-38 and RR-28 are **CLOSED** (resolved S-159)

---

## FIRST ACTION NEXT CHAT

Ask Shawn if new items exist before defaulting to queue below.

**S-162 Priority Queue:**
1. **HP-6** (Med) — Webhook key rotation — generate new keys, update n8n cred fTrhOzBkjS1s67bm + App.jsx occurrences + any hardcoded workflow params
2. **HP-7** (Med) — nginx/proxy rate limiting — SSH to VPS, locate nginx config, apply `limit_req_zone` at 30r/m for /webhook/

---

## HP-6 Execution Notes
- Generate two new keys: `gda-api-2026-[random 8 hex chars]` and `gda-deploy-2026-[random 8 hex chars]`
- Use: `python3 -c "import secrets; print(secrets.token_hex(4))"` twice
- Update n8n HTTP Header Auth credential `fTrhOzBkjS1s67bm` (GDA Webhook Auth) with new deploy key
- Search App.jsx for all `gda-api-2026-secure` occurrences and patch inline (SSH workflow pattern — large file)
- Search all n8n workflows for hardcoded `gda-api-2026-secure` in node parameters
- Build and deploy frontend after App.jsx patch
- Update GDA Session State / Kickoff doc with new key values

## HP-7 Execution Notes
- SSH to VPS (187.77.206.105), credential `VqYFb1aRGJa8UfBc`
- Locate: `/etc/nginx/sites-available/n8n` or `/etc/nginx/nginx.conf`
- Add in `http` block: `limit_req_zone $binary_remote_addr zone=gda_webhooks:10m rate=30r/m;`
- Add in `location /webhook/` block: `limit_req zone=gda_webhooks burst=10 nodelay;`
- Test: `nginx -t` → if clean: `nginx -s reload`
- Verify single webhook call returns 200

---

## Platform State

| Item | Status |
|---|---|
| Active workflows | ~155 |
| Frontend (gda.csr-llc.tech) | LIVE |
| GDA.util.ssh-read-file | HARDENED — headerAuth + Guard allowlist active |
| All cron workflows | errorWorkflow → 2Swf6LP9AzFjHFYU ✅ |
| morning-briefing, dashboard-mega, opp-tracker 2, capture-plan | saveDataSuccessExecution: none ✅ |
| Hardening Items 1–5 | COMPLETE |
| HP-8 (Postgres queryReplacement sweep) | COMPLETE — 7 nodes patched S-161 |
| HP-6 (Key rotation) | QUEUED |
| HP-7 (nginx rate limiting) | QUEUED |
| queryReplacement remaining | **ZERO** — platform-wide clean |

---

## Open Debt

| ID | Sev | Summary |
|---|---|---|
| HP-6 | Med | Webhook key rotation — gda-api-2026-secure + gda-deploy-2026-secure |
| HP-7 | Med | nginx/proxy rate limiting — proxy config location TBD via SSH |
| RR-36 | Med | Chrome MCP cross-origin — workaround in place |
| RR-43 | Low | Bot dual-routing — fix when telegram-chat next touched |
| RR-44 | Low | n8n_test_workflow 403 on headerAuth — workaround documented |

---

## Key Workflow IDs

| Workflow | ID |
|---|---|
| GDA.util.ssh-read-file | IcD4K740vpWSIuaZ |
| GDA.dev.deploy | 8GnGxnBL9TJjj1i2 |
| GDA.bot.telegram-chat | 1ItrrFxGI3L43Pdv |
| GDA.intel.morning-briefing-v1 | YIvCdrOgF1LGmFNL |
| GDA.api.capture-plan | QgperN6cuOpfnb09 |
| GDA.api.dashboard-mega | UYGJPu7N5YZblvEU |
| GDA.cron.recompete-early-warning | MtcQwAgm1zHYXNfB |
| GDA.cron.win-rate-weekly-digest | ZuQkz1HrMONclkFm |
| GDA.cron.idiq-task-order-alert | DeSN1t1swXX14xTc |
| GDA.cron.capture-opp-sync | 0E3lCtWt2rdJlMPY |
| GDA.cron.learning-engine | fZpqchmmPnqAmiMq |
| GDA.cron.capture-milestone-alerts | Kk7O8Bw2FOe41M9l |
| Error handler | 2Swf6LP9AzFjHFYU |

---

## Infrastructure

| Resource | Detail |
|---|---|
| Frontend source | /opt/gda-command/src/App.jsx |
| Deploy webhook | POST https://n8n.csr-llc.tech/webhook/gda-deploy |
| Deploy auth | Header: x-gda-auth: gda-deploy-2026-secure |
| SSH webhook (read) | POST https://n8n.csr-llc.tech/webhook/ssh-read-file |
| SSH auth (read) | Header: x-gda-key: gda-api-2026-secure (RR-44: temp set to none → fire → restore) |
| API auth | Header: x-gda-key: gda-api-2026-secure |
| Webhook Auth cred | fTrhOzBkjS1s67bm (GDA Webhook Auth) |
| Postgres cred | HwronxMmGY5XDGEt |
| VPS | 187.77.206.105 |
| n8n | https://n8n.csr-llc.tech |
| MCP | https://mcp.csr-llc.tech/mcp |

---

## Critical Rules

- Claude executes everything via MCP. Never tell Shawn to manually do things.
- All Postgres nodes at typeVersion 2.5/2.6: use inline `{{ $json.field }}` expressions — NEVER queryValues arrays or queryReplacement strings.
- Switch node is broken — use IF or Code nodes.
- LangChain cred d92MU0tRK7bEGV83 is BROKEN — all Anthropic calls via direct HTTP with $env.ANTHROPIC_API_KEY.
- Webhook test pattern (RR-44): temp set auth to none → fire → restore headerAuth.
- SSH Guard allowlist: cat, ls, wc, echo, find /opt/gda-command, python3 /tmp/gda_* — do NOT add /etc paths permanently.

---

## Schema (Canonical)

- `gda_intelligence_log` time column: **timestamp only** — created_at DROPPED S-159
- Allocation revenue: `gda_capture_plans.plan_data->>'allocated_revenue'` (JSONB, dollars)
- `opp-tracker 2` and `ooda-loop 2` are LIVE CANONICAL — do not delete
- `gda_mega_cache` — id=1 singleton, 60min TTL
- capture-plan Postgres nodes use inline `{{ }}` expressions — queryReplacement fully removed S-158 Chat 2
- queryReplacement: ZERO remaining platform-wide as of S-161

---

*— GDA S-162 Kickoff | Prepared at S-161 close | April 22, 2026 —*
