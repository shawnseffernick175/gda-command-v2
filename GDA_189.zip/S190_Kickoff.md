# S-190 Kickoff — GDA Command Platform
**Date:** Next session after May 2, 2026
**Operator:** Claude (Anthropic)
**Platform:** GDA OU3 / Envision Innovative Solutions

---

## Session Open Protocol (MANDATORY)
1. `tool_search("n8n")` — load MCP context
2. `tool_search("fuck this shit n8n test workflow")` — load test/execute tools
3. Read this file
4. Execute top item from queue below without interrogating

---

## Current Platform Health
| Component | State |
|---|---|
| VPS 187.77.206.105 | ONLINE |
| n8n.csr-llc.tech | ACTIVE — 160 workflows / 158 active |
| gda.csr-llc.tech | LIVE — React SPA, QACenterPage updated S-188 |
| API Gateway nginx | WIRED — /api/ → 172.18.0.1:8788. /api/qa/health → 6/8 PASS ✓ |
| agent-runner | **FIXED S-189** — TxcPdvx2Ld9rE9er, health {ok:true}, 3 patches applied |
| fix-runner | ACTIVE — aAVitXXjGWaP7bb2, health OK, dry-run mode |
| SSH Exec Workflow | ACTIVE — IcD4K740vpWSIuaZ, headerAuth RESTORED |

---

## S-190 Priority Queue

### **RANK 1 — C-5 Failures: Investigate 4 Failing Webhooks**
4 React-used webhooks return HTTP 500. Root cause unknown. Prior test used stale webhook key in agent-runner (updated S-189). Re-run C-5 first — failures may clear with updated key.

**Step 1:** Re-run test_react_used_workflows
```
n8n_test_workflow → TxcPdvx2Ld9rE9er
headers: {x-gda-qa-key: qa-agent-test-2026-adlkjfn7987-srkigio-99-eatshit}
body: {action: "test_react_used_workflows"}
```

**Step 2:** If still failing, pull latest failed executions:
```
body: {action: "return_latest_failed_workflows", limit: 25}
```
Identify which executions map to: gda-smoke-test, gda-daily-actions-list, gda-action-history, gda-deep-research-history. Inspect stderr/error field.

**Step 3:** Fix root causes per execution error. Likely: stale auth key in workflow, broken Postgres query, or missing env var.

### **RANK 2 — Block B: React auth_key Verification**
The 5 pages (IdiqOnRampPage, IncumbentAnalysisPage, BlackHatPage, WargamePage, TeamingFinderPage) were supposed to have auth_key removed after gateway went live. Never confirmed.

```
SSH cmd: grep -r "auth_key" /opt/gda-command/src/components/pages/ 2>/dev/null | grep -v ".bak"
```
If auth_key present → patch those pages → build → deploy.

### **RANK 3 — Block D: Rescue Map Audit**
6 workflows claimed fixed but never verified live post-fix. Trigger each and check executions.

| Workflow | ID | Trigger Method |
|---|---|---|
| weekly-comp-scan | uQ5cZ97cCrx5iIXk | SSH: trigger via n8n API execute endpoint |
| morning-briefing-v1 | YIvCdrOgF1LGmFNL | n8n_test_workflow → gda-briefing-test |
| nightly-fy-revenue-calc | EGQzp92GxbjTJ03X | n8n API manual execute |
| data-retention | LzjiBI80aDAZgDIp | n8n API manual execute |
| e2e-gemini-report | BLS36QTOznJ8mJlC | n8n_test_workflow → gda-e2e-gemini |
| dept-opp-sweep | JRnWGEH9cesb8f3w | n8n_test_workflow → gda-dept-sweep |

### **RANK 4 — Block E Hardening**
- HP-5: Set errorWorkflow: 2Swf6LP9AzFjHFYU on 6 cron workflows lacking it
- HP-4: Audit saveDataSuccessExecution on high-volume workflows
- HP-7: nginx rate limiting (SSH to /root/gda-frontend/nginx.conf)

---

## Key Credentials (S-189 canonical)
```
x-gda-key:                gda-api-2027-AWqjhbxDYNcyV1mr
GDA Webhook Auth cred:    1pNPY36DDz49OtKL
VPS SSH Key cred:         NKOxLo5F81sRNPua
QA Agent key:             qa-agent-test-2026-adlkjfn7987-srkigio-99-eatshit  (header: x-gda-qa-key)
n8n JWT:                  Read fresh from /root/n8n-envision/.env via SSH each session
GDA_QA_FIX_MODE:          dry-run
Shawn chat_id:            8631035943
```

## Key Workflow IDs
```
SSH Exec:       IcD4K740vpWSIuaZ
Deploy:         8GnGxnBL9TJjj1i2
Dashboard:      UYGJPu7N5YZblvEU
opp-tracker 2:  SEJLE89wZa1yfQyB  (CANONICAL - never delete)
ooda-loop 2:    pkPpMhiz8IdRy7To  (CANONICAL - never delete)
agent-runner:   TxcPdvx2Ld9rE9er  (FIXED S-189 - health {ok:true})
fix-runner:     aAVitXXjGWaP7bb2
Morning brief:  YIvCdrOgF1LGmFNL
Capture-plan:   QgperN6cuOpfnb09
gist-update:    PoOofuf0OgaYJCBN  (ACTIVE - GIST-01 RESOLVED)
```

## Hard Rules (S-189 additions + all prior)
- Switch node → broken → use IF or Code nodes
- LangChain cred `d92MU0tRK7bEGV83` → permanently broken → HTTP + `$env.ANTHROPIC_API_KEY`
- Postgres typeVersion 2.5/2.6 → inline `{{ $json.field }}` in SQL only, no queryValues
- App.jsx writes → UTF-8 only; backup at `/opt/gda-command/src/App.jsx.bak-s158-kpi`
- Deploy sequence: `vite build → cp -r dist/. /root/gda-frontend/dist/`
- N8N_ENCRYPTION_KEY → must persist in `/root/n8n-envision/.env`
- nginx config: bind-mounted from `/root/gda-frontend/nginx.conf`; write to host, then `docker exec nginx -s reload`
- Gateway IP from inside Docker: `172.18.0.1`
- MCP prefix: **fuck-this-shit: exclusively**. n8n: times out.
- n8n_get_workflow: mode:full works. mode:structure/minimal may throw error — retry with mode:full.
- **CODE-01 (revised):** n8n Code node HTTP = `this.helpers.httpRequest({url, method, headers, body, returnFullResponse:true, ignoreHttpStatusErrors:true})`. Neither `require('https')` nor `fetch()` available in task runner.
- n8n JWT: read fresh from /root/n8n-envision/.env each session. Never rely on hardcoded value.
- RR-38 and RR-28 are RESOLVED. Do not reference as frozen.
- GIST-01 RESOLVED: Two gist workflows live (PoOofuf0OgaYJCBN + djgOV2vX3PIv9cvm). Old ID t85atQIzsTajgUre was stale.

---

## What Remains to "Be Done" (North Star Gap)
| Remaining | Effort |
|---|---|
| C-5 4 failing webhooks | S-190 Rank 1 |
| Block B auth_key verify | S-190 Rank 2 |
| Block D rescue map audit | S-190 Rank 3 |
| Block E hardening (HP-4/5/7) | S-190/191 |
| Block F: OODA auto / Telegram daily / pwin loop / recompete alert / capture AI assist | S-191+ |

Platform is ~80% of North Star vision. Blocks D+E are verification/hardening. Block F is the autonomous BD ops layer (the original end goal).

---
*Generated by R-SR-09 close protocol at end of S-189 — May 2, 2026*
