# GDA Command Platform — Session State
**Last Updated:** S-167 — April 29, 2026
**Operator:** Shawn Seffernick, President, Envision Innovative Solutions (OU3)

---

## Pre-Flight (Every Chat)
1. `tool_search("n8n")` — load MCP
2. Read this file
3. Read ALL uploaded documents before taking any action
4. RR-38 and RR-28 are RESOLVED — do not reference as frozen

---

## FIRST ACTION NEXT CHAT (S-168)

**SSH key confirmation required before anything else.** Open n8n UI → Credentials → "GDA Webhook Auth" (ID: fTrhOzBkjS1s67bm) → read current header value. That is the key for all SSH-read calls this session. Once confirmed, proceed to S-168-01.

**S-168 Priority Queue:**
1. S-168-01 (High) — Fix QA agent-runner Router: swap this.helpers.httpRequest to await fetch. Use patched code from bundle (gda-qa-agents/workflows/GDA.qa.agent-runner.json), preserve hardcoded keys from live deployment.
2. S-168-02 (High) — Remove Auth Guard Code nodes from 8 workflows: dashboard-mega, platform-health, intel-feed, data-learn, ndaa-far-ingest, morning-briefing, golden-dome-monitor, dept-market-refresh. Show current→fixed before each.
3. S-168-03 (Med) — Deploy API Gateway v1 to VPS: unzip gda-api-gateway-v1.zip to /opt/gda-api-gateway-v1/, npm install, configure .env, wire nginx proxy for /api/qa/* /api/workflows/* /api/failures/*
4. S-168-04 (Med) — Strip auth_key inline values from 6 React page components: IdiqOnRampPage, IncumbentAnalysisPage, BlackHatPage, WargamePage, TeamingFinderPage. Build + deploy.
5. S-168-05 (Med) — Activate fix-runner (aAVitXXjGWaP7bb2) and run health check.
6. S-168-06 (Low) — Audit 6 remaining Rescue Map workflows.

---

## Platform State

| Item | Status |
|---|---|
| Active workflows | 156 (registry baseline: 159 total, 3 inactive) |
| Frontend (gda.csr-llc.tech) | LIVE — QA Center deployed, all 23 sidebar routes passing |
| React source | github-ready zip is canonical — 418,018 bytes App.jsx, QACenterPage present |
| API Gateway v1 | BUILT (gda-api-gateway-v1.zip) — NOT YET ON VPS |
| GDA.qa.agent-runner | BROKEN — this.helpers.httpRequest syntax error, all executions failing |
| GDA.qa.fix-runner | EXISTS (aAVitXXjGWaP7bb2) — 3 nodes, INACTIVE |
| GDA.controlled-fix-agent | ACTIVE (akvlbmdUBCgx58PC) |
| 8 n8n workflows | Auth Guard nodes NOT removed despite Rescue Map claim |
| SSH webhook key | UNKNOWN — HP-6 rotation done but value not in session state |

---

## Key Workflow IDs

| Workflow | ID |
|---|---|
| GDA.dev.deploy | 8GnGxnBL9TJjj1i2 |
| GDA.util.ssh-read-file | IcD4K740vpWSIuaZ |
| GDA.bot.telegram-chat | 1ItrrFxGI3L43Pdv |
| GDA.api.dashboard-mega | UYGJPu7N5YZblvEU |
| GDA.api.opp-tracker 2 | SEJLE89wZa1yfQyB |
| GDA.api.ooda-loop 2 | pkPpMhiz8IdRy7To |
| GDA.api.launchpad-funnel | vaRzM1Jl6HcXjuxs |
| GDA.api.platform-health | UBgoJGxZro834RbT |
| GDA.api.daily-actions | C7Bh7KcAl1IgSTRr |
| GDA.qa.agent-runner | TxcPdvx2Ld9rE9er |
| GDA.qa.fix-runner | aAVitXXjGWaP7bb2 |
| GDA.controlled-fix-agent | akvlbmdUBCgx58PC |
| GDA.error.handler | 2Swf6LP9AzFjHFYU |

---

## Credential Reference

| Credential | ID | Notes |
|---|---|---|
| GDA Webhook Auth | fTrhOzBkjS1s67bm | Current key UNKNOWN — check n8n UI before S-168 |
| VPS Root SSH | VqYFb1aRGJa8UfBc | Used by ssh-read-file workflow |
| Anthropic API | $env.ANTHROPIC_API_KEY | Direct HTTP only — LangChain cred d92MU0tRK7bEGV83 is BROKEN |

---

## Rules

- Read ALL documents before acting — no exceptions
- Claude executes everything via MCP. Never tell Shawn to manually do things.
- Show broken vs fixed BEFORE deploying (R-SR-04)
- Spot-check 2 items before any batch operation (R-SR-13)
- End every session: 4 R-SR-09 artifacts
- RR-38 and RR-28 are RESOLVED — closed ~3 weeks before April 29 2026
- Auth standard: n8n webhook credential-level auth only; remove hardcoded Code-node auth guards
- opp-tracker 2 and ooda-loop 2 are LIVE CANONICAL — do not delete
- Anthropic API: direct HTTP with $env.ANTHROPIC_API_KEY — LangChain cred d92MU0tRK7bEGV83 BROKEN
- Department of War (not DoD) is correct top-level hierarchy name
- Platform is React-only going forward — Retool archived/reference only

---

## Schema (Canonical)

- `gda_intelligence_log` time column: timestamp (created_at also present)
- Allocation revenue: `gda_capture_plans.plan_data->>'allocated_revenue'` (JSONB, dollars)
- `gda_mega_cache` — id=1 singleton, 60min TTL
- Postgres `queryValues` arrays canonical — queryReplacement fully removed
- n8n Response Standard envelope: {success, workflow, action, dryRun, data, meta, error}
