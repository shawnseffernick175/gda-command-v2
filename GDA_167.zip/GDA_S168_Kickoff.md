# GDA Command Platform — S-168 Kickoff
**Prepared:** S-167 close | April 29, 2026
**Operator:** Shawn Seffernick, President EIS/GDA OU3

---

## Pre-Flight (Every Chat)
1. `tool_search("n8n")` — load MCP
2. Read this file
3. Read ALL uploaded documents before taking any action
4. RR-38 and RR-28 are RESOLVED — never reference as frozen

---

## FIRST ACTION

Check current x-gda-key credential value: n8n UI → Credentials → "GDA Webhook Auth" (fTrhOzBkjS1s67bm) → read header value. This unlocks SSH reads for the session.

---

## S-168 Priority Queue

1. **S-168-01 (High)** — Fix QA agent-runner Router
   - Workflow: TxcPdvx2Ld9rE9er
   - Fix: swap jsCode to fetch-based version from gda-qa-agents bundle
   - Preserve: QA_AGENT_KEY = 'qa-agent-test-2026-adlkjfn7987-srkigio-99-eatshit', WEBHOOK_HEADER_VALUE = 'gda-api-2026-f584dae2', N8N_API_KEY (JWT)
   - Test: hit /webhook/gda-qa-agent with action: health — must return {ok:true}

2. **S-168-02 (High)** — Remove 8 Auth Guard Code nodes from live n8n
   - Workflows: dashboard-mega, platform-health, intel-feed, data-learn, ndaa-far-ingest, morning-briefing, golden-dome-monitor, dept-market-refresh
   - Pattern: Webhook → [remove Auth Guard] → next functional node
   - Show current→fixed before each deployment (R-SR-04)

3. **S-168-03 (Med)** — Deploy API Gateway v1 to VPS
   - Source: gda-api-gateway-v1.zip
   - Target: /opt/gda-api-gateway-v1/ on VPS 187.77.206.105
   - Port: 8787
   - nginx: proxy /api/qa/* /api/workflows/* /api/failures/* → localhost:8787
   - Env: N8N_BASE_URL=https://n8n.csr-llc.tech, N8N_API_KEY=<jwt>, WEBHOOK_HEADER_VALUE=<current-key>

4. **S-168-04 (Med)** — Strip auth_key from 6 React pages
   - Files: IdiqOnRampPage.jsx, IncumbentAnalysisPage.jsx, BlackHatPage.jsx, WargamePage.jsx, TeamingFinderPage.jsx
   - Remove: auth_key: 'gda-api-2026-f584dae2' from POST request bodies
   - Build + deploy via GDA.dev.deploy

5. **S-168-05 (Med)** — Activate fix-runner
   - Workflow: aAVitXXjGWaP7bb2
   - Keep GDA_QA_FIX_MODE=dry-run
   - Run health check after activation

6. **S-168-06 (Low)** — Audit 6 remaining Rescue Map workflows
   - weekly-comp-scan (uQ5cZ97cCrx5iIXk) — verify SQL parameterization
   - morning-briefing-v1 (YIvCdrOgF1LGmFNL) — verify stale key fix
   - nightly-fy-revenue-calc (EGQzp92GxbjTJ03X) — verify cache fix
   - data-retention (LzjiBI80aDAZgDIp) — verify timestamp fix
   - e2e-gemini-report (BLS36QTOznJ8mJlC) — verify key removal
   - dept-opp-sweep (JRnWGEH9cesb8f3w) — verify auth fix

---

*— End of S-168 Kickoff —*
