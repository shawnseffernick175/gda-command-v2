# S-179 SESSION KICKOFF
**GDA Command Platform | EIS / GDA OU3 | Shawn Seffernick**
**Generated: 2026-05-01 (S-178 Close)**

---

## MANDATORY FIRST ACTION
```
tool_search("n8n")   ← load MCP before ANY other action
```

---

## CARRY-FORWARD STATUS
- R-SR-09 artifacts from S-178: **COMPLETE** (Session Delta DOCX, DevOps Report DOCX, Master Build XLSX v4.178, this Kickoff MD)
- HP-6 RESOLVED: Both webhook keys rotated, all env files patched, services restarted
- HP-7 BLOCKED at S-178 close: MCP server went unresponsive — resume immediately

---

## S-179 PRIORITY QUEUE (Execute in Order)

| Rank | ID | Priority | Description |
|------|----|----------|-------------|
| 1 | **HP-7** | 🔴 HIGH | nginx rate limiting via SSH to VPS (187.77.206.105). MCP was down at S-178 close — verify MCP health first, then execute. |
| 2 | **GIST-RBL** | 🟡 MED | Rebuild Gist update workflow (`t85atQIzsTajgUre` no longer exists) |
| 3 | **S-164-01** | 🟡 MED | Retool Launchpad KPI binding mismatch ($0 display) — frontend fix |
| 4 | **AN-1** | 🟡 MED | Incumbent analysis + win themes seeded into AI agent |

---

## HP-6 ROTATION SUMMARY (reference)

| Key | Old | New |
|-----|-----|-----|
| API Key (x-gda-key) | gda-api-2026-secure / gda-api-2026-f584dae2 | gda-api-2027-AWqjhbxDYNcyV1mr |
| Deploy Key | gda-deploy-2026-secure | gda-deploy-2027-a4zslQ79hn9A9UIi |
| n8n cred | fTrhOzBkjS1s67bm | UPDATED |

All SSH workflow calls must now use: `x-gda-key: gda-api-2027-AWqjhbxDYNcyV1mr`

---

## HP-7 EXECUTION PLAN (ready to run)

Target: Add nginx rate limiting to protect n8n webhook and frontend endpoints.

**Approach:**
1. Read `/etc/nginx/nginx.conf` via SSH to confirm `http {}` block location
2. Read `/etc/nginx/sites-enabled/` or `/etc/nginx/conf.d/` for site configs
3. Add `limit_req_zone` in `http {}` block:
   ```nginx
   limit_req_zone $binary_remote_addr zone=gda_api:10m rate=30r/m;
   limit_req_zone $binary_remote_addr zone=gda_web:10m rate=60r/m;
   ```
4. Add `limit_req` directives to webhook and API location blocks
5. `nginx -t` to validate; if clean, `systemctl reload nginx`

---

## PLATFORM SNAPSHOT (entering S-179)

| Component | Status |
|-----------|--------|
| n8n | OPERATIONAL |
| Frontend (gda.csr-llc.tech) | OPERATIONAL |
| Postgres | OPERATIONAL |
| getMegaDash | LIVE ($2.3B+ pipeline) |
| Telegram Bot | ACTIVE |
| gda-api-gateway | ACTIVE (new key) |
| gda-gateway | ACTIVE (new key) |
| Retool Launchpad | PARTIAL (S-164-01 open) |
| MCP Server | ⚠️ WAS DOWN AT S-178 CLOSE — verify at session open |

---

## STANDING HARD RULES (never break)
- **Switch node** → broken platform-wide → use IF or Code nodes
- **LangChain cred `d92MU0tRK7bEGV83`** → permanently broken → use HTTP + `$env.ANTHROPIC_API_KEY`
- **Postgres typeVersion 2.5/2.6** → inline `{{ $json.field }}` in SQL only. No `queryValues`. No `queryReplacement`
- **App.jsx** → UTF-8 only. Large patches via base64 Python script
- **n8n container restart** → never `docker compose up -d n8n` from within n8n (loop)
- **N8N_ENCRYPTION_KEY** → must persist in `/root/n8n-envision/.env`
- **Webhook auth test** → temporarily patch to `none` → fire → restore `headerAuth` (RR-44 pattern)
- **RR-38, RR-28** → FROZEN. Do not reference as open

---

## KEY IDs (quick reference)
```
Dashboard-Mega:    UYGJPu7N5YZblvEU
SSH Exec:          IcD4K740vpWSIuaZ   (x-gda-key: gda-api-2027-AWqjhbxDYNcyV1mr)
Deploy:            8GnGxnBL9TJjj1i2
Morning Briefing:  YIvCdrOgF1LGmFNL
Briefing API:      0zVPgmYsvcqhyyo6
Capture-Plan:      QgperN6cuOpfnb09
GDA Webhook Cred:  fTrhOzBkjS1s67bm
GitHub Gist PAT:   sKJFLNzetK86JnvO
VPS Root SSH:      VqYFb1aRGJa8UfBc
Telegram user_id:  8626724926
Telegram chat_id:  8631035943
```

---

## SESSION PROTOCOL REMINDER
- Do not interrogate. Do not run in circles. Do not contradict prior sessions.
- If Shawn says "continue" / "go" / anything ambiguous → execute top item from queue above.
- Close every session with R-SR-09 (4 artifacts).
- MCP check: if n8n tool calls time out, report blocked and proceed to next executable item.

---
*S-179 Kickoff | GDA Command Platform | EIS / GDA OU3 | CONFIDENTIAL*
