# S-197 Kickoff — GDA Command Platform
**Date:** Next session after May 4, 2026
**Operator:** Claude (Anthropic)
**Platform:** GDA OU3 / Envision Innovative Solutions

---

## Session Open Protocol (MANDATORY)
1. `tool_search("n8n")` — load MCP context
2. Read this file
3. Execute top item from queue below without interrogating

---

## Platform State at S-196 Close
| Component | State |
|---|---|
| VPS 187.77.206.105 | ONLINE — stable |
| n8n.csr-llc.tech | ONLINE — 156+ active workflows |
| gda.csr-llc.tech | LIVE — React SPA 23 pages, all routing PASS |
| API Gateway | LIVE — systemd active :8788, nginx /api/ wired to 172.18.0.1:8788 |
| gda_win_loss_db | CREATED S-196 — 8 Won, 2 Lost records |
| AN-1 Win Themes | LIVE — patched, seeded, Telegram confirmed (msg 581) |
| QA fix-runner | ACTIVE — aAVitXXjGWaP7bb2 |
| Gist session-update | ACTIVE — 4bhVvKvVgLXcX6AZ |
| North Star | ~97% |

---

## S-197 Priority Queue

### **RANK 1 — Block E Hardening**
```
HP-4: Check saveDataSuccessExecution on all 156 workflows — flag any storing 'all' on success
HP-5: Confirm errorWorkflow: 2Swf6LP9AzFjHFYU set on all 6 remaining cron workflows
HP-7: SSH: verify nginx rate limiting completeness (limit_req_zone + limit_req in nginx.conf)
```

### **RANK 2 — React Coverage Re-run**
```
Run coverage report against live app — all 4 prior failures (Intel Feed, Deep Research,
Proposal Factory, Financial Bible) were resolved S-195.
Expected result: 23/23 passing.
Use QA fix-runner or SSH curl to trigger the coverage check.
```

### **RANK 3 — AN-1 Learning Engine Calibration**
```
Verify gda_learned_weights table has updated rows from AN-1 seed run.
Check if pwin-calculator workflow loads from learned weights.
If not wired: patch pwin-calculator to read from gda_learned_weights before scoring.
```

---

## DO NOT RE-AUDIT (Block D — CLOSED)
| Workflow | ID | Verdict |
|---|---|---|
| weekly-comp-scan | uQ5cZ97cCrx5iIXk | FIXED |
| morning-briefing-v1 | YIvCdrOgF1LGmFNL | VERIFIED |
| nightly-fy-revenue-calc | EGQzp92GxbjTJ03X | VERIFIED |
| data-retention | LzjiBI80aDAZgDIp | VERIFIED |
| e2e-gemini-report | BLS36QTOznJ8mJlC | VERIFIED |
| dept-opp-sweep | JRnWGEH9cesb8f3w | VERIFIED |

---

## Key Credentials (S-196 canonical — unchanged)
```
x-gda-key:                gda-api-2027-AWqjhbxDYNcyV1mr
GDA Webhook Auth cred:    fTrhOzBkjS1s67bm  (primary)
GDA Webhook Auth cred:    1pNPY36DDz49OtKL  (alternate — SSH workflow uses this)
VPS SSH Key cred:         NKOxLo5F81sRNPua
Telegram cred:            Jr8OOsZqc9DarQE6  (GDA Telegram Bot)
Postgres cred:            HwronxMmGY5XDGEt  (GDA Postgres)
GitHub Gist PAT:          sKJFLNzetK86JnvO
QA Agent key:             qa-agent-test-2026-adlkjfn7987-srkigio-99-eatshit
```

## Key Workflow IDs (S-196 — no changes except AN-1 patched)
```
AN-1 Win Themes:          yMo7WrELV8JVOi2M  (ACTIVE — patched S-196, Telegram confirmed)
QA fix-runner:            aAVitXXjGWaP7bb2  (ACTIVE)
Gist session-update:      4bhVvKvVgLXcX6AZ  (ACTIVE)
SSH Exec:                 IcD4K740vpWSIuaZ   (versionCounter 685)
Deploy:                   8GnGxnBL9TJjj1i2
Dashboard-mega:           UYGJPu7N5YZblvEU
opp-tracker 2:            SEJLE89wZa1yfQyB   (CANONICAL)
ooda-loop 2:              pkPpMhiz8IdRy7To   (CANONICAL)
Morning briefing:         YIvCdrOgF1LGmFNL   (VERIFIED — Block D)
comp-intel 2:             geW4zw6lvkkizF82   (Auth Guard patched S-194)
weekly-comp-scan:         uQ5cZ97cCrx5iIXk   (FIXED S-194)
```

## DB State (S-196 canonical)
```
gda_win_loss_db:          CREATED — 8 Won / 2 Lost
gda_opportunity_tracker:  1344 rows (stages: No-Bid 866, No-Go 222, Qualified 132, Identified 124)
gda_learned_weights:      Seeded by AN-1 (5 factors: incumbent_displacement, agency_relationship,
                           teaming_strength, naics_alignment, past_performance)
```

## Hard Rules (S-196 canonical — unchanged)
- Switch node → broken → use IF or Code nodes
- LangChain cred d92MU0tRK7bEGV83 → permanently broken → HTTP + $env.ANTHROPIC_API_KEY
- Postgres typeVersion 2.5/2.6 → inline `{{ $json.field }}` in SQL; no queryValues
- App.jsx writes → UTF-8 only; backup at /opt/gda-command/src/App.jsx.bak-s158-kpi
- Deploy: vite build → cp -r dist/. /root/gda-frontend/dist/ → docker exec nginx -s reload
- N8N_ENCRYPTION_KEY → must persist in /root/n8n-envision/.env
- SSH Guard allows: bash -c, python3, cat, grep, sed, tee, tail, find, ls, systemctl, curl, nginx
- Code nodes: use native fetch() — never $helpers.httpRequest (CODE-01)
- RR-38 and RR-28 are RESOLVED — do not reference as frozen
- Canonical opp table: gda_opportunity_tracker; PURSUE label: gda_label = 'PURSUE'
- Canonical active pipeline: stage NOT IN ('No-Bid','Cancelled','No-Go','Lost','Won')
- Top-level defense department: Department of War (not Department of Defense)
- MCP prefix: fuck-this-shit: for all n8n management calls
- SSH bulk inserts: use base64 Python script pattern (heredoc unreliable in bash -c)
- Postgres ARRAY syntax: ARRAY['a','b'] not {a,b} when passing via psql -c argument

---

## North Star Gap (post S-196)
| Remaining | Effort |
|---|------|
| Block E Hardening | S-197 Rank 1 — HP-4/HP-5/HP-7 |
| React Coverage Re-run | S-197 Rank 2 — confirm 23/23 |
| AN-1 Learning Engine | S-197 Rank 3 — verify pwin-calculator wired to learned weights |

Platform is ~97% of North Star. All substantive functional gaps are now hardening and verification items.

---
*Generated by R-SR-09 close protocol at end of S-196 — May 4, 2026*
