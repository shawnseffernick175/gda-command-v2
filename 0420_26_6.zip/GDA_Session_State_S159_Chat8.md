# GDA Command Platform — Session State
**Last Updated:** S-159 Chat 8 — April 20, 2026
**Operator:** Shawn Seffernick, President, Envision Innovative Solutions (OU3)

---

## Pre-Flight (Every Chat)
1. `tool_search("n8n")` — load MCP
2. Read this file
3. **RR-38 and RR-28 are FROZEN** — do not touch ever

---

## FIRST ACTION NEXT CHAT
Auth fix deployed. Start with I-1 (Intel Feed 0 results) — pull gda-intel-feed workflow and fix. Then D-1, A-2, L-2 in order. See full backlog in Master Build xlsx.

---

## CRITICAL: Auth Header
**Correct header is `x-gda-key: gda-api-2026-secure`** — NOT x-gda-auth.
Confirmed by curl test. Fixed in: gda.jsx AUTH constant, E2E checker HEADERS object.

## CRITICAL: App.jsx encoding rule
**Always write App.jsx with UTF-8 encoding.**

## Deploy pattern
`{"mode": "build_only", "msg": "description"}` → deploy webhook → builds + copies + restarts container.
Deploy webhook RR-44 workaround: set auth to none → fire → restore headerAuth.

## SSH Read Note
ssh-read-file expects `body.command` or `body.cmd`. Docker Postgres: `n8n-envision-postgres-1`.
DB patch pattern: write JSON to /tmp, docker cp into container, psql with pg_read_file.

---

## Platform State

| Item | Status |
|---|---|
| Active workflows | ~151 |
| Frontend (gda.csr-llc.tech) | LIVE — S-159C8 build deployed |
| Auth header | FIXED — x-gda-key in gda.jsx + E2E checker |
| Intel Feed | BROKEN — 0 results (I-1) |
| Deep Research | BROKEN — auth error (D-1, verify fix) |
| AI Agent history | BROKEN — v.map crash (A-2) |
| Top Opps table | BROKEN — no rows (L-2) |
| E2E checker | Auth fixed — x-gda-key in HEADERS |
| weekly-comp-scan | FIXED — queryReplacement removed |
| embed-and-store | FIXED S-159C7 |
| Vector store | SEEDED — 94 plans |
| Morning Brief | FIXED endpoint/renderer |
| All cron workflows | ACTIVE |

---

## Key Workflow IDs

| Workflow | ID |
|---|---|
| GDA.dev.deploy | 8GnGxnBL9TJjj1i2 |
| GDA.api.daily-actions | C7Bh7KcAl1IgSTRr |
| GDA.api.action-history | 1OPkoA5e8DYVQKm1 |
| GDA.intel.morning-briefing-v1 | YIvCdrOgF1LGmFNL |
| GDA.api.morning-briefing (read) | 0zVPgmYsvcqhyyo6 |
| GDA.api.dashboard-mega | UYGJPu7N5YZblvEU |
| GDA.api.opp-tracker 2 | SEJLE89wZa1yfQyB |
| GDA.api.capture-plan | QgperN6cuOpfnb09 |
| GDA.api.platform-health | UBgoJGxZro834RbT |
| GDA.util.ssh-read-file | IcD4K740vpWSIuaZ |
| GDA.api.embed-and-store | yA4NHeu0ctVVxzYg |
| GDA.api.intel-feed | KIT8cj4V2cMFdSkA |
| GDA.auto.e2e-gemini-report | BLS36QTOznJ8mJlC |
| GDA.cron.weekly-comp-scan | uQ5cZ97cCrx5iIXk |

---

## Open Debt (Priority Order)

| ID | Sev | Summary |
|---|---|---|
| I-1 | HIGH | Intel Feed 0 results — backend broken |
| D-1 | HIGH | Deep Research 403 auth error |
| A-2 | HIGH | AI Agent history v.map crash |
| L-2 | HIGH | Top Opps table — no rows |
| O-4 | HIGH | Dropdowns default closed — requested repeatedly |
| O-1 | HIGH | Numbers inconsistent platform-wide |
| A-1 | HIGH | AI Agent missing GDA platform context |
| S-7 | HIGH | Morning Brief empty — RSS not pulling real data |
| AN-1 | HIGH | Real analysis: incumbent, win themes, what it takes to win |
| AN-2 | HIGH | Ingest competitive intel from internet |
| L-1 | MED | KPI numbers don't match capture plan |
| L-3 | MED | 63 overdue opps never auto-moved to Pass |
| L-4 | MED | Qualified bar chart text invisible |
| L-5 | MED | Capture Plan Stages right side empty |
| L-6 | MED | Deadline list no dollar value no analysis |
| L-7 | MED | GovTribe links 404 |
| L-8 | MED | SITREP not auto-generated |
| L-9 | MED | Predictive analysis empty |
| L-10 | MED | Action items <30d should auto-Pass |
| S-1 | MED | World News no sources one sentence filler |
| S-2 | MED | DoD News source links to Launchpad |
| S-3 | MED | Other Dept News all filler |
| S-4 | MED | Acquisition News recycled stats |
| S-5 | MED | Opportunities/Risks cards duplicate Launchpad |
| S-6 | MED | Merge Morning Brief + SITREP |
| I-2 | MED | Intel Feed history renders blank |
| D-2 | MED | Deep Research history empty |
| C-1 | MED | Comp Intel — opening one card expands whole row |
| C-2 | MED | Comp Intel — no so-what vs GDA |
| C-3 | MED | Comp Intel — no threat mapping per agency |
| C-4 | MED | Comp Intel — data static needs daily update |
| C-5 | MED | Comp Intel — missing INSCOM/TRADOC/PEO Soldier/PEO STRI/APG/Army Futures/Fort Liberty |
| C-6 | MED | Comp Intel — no AI threat narrative |
| N-1 | MED | Merge Wargame + Incumbent + Teaming → Bid Strategy |
| O-2 | MED | Opp Tracker sub-rows missing columns |
| O-7 | MED | NDAA Intel placeholder needs real ingestion |
| P-1 | MED | Claude never ran smoke test as directed |
| O-3 | LOW | Remove Unassigned category |
| O-5 | LOW | Department of War wrong name |
| O-6 | LOW | IDIQ vehicles duplicated |
| RR-43 | LOW | Bot dual-routing |
| RR-44 | LOW | headerAuth 403 workaround |
| RR-38 | FROZEN | Do not touch |
| RR-28 | FROZEN | Do not touch |

---

## Rules
- Claude executes everything via MCP. Never tell Shawn to manually do things.
- RR-38 and RR-28 are FROZEN. Do not touch.
- Correct auth: `x-gda-key: gda-api-2026-secure`
- Anthropic API: direct HTTP with $env.ANTHROPIC_API_KEY — LangChain d92MU0tRK7bEGV83 BROKEN
- Postgres inline template rule: `{{ $json.field }}` inline — never queryValues/queryReplacement at typeVersion 2.5/2.6
- Switch node broken — use IF or Code
- No filler content anywhere in this platform

## Schema (Canonical)
- gda_morning_briefings.briefing = plain markdown TEXT
- deadline-escalation writes to `risk_register`
- embed-and-store outbound: header `x-gda-auth: gda-deploy-2026-secure`
- capture-plan Postgres nodes use `queryValues` arrays
