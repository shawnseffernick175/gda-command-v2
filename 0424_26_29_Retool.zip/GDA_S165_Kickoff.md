# GDA Command Platform — S-165 Kickoff

**Last session:** S-164 — April 24, 2026
**Operator:** Shawn Seffernick, President EIS/GDA OU3
**Platform:** Retool — gdacommand.retool.com

---

## Pre-Flight (Every Chat)
1. tool_search("n8n") — load MCP
2. Read this file
3. RR-38 and RR-28: UNFROZEN — Shawn released this session

---

## FIRST ACTION NEXT CHAT

**S-164-01 (Med) — Launchpad KPIs showing $0 across all fields**

getMegaDash n8n workflow is confirmed working — returns full payload (213 opps, $2.3B pipeline). But Launchpad page KPIs all show 0 after Refresh. Root cause: Retool launchpadPage field path bindings don't match the new payload shape.

**Steps next session:**
1. Retool editor → launchpadPage → inspect getMegaDash response shape
2. Check what field paths KPI stat components bind to (e.g. {{getMegaDash.data.stats.pipeline_value}})
3. Patch broken bindings to match confirmed payload shape
4. Proceed to S-162-02 E2E test all 25 pages

---

## What Was Done S-164

### S-163-01: getMegaDash CLOSED
9 root cause bugs fixed in GDA.api.dashboard-mega (UYGJPu7N5YZblvEU):
- Check Cache returned 0 rows on MISS → rewrote to LEFT JOIN dummy row
- IF node typeVersion 1 null-handling → upgraded to typeVersion 2
- gda_intelligence_log ORDER BY created_at → fixed to timestamp
- gda_aop_kpi table doesn't exist → removed
- gda_morning_briefings.summary doesn't exist → fixed to briefing AS summary
- gda_opportunity_tracker.pwin → NULL AS "PWin"
- Write Cache Mustache on JSON payload (RR-42 pattern) → dollar-quoting
- KPI/Briefing parallel branch timing → folded into single Query All
- alwaysOutputData on IF caused double-routing → removed

Verified live: 213 opps, $2.3B pipeline, 103 PURSUE, today's Breaking Defense headlines. dashboard-mega versionCounter ~440.

### RR-38 / RR-28: UNFROZEN per Shawn this session.

---

## Open Debt

| ID | Sev | Summary |
|---|---|---|
| S-164-01 | Med | Launchpad KPIs $0 — binding mismatch on launchpadPage |
| S-162-02 | Low | E2E 25 pages — Dashboard PASS, Launchpad FAIL, 23 untested |
| RR-43 | Low | Bot dual-routing — fix when telegram-chat touched |
| RR-36 | Med | Chrome MCP cross-origin — workaround in place |
| RR-44 | Low | Webhook headerAuth workaround documented |

---

## getMegaDash Confirmed Payload Shape

```
{status, cached_at, funnel[], risks[], stats{total_opps, pursue, evaluate, won, pipeline_value, deadlines_14d}, trends[], contracts[], opps[], briefing{summary, headlines, generated_at}, sitrep{...}}
```

---

## Platform State

| Item | Status |
|---|---|
| Retool app | LIVE |
| getMegaDash | FIXED — full payload live |
| GDA.api.dashboard-mega | ACTIVE, 11 nodes, versionCounter ~440 |
| n8n | https://n8n.csr-llc.tech (v2.47.14) |
| Auth | x-gda-key: gda-api-2026-8ced0b75 |
| Active workflows | ~156 |

---

## Key Credentials / Workflow IDs

| Item | Value |
|---|---|
| GDA webhook auth cred | fTrhOzBkjS1s67bm |
| VPS SSH cred | VqYFb1aRGJa8UfBc |
| GDA.api.dashboard-mega | UYGJPu7N5YZblvEU |
| GDA.dev.deploy | 8GnGxnBL9TJjj1i2 |
| GDA.bot.telegram-chat | 1ItrrFxGI3L43Pdv |
| GDA.intel.morning-briefing-v1 | YIvCdrOgF1LGmFNL |
| GDA.api.capture-plan | QgperN6cuOpfnb09 |
| GDA.util.ssh-read-file | IcD4K740vpWSIuaZ |
| GDA.api.opp-tracker 2 | SEJLE89wZa1yfQyB |

---

## Platform Rules

- Claude executes via MCP only.
- RR-38 and RR-28: UNFROZEN.
- End every session: R-SR-09 (4 artifacts).
- Webhook auth workaround (RR-44): temp set to none, fire, restore.
- Never queryReplacement at typeVersion 2.5/2.6.
- Switch node broken — use IF nodes.
- LangChain cred d92MU0tRK7bEGV83: BROKEN.
- gda_intelligence_log time column: timestamp.
- gda_morning_briefings columns: briefing, model, input_tokens, output_tokens, headlines, generated_at.
- gda_opportunity_tracker: no pwin column.
- gda_aop_kpi table does NOT exist.
