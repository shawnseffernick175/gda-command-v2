# GDA Command Platform — Session State
**Last Updated:** S-159 Chat 7 — April 20, 2026
**Operator:** Shawn Seffernick, President, Envision Innovative Solutions (OU3)

---

## Pre-Flight (Every Chat)
1. `tool_search("n8n")` — load MCP
2. Read this file
3. **RR-38 and RR-28 are FROZEN** — do not touch ever

---

## FIRST ACTION NEXT CHAT
RR-63 still open. Browser DevTools stack trace needed — ask Shawn to open Platform Health tab, open DevTools console, capture the exact React error stack. If stack trace is provided, fix the specific line. Otherwise proceed to weekly-comp-scan ($2 queryReplacement fix) as it's actionable now.

---

## CRITICAL: App.jsx encoding rule
**Always write App.jsx with UTF-8 encoding.**

## Deploy pattern
`{"mode": "build_only", "msg": "description"}` → deploy webhook → builds + copies + restarts container.

## SSH Read Note
ssh-read-file expects `body.command` or `body.cmd` — NOT `body.file`. Docker Postgres container: `n8n-envision-postgres-1`, user: `$POSTGRES_USER`, db: `$POSTGRES_DB`.

---

## Platform State

| Item | Status |
|---|---|
| Active workflows | ~151 |
| Frontend (gda.csr-llc.tech) | LIVE — fresh build deployed S-159C7 |
| **Vector store** | ✅ SEEDED — 94 capture plans embedded S-159C7 |
| **embed-and-store** | ✅ FIXED S-159C7 — queryReplacement removed, inline templates live. versionId: af4681c7 |
| **intel-feed** | ✅ FIXED S-159C7 — Write to Intelligence Log inline |
| **Platform Guide / Platform Health** | ⚠️ RR-63 — React #300 still reported. Build is clean. Browser stack trace needed. |
| Platform Health E2E | ⚠️ 32 FAIL — E2E checker uses wrong auth. Not a real outage. |
| Morning Brief | FIXED — endpoint, response key, date, renderer. b9262cd. |
| GDA.api.daily-actions | ACTIVE — Switch→IF + Write Cache inline + Save Actions inline. |
| GDA.api.action-history | FIXED — RR-62: Save Action SQL corruption. |
| GDA.api.capture-plan | ACTIVE — RR-42+RR-55+RR-56+RR-57-B1 FIXED |
| GDA.cron.auto-capture-plan | ACTIVE — schedule 10 */4 * * * |
| GDA.cron.auto-opp-analysis | ACTIVE — schedule 5,35 * * * * |
| GDA.cron.deadline-escalation | ACTIVE — table name corrected |
| GDA.cron.nightly-fy-revenue-calc | ACTIVE — direct Postgres calc |
| All other workflows | ACTIVE |

---

## RR-63 Platform Guide/Health Status
- Build confirmed clean S-159C7: 676 modules, 0 errors
- PlatformGuidePage.jsx, PlatformHealthPage.jsx, IntelFeedPage.jsx all reviewed — no static object-as-child bug found
- Fresh build+copy+docker restart executed
- If crash persists: open DevTools → Platform Health tab → capture exact stack trace line → fix runtime data issue

---

## weekly-comp-scan Fix (Ready to Execute)
- Workflow: `GDA.cron.weekly-comp-scan` (ID: `uQ5cZ97cCrx5iIXk`)
- Bug: queryReplacement with $2 positional — same pattern as RR-42
- Fix: switch to inline `{{ }}` template expressions
- Low priority — fix on next cron touch or when convenient

---

## Key Workflow IDs

| Workflow | ID |
|---|---|
| GDA.dev.deploy | 8GnGxnBL9TJjj1i2 |
| GDA.api.daily-actions | C7Bh7KcAl1IgSTRr |
| GDA.api.action-history | 1OPkoA5e8DYVQKm1 |
| GDA.intel.morning-briefing-v1 | YIvCdrOgF1LGmFNL |
| GDA.api.morning-briefing (read) | 0zVPgmYsvcqhyyo6 |
| GDA.api.dashboard-mega | UYGJPu7N5YZblvEU |
| GDA.api.opp-tracker 2 | SEJLE89wZa1yfQyB |
| GDA.api.capture-plan | QgperN6cuOpfnb09 |
| GDA.api.platform-health | UBgoJGxZro834RbT |
| GDA.util.ssh-read-file | IcD4K740vpWSIuaZ |
| GDA.api.embed-and-store | yA4NHeu0ctVVxzYg |
| GDA.api.intel-feed | KIT8cj4V2cMFdSkA |
| GDA.oneshot.embed-capture-plans | alHJibzND41T6p93 |
| GDA.cron.auto-capture-plan | 7gERqvfD6THg1gWf |
| GDA.cron.auto-opp-analysis | IGw8FBZhZwnwiIe1 |
| GDA.cron.deadline-escalation | Qg55lRKjubgsvD28 |
| GDA.cron.nightly-fy-revenue-calc | EGQzp92GxbjTJ03X |
| GDA.cron.learning-engine | fZpqchmmPnqAmiMq |
| GDA.cron.weekly-comp-scan | uQ5cZ97cCrx5iIXk |

---

## Open Debt

| ID | Sev | Summary |
|---|---|---|
| RR-63 | Med | Platform Health/Guide: React #300. Build clean. Need browser DevTools stack trace to find runtime cause. |
| weekly-comp-scan | Low | queryReplacement $2 bug — fix when near cron work |
| RR-57-B2 | Low | Sidebar dropdowns — retest |
| RR-36 | Med | Chrome MCP cross-origin — workaround in place |
| RR-43 | Low | Bot dual-routing double-fire |
| RR-44 | Low | n8n_test_workflow 403 on headerAuth |
| RR-38 | FROZEN | Do not touch |
| RR-28 | FROZEN | Do not touch |

---

## Schema (Canonical)
- Anthropic API: direct HTTP with $env.ANTHROPIC_API_KEY — LangChain d92MU0tRK7bEGV83 BROKEN
- Postgres inline template rule: ALL nodes use `{{ $json.field }}` inline — never queryValues/queryReplacement at typeVersion 2.5/2.6
- Switch node broken — use IF or Code
- gda_morning_briefings.briefing = plain markdown TEXT
- deadline-escalation writes to `risk_register` (NOT gda_risk_register)
- Risk register: 247 risks are legitimate — 241 from auto-risk-cron, 6 from deadline-escalation
- gda.jsx AUTH constant has no X-GDA-Key — most endpoints pass via origin-check in Auth Guard
- embed-and-store outbound calls must use header `x-gda-auth: gda-deploy-2026-secure`
