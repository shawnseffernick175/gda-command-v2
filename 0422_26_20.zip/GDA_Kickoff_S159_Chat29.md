# GDA Command Platform — Session S-159 Chat 29 Kickoff
**Prepared:** April 22, 2026 15:10 UTC  
**Next Session:** S-159 Chat 29  
**Build:** v157.28

---

## FIRST ACTION NEXT CHAT
`tool_search("n8n")` → read this file → **RR-38 and RR-28 are FROZEN**

---

## Top Priority Queue

### 🟢 TOP — O-2: OppTracker Sub-rows
- **Workflow:** `SEJLE89wZa1yfQyB` (GDA.api.opp-tracker 2)
- **Fields to expose:** `incumbent_analysis`, `likely_competitors`, `eligible_vehicles`
- **Task:** Expandable row component in React frontend (DeepResearchPage pattern for reference)
- **Access:** SSH read via `IcD4K740vpWSIuaZ`
- **Est:** 4 hours

### 🟡 MEDIUM — P-1: Platform Smoke Test
- Create n8n workflow testing key API endpoints
- Est: 2 hours

---

## What Changed This Session (S-159 C28)

| Fix | Detail |
|---|---|
| D-2 COMPLETE | GDA.research.deep-research Success Response node patched. Added `report` (full object), `sources_used`, `follow_up_queries` to response. Frontend competitive intel / capture implications / key findings sections now render. versionCounter 87. |

---

## Deploy Pattern (confirmed working)

Fire via `n8n_test_workflow` to `IcD4K740vpWSIuaZ` (ssh-read-file):
```json
{"cmd": "printf '%s' '<b64>' | base64 -d > /tmp/p.py && python3 /tmp/p.py && rm /tmp/p.py && cd /opt/gda-command && printf '/* /index.html 200' > public/_redirects && PATH=/root/.nvm/versions/node/v20.20.0/bin:$PATH npm run build 2>&1 | tail -8 && cp -r dist/. /root/gda-frontend/dist/ && docker restart n8n-envision-gda-frontend-1 && echo DEPLOY_COMPLETE"}
```

---

## Platform State

| Item | Status |
|---|---|
| Active workflows | ~151 |
| Frontend | LIVE — gda.csr-llc.tech |
| Bid Strategy tab | LIVE — Wargame / Incumbent Analysis / Teaming Finder |
| Deep Research | LIVE — full report now returned, all sections render |
| GDA.util.ssh-read-file | ACTIVE — IcD4K740vpWSIuaZ |
| GDA.dev.deploy | ACTIVE — 8GnGxnBL9TJjj1i2 |
| Morning briefing | LIVE — YIvCdrOgF1LGmFNL |

---

## Key Workflow IDs

| Workflow | ID |
|---|---|
| GDA.dev.deploy | 8GnGxnBL9TJjj1i2 |
| GDA.util.ssh-read-file | IcD4K740vpWSIuaZ |
| GDA.api.opp-tracker 2 | SEJLE89wZa1yfQyB |
| GDA.research.deep-research | q9YWVQCwnJGqmrO7 |
| GDA.intel.morning-briefing-v1 | YIvCdrOgF1LGmFNL |
| GDA.api.capture-plan | QgperN6cuOpfnb09 |
| GDA.bot.telegram-chat | 1ItrrFxGI3L43Pdv |

---

## Open Debt

| ID | Sev | Summary |
|---|---|---|
| D-2 | CLOSED | Deep Research full report response — FIXED S-159 C28 |
| O-2 | Ready | OppTracker sub-rows — next priority |
| P-1 | Med | Platform smoke test |
| RR-36 | Med | Chrome MCP cross-origin workaround in place |
| RR-43 | Low | Bot dual-routing fix pending |
| RR-44 | Low | headerAuth test workaround documented |
| RR-38 | FROZEN | Do not touch |
| RR-28 | FROZEN | Do not touch |

---

## Rules

- Claude executes everything via MCP. Never tell Shawn to manually do things.
- RR-38 and RR-28 are FROZEN
- Postgres nodes: queryValues arrays only, never string interpolation
- Bot rollback: n8n_workflow_versions(mode=rollback, workflowId=1ItrrFxGI3L43Pdv) to v4
- App.jsx is ~413KB — use base64 patch script pattern for all edits
- Switch node is broken — use IF nodes or Code nodes for routing
- LangChain cred d92MU0tRK7bEGV83 BROKEN — use direct HTTP with $env.ANTHROPIC_API_KEY
