# GDA Command Platform — S-169 Kickoff
**Session:** S-169 Chat 1
**Date:** Next session after April 25, 2026
**Operator:** Shawn Seffernick, EIS/GDA OU3
**Mode:** Pure-MCP
**Master Build:** v168

---

## Pre-Flight Checklist
1. `tool_search("n8n")` — load MCP toolset
2. Read this file
3. **RR-38 and RR-28 are FROZEN** — do not touch ever

---

## FIRST ACTION NEXT CHAT

**Fix Competitive Intel before anything else.**

In Retool editor → Competitive Intel page → click `getCompetitorIntel` query tab → replace SQL with:
```sql
SELECT id, competitor_name, agency, contract_vehicle, incumbent, strengths, weaknesses, updated_at
FROM gda_competitor_intel
ORDER BY updated_at DESC LIMIT 500
```
Save & Run. Confirm table shows correct columns.

Then proceed to build the 8 missing Retool pages in order:
1. OODA Loop
2. Opportunities (Opp Tracker)
3. PWin Calculator
4. Capture Plan
5. Email Drafter
6. Platform Health
7. Platform Guide
8. Admin CORS fix (health cards)

Each page must match React feature set and layout. Use Retool Assist with specific, targeted prompts. Wire to GDA Postgres where applicable.

---

## n8n API Key
- New key active as of S-168 C1
- Stored in `/root/n8n-envision/.env` as `N8N_API_KEY`
- MCP container: `n8n-envision-mcp-1`
- If MCP fails again: `cd /root/n8n-envision && docker compose up -d --force-recreate mcp`

---

## Open Debt

| ID | Sev | Summary |
|---|---|---|
| RETOOL-CI-1 | **HIGH** | Competitive Intel: fix getCompetitorIntel SQL — first action |
| RETOOL-BUILD | **HIGH** | 8 Retool pages need building to match React |
| RETOOL-02 | Low | Admin health cards CORS fix — gda-health webhook |
| REACT-MB | Med | Morning Brief: n8n returning empty JSON body |
| REACT-OT | Low | Opportunity Tracker 403 on data fetch |
| REACT-PG | Low | Platform Guide blank component |
| RR-36 | Med | Chrome MCP cross-origin — workaround in place |
| RR-43 | Low | Bot dual-routing — fix when telegram-chat next touched |
| RR-44 | Low | n8n_test_workflow 403 on headerAuth — workaround documented |
| RR-38 | FROZEN | Do not touch |
| RR-28 | FROZEN | Do not touch |

---

## Platform State

| Item | Status |
|---|---|
| n8n MCP | LIVE — new API key active |
| n8n workflows | ~156 active |
| React frontend | LIVE — gda.csr-llc.tech |
| Retool | LIVE — gdacommand.retool.com — 13 pages built, Competitive Intel wiring incomplete |
| GDA Postgres | LIVE — all 4 new tables created |

## Key Retool Info

| Item | Value |
|---|---|
| App URL | gdacommand.retool.com |
| App UUID | 9b2e8dbe-3f30-11f1-a98a-d30e2de07c9f |
| GDA Postgres resource | Connected as "GDA Postgres" |

## New Postgres Tables (created S-168 C1)
- `gda_competitor_intel` — id, competitor_name, agency, contract_vehicle, incumbent, strengths, weaknesses, updated_at
- `gda_meeting_notes` — id, title, meeting_date, attendees, meeting_type, notes, created_at
- `gda_risk_register` — id, opportunity_id, risk_description, likelihood, impact, mitigation, status, created_at
- `gda_proposal_sections` — id, opportunity_id, section_type, content, updated_at

## Key Workflow IDs (unchanged)
| Workflow | ID |
|---|---|
| GDA.dev.deploy | 8GnGxnBL9TJjj1i2 |
| GDA.util.ssh-read | IcD4K740vpWSIuaZ |
| GDA.api.capture-plan | QgperN6cuOpfnb09 |
| GDA.intel.morning-briefing-v1 | YIvCdrOgF1LGmFNL |

## Rules
- RR-38 and RR-28 FROZEN
- Postgres queryValues pattern — no queryReplacement
- Switch node broken — use IF nodes
- LangChain cred d92MU0tRK7bEGV83 BROKEN — use direct HTTP with $env.ANTHROPIC_API_KEY
- App.jsx write always UTF-8

*GDA Command Platform — S-169 Kickoff | v168 | April 25, 2026*
