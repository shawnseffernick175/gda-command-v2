/**
 * GDA Rebuild — Vite Config
 * S-002 | Phase 1
 *
 * Proxies /api/... requests from the Vite dev server (port 5173)
 * to the Express API server (port 3001).
 *
 * This means:
 * - React calls fetch('/api/financial/kpis') in the browser
 * - Vite forwards it to http://localhost:3001/api/financial/kpis
 * - No CORS issues in development
 * - No secrets ever touch the browser
 *
 * In production, the same proxy relationship is handled by your
 * deploy platform's reverse proxy (Render, Railway, nginx, etc.)
 */

import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

export default defineConfig({
  plugins: [react()],

  server: {
    port: 5173,
    proxy: {
      // Forward all /api/... calls to the Express server
      "/api": {
        target:      "http://localhost:3001",
        changeOrigin: true,
        secure:       false,
        // Log proxy hits in dev for visibility
        configure: (proxy) => {
          proxy.on("proxyReq", (_, req) => {
            console.log(`[vite proxy] ${req.method} ${req.url} → http://localhost:3001${req.url}`);
          });
          proxy.on("error", (err, req) => {
            console.error(`[vite proxy] ERROR on ${req.url}:`, err.message);
            console.error("  → Is the Express server running? (npm run dev in /api)");
          });
        },
      },
    },
  },

  build: {
    outDir:      "dist",
    sourcemap:   false,
    // Clean output on each build — prevents stale files surviving deploys
    emptyOutDir: true,
  },
});
