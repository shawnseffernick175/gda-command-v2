/**
 * GDA Rebuild — Financial Bible Page
 * S-006 | Phase 1
 *
 * PURPOSE
 * -------
 * Real Financial Bible page replacing the App-5.jsx placeholder.
 * Mounted at /financial-bible (with optional ?kpi=<key> query param).
 *
 * BEHAVIOR
 * --------
 * With ?kpi=<key>:
 *   - Focused view: named header, current value, prose description,
 *     contextual breakdown table — all from existing KPI context data.
 *   - "← All KPIs" link returns to /financial-bible (overview).
 *
 * Without ?kpi:
 *   - Overview grid of all 7 KPIs, each clickable to its detail view.
 *
 * DATA SOURCE
 * -----------
 * Reads exclusively from useKpi() (GDAKpiContext.jsx).
 * No new API calls. No new endpoints.
 * Works correctly in both KPI_USE_MOCK = true and false.
 *
 * S-006 CHANGES
 * -------------
 * - New file. Replaces FinancialBiblePlaceholder in App-5.jsx.
 * - Wired into App-6.jsx at /financial-bible route.
 *
 * REACT STAYS READ-ONLY
 * ---------------------
 * GET only (via shared KPI context). No writes. No dryRun:false. Ever.
 */

import { useKpi, KPI_KEYS } from "./GDAKpiContext.jsx";
import { GDAKpiStrip }      from "./GDAKpiContext.jsx";

// ─── KPI metadata catalogue ───────────────────────────────────────────────────
// Business-context descriptions for each KPI in the defense BD environment.
// Used by the focused drill-down view.
const KPI_META = {
  orders: {
    fullLabel:   "Orders",
    description: "Orders represent the total dollar value of contracts awarded to the business unit during the measurement period. In defense contracting, orders are booked when a contract is signed or a task order is issued — they are a leading indicator of future revenue and backlog health. A strong orders figure relative to sales indicates the pipeline is being converted and backlog is growing.",
    breakdown: [
      { label: "What it measures",   value: "Awarded contract value (new bookings) in the period" },
      { label: "Defense context",    value: "Includes CPFF, FFP, T&M, and IDIQ task orders at award" },
      { label: "Leads or lags",      value: "Leading — awards precede revenue recognition by weeks to months" },
      { label: "Healthy signal",     value: "Orders ≥ Sales (book-to-bill ≥ 1.0) sustains backlog" },
      { label: "Watch for",          value: "Large single awards can spike the number; look at trailing 12-month trend" },
    ],
  },
  sales: {
    fullLabel:   "Sales (Revenue)",
    description: "Sales is recognized revenue — the amount earned during the period as work is performed on active contracts. In defense contracting this is driven by cost incurrence on cost-type contracts and deliverable acceptance on fixed-price work. Sales is the primary top-line metric and the denominator for ROS.",
    breakdown: [
      { label: "What it measures",   value: "Revenue recognized from active contract performance" },
      { label: "Defense context",    value: "Cost-type: recognized as costs incurred. FFP: recognized on deliverable milestones" },
      { label: "Leads or lags",      value: "Coincident — reflects current execution velocity" },
      { label: "Healthy signal",     value: "Steady or growing sales with stable ROS" },
      { label: "Watch for",          value: "Revenue gaps from CR periods, stop-work orders, or slow ramp-ups" },
    ],
  },
  ebit: {
    fullLabel:   "EBIT (Earnings Before Interest & Tax)",
    description: "EBIT is the operating profit of the business — sales minus cost of sales and overhead, before interest and taxes. In defense contracting, EBIT is the primary profitability measure because it reflects program execution discipline, overhead control, and bid accuracy. It is watched closely by program managers and finance leadership.",
    breakdown: [
      { label: "What it measures",   value: "Operating profit: Sales − COGS − SG&A" },
      { label: "Defense context",    value: "Includes fee earned on cost-type contracts and margin on FFP" },
      { label: "Leads or lags",      value: "Coincident — reflects the current period's execution quality" },
      { label: "Healthy signal",     value: "EBIT positive and consistent with bid margins" },
      { label: "Watch for",          value: "EAC headwinds, cost overruns on FFP, or under-recovery on overhead pools" },
    ],
  },
  ros: {
    fullLabel:   "ROS (Return on Sales)",
    description: "ROS is EBIT divided by Sales, expressed as a percentage. It measures how much profit the business generates per dollar of revenue. In defense contracting, ROS benchmarks vary by contract type — cost-plus programs typically run 7–12%, while well-executed FFP programs can exceed 15%. ROS is a primary performance indicator for OU-level reporting.",
    breakdown: [
      { label: "What it measures",   value: "EBIT ÷ Sales × 100 (%)" },
      { label: "Defense context",    value: "Cost-type: fee rate + indirect recovery. FFP: bid margin minus execution variance" },
      { label: "Leads or lags",      value: "Coincident — reflects combined revenue and profitability in the period" },
      { label: "Healthy signal",     value: "ROS at or above bid target; trending stable quarter-over-quarter" },
      { label: "Watch for",          value: "ROS compression from overhead under-recovery or FFP cost growth" },
    ],
  },
  funded_backlog: {
    fullLabel:   "Funded Backlog",
    description: "Funded backlog is the dollar value of work already contracted and funded that has not yet been recognized as revenue. It represents firm, executable work — the most reliable near-term revenue indicator. In defense, funded backlog comes from appropriated dollars obligated on contract; it can burn off quickly in a continuing resolution environment.",
    breakdown: [
      { label: "What it measures",   value: "Obligated contract value not yet converted to revenue" },
      { label: "Defense context",    value: "Only includes funded CLINs; excludes unexercised options and unfunded IDIQs" },
      { label: "Leads or lags",      value: "Leading — funded backlog converts to sales over the execution period" },
      { label: "Healthy signal",     value: "Funded backlog ≥ 12 months of run-rate sales gives high revenue confidence" },
      { label: "Watch for",          value: "Rapid burn without replenishment; CR-driven funding gaps on multi-year programs" },
    ],
  },
  backlog: {
    fullLabel:   "Total Backlog",
    description: "Total backlog includes all contracted but unearned revenue — both funded and unfunded (options, IDIQs, ceiling values). It is the broadest measure of contracted work and reflects the potential revenue stream if all options are exercised. In defense BD, total backlog is a key indicator of long-term business health and capture health.",
    breakdown: [
      { label: "What it measures",   value: "All contracted but unrecognized revenue (funded + unfunded options)" },
      { label: "Defense context",    value: "Includes IDIQ ceiling values, unexercised option years, and BOA ceiling" },
      { label: "Leads or lags",      value: "Long-leading — options may be 1–5 years away from execution" },
      { label: "Healthy signal",     value: "Total backlog growing; book-to-bill > 1.0 over trailing four quarters" },
      { label: "Watch for",          value: "Backlog dominated by a single program creates concentration risk" },
    ],
  },
  gross_profit: {
    fullLabel:   "Gross Profit",
    description: "Gross profit is sales minus direct program costs (labor, materials, subcontractors, ODCs) before overhead and G&A allocation. It measures raw program-level margin before the corporate cost structure is applied. Strong gross profit provides headroom to absorb overhead and still deliver healthy EBIT. It is the most direct signal of program execution quality.",
    breakdown: [
      { label: "What it measures",   value: "Sales − direct costs (labor, materials, subcontractors, ODCs)" },
      { label: "Defense context",    value: "Pre-overhead, pre-G&A; reflects raw bid-to-actual performance" },
      { label: "Leads or lags",      value: "Coincident — reflects current period direct cost performance" },
      { label: "Healthy signal",     value: "Gross profit consistently above overhead pool recovery requirement" },
      { label: "Watch for",          value: "Subcontractor cost growth or labor mix shift eroding direct margin" },
    ],
  },
};

// ─── Styles ───────────────────────────────────────────────────────────────────
const S = {
  page: {
    minHeight: "100vh",
    backgroundColor: "#f8fafc",
    fontFamily: "'Inter', 'Segoe UI', system-ui, sans-serif",
    color: "#1f2937",
  },
  // Secondary strip (tool-specific, below KPI strip)
  summaryStrip: {
    display: "flex",
    alignItems: "center",
    gap: 16,
    backgroundColor: "#ffffff",
    borderBottom: "1px solid #e2e8f0",
    padding: "10px 24px",
    overflowX: "auto",
  },
  stripLabel: {
    fontSize: 11,
    fontWeight: 700,
    color: "#64748b",
    textTransform: "uppercase",
    letterSpacing: "0.07em",
  },
  stripValue: {
    fontSize: 13,
    fontWeight: 600,
    color: "#0f172a",
  },
  stripDivider: {
    width: 1,
    height: 24,
    backgroundColor: "#e2e8f0",
    flexShrink: 0,
  },
  // Page header
  pageHeader: {
    padding: "20px 24px 0",
    display: "flex",
    alignItems: "flex-start",
    justifyContent: "space-between",
    flexWrap: "wrap",
    gap: 12,
    borderBottom: "1px solid #e2e8f0",
    paddingBottom: 16,
    backgroundColor: "#ffffff",
  },
  pageTitle: { fontSize: 22, fontWeight: 700, color: "#0f172a", margin: 0 },
  pageSubtitle: { fontSize: 13, color: "#64748b", marginTop: 4 },
  backLink: {
    fontSize: 13, color: "#0369a1", textDecoration: "none",
    display: "flex", alignItems: "center", gap: 4,
    cursor: "pointer", background: "none", border: "none",
    padding: 0, whiteSpace: "nowrap",
  },
  // Body content
  body: { padding: "24px" },
  // Overview grid
  overviewGrid: {
    display: "grid",
    gridTemplateColumns: "repeat(auto-fill, minmax(220px, 1fr))",
    gap: 16,
    marginTop: 8,
  },
  kpiCard: {
    backgroundColor: "#ffffff",
    border: "1px solid #e2e8f0",
    borderRadius: 10,
    padding: "18px 20px",
    cursor: "pointer",
    textDecoration: "none",
    display: "block",
    transition: "box-shadow 0.15s, border-color 0.15s",
  },
  kpiCardHover: {
    boxShadow: "0 2px 8px rgba(14,165,233,0.15)",
    borderColor: "#7dd3fc",
  },
  kpiCardLabel: {
    fontSize: 11, fontWeight: 700, color: "#64748b",
    textTransform: "uppercase", letterSpacing: "0.07em", marginBottom: 6,
  },
  kpiCardValue: {
    fontSize: 26, fontWeight: 700, color: "#0f172a", lineHeight: 1.1,
  },
  kpiCardCta: {
    fontSize: 11, color: "#0369a1", marginTop: 8,
  },
  // Detail view
  detailKpiValue: {
    fontSize: 36, fontWeight: 800, color: "#0f172a",
    letterSpacing: "-0.02em",
  },
  detailKpiLabel: {
    fontSize: 13, color: "#64748b", marginBottom: 4,
  },
  mockTag: {
    display: "inline-block",
    padding: "2px 8px",
    backgroundColor: "#fef9c3",
    border: "1px solid #fde68a",
    borderRadius: 10,
    fontSize: 10,
    fontWeight: 700,
    color: "#92400e",
    marginLeft: 10,
    verticalAlign: "middle",
    letterSpacing: "0.04em",
  },
  prose: {
    fontSize: 14,
    lineHeight: 1.7,
    color: "#374151",
    maxWidth: 680,
    marginTop: 16,
    marginBottom: 20,
  },
  breakdownCard: {
    backgroundColor: "#ffffff",
    border: "1px solid #e2e8f0",
    borderRadius: 10,
    overflow: "hidden",
    maxWidth: 680,
    marginTop: 4,
  },
  breakdownTitle: {
    fontSize: 11, fontWeight: 700, color: "#64748b",
    textTransform: "uppercase", letterSpacing: "0.07em",
    padding: "10px 16px",
    backgroundColor: "#f1f5f9",
    borderBottom: "1px solid #e2e8f0",
  },
  breakdownRow: {
    display: "flex",
    gap: 16,
    padding: "10px 16px",
    borderBottom: "1px solid #f1f5f9",
    fontSize: 13,
  },
  breakdownKey: { color: "#64748b", fontWeight: 600, minWidth: 160, flexShrink: 0 },
  breakdownVal: { color: "#0f172a", flex: 1, lineHeight: 1.5 },
  // Not found
  notFound: {
    margin: "24px",
    padding: 20,
    backgroundColor: "#fff7ed",
    border: "1px solid #fed7aa",
    borderRadius: 8,
    color: "#9a3412",
    fontSize: 13,
  },
  // Error
  errorBox: {
    margin: "24px",
    padding: 16,
    backgroundColor: "#fee2e2",
    borderRadius: 8,
    color: "#991b1b",
    fontSize: 13,
  },
};

// ─── Overview — all 7 KPIs ────────────────────────────────────────────────────
function FinancialOverview({ kpis, onSelectKpi }) {
  const [hovered, setHovered] = useState(null);

  return (
    <>
      <div style={{ marginBottom: 20 }}>
        <h2 style={{ fontSize: 16, fontWeight: 700, color: "#0f172a", margin: "0 0 4px" }}>
          Financial Overview
        </h2>
        <div style={{ fontSize: 13, color: "#64748b" }}>
          Click any KPI to see its definition, business context, and breakdown.
        </div>
      </div>

      <div style={S.overviewGrid}>
        {KPI_KEYS.map(key => {
          const meta = KPI_META[key] || {};
          const kpi  = kpis[key];
          const val  = kpi?.formatted ?? kpi?.value ?? (kpi != null ? String(kpi) : "—");
          const isH  = hovered === key;

          return (
            <button
              key={key}
              style={{ ...S.kpiCard, ...(isH ? S.kpiCardHover : {}), textAlign: "left", fontFamily: "inherit" }}
              onMouseEnter={() => setHovered(key)}
              onMouseLeave={() => setHovered(null)}
              onClick={() => onSelectKpi(key)}
              aria-label={`View ${meta.fullLabel || key} detail`}
            >
              <div style={S.kpiCardLabel}>{meta.fullLabel || key}</div>
              <div style={S.kpiCardValue}>{val}</div>
              <div style={S.kpiCardCta}>View breakdown →</div>
            </button>
          );
        })}
      </div>
    </>
  );
}

// ─── Detail — single KPI drill-down ──────────────────────────────────────────
function KpiDetail({ kpiKey, kpis, onBack }) {
  const meta = KPI_META[kpiKey];
  const kpi  = kpis?.[kpiKey];
  const val  = kpi?.formatted ?? kpi?.value ?? (kpi != null ? String(kpi) : "—");

  if (!meta) {
    return (
      <div style={S.notFound}>
        <strong>Unknown KPI:</strong> "<code>{kpiKey}</code>" is not a recognised financial KPI key.
        <div style={{ marginTop: 8 }}>
          <button style={{ ...S.backLink, display: "inline-flex" }} onClick={onBack}>
            ← Back to Financial Overview
          </button>
        </div>
      </div>
    );
  }

  return (
    <>
      {/* Back link */}
      <div style={{ marginBottom: 20 }}>
        <button style={S.backLink} onClick={onBack}>
          ← All KPIs
        </button>
      </div>

      {/* KPI hero value */}
      <div style={{ marginBottom: 4 }}>
        <div style={S.detailKpiLabel}>{meta.fullLabel}</div>
        <div>
          <span style={S.detailKpiValue}>{val}</span>
          <span style={S.mockTag}>
            {/* KPI_USE_MOCK imported indirectly via context; label driven by data shape */}
            {kpi?.raw != null ? "current period" : "mock"}
          </span>
        </div>
      </div>

      {/* Prose description */}
      <p style={S.prose}>{meta.description}</p>

      {/* Breakdown table */}
      {meta.breakdown && (
        <div style={S.breakdownCard}>
          <div style={S.breakdownTitle}>Breakdown &amp; Context</div>
          {meta.breakdown.map((row, i) => (
            <div
              key={row.label}
              style={{
                ...S.breakdownRow,
                backgroundColor: i % 2 === 0 ? "#ffffff" : "#f8fafc",
                borderBottom: i < meta.breakdown.length - 1 ? "1px solid #f1f5f9" : "none",
              }}
            >
              <div style={S.breakdownKey}>{row.label}</div>
              <div style={S.breakdownVal}>{row.value}</div>
            </div>
          ))}
        </div>
      )}

      {/* Cross-links to adjacent KPIs */}
      <div style={{ marginTop: 24, fontSize: 12, color: "#64748b" }}>
        <strong>Other KPIs: </strong>
        {KPI_KEYS.filter(k => k !== kpiKey).map((k, i) => (
          <span key={k}>
            {i > 0 && " · "}
            <button
              style={{ ...S.backLink, display: "inline", fontSize: 12 }}
              onClick={() => {
                const url = new URL(window.location.href);
                url.searchParams.set("kpi", k);
                window.history.pushState({}, "", url.toString());
                // Force re-render by triggering a popstate-like effect
                window.dispatchEvent(new PopStateEvent("popstate"));
              }}
            >
              {KPI_META[k]?.fullLabel || k}
            </button>
          </span>
        ))}
      </div>
    </>
  );
}

// ─── Main component ───────────────────────────────────────────────────────────
import { useState, useEffect } from "react";

export default function GDAFinancialBible() {
  const { kpis, loading, error } = useKpi();

  // Read ?kpi= from URL; respond to browser back/forward navigation
  const [kpiKey, setKpiKey] = useState(() => {
    const p = new URLSearchParams(window.location.search);
    return p.get("kpi") || null;
  });

  useEffect(() => {
    function onPop() {
      const p = new URLSearchParams(window.location.search);
      setKpiKey(p.get("kpi") || null);
    }
    window.addEventListener("popstate", onPop);
    return () => window.removeEventListener("popstate", onPop);
  }, []);

  function selectKpi(key) {
    const url = new URL(window.location.href);
    url.searchParams.set("kpi", key);
    window.history.pushState({}, "", url.toString());
    setKpiKey(key);
  }

  function clearKpi() {
    const url = new URL(window.location.href);
    url.searchParams.delete("kpi");
    window.history.pushState({}, "", url.toString());
    setKpiKey(null);
  }

  // Secondary strip labels
  const stripItems = kpiKey
    ? [
        { label: "Viewing", value: KPI_META[kpiKey]?.fullLabel || kpiKey },
        { label: "Module",  value: "Financial Bible" },
      ]
    : [
        { label: "KPIs shown", value: "7" },
        { label: "Module",     value: "Financial Bible — Overview" },
      ];

  return (
    <div style={S.page}>

      {/* ── Persistent KPI strip ──────────────────────────────────────────── */}
      <GDAKpiStrip onKpiClick={selectKpi} />

      {/* ── Tool-specific secondary strip ─────────────────────────────────── */}
      <div style={S.summaryStrip}>
        {stripItems.map((item, i) => (
          <div key={item.label} style={{ display: "flex", alignItems: "center", gap: 12 }}>
            {i > 0 && <div style={S.stripDivider} />}
            <div>
              <div style={S.stripLabel}>{item.label}</div>
              <div style={S.stripValue}>{item.value}</div>
            </div>
          </div>
        ))}
        <div style={{ marginLeft: "auto", display: "flex", alignItems: "center", gap: 12 }}>
          <div style={S.stripDivider} />
          <div>
            <div style={S.stripLabel}>Source</div>
            <div style={{ fontSize: 12, color: "#64748b" }}>GET /api/financial/kpis</div>
          </div>
        </div>
      </div>

      {/* ── Page header ───────────────────────────────────────────────────── */}
      <div style={S.pageHeader}>
        <div>
          <h1 style={S.pageTitle}>Financial Bible</h1>
          <div style={S.pageSubtitle}>
            {kpiKey
              ? `KPI detail — ${KPI_META[kpiKey]?.fullLabel || kpiKey}`
              : "Financial KPI definitions, business context, and breakdowns"}
          </div>
        </div>
        <a
          href="/"
          style={S.backLink}
          onClick={e => { e.preventDefault(); window.location.href = "/"; }}
          title="Back to Launchpad"
        >
          ← Launchpad
        </a>
      </div>

      {/* ── Body ──────────────────────────────────────────────────────────── */}
      <div style={S.body}>

        {loading && (
          <div style={{ padding: 32, textAlign: "center", color: "#64748b" }}>
            Loading financial data…
          </div>
        )}

        {!loading && error && (
          <div style={S.errorBox}>
            <strong>KPI data unavailable:</strong> {error}
            <div style={{ marginTop: 8, fontSize: 12 }}>
              Check that Express is running on :3001 and <code>DATABASE_URL</code> is set.
              Set <code>KPI_USE_MOCK = true</code> in GDAKpiContext.jsx to use mock data.
            </div>
          </div>
        )}

        {!loading && !error && kpis && (
          kpiKey
            ? <KpiDetail kpiKey={kpiKey} kpis={kpis} onBack={clearKpi} />
            : <FinancialOverview kpis={kpis} onSelectKpi={selectKpi} />
        )}
      </div>
    </div>
  );
}
