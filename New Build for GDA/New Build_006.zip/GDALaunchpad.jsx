/**
 * GDA Rebuild — Launchpad Page
 * S-006 | Phase 1
 *
 * PURPOSE
 * -------
 * Front door to the GDA platform. Shows the top 10 scoring opportunities,
 * platform summary cards, and navigation into the five core tools.
 *
 * S-006 CHANGES
 * -------------
 * - Secondary summary strip added: reads total_opportunities, pipeline_count,
 *   active_risks from GET /api/launchpad/summary (existing endpoint, no changes).
 * - Launchpad summary fetch is page-level (single useEffect). A TODO comment
 *   marks where this could be promoted to a shared context in a future sprint.
 * - If /api/launchpad/summary fails, a small localized error panel appears
 *   in the strip only — the rest of the page renders normally.
 * - KPI strip sourced from <GDAKpiStrip /> (shared context, no duplicate fetch).
 * - Top-10 table rows still driven by USE_MOCK until schema passes all_ok:true.
 *
 * REACT STAYS READ-ONLY
 * ---------------------
 * GET requests only. No writes. No dryRun:false. Ever.
 *
 * PRODUCT RULES ENFORCED
 * ----------------------
 * - Opportunities shown are the top 10 by score — NOT pipeline items.
 * - An opportunity is not pipeline until explicitly qualified (see Ops Tracker).
 * - No charts. Tables, counts, lists, and navigation only.
 */

import { useState, useEffect, useRef } from "react";
import { GDAKpiStrip } from "./GDAKpiContext.jsx";

// ─── Mock controls ────────────────────────────────────────────────────────────
// Set false once /api/opportunities/top10 is confirmed live and schema passes.
export const USE_MOCK = true;

// ─── Mock data ────────────────────────────────────────────────────────────────
const MOCK_TOP10 = [
  { id: "OPP-001", title: "Dept of Army SIGINT Modernization",  dept: "Army",      value: 4200000,  pwin: 72, score: 91, status: "Tracking",    due_date: "2026-06-15" },
  { id: "OPP-002", title: "AFRL Advanced ISR Platform Study",   dept: "Air Force", value: 1850000,  pwin: 58, score: 84, status: "Tracking",    due_date: "2026-05-30" },
  { id: "OPP-003", title: "DHS Border Surveillance Tech",       dept: "DHS",       value: 3100000,  pwin: 45, score: 79, status: "Tracking",    due_date: "2026-07-01" },
  { id: "OPP-004", title: "Navy C2 Comms Upgrade Phase II",     dept: "Navy",      value: 7400000,  pwin: 61, score: 78, status: "Tracking",    due_date: "2026-08-20" },
  { id: "OPP-005", title: "SOCOM Tactical Edge Computing",      dept: "SOCOM",     value: 2250000,  pwin: 55, score: 74, status: "Tracking",    due_date: "2026-06-05" },
  { id: "OPP-006", title: "NRO Ground Station Refresh",         dept: "NRO",       value: 5600000,  pwin: 40, score: 71, status: "Identifying", due_date: "2026-09-10" },
  { id: "OPP-007", title: "DISA Zero Trust Architecture BPA",   dept: "DISA",      value: 890000,   pwin: 68, score: 69, status: "Tracking",    due_date: "2026-05-22" },
  { id: "OPP-008", title: "Army Cyber Range Infrastructure",    dept: "Army",      value: 3350000,  pwin: 38, score: 65, status: "Identifying", due_date: "2026-10-01" },
  { id: "OPP-009", title: "NSA Analytics Modernization IDIQ",   dept: "NSA",       value: 12000000, pwin: 25, score: 62, status: "Identifying", due_date: "2026-11-15" },
  { id: "OPP-010", title: "USMC Logistics Automation Pilot",    dept: "USMC",      value: 640000,   pwin: 52, score: 58, status: "Tracking",    due_date: "2026-06-28" },
];

const MOCK_SUMMARY = {
  total_opportunities: 47,
  pipeline_count:      8,
  active_risks:        3,
  decisions_due:       2,
  due_soon_count:      5,
};

// ─── Helpers ──────────────────────────────────────────────────────────────────
function fmtDollars(n) {
  if (n == null) return "—";
  if (n >= 1_000_000) return `$${(n / 1_000_000).toFixed(1)}M`;
  if (n >= 1_000)     return `$${(n / 1_000).toFixed(0)}K`;
  return `$${n}`;
}

function fmtDate(d) {
  if (!d) return "—";
  try {
    return new Date(d).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" });
  } catch { return d; }
}

function PwinBadge({ pwin }) {
  const v  = Number(pwin) || 0;
  let bg   = "#fee2e2";
  if (v >= 65)      bg = "#dcfce7";
  else if (v >= 45) bg = "#fef9c3";
  return (
    <span style={{
      display: "inline-block", padding: "2px 8px", borderRadius: 12,
      fontSize: 12, fontWeight: 600, backgroundColor: bg, color: "#1f2937",
      minWidth: 40, textAlign: "center",
    }}>
      {v}%
    </span>
  );
}

function ScoreBadge({ score }) {
  const v   = Number(score) || 0;
  let color = "#6b7280";
  if (v >= 80)      color = "#15803d";
  else if (v >= 60) color = "#b45309";
  else              color = "#dc2626";
  return <span style={{ fontWeight: 700, color }}>{v}</span>;
}

// ─── API fetches ──────────────────────────────────────────────────────────────
async function fetchTop10() {
  const resp        = await fetch("/api/opportunities/top10");
  const contentType = resp.headers.get("content-type") || "";
  if (!contentType.includes("application/json")) {
    throw new Error(
      `API returned non-JSON (HTTP ${resp.status}). Check Express :3001 and Vite proxy.`
    );
  }
  const env = await resp.json();
  const required = ["success", "workflow", "action", "dryRun", "data", "meta", "error"];
  const missing  = required.filter(k => !(k in env));
  if (missing.length) throw new Error(`Missing envelope fields: ${missing.join(", ")}`);
  if (!env.success)   throw new Error(env.error || "success:false");
  return env;
}

async function fetchLaunchpadSummary() {
  const resp        = await fetch("/api/launchpad/summary");
  const contentType = resp.headers.get("content-type") || "";
  if (!contentType.includes("application/json")) {
    throw new Error(`Non-JSON response (HTTP ${resp.status}) from /api/launchpad/summary.`);
  }
  const env = await resp.json();
  const required = ["success", "workflow", "action", "dryRun", "data", "meta", "error"];
  const missing  = required.filter(k => !(k in env));
  if (missing.length) throw new Error(`Envelope missing: ${missing.join(", ")}`);
  if (!env.success)   throw new Error(env.error || "success:false from /api/launchpad/summary");
  return env.data;
}

// ─── Core tool navigation cards ───────────────────────────────────────────────
const CORE_TOOLS = [
  { label: "Ops Tracker",       href: "/ops-tracker",      desc: "Opportunity discovery and management" },
  { label: "Financial Bible",   href: "/financial-bible",  desc: "KPI drill-downs and financial detail" },
  { label: "Prompt Architect",  href: "/prompt-architect", desc: "Operational prompt generation and reuse", soon: true },
  { label: "Compliance Matrix", href: "/compliance",       desc: "Compliance workspace", soon: true },
  { label: "Proposal Review",   href: "/proposal-review",  desc: "Proposal evaluation and review", soon: true },
];

// ─── Styles ───────────────────────────────────────────────────────────────────
const S = {
  page: {
    minHeight: "100vh",
    backgroundColor: "#f8fafc",
    fontFamily: "'Inter', 'Segoe UI', system-ui, sans-serif",
    color: "#1f2937",
  },

  // ── Secondary summary strip ────────────────────────────────────────────────
  summaryStrip: {
    display: "flex",
    alignItems: "center",
    gap: 0,
    backgroundColor: "#ffffff",
    borderBottom: "1px solid #e2e8f0",
    padding: "0 24px",
    overflowX: "auto",
    minHeight: 52,
  },
  summaryItem: {
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    padding: "10px 20px",
    borderRight: "1px solid #e2e8f0",
    minWidth: 110,
  },
  summaryLabel: { fontSize: 10, fontWeight: 600, color: "#94a3b8", letterSpacing: "0.07em", textTransform: "uppercase" },
  summaryValue: { fontSize: 18, fontWeight: 700, color: "#0f172a", marginTop: 2 },
  stripError: {
    padding: "10px 16px",
    fontSize: 12,
    color: "#92400e",
    backgroundColor: "#fff7ed",
    border: "1px solid #fed7aa",
    borderRadius: 6,
    margin: "auto 0",
    maxWidth: 380,
  },
  stripLoading: {
    padding: "10px 16px",
    fontSize: 12,
    color: "#64748b",
    fontStyle: "italic",
  },

  // ── Page header ────────────────────────────────────────────────────────────
  pageHeader: {
    padding: "20px 24px 16px",
    display: "flex",
    alignItems: "flex-start",
    justifyContent: "space-between",
    flexWrap: "wrap",
    gap: 12,
  },
  pageTitle:    { fontSize: 22, fontWeight: 700, color: "#0f172a", margin: 0 },
  pageSubtitle: { fontSize: 13, color: "#64748b", marginTop: 4 },

  // ── Mock banner ────────────────────────────────────────────────────────────
  mockBanner: { backgroundColor: "#fef3c7", borderBottom: "1px solid #fcd34d", padding: "6px 24px", fontSize: 12, color: "#92400e" },

  // ── Content layout ─────────────────────────────────────────────────────────
  content: { padding: "0 24px 24px", display: "grid", gridTemplateColumns: "1fr 300px", gap: 24, alignItems: "start" },
  contentSingle: { padding: "0 24px 24px" },

  // ── Section headers ────────────────────────────────────────────────────────
  sectionHeader: {
    display: "flex", alignItems: "center", justifyContent: "space-between",
    marginBottom: 12,
  },
  sectionTitle: { fontSize: 15, fontWeight: 700, color: "#0f172a" },
  sectionLink: {
    fontSize: 12, color: "#0369a1", textDecoration: "none",
    fontWeight: 600, background: "none", border: "none",
    cursor: "pointer", padding: 0,
  },

  // ── Top-10 table ───────────────────────────────────────────────────────────
  tableWrap: { backgroundColor: "#ffffff", border: "1px solid #e2e8f0", borderRadius: 10, overflow: "hidden" },
  table:     { width: "100%", borderCollapse: "collapse" },
  thead:     { backgroundColor: "#f1f5f9" },
  th: {
    padding: "9px 12px", textAlign: "left",
    fontSize: 10, fontWeight: 700, color: "#374151",
    textTransform: "uppercase", letterSpacing: "0.06em",
    borderBottom: "1px solid #e2e8f0",
  },
  td: { padding: "10px 12px", fontSize: 12, color: "#374151", borderBottom: "1px solid #f1f5f9", verticalAlign: "middle" },
  trHover: { backgroundColor: "#f8fafc" },
  emptyRow: { textAlign: "center", padding: 28, color: "#9ca3af", fontSize: 13 },

  // ── Sidebar ────────────────────────────────────────────────────────────────
  sidebar: { display: "flex", flexDirection: "column", gap: 16 },
  card: {
    backgroundColor: "#ffffff", border: "1px solid #e2e8f0",
    borderRadius: 10, padding: "16px",
  },
  cardTitle: { fontSize: 13, fontWeight: 700, color: "#0f172a", marginBottom: 10 },

  // ── Tool nav ───────────────────────────────────────────────────────────────
  toolBtn: {
    display: "block", width: "100%", textAlign: "left",
    padding: "10px 12px", borderRadius: 7,
    backgroundColor: "#f8fafc", border: "1px solid #e2e8f0",
    marginBottom: 8, cursor: "pointer",
    textDecoration: "none", color: "inherit",
    fontFamily: "inherit",
    transition: "border-color 0.12s, background 0.12s",
  },
  toolBtnHover: { backgroundColor: "#eff6ff", borderColor: "#bfdbfe" },
  toolLabel:    { fontSize: 13, fontWeight: 600, color: "#0f172a" },
  toolDesc:     { fontSize: 11, color: "#64748b", marginTop: 2 },
  toolSoon:     { fontSize: 10, color: "#9ca3af", marginTop: 2, fontStyle: "italic" },

  // ── Error / info boxes ─────────────────────────────────────────────────────
  errorBox: { margin: "16px 24px", padding: 16, backgroundColor: "#fee2e2", borderRadius: 8, color: "#991b1b", fontSize: 13 },
  pipelineNote: {
    marginTop: 12, padding: "10px 14px",
    backgroundColor: "#eff6ff", border: "1px solid #bfdbfe",
    borderRadius: 8, fontSize: 12, color: "#1e40af",
  },
};

// ─── Component ────────────────────────────────────────────────────────────────
export default function GDALaunchpad() {
  // ── Top-10 state ──────────────────────────────────────────────────────────
  const [opps,    setOpps]    = useState([]);
  const [loading, setLoading] = useState(true);
  const [error,   setError]   = useState(null);

  // ── Launchpad summary state ────────────────────────────────────────────────
  // S-006: fetches /api/launchpad/summary at page level.
  // TODO (future sprint): promote to shared context if other pages need it.
  const [summary,      setSummary]      = useState(null);
  const [summaryLoad,  setSummaryLoad]  = useState(true);
  const [summaryError, setSummaryError] = useState(null);

  // ── Hover state ────────────────────────────────────────────────────────────
  const [hoveredRow,  setHoveredRow]  = useState(null);
  const [hoveredTool, setHoveredTool] = useState(null);

  // ── Data loads ─────────────────────────────────────────────────────────────
  useEffect(() => {
    let cancelled = false;

    // Top-10 opportunities
    if (USE_MOCK) {
      const t = setTimeout(() => {
        if (cancelled) return;
        setOpps(MOCK_TOP10);
        setLoading(false);
      }, 280);
      // Also mock summary
      const t2 = setTimeout(() => {
        if (cancelled) return;
        setSummary(MOCK_SUMMARY);
        setSummaryLoad(false);
      }, 320);
      return () => { cancelled = true; clearTimeout(t); clearTimeout(t2); };
    }

    // Live: top-10
    fetchTop10()
      .then(env => { if (!cancelled) { setOpps(env.data?.opportunities || []); setLoading(false); } })
      .catch(err => { if (!cancelled) { setError(err.message); setLoading(false); } });

    // Live: launchpad summary (independent — strip should not block top-10)
    fetchLaunchpadSummary()
      .then(data => { if (!cancelled) { setSummary(data); setSummaryLoad(false); } })
      .catch(err  => { if (!cancelled) { setSummaryError(err.message); setSummaryLoad(false); } });

    return () => { cancelled = true; };
  }, []);

  // ── Summary strip items from API ───────────────────────────────────────────
  const stripItems = summary
    ? [
        { label: "Total Opportunities", value: summary.total_opportunities ?? "—" },
        { label: "Pipeline",            value: summary.pipeline_count      ?? "—" },
        { label: "Active Risks",        value: summary.active_risks        ?? "—" },
        ...(summary.decisions_due  != null ? [{ label: "Decisions Due",  value: summary.decisions_due  }] : []),
        ...(summary.due_soon_count != null ? [{ label: "Due Soon",        value: summary.due_soon_count }] : []),
      ]
    : null;

  // ── Navigate to Ops Tracker ────────────────────────────────────────────────
  function goToOpsTracker(e) {
    e.preventDefault();
    window.location.href = "/ops-tracker";
  }

  // ── Render ─────────────────────────────────────────────────────────────────
  return (
    <div style={S.page}>

      {/* ── Persistent Financial KPI Strip (shared context — no extra fetch) ── */}
      <GDAKpiStrip />

      {/* ── Secondary summary strip — Launchpad-specific ─────────────────── */}
      <div style={S.summaryStrip} role="region" aria-label="Platform summary">

        {summaryLoad && (
          <div style={S.stripLoading}>Loading platform summary…</div>
        )}

        {!summaryLoad && summaryError && (
          <div style={S.stripError}>
            ⚠ Summary unavailable — {summaryError.length > 100 ? summaryError.slice(0, 100) + "…" : summaryError}
            <div style={{ marginTop: 4, fontSize: 11 }}>
              Check <code>/api/launchpad/summary</code> — page is still usable.
            </div>
          </div>
        )}

        {!summaryLoad && !summaryError && stripItems && stripItems.map((item, i) => (
          <div key={item.label} style={S.summaryItem}>
            <span style={S.summaryLabel}>{item.label}</span>
            <span style={S.summaryValue}>{item.value}</span>
          </div>
        ))}

        {/* Pipeline rule pill — always shown */}
        {!summaryLoad && !summaryError && (
          <div style={{ ...S.summaryItem, marginLeft: "auto", borderRight: "none", borderLeft: "1px solid #e2e8f0", backgroundColor: "#eff6ff" }}>
            <span style={{ ...S.summaryLabel, color: "#1e40af" }}>Pipeline Rule</span>
            <span style={{ ...S.summaryValue, fontSize: 12, color: "#1e40af" }}>Qualify to Add</span>
          </div>
        )}
      </div>

      {/* ── Mock banner ───────────────────────────────────────────────────── */}
      {USE_MOCK && (
        <div style={S.mockBanner}>
          ⚠ MOCK DATA — set <code>USE_MOCK = false</code> in GDALaunchpad.jsx after Express API is live on :3001 and /api/schema/check passes all_ok:true
        </div>
      )}

      {/* ── Page header ───────────────────────────────────────────────────── */}
      <div style={S.pageHeader}>
        <div>
          <h1 style={S.pageTitle}>Launchpad</h1>
          <div style={S.pageSubtitle}>Platform summary · Top scoring opportunities · Core tool navigation</div>
        </div>
      </div>

      {/* ── Error states ──────────────────────────────────────────────────── */}
      {error && (
        <div style={S.errorBox}>
          <strong>Error loading opportunities:</strong> {error}
          <div style={{ marginTop: 8, fontSize: 12 }}>
            Check Express :3001 and <code>DATABASE_URL</code>.
          </div>
        </div>
      )}

      {/* ── Main content: top-10 + sidebar ────────────────────────────────── */}
      <div style={S.content}>

        {/* ── Left: Top-10 opportunities ─────────────────────────────────── */}
        <div>
          <div style={S.sectionHeader}>
            <div style={S.sectionTitle}>Top 10 Scoring Opportunities</div>
            <a
              href="/ops-tracker"
              style={S.sectionLink}
              onClick={goToOpsTracker}
            >
              VIEW ALL →
            </a>
          </div>

          {loading && (
            <div style={{ padding: 24, textAlign: "center", color: "#64748b", fontSize: 13 }}>
              Loading opportunities…
            </div>
          )}

          {!loading && !error && (
            <>
              <div style={S.tableWrap}>
                <table style={S.table}>
                  <thead style={S.thead}>
                    <tr>
                      <th style={S.th}>Title</th>
                      <th style={S.th}>Dept</th>
                      <th style={S.th}>Value</th>
                      <th style={S.th}>P(Win)</th>
                      <th style={S.th}>Score</th>
                      <th style={S.th}>Due</th>
                    </tr>
                  </thead>
                  <tbody>
                    {opps.length === 0 ? (
                      <tr>
                        <td colSpan={6} style={S.emptyRow}>No opportunities found.</td>
                      </tr>
                    ) : (
                      opps.map(opp => (
                        <tr
                          key={opp.id}
                          style={hoveredRow === opp.id ? S.trHover : {}}
                          onMouseEnter={() => setHoveredRow(opp.id)}
                          onMouseLeave={() => setHoveredRow(null)}
                        >
                          <td style={{ ...S.td, fontWeight: 500, maxWidth: 240 }}>{opp.title}</td>
                          <td style={S.td}>{opp.dept || "—"}</td>
                          <td style={{ ...S.td, fontVariantNumeric: "tabular-nums", fontWeight: 600 }}>{fmtDollars(opp.value)}</td>
                          <td style={S.td}><PwinBadge pwin={opp.pwin} /></td>
                          <td style={S.td}><ScoreBadge score={opp.score} /></td>
                          <td style={{ ...S.td, whiteSpace: "nowrap", fontSize: 11 }}>{fmtDate(opp.due_date)}</td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>

              <div style={S.pipelineNote}>
                <strong>Opportunity ≠ Pipeline.</strong> These are the top 10 <em>scoring opportunities</em> —
                not qualified pipeline. Go to <a href="/ops-tracker" onClick={goToOpsTracker}
                  style={{ color: "#1e40af", fontWeight: 600 }}>Ops Tracker</a> to
                preview or initiate qualification.
              </div>
            </>
          )}
        </div>

        {/* ── Right: Sidebar ─────────────────────────────────────────────── */}
        <div style={S.sidebar}>

          {/* Platform status card */}
          <div style={S.card}>
            <div style={S.cardTitle}>Platform Status</div>
            {summaryLoad && <div style={{ fontSize: 12, color: "#64748b" }}>Loading…</div>}
            {!summaryLoad && summaryError && (
              <div style={{ fontSize: 12, color: "#92400e" }}>
                Summary unavailable — check /api/launchpad/summary
              </div>
            )}
            {!summaryLoad && !summaryError && summary && (
              <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
                {[
                  ["Opportunities",  summary.total_opportunities ?? "—"],
                  ["In Pipeline",    summary.pipeline_count      ?? "—"],
                  ["Active Risks",   summary.active_risks        ?? "—"],
                  ...(summary.decisions_due  != null ? [["Decisions Due",  summary.decisions_due]] : []),
                  ...(summary.due_soon_count != null ? [["Due Soon",        summary.due_soon_count]] : []),
                ].map(([label, value]) => (
                  <div key={label} style={{ display: "flex", justifyContent: "space-between", fontSize: 13 }}>
                    <span style={{ color: "#64748b" }}>{label}</span>
                    <span style={{ fontWeight: 700, color: "#0f172a" }}>{value}</span>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Core tool navigation */}
          <div style={S.card}>
            <div style={S.cardTitle}>Core Tools</div>
            {CORE_TOOLS.map(tool => (
              <a
                key={tool.label}
                href={tool.href}
                style={{
                  ...S.toolBtn,
                  ...(hoveredTool === tool.label && !tool.soon ? S.toolBtnHover : {}),
                  opacity: tool.soon ? 0.55 : 1,
                  cursor: tool.soon ? "default" : "pointer",
                }}
                onMouseEnter={() => !tool.soon && setHoveredTool(tool.label)}
                onMouseLeave={() => setHoveredTool(null)}
                onClick={tool.soon ? e => e.preventDefault() : undefined}
                aria-disabled={tool.soon}
                tabIndex={tool.soon ? -1 : 0}
              >
                <div style={S.toolLabel}>{tool.label}</div>
                <div style={S.toolDesc}>{tool.desc}</div>
                {tool.soon && <div style={S.toolSoon}>Coming in a future sprint</div>}
              </a>
            ))}
          </div>

          {/* Placeholder: risks / decisions (future sprint) */}
          <div style={{ ...S.card, backgroundColor: "#f8fafc", borderStyle: "dashed" }}>
            <div style={{ ...S.cardTitle, color: "#9ca3af" }}>Active Risks &amp; Decisions</div>
            <div style={{ fontSize: 12, color: "#94a3b8" }}>
              Risk and decision detail views ship in a future sprint.
              Count shown in the summary strip above.
            </div>
          </div>

        </div>
      </div>
    </div>
  );
}
