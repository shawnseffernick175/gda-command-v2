/**
 * GDA Rebuild — App Shell
 * S-006 | Phase 1
 *
 * CHANGES vs S-005 (App-5.jsx)
 * -----------------------------
 * 1. /financial-bible route now renders <GDAFinancialBible> (real page)
 *    instead of the FinancialBiblePlaceholder stub. KPI clicks are fully
 *    functional drill-downs.
 *
 * 2. GDALaunchpad import updated to the S-006 version (GDALaunchpad.jsx)
 *    which includes the secondary summary strip driven by /api/launchpad/summary.
 *
 * 3. GDAOpsTracker import updated to GDAOpsTracker-6.jsx (S-006 panel polish).
 *
 * 4. All other structure unchanged:
 *    - <GDAKpiProvider> wraps the router (single KPI fetch per session).
 *    - <GDAHealthBadge /> persists in the footer across all pages.
 *    - Catch-all → / redirect unchanged.
 *
 * REACT STAYS READ-ONLY
 * ---------------------
 * No writes. No dryRun:false. All browser calls to /api/... only.
 *
 * Usage: mount <App /> in main.jsx — unchanged from S-005.
 */

import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import GDALaunchpad        from "./GDALaunchpad.jsx";
import GDAOpsTracker       from "./GDAOpsTracker-6.jsx";
import GDAFinancialBible   from "./GDAFinancialBible.jsx";
import { GDAKpiProvider }  from "./GDAKpiContext.jsx";
import GDAHealthBadge      from "./GDAHealthBadge.jsx";

export default function App() {
  return (
    <GDAKpiProvider>
      <BrowserRouter>
        <div style={{ display: "flex", flexDirection: "column", minHeight: "100vh" }}>

          {/* ── Page content (all routes) ────────────────────────────────── */}
          <div style={{ flex: 1 }}>
            <Routes>
              {/* Front door */}
              <Route path="/"                element={<GDALaunchpad />}       />

              {/* Ops Tracker */}
              <Route path="/ops-tracker"     element={<GDAOpsTracker />}      />

              {/* Financial Bible — real page as of S-006 */}
              <Route path="/financial-bible" element={<GDAFinancialBible />}  />

              {/* Placeholder routes — future sprints */}
              <Route path="/prompt-architect" element={<ComingSoon label="Prompt Architect" />}  />
              <Route path="/compliance"       element={<ComingSoon label="Compliance Matrix" />} />
              <Route path="/proposal-review"  element={<ComingSoon label="Proposal Review" />}   />

              {/* Catch-all */}
              <Route path="*" element={<Navigate to="/" replace />} />
            </Routes>
          </div>

          {/* ── System health footer (non-blocking) ─────────────────────── */}
          <GDAHealthBadge />
        </div>
      </BrowserRouter>
    </GDAKpiProvider>
  );
}

// ─── Thin placeholder for future tool routes ──────────────────────────────────
// Prevents 404 on tool nav links that are not yet implemented.
import { GDAKpiStrip } from "./GDAKpiContext.jsx";

function ComingSoon({ label }) {
  return (
    <div style={{
      minHeight: "100vh",
      backgroundColor: "#f8fafc",
      fontFamily: "'Inter', 'Segoe UI', system-ui, sans-serif",
    }}>
      <GDAKpiStrip />
      <div style={{ padding: "40px 24px", textAlign: "center" }}>
        <h2 style={{ fontSize: 22, fontWeight: 700, color: "#0f172a", marginBottom: 8 }}>
          {label}
        </h2>
        <p style={{ color: "#64748b", fontSize: 14, maxWidth: 400, margin: "0 auto 24px" }}>
          This tool is scoped for a future sprint and is not yet implemented.
        </p>
        <a
          href="/"
          style={{ color: "#0369a1", fontWeight: 600, textDecoration: "none", fontSize: 14 }}
          onClick={e => { e.preventDefault(); window.location.href = "/"; }}
        >
          ← Back to Launchpad
        </a>
      </div>
    </div>
  );
}

/*
 * ── Vite proxy config (unchanged from S-005) ──────────────────────────────
 *
 *   import { defineConfig } from "vite";
 *   import react from "@vitejs/plugin-react";
 *
 *   export default defineConfig({
 *     plugins: [react()],
 *     server: {
 *       proxy: {
 *         "/api": {
 *           target:       "http://localhost:3001",
 *           changeOrigin: true,
 *         },
 *       },
 *     },
 *   });
 */
