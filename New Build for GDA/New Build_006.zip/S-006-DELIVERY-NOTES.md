# S-006 Delivery Notes
GDA Rebuild — Sprint S-006 | Phase 1

---

## What shipped

### 1. `GDAFinancialBible.jsx` — Financial Bible page v1 (NEW)

Replaces the `FinancialBiblePlaceholder` stub from S-005. Mounted at `/financial-bible`.

**Two modes driven by `?kpi=` query param:**

**Overview (no `?kpi=`):**
- Grid of all 7 KPI cards, each showing label + current value from `useKpi()`.
- Clicking any card navigates to that KPI's detail view (pushes to browser history).

**Detail (`?kpi=<key>`):**
- Focused header with KPI name and current value.
- Prose description of what the KPI means in the defense contracting context.
- "Breakdown & Context" table with 5 rows per KPI:
  `What it measures`, `Defense context`, `Leads or lags`, `Healthy signal`, `Watch for`.
- Cross-links to all other KPIs at the bottom.
- "← All KPIs" back link returns to overview (browser history push).

**Data source:** `useKpi()` only — no new API calls, no new endpoints.

**Works in both mock and live modes** — driven by `KPI_USE_MOCK` in `GDAKpiContext.jsx`.

**KPI keys with full metadata:** `orders`, `sales`, `ebit`, `ros`, `funded_backlog`, `backlog`, `gross_profit`.

---

### 2. `GDALaunchpad.jsx` — Secondary summary strip (NEW / REBUILT)

Launchpad was not in any prior zip delivery. This is the canonical S-006 build including all features.

**Secondary summary strip (S-006 new):**
- Calls `GET /api/launchpad/summary` independently at page level.
- Shows: `Total Opportunities`, `Pipeline`, `Active Risks`, plus `Decisions Due` and `Due Soon` if present.
- If the fetch fails: small amber error panel appears in the strip only — the rest of the page renders normally.
- Pipeline rule pill always visible on the right edge.

**Also includes:**
- Top-10 scoring opportunity table with `USE_MOCK` toggle.
- Platform Status sidebar card (mirrors strip data).
- Core Tools navigation sidebar (Ops Tracker + Financial Bible live; others marked "coming soon").
- Risks & Decisions placeholder card.
- Pipeline rule callout below the table.

**TODO left in code:**
```js
// TODO (future sprint): promote to shared context if other pages need it.
```

---

### 3. `GDAOpsTracker-6.jsx` — Qualify preview panel refinements (UPDATED)

**Visual grouping (S-006):**
- 4px solid `#0ea5e9` left accent bar runs the full height of the panel, binding it visually to its source row.
- Panel TD background: `#e0f2fe` with `2px solid #0ea5e9` bottom border — reads as a continuous unit with the row above.

**Server note field (S-006):**
- If `env.data.note` is present in the API response, renders:
  ```
  Server note: <note text>
  ```
  as a grey separator line at the bottom of the panel content.
- If absent: nothing rendered, no layout shift.

**Keyboard focus (S-006):**
- "Preview Qualify" button: `Tab`-focusable, `Enter`/`Space` activates.
- On open: `panelRef.current.focus()` fires via `useEffect` after content loads — keyboard users land inside the panel.
- On close (`×` button **or** second click on "Preview Qualify"):
  ```js
  requestAnimationFrame(() => qualifyBtnRefs.current[oppId]?.focus());
  ```
  Focus returns to that row's trigger button.
- Close button: `Tab`-reachable, `Enter`/`Space` closes.
- `qualifyBtnRefs` is a `useRef` map keyed by `oppId` — one ref per row, populated via `ref={el => { qualifyBtnRefs.current[opp.id] = el; }}`.

**USE_MOCK:** unchanged from S-005. S-006 only refines the panel.

---

### 4. `App-6.jsx` — Updated app shell (UPDATED)

- `/financial-bible` → `<GDAFinancialBible />` (real page, replaces stub).
- `/` → `<GDALaunchpad />` (S-006 version with secondary strip).
- `/ops-tracker` → `<GDAOpsTracker-6 />` (S-006 panel polish).
- `/prompt-architect`, `/compliance`, `/proposal-review` → `<ComingSoon />` placeholder (prevents 404 on sidebar nav clicks).
- All other structure unchanged (`<GDAKpiProvider>`, `<GDAHealthBadge />`, catch-all redirect).

---

### 5. `gda-smoke-tests-6.js` — Updated smoke tests (UPDATED)

All S-004/S-005 hard assertions preserved. Changes:

| Test | Change |
|------|--------|
| Suite header | S-006 |
| `/api/financial/kpis` | Comment updated: "consumed by GDAFinancialBible" |
| `/api/launchpad/summary` | **Strengthened**: now hard-asserts `total_opportunities`, `pipeline_count`, `active_risks` are all present (these drive the S-006 secondary strip) |
| `/api/qualify dryRun:true` | Added **soft warn** (non-fatal) for `data.note` field — server may not supply it yet; panel renders it when available |
| `/api/qualify dryRun:false` | **Unchanged** — still hard HTTP 400 + "not enabled" assertion |
| `/api/schema/check` | **Unchanged** — `all_ok:false` still hard-fails the suite |

---

## Files changed / new

| File | Status | Description |
|------|--------|-------------|
| `GDAFinancialBible.jsx`  | NEW     | Financial Bible overview grid + KPI detail views |
| `GDALaunchpad.jsx`       | NEW     | Launchpad with secondary summary strip |
| `GDAOpsTracker-6.jsx`    | UPDATED | Qualify panel: visual grouping, server note, keyboard focus |
| `App-6.jsx`              | UPDATED | Routes to real Financial Bible, Launchpad S-006, OpsTracker-6 |
| `gda-smoke-tests-6.js`   | UPDATED | S-006 assertions, all prior hard gates preserved |

**Not touched:** `server-3-2.js`, `gda-api-routes-4-3.js`, frozen workflows,
`GDAKpiContext.jsx`, `GDAHealthBadge.jsx`.

---

## Toggle cheat sheet

| Flag | File | Controls |
|------|------|----------|
| `USE_MOCK = true` | `GDAOpsTracker-6.jsx` | Top10 table rows |
| `USE_MOCK = true` | `GDALaunchpad.jsx` | Top10 + launchpad summary |
| `KPI_USE_MOCK = true` | `GDAKpiContext.jsx` | KPI strip + Financial Bible values |

Switch each to `false` independently. Do not flip any until `/api/schema/check` returns `all_ok: true`.

---

## How to run

```bash
# API (Express :3001)
cd api && npm run dev

# React (Vite :5173)
npm run dev

# Smoke tests
node gda-smoke-tests-6.js http://localhost:3001
```

---

## What remains read-only

S-006 is entirely read-only from the React side.
`dryRun:false` is never sent. No writes. No deploys. No paid calls.
RR-38 and RR-28 remain frozen.

---

## S-007 candidates

1. Wire real qualify approval gate (explicit Shawn sign-off required first).
2. Financial Bible drill-down: connect to real financial breakdown data (may need new endpoint — evaluate at sprint planning).
3. Launchpad risks + decisions detail cards (beyond count display).
4. Pipeline view — separate from Ops Tracker, shows only qualified records.
