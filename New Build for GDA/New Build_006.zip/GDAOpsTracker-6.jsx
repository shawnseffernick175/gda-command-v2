/**
 * GDA Rebuild — Ops Tracker Page
 * S-006 | Phase 1
 *
 * CHANGES vs S-005 (GDAOpsTracker-5.jsx)
 * ----------------------------------------
 * 1. Qualify preview panel — visual refinements:
 *    - Left accent bar (3px solid #0ea5e9) visually groups panel with its row.
 *    - Panel TD background (#e0f2fe) + bottom border (2px #0ea5e9) make the
 *      row+panel read as a continuous unit, not a floating overlay.
 *
 * 2. Qualify preview panel — "server says" note field:
 *    - If env.data.note is present in the API response, renders a grey
 *      "Server note:" line at the bottom of the panel content area.
 *    - Absent → nothing rendered. No layout shift.
 *
 * 3. Keyboard focus behavior (S-006):
 *    - "Preview Qualify" button: Tab-focusable, Enter/Space activates.
 *    - On open: panel container (tabIndex={-1}) receives programmatic focus
 *      via useEffect + ref, so keyboard users land inside the panel.
 *    - On close (× button OR second click on "Preview Qualify"):
 *      focus returns to that row's "Preview Qualify" button via a ref map
 *      (qualifyBtnRefs keyed by oppId).
 *    - Close button is Tab-accessible and Enter/Space activatable.
 *
 * 4. USE_MOCK behavior: unchanged from S-005.
 *    S-006 does not change USE_MOCK. KPI strip uses its own KPI_USE_MOCK.
 *
 * REACT STAYS READ-ONLY
 * ---------------------
 * All browser calls: /api/... only. No writes. dryRun:false NEVER sent.
 * Real writes require server-side approval gate (locked until explicitly unlocked).
 */

import { useState, useEffect, useRef } from "react";
import { GDAKpiStrip } from "./GDAKpiContext.jsx";

// ─── Mock data ────────────────────────────────────────────────────────────────
const MOCK_OPPORTUNITIES = [
  { id: "OPP-001", title: "Dept of Army SIGINT Modernization",  dept: "Army",      value: 4200000,  pwin: 72, score: 91, status: "Tracking",    due_date: "2026-06-15" },
  { id: "OPP-002", title: "AFRL Advanced ISR Platform Study",   dept: "Air Force", value: 1850000,  pwin: 58, score: 84, status: "Tracking",    due_date: "2026-05-30" },
  { id: "OPP-003", title: "DHS Border Surveillance Tech",       dept: "DHS",       value: 3100000,  pwin: 45, score: 79, status: "Tracking",    due_date: "2026-07-01" },
  { id: "OPP-004", title: "Navy C2 Comms Upgrade Phase II",     dept: "Navy",      value: 7400000,  pwin: 61, score: 78, status: "Tracking",    due_date: "2026-08-20" },
  { id: "OPP-005", title: "SOCOM Tactical Edge Computing",      dept: "SOCOM",     value: 2250000,  pwin: 55, score: 74, status: "Tracking",    due_date: "2026-06-05" },
  { id: "OPP-006", title: "NRO Ground Station Refresh",         dept: "NRO",       value: 5600000,  pwin: 40, score: 71, status: "Identifying", due_date: "2026-09-10" },
  { id: "OPP-007", title: "DISA Zero Trust Architecture BPA",   dept: "DISA",      value: 890000,   pwin: 68, score: 69, status: "Tracking",    due_date: "2026-05-22" },
  { id: "OPP-008", title: "Army Cyber Range Infrastructure",    dept: "Army",      value: 3350000,  pwin: 38, score: 65, status: "Identifying", due_date: "2026-10-01" },
  { id: "OPP-009", title: "NSA Analytics Modernization IDIQ",   dept: "NSA",       value: 12000000, pwin: 25, score: 62, status: "Identifying", due_date: "2026-11-15" },
  { id: "OPP-010", title: "USMC Logistics Automation Pilot",    dept: "USMC",      value: 640000,   pwin: 52, score: 58, status: "Tracking",    due_date: "2026-06-28" },
];

const MOCK_SUMMARY = {
  total_opportunities: 10,
  avg_score:  73,
  avg_pwin:   51,
  total_value: 41280000,
};

// ─── Config ───────────────────────────────────────────────────────────────────
export const USE_MOCK = true;

// ─── Helpers ──────────────────────────────────────────────────────────────────
function fmtDollars(n) {
  if (n == null) return "—";
  if (n >= 1_000_000) return `$${(n / 1_000_000).toFixed(1)}M`;
  if (n >= 1_000)     return `$${(n / 1_000).toFixed(0)}K`;
  return `$${n}`;
}

function fmtDate(d) {
  if (!d) return "—";
  try { return new Date(d).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" }); }
  catch { return d; }
}

function PwinBadge({ pwin }) {
  const v = Number(pwin) || 0;
  let bg  = "#fee2e2";
  if (v >= 65)      bg = "#dcfce7";
  else if (v >= 45) bg = "#fef9c3";
  return (
    <span style={{
      display: "inline-block", padding: "2px 8px", borderRadius: 12,
      fontSize: 12, fontWeight: 600, backgroundColor: bg,
      color: "#1f2937", minWidth: 40, textAlign: "center",
    }}>
      {v}%
    </span>
  );
}

function ScoreBadge({ score }) {
  const v = Number(score) || 0;
  let color = "#6b7280";
  if (v >= 80)      color = "#15803d";
  else if (v >= 60) color = "#b45309";
  else              color = "#dc2626";
  return <span style={{ fontWeight: 700, color }}>{v}</span>;
}

function StatusPill({ status }) {
  const map = {
    Pipeline:    { bg: "#dbeafe", color: "#1e40af" },
    Tracking:    { bg: "#e0f2fe", color: "#0369a1" },
    Identifying: { bg: "#f3f4f6", color: "#374151" },
    Pursuing:    { bg: "#fef9c3", color: "#92400e" },
    Lost:        { bg: "#fee2e2", color: "#991b1b" },
    "No Bid":    { bg: "#f3f4f6", color: "#9ca3af" },
  };
  const s = map[status] || { bg: "#f3f4f6", color: "#374151" };
  return (
    <span style={{
      display: "inline-block", padding: "2px 10px", borderRadius: 12,
      fontSize: 12, fontWeight: 600, backgroundColor: s.bg, color: s.color,
    }}>
      {status || "—"}
    </span>
  );
}

// ─── Filters ──────────────────────────────────────────────────────────────────
const DEPTS    = ["All", "Army", "Air Force", "Navy", "USMC", "SOCOM", "DHS", "DISA", "NRO", "NSA", "Other"];
const STATUSES = ["All", "Tracking", "Identifying", "Pursuing", "Pipeline", "Lost", "No Bid"];

function applyFilters(rows, { dept, status, minPwin, sortKey, sortDir }) {
  let out = [...rows];
  if (dept   !== "All") out = out.filter(r => r.dept   === dept);
  if (status !== "All") out = out.filter(r => r.status === status);
  if (minPwin > 0)      out = out.filter(r => (Number(r.pwin) || 0) >= minPwin);
  if (sortKey) {
    out.sort((a, b) => {
      let av = a[sortKey], bv = b[sortKey];
      if (typeof av === "string") av = av.toLowerCase();
      if (typeof bv === "string") bv = bv.toLowerCase();
      return (av < bv ? -1 : av > bv ? 1 : 0) * (sortDir === "asc" ? 1 : -1);
    });
  }
  return out;
}

// ─── API: top10 ───────────────────────────────────────────────────────────────
async function fetchTop10() {
  const resp        = await fetch("/api/opportunities/top10");
  const contentType = resp.headers.get("content-type") || "";
  if (!contentType.includes("application/json")) {
    throw new Error(
      `API returned non-JSON (HTTP ${resp.status}, Content-Type: "${contentType}"). ` +
      "Check Express :3001 and Vite proxy."
    );
  }
  const env      = await resp.json();
  const required = ["success", "workflow", "action", "dryRun", "data", "meta", "error"];
  const missing  = required.filter(k => !(k in env));
  if (missing.length) throw new Error(`Missing envelope fields: ${missing.join(", ")}. Check gda-api-routes.js.`);
  if (!env.success)   throw new Error(env.error || "API returned success:false with no error.");
  return env;
}

// ─── API: qualify preview — dryRun:true ONLY ──────────────────────────────────
// SAFETY: This function NEVER sends dryRun:false. The value is hardcoded below.
async function fetchQualifyPreview(id) {
  const resp = await fetch(`/api/opportunities/${encodeURIComponent(id)}/qualify`, {
    method:  "POST",
    headers: { "Content-Type": "application/json" },
    body:    JSON.stringify({ dryRun: true }),   // ← hardcoded; never false
  });
  const contentType = resp.headers.get("content-type") || "";
  if (!contentType.includes("application/json")) {
    throw Object.assign(new Error(`Non-JSON response (HTTP ${resp.status}).`), { httpStatus: resp.status });
  }
  const env = await resp.json();
  if (resp.status === 404) return { notFound: true, env };
  return { notFound: false, httpStatus: resp.status, env };
}

// ─── Qualify Preview Panel ────────────────────────────────────────────────────
// S-006 changes:
//   • Left accent bar — 3px cyan strip to group panel visually with its row.
//   • Server note field — renders env.data.note when present.
//   • Focus management — panelRef receives focus on load; onClose returns
//     focus to the trigger button via the parent's qualifyBtnRefs map.

function QualifyPanel({ oppId, onClose }) {
  const [loading,  setLoading]  = useState(true);
  const [result,   setResult]   = useState(null);
  const [fetchErr, setFetchErr] = useState(null);

  // S-006: panel container takes focus when content is ready
  const panelRef = useRef(null);

  useEffect(() => {
    let cancelled = false;
    fetchQualifyPreview(oppId)
      .then(r  => { if (!cancelled) { setResult(r);          setLoading(false); } })
      .catch(e => { if (!cancelled) { setFetchErr(e.message); setLoading(false); } });
    return () => { cancelled = true; };
  }, [oppId]);

  // Move focus into the panel container once content arrives
  useEffect(() => {
    if (!loading && panelRef.current) {
      panelRef.current.focus();
    }
  }, [loading]);

  // ── Styles ─────────────────────────────────────────────────────────────────
  const wrap = {
    display: "flex",
    alignItems: "stretch",
    borderRadius: 8,
    overflow: "hidden",
  };
  const accent = {
    width: 4,
    backgroundColor: "#0ea5e9",
    flexShrink: 0,
  };
  const inner = {
    flex: 1,
    backgroundColor: "#f0f9ff",
    border: "1px solid #bae6fd",
    borderLeft: "none",
    padding: "14px 18px 14px 16px",
    fontSize: 13,
    color: "#0c4a6e",
    position: "relative",
    outline: "none",
  };
  const closeBtnStyle = {
    position: "absolute", top: 10, right: 12,
    background: "none", border: "1px solid #bae6fd",
    borderRadius: 4, cursor: "pointer",
    color: "#0369a1", fontSize: 16, lineHeight: 1,
    padding: "1px 6px",
  };
  const dryRunBadge = {
    display: "inline-block", padding: "2px 10px",
    backgroundColor: "#fef9c3", border: "1px solid #fde68a",
    borderRadius: 12, fontSize: 11, fontWeight: 700,
    color: "#92400e", marginBottom: 10, letterSpacing: "0.04em",
  };
  const fKey = { color: "#64748b", fontWeight: 600, marginRight: 6, fontSize: 12 };
  const fVal = { color: "#0f172a", fontWeight: 500 };

  return (
    <div style={wrap}>
      {/* S-006: left accent bar */}
      <div style={accent} aria-hidden="true" />

      {/* Panel body — receives focus on open */}
      <div
        ref={panelRef}
        style={inner}
        tabIndex={-1}
        role="region"
        aria-label={`Qualify preview for ${oppId}`}
      >
        {/* Close button — keyboard accessible */}
        <button
          style={closeBtnStyle}
          onClick={onClose}
          aria-label="Close qualify preview panel"
          title="Close (Esc)"
        >
          ×
        </button>

        <div style={dryRunBadge}>⚠ DRY RUN — no changes made</div>

        {/* ── Loading ──────────────────────────────────────────────────── */}
        {loading && (
          <div style={{ color: "#0369a1" }}>Checking qualify status…</div>
        )}

        {/* ── Fetch error ───────────────────────────────────────────────── */}
        {!loading && fetchErr && (
          <div style={{ color: "#dc2626" }}>
            <strong>Error:</strong> {fetchErr}
          </div>
        )}

        {/* ── 404 / out of sync ─────────────────────────────────────────── */}
        {!loading && !fetchErr && result?.notFound && (
          <div style={{ color: "#92400e" }}>
            <strong>Not found / out of sync</strong> — Opportunity{" "}
            <code>{oppId}</code> was not found on the server.
            The table may be showing stale data. Refresh to resync.
          </div>
        )}

        {/* ── Preview data ──────────────────────────────────────────────── */}
        {!loading && !fetchErr && result && !result.notFound && (() => {
          const env = result.env;
          if (!env?.success) {
            return (
              <div style={{ color: "#dc2626" }}>
                <strong>API error:</strong> {env?.error || "Unknown error from qualify endpoint."}
              </div>
            );
          }
          const d = env.data || {};
          return (
            <>
              <div style={{ fontWeight: 700, marginBottom: 10, color: "#0c4a6e" }}>
                Qualify Preview — {oppId}
              </div>

              {[
                ["Current Status",    d.current_status    ?? "—"],
                ["Proposed Status",   d.proposed_status   ?? "—"],
                ["Would Change",
                  d.would_change != null
                    ? (d.would_change ? "Yes" : "No")
                    : "—"],
                ["Already Qualified",
                  d.already_qualified != null
                    ? (d.already_qualified ? "Yes — already pipeline" : "No")
                    : "—"],
              ].map(([k, v]) => (
                <div key={k} style={{ marginBottom: 6 }}>
                  <span style={fKey}>{k}:</span>
                  <span style={fVal}>{String(v)}</span>
                </div>
              ))}

              {Array.isArray(d.fields_to_update) && d.fields_to_update.length > 0 && (
                <div style={{ marginTop: 10 }}>
                  <div style={{ ...fKey, display: "block", marginBottom: 4 }}>
                    Fields that would update:
                  </div>
                  <ul style={{ margin: 0, paddingLeft: 18, fontSize: 12, color: "#0f172a" }}>
                    {d.fields_to_update.map((f, i) => (
                      <li key={i}>{typeof f === "object" ? JSON.stringify(f) : f}</li>
                    ))}
                  </ul>
                </div>
              )}

              {/* S-006: server note — rendered only when present in response */}
              {d.note && (
                <div style={{
                  marginTop: 10, paddingTop: 8,
                  borderTop: "1px solid #bae6fd",
                  fontSize: 11, color: "#475569",
                }}>
                  <strong>Server note:</strong> {d.note}
                </div>
              )}

              <div style={{
                marginTop: 12, paddingTop: 8,
                borderTop: "1px solid #bae6fd",
                fontSize: 11, color: "#64748b",
              }}>
                Real qualification requires explicit approval.
                POST dryRun:false is blocked server-side until the approval gate ships.
              </div>
            </>
          );
        })()}
      </div>
    </div>
  );
}

// ─── Styles ───────────────────────────────────────────────────────────────────
const S = {
  page:         { minHeight: "100vh", backgroundColor: "#f8fafc", fontFamily: "'Inter', 'Segoe UI', system-ui, sans-serif", color: "#1f2937" },
  summaryStrip: { display: "flex", gap: 16, backgroundColor: "#ffffff", borderBottom: "1px solid #e2e8f0", padding: "12px 24px", overflowX: "auto", alignItems: "center" },
  summaryCard:  { display: "flex", flexDirection: "column", alignItems: "center", padding: "8px 20px", minWidth: 110, backgroundColor: "#f8fafc", border: "1px solid #e2e8f0", borderRadius: 8 },
  summaryLabel: { fontSize: 11, color: "#6b7280", fontWeight: 500 },
  summaryValue: { fontSize: 18, fontWeight: 700, color: "#0f172a", marginTop: 2 },
  pageHeader:   { padding: "20px 24px 8px", display: "flex", alignItems: "center", justifyContent: "space-between", flexWrap: "wrap", gap: 12 },
  pageTitle:    { fontSize: 22, fontWeight: 700, color: "#0f172a", margin: 0 },
  pageSubtitle: { fontSize: 13, color: "#64748b", marginTop: 2 },
  backLink:     { fontSize: 13, color: "#0369a1", textDecoration: "none", display: "flex", alignItems: "center", gap: 4, cursor: "pointer", background: "none", border: "none", padding: 0 },
  filterBar:    { display: "flex", gap: 12, padding: "10px 24px", alignItems: "center", flexWrap: "wrap", backgroundColor: "#ffffff", borderBottom: "1px solid #e2e8f0" },
  filterLabel:  { fontSize: 12, color: "#6b7280", fontWeight: 500 },
  select:       { fontSize: 13, padding: "5px 10px", border: "1px solid #d1d5db", borderRadius: 6, backgroundColor: "#ffffff", color: "#1f2937", cursor: "pointer" },
  tableWrap:    { padding: "16px 24px" },
  table:        { width: "100%", borderCollapse: "collapse", backgroundColor: "#ffffff", borderRadius: 10, overflow: "hidden", border: "1px solid #e2e8f0" },
  thead:        { backgroundColor: "#f1f5f9" },
  th:           { padding: "10px 14px", textAlign: "left", fontSize: 11, fontWeight: 700, color: "#374151", textTransform: "uppercase", letterSpacing: "0.06em", borderBottom: "1px solid #e2e8f0", cursor: "pointer", userSelect: "none", whiteSpace: "nowrap" },
  td:           { padding: "11px 14px", fontSize: 13, color: "#374151", borderBottom: "1px solid #f1f5f9", verticalAlign: "middle" },
  trHover:      { backgroundColor: "#f8fafc" },
  mockBanner:   { backgroundColor: "#fef3c7", borderBottom: "1px solid #fcd34d", padding: "6px 24px", fontSize: 12, color: "#92400e" },
  errorBox:     { margin: "24px", padding: "16px", backgroundColor: "#fee2e2", borderRadius: 8, color: "#991b1b", fontSize: 13 },
  emptyRow:     { textAlign: "center", padding: 32, color: "#9ca3af", fontSize: 13 },
  envErrBox:    { margin: "24px", padding: "16px", backgroundColor: "#fff7ed", border: "1px solid #fed7aa", borderRadius: 8, color: "#9a3412", fontSize: 13 },
  qualifyBtn:   { fontSize: 11, fontWeight: 600, color: "#0369a1", background: "none", border: "1px solid #bae6fd", borderRadius: 6, padding: "3px 10px", cursor: "pointer", whiteSpace: "nowrap" },
  // S-006: panel row TD — distinct bg + bottom border to group with its data row
  panelTd: {
    padding: "0 16px 12px 16px",
    backgroundColor: "#e0f2fe",
    borderBottom: "2px solid #0ea5e9",
  },
};

// ─── Component ────────────────────────────────────────────────────────────────
export default function GDAOpsTracker() {
  const [opps,       setOpps]       = useState([]);
  const [summary,    setSummary]    = useState(null);
  const [loading,    setLoading]    = useState(true);
  const [error,      setError]      = useState(null);
  const [envError,   setEnvError]   = useState(null);
  const [hoveredRow, setHoveredRow] = useState(null);

  const [dept,    setDept]    = useState("All");
  const [status,  setStatus]  = useState("All");
  const [minPwin, setMinPwin] = useState(0);
  const [sortKey, setSortKey] = useState("score");
  const [sortDir, setSortDir] = useState("desc");

  // S-006: open panel id + ref map for focus return
  const [openQualifyId, setOpenQualifyId] = useState(null);
  const qualifyBtnRefs = useRef({});   // { [oppId]: HTMLButtonElement }

  // ── Data load ──────────────────────────────────────────────────────────────
  useEffect(() => {
    let cancelled = false;

    if (USE_MOCK) {
      const t = setTimeout(() => {
        if (cancelled) return;
        setOpps(MOCK_OPPORTUNITIES);
        setSummary(MOCK_SUMMARY);
        setLoading(false);
      }, 300);
      return () => { cancelled = true; clearTimeout(t); };
    }

    fetchTop10()
      .then(env => {
        if (cancelled) return;
        setOpps(env.data?.opportunities || []);
        setSummary(env.data?.summary    || null);
        setLoading(false);
      })
      .catch(err => {
        if (cancelled) return;
        if (err.message.includes("envelope") || err.message.includes("non-JSON")) {
          setEnvError(err.message);
        } else {
          setError(err.message);
        }
        setLoading(false);
      });

    return () => { cancelled = true; };
  }, []);

  // ── Sort ───────────────────────────────────────────────────────────────────
  function handleSort(key) {
    if (sortKey === key) setSortDir(d => (d === "asc" ? "desc" : "asc"));
    else { setSortKey(key); setSortDir("desc"); }
  }
  function sortIndicator(key) {
    if (sortKey !== key) return " ↕";
    return sortDir === "asc" ? " ↑" : " ↓";
  }

  const visible = applyFilters(opps, { dept, status, minPwin, sortKey, sortDir });

  const shownSummary = {
    shown:     visible.length,
    total:     opps.length,
    avg_score: visible.length
      ? Math.round(visible.reduce((s, r) => s + (Number(r.score) || 0), 0) / visible.length)
      : "—",
    avg_pwin: visible.length
      ? Math.round(visible.reduce((s, r) => s + (Number(r.pwin)  || 0), 0) / visible.length)
      : "—",
    total_val: visible.reduce((s, r) => s + (Number(r.value) || 0), 0),
  };

  function goToLaunchpad(e) {
    e.preventDefault();
    window.location.href = "/";
  }

  // S-006: toggle panel; return focus to trigger on close
  function toggleQualify(oppId) {
    if (openQualifyId === oppId) {
      setOpenQualifyId(null);
      requestAnimationFrame(() => qualifyBtnRefs.current[oppId]?.focus());
    } else {
      setOpenQualifyId(oppId);
    }
  }

  function closePanel(oppId) {
    setOpenQualifyId(null);
    requestAnimationFrame(() => qualifyBtnRefs.current[oppId]?.focus());
  }

  // ── Render ─────────────────────────────────────────────────────────────────
  return (
    <div style={S.page}>

      {/* ── Persistent Financial KPI Strip (shared context) ───────────────── */}
      <GDAKpiStrip />

      {/* ── Tool-specific Summary Strip ───────────────────────────────────── */}
      <div style={S.summaryStrip}>
        <div style={S.summaryCard}>
          <span style={S.summaryLabel}>Showing</span>
          <span style={S.summaryValue}>{shownSummary.shown}/{shownSummary.total}</span>
        </div>
        <div style={S.summaryCard}>
          <span style={S.summaryLabel}>Avg Score</span>
          <span style={S.summaryValue}>{shownSummary.avg_score}</span>
        </div>
        <div style={S.summaryCard}>
          <span style={S.summaryLabel}>Avg P(Win)</span>
          <span style={S.summaryValue}>
            {typeof shownSummary.avg_pwin === "number" ? `${shownSummary.avg_pwin}%` : shownSummary.avg_pwin}
          </span>
        </div>
        <div style={S.summaryCard}>
          <span style={S.summaryLabel}>Total Value</span>
          <span style={S.summaryValue}>{fmtDollars(shownSummary.total_val)}</span>
        </div>
        <div style={{ ...S.summaryCard, marginLeft: "auto", borderColor: "#bfdbfe", backgroundColor: "#eff6ff" }}>
          <span style={{ ...S.summaryLabel, color: "#1e40af" }}>Pipeline Rule</span>
          <span style={{ ...S.summaryValue, color: "#1e40af", fontSize: 12 }}>Qualify to Add →</span>
        </div>
      </div>

      {/* ── Mock / live banner ───────────────────────────────────────────── */}
      {USE_MOCK ? (
        <div style={S.mockBanner}>
          ⚠ MOCK DATA — set <code>USE_MOCK = false</code> in GDAOpsTracker-6.jsx after Express API is live on :3001
        </div>
      ) : (
        <div style={{ ...S.mockBanner, backgroundColor: "#f0fdf4", borderColor: "#bbf7d0", color: "#166534" }}>
          ✓ LIVE DATA — <code>GET /api/opportunities/top10</code>
        </div>
      )}

      {/* ── Page Header ──────────────────────────────────────────────────── */}
      <div style={S.pageHeader}>
        <div>
          <h1 style={S.pageTitle}>Ops Tracker</h1>
          <div style={S.pageSubtitle}>
            Opportunity discovery and management · Qualify to move to Pipeline
          </div>
        </div>
        <a href="/" style={S.backLink} onClick={goToLaunchpad}>← Launchpad</a>
      </div>

      {/* ── Filter Bar ───────────────────────────────────────────────────── */}
      <div style={S.filterBar}>
        <span style={S.filterLabel}>Filter:</span>

        <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
          <label style={S.filterLabel} htmlFor="dept-filter">Dept</label>
          <select id="dept-filter" style={S.select} value={dept} onChange={e => setDept(e.target.value)}>
            {DEPTS.map(d => <option key={d}>{d}</option>)}
          </select>
        </div>

        <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
          <label style={S.filterLabel} htmlFor="status-filter">Status</label>
          <select id="status-filter" style={S.select} value={status} onChange={e => setStatus(e.target.value)}>
            {STATUSES.map(s => <option key={s}>{s}</option>)}
          </select>
        </div>

        <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
          <label style={S.filterLabel} htmlFor="pwin-filter">Min P(Win)</label>
          <select id="pwin-filter" style={S.select} value={minPwin} onChange={e => setMinPwin(Number(e.target.value))}>
            <option value={0}>Any</option>
            <option value={25}>≥ 25%</option>
            <option value={40}>≥ 40%</option>
            <option value={55}>≥ 55%</option>
            <option value={70}>≥ 70%</option>
          </select>
        </div>

        {(dept !== "All" || status !== "All" || minPwin > 0) && (
          <button
            style={{ ...S.select, backgroundColor: "#fee2e2", color: "#dc2626", border: "1px solid #fca5a5", cursor: "pointer" }}
            onClick={() => { setDept("All"); setStatus("All"); setMinPwin(0); }}
          >
            Clear
          </button>
        )}
      </div>

      {/* ── Table ────────────────────────────────────────────────────────── */}
      <div style={S.tableWrap}>

        {envError && (
          <div style={S.envErrBox}>
            <strong>API contract error:</strong> {envError}
            <div style={{ marginTop: 8, fontSize: 12 }}>
              Check <code>gda-api-routes.js</code> and Vite proxy config.
            </div>
          </div>
        )}

        {error && !envError && (
          <div style={S.errorBox}>
            <strong>Error loading opportunities:</strong> {error}
            <div style={{ marginTop: 8, fontSize: 12 }}>
              Check that Express is running on :3001 and <code>DATABASE_URL</code> is set.
            </div>
          </div>
        )}

        {loading && (
          <div style={{ padding: 32, textAlign: "center", color: "#64748b" }}>
            Loading opportunities…
          </div>
        )}

        {!loading && !error && !envError && (
          <>
            <table style={S.table}>
              <thead style={S.thead}>
                <tr>
                  {[
                    { key: "id",       label: "ID"       },
                    { key: "title",    label: "Title"    },
                    { key: "dept",     label: "Dept"     },
                    { key: "value",    label: "Value"    },
                    { key: "pwin",     label: "P(Win)"   },
                    { key: "score",    label: "Score"    },
                    { key: "status",   label: "Status"   },
                    { key: "due_date", label: "Due Date" },
                    { key: null,       label: "Actions"  },
                  ].map(col => (
                    <th
                      key={col.label}
                      style={{ ...S.th, cursor: col.key ? "pointer" : "default" }}
                      onClick={col.key ? () => handleSort(col.key) : undefined}
                    >
                      {col.label}{col.key ? sortIndicator(col.key) : ""}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {visible.length === 0 ? (
                  <tr>
                    <td colSpan={9} style={S.emptyRow}>
                      No opportunities match the current filters.
                    </td>
                  </tr>
                ) : (
                  visible.map(opp => {
                    const isOpen = openQualifyId === opp.id;
                    return (
                      <>
                        {/* ── Data row ────────────────────────────────── */}
                        <tr
                          key={opp.id}
                          style={hoveredRow === opp.id ? S.trHover : {}}
                          onMouseEnter={() => setHoveredRow(opp.id)}
                          onMouseLeave={() => setHoveredRow(null)}
                        >
                          <td style={{ ...S.td, fontFamily: "monospace", fontSize: 11, color: "#6b7280" }}>
                            {opp.id}
                          </td>
                          <td style={{ ...S.td, fontWeight: 500, maxWidth: 260 }}>{opp.title}</td>
                          <td style={S.td}>{opp.dept || "—"}</td>
                          <td style={{ ...S.td, fontWeight: 600, fontVariantNumeric: "tabular-nums" }}>
                            {fmtDollars(opp.value)}
                          </td>
                          <td style={S.td}><PwinBadge pwin={opp.pwin} /></td>
                          <td style={S.td}><ScoreBadge score={opp.score} /></td>
                          <td style={S.td}><StatusPill status={opp.status} /></td>
                          <td style={{ ...S.td, whiteSpace: "nowrap" }}>{fmtDate(opp.due_date)}</td>
                          <td style={S.td}>
                            {/* S-006: ref stored for focus-return on panel close */}
                            <button
                              ref={el => { qualifyBtnRefs.current[opp.id] = el; }}
                              style={{
                                ...S.qualifyBtn,
                                backgroundColor: isOpen ? "#e0f2fe" : "transparent",
                              }}
                              onClick={() => toggleQualify(opp.id)}
                              aria-expanded={isOpen}
                              aria-controls={`qualify-panel-${opp.id}`}
                              title="Preview qualification status (dry run — no changes)"
                            >
                              {isOpen ? "▲ Close" : "Preview Qualify"}
                            </button>
                          </td>
                        </tr>

                        {/* ── S-006: Inline qualify preview panel ─────── */}
                        {isOpen && (
                          <tr key={`${opp.id}-panel`}>
                            <td
                              colSpan={9}
                              style={S.panelTd}
                              id={`qualify-panel-${opp.id}`}
                            >
                              <QualifyPanel
                                oppId={opp.id}
                                onClose={() => closePanel(opp.id)}
                              />
                            </td>
                          </tr>
                        )}
                      </>
                    );
                  })
                )}
              </tbody>
            </table>

            {/* Pipeline rule callout */}
            <div style={{
              marginTop: 16, padding: "10px 16px",
              backgroundColor: "#eff6ff", border: "1px solid #bfdbfe",
              borderRadius: 8, fontSize: 12, color: "#1e40af",
            }}>
              <strong>Pipeline Rule:</strong> An opportunity does not become Pipeline until explicitly qualified.
              {" "}Use <em>Preview Qualify</em> per row to see what would change (dry run only).
              {" "}Real write requires approval gate — enforced server-side.
            </div>
          </>
        )}
      </div>
    </div>
  );
}
