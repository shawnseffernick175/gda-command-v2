/**
 * GDA Rebuild — Smoke Test Runner
 * S-006 | Phase 1
 *
 * CHANGES vs S-005 (gda-smoke-tests-5.js)
 * -----------------------------------------
 * - Suite header updated to S-006.
 * - testFinancialKpis(): assertion text updated to reference S-006 + GDAFinancialBible.
 *   All 7 KPI key checks carry forward unchanged.
 * - testQualifyDryRun(): added check for data.note field (soft — warn if absent,
 *   not a hard failure, since server may not supply it yet).
 * - testLaunchpadSummary(): strengthened to verify the three keys the S-006
 *   secondary strip depends on (total_opportunities, pipeline_count, active_risks).
 * - No existing hard failures weakened:
 *   • /api/schema/check all_ok:true still hard-fails.
 *   • /api/qualify dryRun:false → HTTP 400 + "not enabled" still hard-fails.
 *   • All envelope contract checks preserved.
 *
 * USE_MOCK notes (S-006):
 *   GDALaunchpad.jsx  — USE_MOCK controls top10 + launchpad summary mock.
 *   GDAOpsTracker-6   — USE_MOCK controls top10 table rows.
 *   GDAKpiContext      — KPI_USE_MOCK controls KPI strip values.
 *   GDAFinancialBible — reads from KPI context; no separate mock flag.
 *   Do not set any USE_MOCK = false until /api/schema/check passes all_ok:true.
 *
 * Usage:
 *   node gda-smoke-tests-6.js http://localhost:3001
 *   node gda-smoke-tests-6.js $GDA_PROD_URL
 *
 * Exit codes:
 *   0 — all tests passed
 *   1 — one or more tests failed
 */

"use strict";

// ─── Args ─────────────────────────────────────────────────────────────────────
const BASE = (process.argv[2] || "http://localhost:3001").replace(/\/$/, "");

// ─── Harness ──────────────────────────────────────────────────────────────────
let passed = 0, failed = 0;
const failures = [];

function pass(name) {
  console.log(`  ✓ ${name}`);
  passed++;
}

function fail(name, reason) {
  console.log(`  ✗ ${name}`);
  console.log(`      → ${reason}`);
  failed++;
  failures.push({ name, reason });
}

function warn(name, reason) {
  // Non-fatal: logged but does not increment failure count or affect exit code.
  console.log(`  ⚠ ${name} (non-fatal)`);
  console.log(`      → ${reason}`);
}

async function GET(path) {
  const r    = await fetch(`${BASE}${path}`);
  const body = await r.json().catch(() => null);
  return { status: r.status, body };
}

async function POST(path, payload) {
  const r = await fetch(`${BASE}${path}`, {
    method:  "POST",
    headers: { "Content-Type": "application/json" },
    body:    JSON.stringify(payload),
  });
  const body = await r.json().catch(() => null);
  return { status: r.status, body };
}

function checkEnvelope(name, body) {
  const required = ["success", "workflow", "action", "dryRun", "data", "meta", "error"];
  const missing  = required.filter(k => !(k in body));
  if (missing.length) {
    fail(`${name} — envelope contract`,
      `Missing fields: ${missing.join(", ")}. Every endpoint must return the full standard envelope.`
    );
    return false;
  }
  pass(`${name} — envelope contract`);
  return true;
}

// ─── Tests ────────────────────────────────────────────────────────────────────

// ── /api/health ───────────────────────────────────────────────────────────────
async function testHealth() {
  console.log("\n── /api/health");
  const { status, body } = await GET("/api/health");

  if (status === 200) pass("/api/health — status 200");
  else fail("/api/health — status 200", `Got HTTP ${status}`);

  if (!body) { fail("/api/health — body parseable", "Not valid JSON"); return; }

  checkEnvelope("/api/health", body);

  if (body.data?.db === "ok") pass("/api/health — db ok");
  else fail("/api/health — db ok",
    `db is "${body.data?.db}". Msg: ${body.data?.db_message}. Check DATABASE_URL + Postgres.`
  );
}

// ── /api/financial/kpis ───────────────────────────────────────────────────────
// S-006: GDAFinancialBible reads these keys via useKpi() context.
// All 7 must be present for the Financial Bible page to render correctly.
async function testFinancialKpis() {
  console.log("\n── /api/financial/kpis  [S-006: consumed by GDAFinancialBible]");
  const { status, body } = await GET("/api/financial/kpis");

  if (status === 200) pass("/api/financial/kpis — status 200");
  else fail("/api/financial/kpis — status 200", `Got HTTP ${status}`);

  if (!body) { fail("/api/financial/kpis — body parseable", "Not valid JSON"); return; }

  checkEnvelope("/api/financial/kpis", body);

  if (!body.success) {
    fail("/api/financial/kpis — success:true",
      `success is false. Error: ${body.error}. ` +
      "financial_kpis_current view may be missing or empty."
    );
    return;
  }
  pass("/api/financial/kpis — success:true");

  // S-006: GDAFinancialBible validates these on mount via GDAKpiContext.
  const required = ["orders", "sales", "ebit", "ros", "funded_backlog", "backlog", "gross_profit"];
  const kpis     = body.data?.kpis || {};
  const missing  = required.filter(k => !(k in kpis));
  if (missing.length) {
    fail("/api/financial/kpis — all 7 KPI keys under data.kpis",
      `Missing: ${missing.join(", ")}. ` +
      "GDAFinancialBible overview grid requires all 7 keys. Check financial_kpis_current view."
    );
  } else {
    pass("/api/financial/kpis — all 7 KPI keys present (orders, sales, ebit, ros, funded_backlog, backlog, gross_profit)");
  }
}

// ── /api/launchpad/summary ────────────────────────────────────────────────────
// S-006: GDALaunchpad secondary strip depends on these three keys.
async function testLaunchpadSummary() {
  console.log("\n── /api/launchpad/summary  [S-006: drives Launchpad secondary strip]");
  const { status, body } = await GET("/api/launchpad/summary");

  if (status === 200) pass("/api/launchpad/summary — status 200");
  else fail("/api/launchpad/summary — status 200", `Got HTTP ${status}`);

  if (!body) { fail("/api/launchpad/summary — body parseable", "Not valid JSON"); return; }

  checkEnvelope("/api/launchpad/summary", body);

  // S-006: strip specifically reads these three fields
  const d = body.data || {};
  const stripKeys = ["total_opportunities", "pipeline_count", "active_risks"];
  const missingStrip = stripKeys.filter(k => !(k in d));
  if (missingStrip.length) {
    fail("/api/launchpad/summary — S-006 strip keys present",
      `Missing: ${missingStrip.join(", ")}. ` +
      "GDALaunchpad secondary strip reads total_opportunities, pipeline_count, active_risks. " +
      `Got: ${Object.keys(d).join(", ")}`
    );
  } else {
    pass("/api/launchpad/summary — S-006 strip keys present (total_opportunities, pipeline_count, active_risks)");
  }
}

// ── /api/opportunities/top10 ──────────────────────────────────────────────────
async function testTop10() {
  console.log("\n── /api/opportunities/top10");
  const { status, body } = await GET("/api/opportunities/top10");

  if (status === 200) pass("/api/opportunities/top10 — status 200");
  else fail("/api/opportunities/top10 — status 200", `Got HTTP ${status}`);

  if (!body) { fail("/api/opportunities/top10 — body parseable", "Not valid JSON"); return; }

  checkEnvelope("/api/opportunities/top10", body);

  if (!body.success) {
    fail("/api/opportunities/top10 — success:true", `success false. Error: ${body.error}`);
    return;
  }
  pass("/api/opportunities/top10 — success:true");

  const opps = body.data?.opportunities;
  if (!Array.isArray(opps)) {
    fail("/api/opportunities/top10 — data.opportunities is array", `Got: ${typeof opps}`);
    return;
  }
  pass("/api/opportunities/top10 — data.opportunities is array");

  if (opps.length > 0) {
    const cols        = ["id", "title", "dept", "value", "pwin", "score", "status", "due_date"];
    const missingCols = cols.filter(c => !(c in opps[0]));
    if (missingCols.length)
      fail("/api/opportunities/top10 — row has required columns",
        `Missing: ${missingCols.join(", ")}.`
      );
    else
      pass("/api/opportunities/top10 — row has required columns");
  }

  pass(`/api/opportunities/top10 — returned ${opps.length} rows`);
}

// ── /api/opportunities/:id/qualify ────────────────────────────────────────────
async function testQualifyDryRun() {
  console.log("\n── /api/opportunities/:id/qualify (dryRun:true)  [S-006: panel note field]");

  const top10   = await GET("/api/opportunities/top10");
  const firstId = top10.body?.data?.opportunities?.[0]?.id;

  // ── 404 on missing ID ──────────────────────────────────────────────────────
  const { status: s404, body: b404 } = await POST(
    "/api/opportunities/NONEXISTENT-ID-999/qualify",
    { dryRun: true }
  );

  if (s404 === 404) pass("/api/qualify dryRun — 404 on missing ID");
  else fail("/api/qualify dryRun — 404 on missing ID", `Expected 404, got ${s404}`);

  if (b404) checkEnvelope("/api/qualify dryRun 404", b404);

  if (b404?.dryRun === true) pass("/api/qualify dryRun — dryRun:true in 404 envelope");
  else fail("/api/qualify dryRun — dryRun:true in 404 envelope", `dryRun: ${b404?.dryRun}`);

  // ── Real ID preview ────────────────────────────────────────────────────────
  if (firstId) {
    const { status: s200, body: b200 } = await POST(
      `/api/opportunities/${firstId}/qualify`,
      { dryRun: true }
    );

    if (s200 === 200) pass(`/api/qualify dryRun — 200 on real ID (${firstId})`);
    else fail(`/api/qualify dryRun — 200 on real ID (${firstId})`, `Got ${s200}`);

    if (b200) checkEnvelope("/api/qualify dryRun 200", b200);

    if (b200?.dryRun === true) pass("/api/qualify dryRun — dryRun:true confirmed");
    else fail("/api/qualify dryRun — dryRun:true confirmed", `dryRun: ${b200?.dryRun}`);

    const d = b200?.data || {};

    // S-005 panel fields (hard assertions carry forward)
    const panelFields   = ["current_status", "proposed_status", "would_change", "already_qualified"];
    const missingPanel  = panelFields.filter(f => !(f in d));
    if (missingPanel.length) {
      fail("/api/qualify dryRun — S-005/S-006 panel fields present",
        `Missing: ${missingPanel.join(", ")}. QualifyPanel requires all four.`
      );
    } else {
      pass("/api/qualify dryRun — panel fields present (current_status, proposed_status, would_change, already_qualified)");
    }

    // S-006: note field — soft check (server may not supply yet)
    if ("note" in d) {
      pass("/api/qualify dryRun — data.note field present (S-006 panel renders it)");
    } else {
      warn("/api/qualify dryRun — data.note field",
        "data.note not present in qualify response. " +
        "GDAOpsTracker-6 panel renders it when available; absent is acceptable. " +
        "Add note to the qualify route handler when meaningful server context exists."
      );
    }

    if ("fields_to_update" in d || "already_qualified" in d)
      pass("/api/qualify dryRun — preview data structure present");
    else
      fail("/api/qualify dryRun — preview data structure present",
        `Missing fields_to_update or already_qualified. Got: ${Object.keys(d).join(", ")}`
      );

  } else {
    console.log("  ⚠  Skipping real-ID qualify test — top10 returned no rows (DB may be empty)");
  }

  // ── dryRun:false MUST be blocked — unchanged hard gate ────────────────────
  console.log("\n── /api/opportunities/:id/qualify (dryRun:false — must still be blocked in S-006)");

  const { status: s400, body: b400 } = await POST(
    "/api/opportunities/NONEXISTENT-ID-999/qualify",
    { dryRun: false }
  );

  if (s400 === 400) pass("/api/qualify dryRun:false — correctly returns HTTP 400");
  else fail("/api/qualify dryRun:false — correctly returns HTTP 400",
    `Expected 400, got ${s400}. Safety gate must not be removed. ` +
    "S-006 UI never sends dryRun:false. Check gda-api-routes.js."
  );

  if (b400?.success === false) pass("/api/qualify dryRun:false — success:false");
  else fail("/api/qualify dryRun:false — success:false", `success was ${b400?.success}`);

  const errMsg         = (b400?.error || "").toLowerCase();
  const hasExpectedMsg = errMsg.includes("not enabled") || errMsg.includes("s-004") ||
                         errMsg.includes("s-005")       || errMsg.includes("s-006") ||
                         errMsg.includes("dry run");
  if (hasExpectedMsg) pass("/api/qualify dryRun:false — error message explains writes not enabled");
  else fail("/api/qualify dryRun:false — error message explains writes not enabled",
    `Error was: "${b400?.error}". Should mention "not enabled", sprint ref, or "dry run".`
  );

  if (b400?.dryRun === false) pass("/api/qualify dryRun:false — dryRun:false echoed in envelope");
  else fail("/api/qualify dryRun:false — dryRun:false echoed in envelope",
    `dryRun was ${b400?.dryRun}`
  );

  if (b400) checkEnvelope("/api/qualify dryRun:false error response", b400);
}

// ── /api/schema/check ─────────────────────────────────────────────────────────
// Unchanged from S-005. all_ok:false is a hard suite failure.
// Do not set any USE_MOCK = false until this passes.
async function testSchemaCheck() {
  console.log("\n── /api/schema/check");
  const { status, body } = await GET("/api/schema/check");

  if (status === 200 || status === 500) pass(`/api/schema/check — responded (HTTP ${status})`);
  else fail("/api/schema/check — responded", `Unexpected ${status}`);

  if (!body) { fail("/api/schema/check — body parseable", "Not valid JSON"); return; }

  checkEnvelope("/api/schema/check", body);

  const checks = body.data?.checks;
  if (!Array.isArray(checks)) { fail("/api/schema/check — data.checks is array", `Got ${typeof checks}`); return; }
  pass("/api/schema/check — data.checks is array");

  const summary = body.data?.summary;
  if (Array.isArray(summary) && summary.length > 0)
    pass(`/api/schema/check — data.summary has ${summary.length} plain-English line(s)`);
  else
    fail("/api/schema/check — data.summary present", `Got: ${JSON.stringify(summary)}`);

  for (const c of checks) {
    if (c.error) {
      fail(`/api/schema/check — ${c.name} query ok`, `Error: ${c.error}`);
    } else if (!c.exists) {
      fail(`/api/schema/check — ${c.name} exists`,
        `"${c.name}" not found. Run schema setup SQL before going live.`
      );
    } else if (!c.has_rows) {
      fail(`/api/schema/check — ${c.name} has rows`,
        `"${c.name}" exists but is empty. Seed before going live.`
      );
    } else {
      pass(`/api/schema/check — ${c.name} exists and has rows`);
    }
  }

  if (body.data?.all_ok === true)
    pass("/api/schema/check — all_ok:true");
  else
    fail("/api/schema/check — all_ok:true",
      "all_ok is false — tables/views missing or empty. " +
      "Do not set USE_MOCK = false in any component until this passes."
    );
}

// ── Unknown route ──────────────────────────────────────────────────────────────
async function testNotFound() {
  console.log("\n── Unknown route → 404 JSON envelope");
  const { status, body } = await GET("/api/this-does-not-exist-s006");

  if (status === 404) pass("Unknown route — status 404");
  else fail("Unknown route — status 404", `Got ${status}`);

  if (body && typeof body === "object" && "success" in body)
    pass("Unknown route — returns JSON envelope (not HTML)");
  else
    fail("Unknown route — returns JSON envelope",
      "React should never receive HTML for missing API routes."
    );
}

// ─── Runner ───────────────────────────────────────────────────────────────────
async function run() {
  console.log(`\nGDA Smoke Tests — S-006`);
  console.log(`Target: ${BASE}`);
  console.log("─".repeat(60));

  try {
    await testHealth();
    await testFinancialKpis();
    await testLaunchpadSummary();
    await testTop10();
    await testQualifyDryRun();
    await testSchemaCheck();
    await testNotFound();
  } catch (err) {
    console.error("\n[FATAL] Test runner threw an unexpected error:");
    console.error(err);
    console.error("\nIs Express running?\n  cd api && npm run dev\n");
    process.exit(1);
  }

  console.log("\n" + "─".repeat(60));
  console.log(`Results: ${passed} passed, ${failed} failed`);

  if (failed === 0) {
    console.log("\n✅  ALL TESTS PASSED — S-006 API layer is clean.\n");
    process.exit(0);
  } else {
    console.log("\n❌  FAILURES:\n");
    for (const f of failures) {
      console.log(`  • ${f.name}`);
      console.log(`      ${f.reason}`);
    }
    console.log();
    process.exit(1);
  }
}

run();
