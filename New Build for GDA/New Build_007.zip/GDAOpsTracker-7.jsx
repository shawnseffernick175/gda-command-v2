/**
 * GDA Rebuild — Ops Tracker Page
 * S-007 | Phase 1
 *
 * CHANGES vs S-006 (GDAOpsTracker-6.jsx)
 * ----------------------------------------
 * 1. Approve & Qualify two-step flow (S-007 primary feature):
 *    - Available ONLY when dryRun preview has succeeded AND would_change is true.
 *    - Step 1: "Approve & Qualify" button appears inside the preview panel.
 *    - Step 2: Inline confirm panel replaces step 1 — user must click "Confirm Qualify"
 *      to actually send the write request. Cancel returns to preview state.
 *    - Only after confirmation is POST /api/opportunities/:id/qualify sent with
 *      { dryRun: false, approve: true }.
 *    - It is impossible in this code path to send dryRun:false without approve:true.
 *    - No single click can both preview and write.
 *
 * 2. Post-write behavior:
 *    - On success: refreshes top10 table via GET /api/opportunities/top10.
 *    - Preview panel updates to show "Already qualified" state.
 *    - Success banner shown briefly in the panel.
 *
 * 3. QUALIFY_WRITES_ENABLED signal from server:
 *    - When server returns a 400 with error containing "QUALIFY_WRITES_ENABLED" or
 *      "disabled", the Approve & Qualify button is hidden and a note is shown instead.
 *    - In all other environments where preview works, the approve path is shown.
 *
 * 4. Accessibility:
 *    - Approve button and Confirm button are Tab-reachable.
 *    - Cancel returns focus to the Approve button.
 *    - Existing keyboard focus behavior (panel focus on open, return to trigger on close)
 *      is preserved unchanged.
 *
 * 5. USE_MOCK behavior: unchanged from S-006.
 *    QUALIFY_WRITES_ENABLED on the server controls whether real writes succeed;
 *    the React UI always shows the approve path when would_change is true.
 *
 * REACT STAYS THIN
 * ----------------
 * No business logic beyond calling the API and rendering responses.
 * All write safety is enforced server-side. React enforces the UI contract only.
 *
 * SAFETY INVARIANT
 * ----------------
 * The approveQualify() function always sends { dryRun: false, approve: true }.
 * The constant APPROVE_PAYLOAD is defined once and used once.
 * No code path in this file can send dryRun:false without approve:true.
 */

import { useState, useEffect, useRef } from "react";
import { GDAKpiStrip } from "./GDAKpiContext.jsx";

// ─── Mock data ────────────────────────────────────────────────────────────────
const MOCK_OPPORTUNITIES = [
  { id: "OPP-001", title: "Dept of Army SIGINT Modernization",  dept: "Army",      value: 4200000,  pwin: 72, score: 91, status: "Tracking",    due_date: "2026-06-15" },
  { id: "OPP-002", title: "AFRL Advanced ISR Platform Study",   dept: "Air Force", value: 1850000,  pwin: 58, score: 84, status: "Tracking",    due_date: "2026-05-30" },
  { id: "OPP-003", title: "DHS Border Surveillance Tech",       dept: "DHS",       value: 3100000,  pwin: 45, score: 79, status: "Tracking",    due_date: "2026-07-01" },
  { id: "OPP-004", title: "Navy C2 Comms Upgrade Phase II",     dept: "Navy",      value: 7400000,  pwin: 61, score: 78, status: "Tracking",    due_date: "2026-08-20" },
  { id: "OPP-005", title: "SOCOM Tactical Edge Computing",      dept: "SOCOM",     value: 2250000,  pwin: 55, score: 74, status: "Tracking",    due_date: "2026-06-05" },
  { id: "OPP-006", title: "NRO Ground Station Refresh",         dept: "NRO",       value: 5600000,  pwin: 40, score: 71, status: "Identifying", due_date: "2026-09-10" },
  { id: "OPP-007", title: "DISA Zero Trust Architecture BPA",   dept: "DISA",      value: 890000,   pwin: 68, score: 69, status: "Tracking",    due_date: "2026-05-22" },
  { id: "OPP-008", title: "Army Cyber Range Infrastructure",    dept: "Army",      value: 3350000,  pwin: 38, score: 65, status: "Identifying", due_date: "2026-10-01" },
  { id: "OPP-009", title: "NSA Analytics Modernization IDIQ",   dept: "NSA",       value: 12000000, pwin: 25, score: 62, status: "Identifying", due_date: "2026-11-15" },
  { id: "OPP-010", title: "USMC Logistics Automation Pilot",    dept: "USMC",      value: 640000,   pwin: 52, score: 58, status: "Tracking",    due_date: "2026-06-28" },
];

const MOCK_SUMMARY = {
  total_opportunities: 10,
  avg_score:  73,
  avg_pwin:   51,
  total_value: 41280000,
};

// ─── Config ───────────────────────────────────────────────────────────────────
export const USE_MOCK = true;

// ─── S-007: Approve payload — defined once, used once. Invariant enforced. ───
// This is the only place in this file where { dryRun: false, approve: true } exists.
// approveQualify() uses APPROVE_PAYLOAD. Nothing else does.
const APPROVE_PAYLOAD = Object.freeze({ dryRun: false, approve: true });

// ─── Helpers ──────────────────────────────────────────────────────────────────
function fmtDollars(n) {
  if (n == null) return "—";
  if (n >= 1_000_000) return `$${(n / 1_000_000).toFixed(1)}M`;
  if (n >= 1_000)     return `$${(n / 1_000).toFixed(0)}K`;
  return `$${n}`;
}

function fmtDate(d) {
  if (!d) return "—";
  try { return new Date(d).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" }); }
  catch { return d; }
}

function PwinBadge({ pwin }) {
  const v = Number(pwin) || 0;
  let bg  = "#fee2e2";
  if (v >= 65)      bg = "#dcfce7";
  else if (v >= 45) bg = "#fef9c3";
  return (
    <span style={{
      display: "inline-block", padding: "2px 8px", borderRadius: 12,
      fontSize: 12, fontWeight: 600, backgroundColor: bg,
      color: "#1f2937", minWidth: 40, textAlign: "center",
    }}>
      {v}%
    </span>
  );
}

function ScoreBadge({ score }) {
  const v = Number(score) || 0;
  let color = "#6b7280";
  if (v >= 80)      color = "#15803d";
  else if (v >= 60) color = "#b45309";
  else              color = "#dc2626";
  return <span style={{ fontWeight: 700, color }}>{v}</span>;
}

function StatusPill({ status }) {
  const map = {
    Pipeline:    { bg: "#dbeafe", color: "#1e40af" },
    Tracking:    { bg: "#e0f2fe", color: "#0369a1" },
    Identifying: { bg: "#f3f4f6", color: "#374151" },
    Pursuing:    { bg: "#fef9c3", color: "#92400e" },
    Lost:        { bg: "#fee2e2", color: "#991b1b" },
    "No Bid":    { bg: "#f3f4f6", color: "#9ca3af" },
  };
  const s = map[status] || { bg: "#f3f4f6", color: "#374151" };
  return (
    <span style={{
      display: "inline-block", padding: "2px 10px", borderRadius: 12,
      fontSize: 12, fontWeight: 600, backgroundColor: s.bg, color: s.color,
    }}>
      {status || "—"}
    </span>
  );
}

// ─── Filters ──────────────────────────────────────────────────────────────────
const DEPTS    = ["All", "Army", "Air Force", "Navy", "USMC", "SOCOM", "DHS", "DISA", "NRO", "NSA", "Other"];
const STATUSES = ["All", "Tracking", "Identifying", "Pursuing", "Pipeline", "Lost", "No Bid"];

function applyFilters(rows, { dept, status, minPwin, sortKey, sortDir }) {
  let out = [...rows];
  if (dept   !== "All") out = out.filter(r => r.dept   === dept);
  if (status !== "All") out = out.filter(r => r.status === status);
  if (minPwin > 0)      out = out.filter(r => (Number(r.pwin) || 0) >= minPwin);
  if (sortKey) {
    out.sort((a, b) => {
      let av = a[sortKey], bv = b[sortKey];
      if (typeof av === "string") av = av.toLowerCase();
      if (typeof bv === "string") bv = bv.toLowerCase();
      return (av < bv ? -1 : av > bv ? 1 : 0) * (sortDir === "asc" ? 1 : -1);
    });
  }
  return out;
}

// ─── API: top10 ───────────────────────────────────────────────────────────────
async function fetchTop10() {
  const resp        = await fetch("/api/opportunities/top10");
  const contentType = resp.headers.get("content-type") || "";
  if (!contentType.includes("application/json")) {
    throw new Error(
      `API returned non-JSON (HTTP ${resp.status}, Content-Type: "${contentType}"). ` +
      "Check Express :3001 and Vite proxy."
    );
  }
  const env      = await resp.json();
  const required = ["success", "workflow", "action", "dryRun", "data", "meta", "error"];
  const missing  = required.filter(k => !(k in env));
  if (missing.length) throw new Error(`Missing envelope fields: ${missing.join(", ")}. Check gda-api-routes.js.`);
  if (!env.success)   throw new Error(env.error || "API returned success:false with no error.");
  return env;
}

// ─── API: qualify preview — dryRun:true ONLY ──────────────────────────────────
// SAFETY: This function NEVER sends dryRun:false. The value is hardcoded below.
async function fetchQualifyPreview(id) {
  const resp = await fetch(`/api/opportunities/${encodeURIComponent(id)}/qualify`, {
    method:  "POST",
    headers: { "Content-Type": "application/json" },
    body:    JSON.stringify({ dryRun: true }),   // ← hardcoded; never false
  });
  const contentType = resp.headers.get("content-type") || "";
  if (!contentType.includes("application/json")) {
    throw Object.assign(new Error(`Non-JSON response (HTTP ${resp.status}).`), { httpStatus: resp.status });
  }
  const env = await resp.json();
  if (resp.status === 404) return { notFound: true, env };
  return { notFound: false, httpStatus: resp.status, env };
}

// ─── API: qualify write — dryRun:false + approve:true ─────────────────────────
// S-007: This function ALWAYS sends APPROVE_PAYLOAD = { dryRun: false, approve: true }.
// It is called ONLY after the user completes the two-step confirm flow.
// SAFETY INVARIANT: dryRun:false is never sent without approve:true in this file.
async function approveQualify(id) {
  const resp = await fetch(`/api/opportunities/${encodeURIComponent(id)}/qualify`, {
    method:  "POST",
    headers: { "Content-Type": "application/json" },
    body:    JSON.stringify(APPROVE_PAYLOAD),   // ← { dryRun: false, approve: true }
  });
  const contentType = resp.headers.get("content-type") || "";
  if (!contentType.includes("application/json")) {
    throw Object.assign(new Error(`Non-JSON response (HTTP ${resp.status}).`), { httpStatus: resp.status });
  }
  const env = await resp.json();
  return { httpStatus: resp.status, env };
}

// ─── Qualify Panel (S-007) ────────────────────────────────────────────────────
// Extends S-006 panel with the two-step Approve & Qualify flow.
//
// Approve flow states (approveState):
//   null       → preview shown, "Approve & Qualify" button shown (if would_change)
//   "confirm"  → inline confirm panel shown, "Confirm Qualify" + "Cancel" buttons
//   "writing"  → spinner/disabling while POST in flight
//   "success"  → success banner shown; panel reflects qualified state
//   "error"    → write error shown; can retry from panel
//   "disabled" → server signals QUALIFY_WRITES_ENABLED=false; button hidden, note shown
//
// After success: parent's onRefresh() is called to reload top10 table.

function QualifyPanel({ oppId, onClose, onRefresh }) {
  const [loading,      setLoading]      = useState(true);
  const [result,       setResult]       = useState(null);
  const [fetchErr,     setFetchErr]     = useState(null);

  // S-007: approve flow state
  const [approveState, setApproveState] = useState(null);  // null | "confirm" | "writing" | "success" | "error" | "disabled"
  const [writeResult,  setWriteResult]  = useState(null);  // successful write envelope data
  const [writeErr,     setWriteErr]     = useState(null);  // write error string

  // S-006 carry-forward: panel container takes focus when content is ready
  const panelRef    = useRef(null);
  const approveRef  = useRef(null);  // S-007: "Approve & Qualify" button
  const confirmRef  = useRef(null);  // S-007: "Confirm Qualify" button

  useEffect(() => {
    let cancelled = false;
    fetchQualifyPreview(oppId)
      .then(r  => { if (!cancelled) { setResult(r);          setLoading(false); } })
      .catch(e => { if (!cancelled) { setFetchErr(e.message); setLoading(false); } });
    return () => { cancelled = true; };
  }, [oppId]);

  // Move focus into the panel container once content arrives
  useEffect(() => {
    if (!loading && panelRef.current) {
      panelRef.current.focus();
    }
  }, [loading]);

  // S-007: when confirm step appears, move focus to confirm button
  useEffect(() => {
    if (approveState === "confirm" && confirmRef.current) {
      confirmRef.current.focus();
    }
  }, [approveState]);

  // S-007: handle "Approve & Qualify" button click — shows confirm step
  function handleApproveClick() {
    setApproveState("confirm");
  }

  // S-007: handle "Cancel" in confirm step — return focus to approve button
  function handleCancelConfirm() {
    setApproveState(null);
    requestAnimationFrame(() => approveRef.current?.focus());
  }

  // S-007: handle "Confirm Qualify" — send the real write
  // SAFETY: this is the ONLY place approveQualify() is called.
  // APPROVE_PAYLOAD = { dryRun: false, approve: true } — hardcoded in approveQualify().
  async function handleConfirmQualify() {
    setApproveState("writing");
    setWriteErr(null);
    try {
      const { httpStatus, env } = await approveQualify(oppId);

      if (env?.success === true) {
        setWriteResult(env.data);
        setApproveState("success");
        // Refresh top10 so table reflects the new Pipeline status
        if (onRefresh) onRefresh();
      } else {
        const errMsg = env?.error || "Unknown error from qualify write.";
        // Detect "writes disabled" server signal so we can show the right message
        const isDisabled = errMsg.toLowerCase().includes("qualify_writes_enabled") ||
                           errMsg.toLowerCase().includes("disabled");
        setWriteErr(errMsg);
        setApproveState(isDisabled ? "disabled" : "error");
      }
    } catch (e) {
      setWriteErr(e.message);
      setApproveState("error");
    }
  }

  // ── Styles ─────────────────────────────────────────────────────────────────
  const wrap = {
    display: "flex",
    alignItems: "stretch",
    borderRadius: 8,
    overflow: "hidden",
  };
  const accent = {
    width: 4,
    backgroundColor: "#0ea5e9",
    flexShrink: 0,
  };
  const inner = {
    flex: 1,
    backgroundColor: "#f0f9ff",
    border: "1px solid #bae6fd",
    borderLeft: "none",
    padding: "14px 18px 14px 16px",
    fontSize: 13,
    color: "#0c4a6e",
    position: "relative",
    outline: "none",
  };
  const closeBtnStyle = {
    position: "absolute", top: 10, right: 12,
    background: "none", border: "1px solid #bae6fd",
    borderRadius: 4, cursor: "pointer",
    color: "#0369a1", fontSize: 16, lineHeight: 1,
    padding: "1px 6px",
  };
  const dryRunBadge = {
    display: "inline-block", padding: "2px 10px",
    backgroundColor: "#fef9c3", border: "1px solid #fde68a",
    borderRadius: 12, fontSize: 11, fontWeight: 700,
    color: "#92400e", marginBottom: 10, letterSpacing: "0.04em",
  };
  const fKey = { color: "#64748b", fontWeight: 600, marginRight: 6, fontSize: 12 };
  const fVal = { color: "#0f172a", fontWeight: 500 };

  // S-007: approve button style
  const approveBtnStyle = {
    marginTop: 14,
    padding: "7px 16px",
    backgroundColor: "#1e40af",
    color: "#ffffff",
    border: "1px solid #1e3a8a",
    borderRadius: 6,
    fontSize: 12,
    fontWeight: 700,
    cursor: "pointer",
    letterSpacing: "0.03em",
  };

  // S-007: confirm panel style
  const confirmPanelStyle = {
    marginTop: 14,
    padding: "12px 16px",
    backgroundColor: "#fef3c7",
    border: "1px solid #fcd34d",
    borderRadius: 8,
    fontSize: 12,
    color: "#78350f",
  };

  const confirmBtnStyle = {
    marginTop: 10,
    marginRight: 8,
    padding: "7px 16px",
    backgroundColor: "#b45309",
    color: "#ffffff",
    border: "none",
    borderRadius: 6,
    fontSize: 12,
    fontWeight: 700,
    cursor: "pointer",
  };

  const cancelBtnStyle = {
    marginTop: 10,
    padding: "7px 14px",
    backgroundColor: "transparent",
    color: "#78350f",
    border: "1px solid #fcd34d",
    borderRadius: 6,
    fontSize: 12,
    cursor: "pointer",
  };

  return (
    <div style={wrap}>
      {/* S-006 carry-forward: left accent bar */}
      <div style={accent} aria-hidden="true" />

      {/* Panel body — receives focus on open */}
      <div
        ref={panelRef}
        style={inner}
        tabIndex={-1}
        role="region"
        aria-label={`Qualify panel for ${oppId}`}
      >
        {/* Close button — keyboard accessible */}
        <button
          style={closeBtnStyle}
          onClick={onClose}
          aria-label="Close qualify panel"
          title="Close (Esc)"
        >
          ×
        </button>

        <div style={dryRunBadge}>⚠ DRY RUN — no changes until you Approve & Qualify</div>

        {/* ── Loading ──────────────────────────────────────────────────── */}
        {loading && (
          <div style={{ color: "#0369a1" }}>Checking qualify status…</div>
        )}

        {/* ── Fetch error ───────────────────────────────────────────────── */}
        {!loading && fetchErr && (
          <div style={{ color: "#dc2626" }}>
            <strong>Error:</strong> {fetchErr}
          </div>
        )}

        {/* ── 404 / out of sync ─────────────────────────────────────────── */}
        {!loading && !fetchErr && result?.notFound && (
          <div style={{ color: "#92400e" }}>
            <strong>Not found / out of sync</strong> — Opportunity{" "}
            <code>{oppId}</code> was not found on the server.
            The table may be showing stale data. Refresh to resync.
          </div>
        )}

        {/* ── Preview data ──────────────────────────────────────────────── */}
        {!loading && !fetchErr && result && !result.notFound && (() => {
          const env = result.env;
          if (!env?.success) {
            return (
              <div style={{ color: "#dc2626" }}>
                <strong>API error:</strong> {env?.error || "Unknown error from qualify endpoint."}
              </div>
            );
          }
          const d = env.data || {};

          // S-007: success state — write completed
          if (approveState === "success" && writeResult) {
            return (
              <>
                <div style={{
                  padding: "12px 16px", marginBottom: 12,
                  backgroundColor: "#dcfce7", border: "1px solid #86efac",
                  borderRadius: 8, fontSize: 13, color: "#14532d",
                }}>
                  <strong>✓ Qualified.</strong>{" "}
                  {oppId} is now <strong>Pipeline</strong>.
                  {writeResult.note && <div style={{ marginTop: 4, fontSize: 11, color: "#166534" }}>{writeResult.note}</div>}
                </div>
                <div style={{ marginBottom: 6 }}>
                  <span style={fKey}>Previous Status:</span>
                  <span style={fVal}>{writeResult.previous_status || "—"}</span>
                </div>
                <div style={{ marginBottom: 6 }}>
                  <span style={fKey}>New Status:</span>
                  <span style={{ ...fVal, color: "#1e40af", fontWeight: 700 }}>{writeResult.new_status || "Pipeline"}</span>
                </div>
                <div style={{ marginBottom: 6 }}>
                  <span style={fKey}>Qualified At:</span>
                  <span style={fVal}>{writeResult.qualified_at ? new Date(writeResult.qualified_at).toLocaleString() : "—"}</span>
                </div>
                <div style={{ marginTop: 10, fontSize: 11, color: "#64748b" }}>
                  Table refreshed. Close this panel to continue.
                </div>
              </>
            );
          }

          return (
            <>
              <div style={{ fontWeight: 700, marginBottom: 10, color: "#0c4a6e" }}>
                Qualify Preview — {oppId}
              </div>

              {[
                ["Current Status",    d.current_status    ?? "—"],
                ["Proposed Status",   d.proposed_status   ?? "—"],
                ["Would Change",
                  d.would_change != null
                    ? (d.would_change ? "Yes" : "No")
                    : "—"],
                ["Already Qualified",
                  d.already_qualified != null
                    ? (d.already_qualified ? "Yes — already pipeline" : "No")
                    : "—"],
              ].map(([k, v]) => (
                <div key={k} style={{ marginBottom: 6 }}>
                  <span style={fKey}>{k}:</span>
                  <span style={fVal}>{String(v)}</span>
                </div>
              ))}

              {Array.isArray(d.fields_to_update) && d.fields_to_update.length > 0 && (
                <div style={{ marginTop: 10 }}>
                  <div style={{ ...fKey, display: "block", marginBottom: 4 }}>
                    Fields that would update:
                  </div>
                  <ul style={{ margin: 0, paddingLeft: 18, fontSize: 12, color: "#0f172a" }}>
                    {d.fields_to_update.map((f, i) => (
                      <li key={i}>{typeof f === "object" ? JSON.stringify(f) : f}</li>
                    ))}
                  </ul>
                </div>
              )}

              {/* S-006 carry-forward: server note */}
              {d.note && (
                <div style={{
                  marginTop: 10, paddingTop: 8,
                  borderTop: "1px solid #bae6fd",
                  fontSize: 11, color: "#475569",
                }}>
                  <strong>Server note:</strong> {d.note}
                </div>
              )}

              {/* S-007: Approve gate — only shown when would_change is true */}
              {d.would_change === true && (
                <div style={{
                  marginTop: 14, paddingTop: 12,
                  borderTop: "1px solid #bae6fd",
                }}>

                  {/* "Disabled" state — server has QUALIFY_WRITES_ENABLED=false */}
                  {approveState === "disabled" && (
                    <div style={{
                      padding: "8px 12px",
                      backgroundColor: "#f3f4f6",
                      border: "1px solid #d1d5db",
                      borderRadius: 6,
                      fontSize: 11,
                      color: "#6b7280",
                    }}>
                      Real qualify writes are currently disabled on this server.
                      Set <code>QUALIFY_WRITES_ENABLED=true</code> in the server environment to enable.
                    </div>
                  )}

                  {/* Write error state */}
                  {approveState === "error" && writeErr && (
                    <div style={{
                      padding: "8px 12px",
                      backgroundColor: "#fee2e2",
                      border: "1px solid #fca5a5",
                      borderRadius: 6,
                      fontSize: 11,
                      color: "#991b1b",
                      marginBottom: 8,
                    }}>
                      <strong>Write failed:</strong> {writeErr}
                    </div>
                  )}

                  {/* Step 1: "Approve & Qualify" button */}
                  {(approveState === null || approveState === "error") && (
                    <>
                      <div style={{ fontSize: 11, color: "#475569", marginBottom: 8 }}>
                        Real qualification is available. This will set status to{" "}
                        <strong>Pipeline</strong> and record <code>qualified_at</code>.
                        This action requires two steps to confirm.
                      </div>
                      <button
                        ref={approveRef}
                        style={approveBtnStyle}
                        onClick={handleApproveClick}
                        aria-label={`Approve and qualify ${oppId} — step 1 of 2`}
                      >
                        Approve &amp; Qualify
                      </button>
                    </>
                  )}

                  {/* Step 2: Inline confirm panel */}
                  {approveState === "confirm" && (
                    <div style={confirmPanelStyle} role="alert" aria-live="polite">
                      <strong>⚠ Confirm real qualification?</strong>
                      <div style={{ marginTop: 6 }}>
                        This will write <strong>status = Pipeline</strong> and{" "}
                        <strong>qualified_at = NOW()</strong> to the database for{" "}
                        <code>{oppId}</code>. This cannot be automatically reversed.
                      </div>
                      <div>
                        <button
                          ref={confirmRef}
                          style={confirmBtnStyle}
                          onClick={handleConfirmQualify}
                          aria-label={`Confirm qualify for ${oppId} — final confirmation`}
                        >
                          Confirm Qualify
                        </button>
                        <button
                          style={cancelBtnStyle}
                          onClick={handleCancelConfirm}
                          aria-label="Cancel — return to preview"
                        >
                          Cancel
                        </button>
                      </div>
                    </div>
                  )}

                  {/* Writing in flight */}
                  {approveState === "writing" && (
                    <div style={{ fontSize: 12, color: "#0369a1", marginTop: 4 }}>
                      Applying qualification…
                    </div>
                  )}
                </div>
              )}

              {/* When already qualified — no approve button needed */}
              {d.already_qualified === true && (
                <div style={{
                  marginTop: 12, paddingTop: 8,
                  borderTop: "1px solid #bae6fd",
                  fontSize: 11, color: "#64748b",
                }}>
                  This opportunity is already Pipeline. No action required.
                </div>
              )}

              {/* When would_change is false and not already qualified */}
              {d.would_change === false && d.already_qualified !== true && (
                <div style={{
                  marginTop: 12, paddingTop: 8,
                  borderTop: "1px solid #bae6fd",
                  fontSize: 11, color: "#64748b",
                }}>
                  No changes would occur for this opportunity.
                </div>
              )}
            </>
          );
        })()}
      </div>
    </div>
  );
}

// ─── Styles ───────────────────────────────────────────────────────────────────
const S = {
  page:         { minHeight: "100vh", backgroundColor: "#f8fafc", fontFamily: "'Inter', 'Segoe UI', system-ui, sans-serif", color: "#1f2937" },
  summaryStrip: { display: "flex", gap: 16, backgroundColor: "#ffffff", borderBottom: "1px solid #e2e8f0", padding: "12px 24px", overflowX: "auto", alignItems: "center" },
  summaryCard:  { display: "flex", flexDirection: "column", alignItems: "center", padding: "8px 20px", minWidth: 110, backgroundColor: "#f8fafc", border: "1px solid #e2e8f0", borderRadius: 8 },
  summaryLabel: { fontSize: 11, color: "#6b7280", fontWeight: 500 },
  summaryValue: { fontSize: 18, fontWeight: 700, color: "#0f172a", marginTop: 2 },
  pageHeader:   { padding: "20px 24px 8px", display: "flex", alignItems: "center", justifyContent: "space-between", flexWrap: "wrap", gap: 12 },
  pageTitle:    { fontSize: 22, fontWeight: 700, color: "#0f172a", margin: 0 },
  pageSubtitle: { fontSize: 13, color: "#64748b", marginTop: 2 },
  backLink:     { fontSize: 13, color: "#0369a1", textDecoration: "none", display: "flex", alignItems: "center", gap: 4, cursor: "pointer", background: "none", border: "none", padding: 0 },
  filterBar:    { display: "flex", gap: 12, padding: "10px 24px", alignItems: "center", flexWrap: "wrap", backgroundColor: "#ffffff", borderBottom: "1px solid #e2e8f0" },
  filterLabel:  { fontSize: 12, color: "#6b7280", fontWeight: 500 },
  select:       { fontSize: 13, padding: "5px 10px", border: "1px solid #d1d5db", borderRadius: 6, backgroundColor: "#ffffff", color: "#1f2937", cursor: "pointer" },
  tableWrap:    { padding: "16px 24px" },
  table:        { width: "100%", borderCollapse: "collapse", backgroundColor: "#ffffff", borderRadius: 10, overflow: "hidden", border: "1px solid #e2e8f0" },
  thead:        { backgroundColor: "#f1f5f9" },
  th:           { padding: "10px 14px", textAlign: "left", fontSize: 11, fontWeight: 700, color: "#374151", textTransform: "uppercase", letterSpacing: "0.06em", borderBottom: "1px solid #e2e8f0", cursor: "pointer", userSelect: "none", whiteSpace: "nowrap" },
  td:           { padding: "11px 14px", fontSize: 13, color: "#374151", borderBottom: "1px solid #f1f5f9", verticalAlign: "middle" },
  trHover:      { backgroundColor: "#f8fafc" },
  mockBanner:   { backgroundColor: "#fef3c7", borderBottom: "1px solid #fcd34d", padding: "6px 24px", fontSize: 12, color: "#92400e" },
  errorBox:     { margin: "24px", padding: "16px", backgroundColor: "#fee2e2", borderRadius: 8, color: "#991b1b", fontSize: 13 },
  emptyRow:     { textAlign: "center", padding: 32, color: "#9ca3af", fontSize: 13 },
  envErrBox:    { margin: "24px", padding: "16px", backgroundColor: "#fff7ed", border: "1px solid #fed7aa", borderRadius: 8, color: "#9a3412", fontSize: 13 },
  qualifyBtn:   { fontSize: 11, fontWeight: 600, color: "#0369a1", background: "none", border: "1px solid #bae6fd", borderRadius: 6, padding: "3px 10px", cursor: "pointer", whiteSpace: "nowrap" },
  panelTd: {
    padding: "0 16px 12px 16px",
    backgroundColor: "#e0f2fe",
    borderBottom: "2px solid #0ea5e9",
  },
};

// ─── Component ────────────────────────────────────────────────────────────────
export default function GDAOpsTracker() {
  const [opps,       setOpps]       = useState([]);
  const [summary,    setSummary]    = useState(null);
  const [loading,    setLoading]    = useState(true);
  const [error,      setError]      = useState(null);
  const [envError,   setEnvError]   = useState(null);
  const [hoveredRow, setHoveredRow] = useState(null);

  const [dept,    setDept]    = useState("All");
  const [status,  setStatus]  = useState("All");
  const [minPwin, setMinPwin] = useState(0);
  const [sortKey, setSortKey] = useState("score");
  const [sortDir, setSortDir] = useState("desc");

  // S-006 carry-forward: open panel id + ref map for focus return
  const [openQualifyId, setOpenQualifyId] = useState(null);
  const qualifyBtnRefs = useRef({});   // { [oppId]: HTMLButtonElement }

  // ── Data load ──────────────────────────────────────────────────────────────
  useEffect(() => {
    loadData();
  }, []);

  function loadData(cancelled = false) {
    if (USE_MOCK) {
      setTimeout(() => {
        if (cancelled) return;
        setOpps(MOCK_OPPORTUNITIES);
        setSummary(MOCK_SUMMARY);
        setLoading(false);
      }, 300);
      return;
    }

    setLoading(true);
    fetchTop10()
      .then(env => {
        if (cancelled) return;
        setOpps(env.data?.opportunities || []);
        setSummary(env.data?.summary    || null);
        setLoading(false);
      })
      .catch(err => {
        if (cancelled) return;
        if (err.message.includes("envelope") || err.message.includes("non-JSON")) {
          setEnvError(err.message);
        } else {
          setError(err.message);
        }
        setLoading(false);
      });
  }

  // S-007: Refresh top10 table after a successful qualify write.
  // Called by QualifyPanel's onRefresh prop.
  function handleRefreshTop10() {
    if (USE_MOCK) {
      // In mock mode, update the specific row's status locally for visual feedback.
      // Real data source does not change in mock mode.
      if (openQualifyId) {
        setOpps(prev => prev.map(o =>
          o.id === openQualifyId ? { ...o, status: "Pipeline" } : o
        ));
      }
      return;
    }
    // Live mode: re-fetch from API
    let cancelled = false;
    fetchTop10()
      .then(env => {
        if (cancelled) return;
        setOpps(env.data?.opportunities || []);
        setSummary(env.data?.summary    || null);
      })
      .catch(() => {
        // Refresh failure is non-fatal — user can manually reload.
        // Do not clear existing data; just log softly.
        console.warn("[GDA] top10 refresh after qualify write failed — data may be stale.");
      });
    return () => { cancelled = true; };
  }

  // ── Sort ───────────────────────────────────────────────────────────────────
  function handleSort(key) {
    if (sortKey === key) setSortDir(d => (d === "asc" ? "desc" : "asc"));
    else { setSortKey(key); setSortDir("desc"); }
  }
  function sortIndicator(key) {
    if (sortKey !== key) return " ↕";
    return sortDir === "asc" ? " ↑" : " ↓";
  }

  const visible = applyFilters(opps, { dept, status, minPwin, sortKey, sortDir });

  const shownSummary = {
    shown:     visible.length,
    total:     opps.length,
    avg_score: visible.length
      ? Math.round(visible.reduce((s, r) => s + (Number(r.score) || 0), 0) / visible.length)
      : "—",
    avg_pwin: visible.length
      ? Math.round(visible.reduce((s, r) => s + (Number(r.pwin)  || 0), 0) / visible.length)
      : "—",
    total_val: visible.reduce((s, r) => s + (Number(r.value) || 0), 0),
  };

  function goToLaunchpad(e) {
    e.preventDefault();
    window.location.href = "/";
  }

  // S-006 carry-forward: toggle panel; return focus to trigger on close
  function toggleQualify(oppId) {
    if (openQualifyId === oppId) {
      setOpenQualifyId(null);
      requestAnimationFrame(() => qualifyBtnRefs.current[oppId]?.focus());
    } else {
      setOpenQualifyId(oppId);
    }
  }

  function closePanel(oppId) {
    setOpenQualifyId(null);
    requestAnimationFrame(() => qualifyBtnRefs.current[oppId]?.focus());
  }

  // ── Render ─────────────────────────────────────────────────────────────────
  return (
    <div style={S.page}>

      {/* ── Persistent Financial KPI Strip (shared context) ───────────────── */}
      <GDAKpiStrip />

      {/* ── Tool-specific Summary Strip ───────────────────────────────────── */}
      <div style={S.summaryStrip}>
        <div style={S.summaryCard}>
          <span style={S.summaryLabel}>Showing</span>
          <span style={S.summaryValue}>{shownSummary.shown}/{shownSummary.total}</span>
        </div>
        <div style={S.summaryCard}>
          <span style={S.summaryLabel}>Avg Score</span>
          <span style={S.summaryValue}>{shownSummary.avg_score}</span>
        </div>
        <div style={S.summaryCard}>
          <span style={S.summaryLabel}>Avg P(Win)</span>
          <span style={S.summaryValue}>
            {typeof shownSummary.avg_pwin === "number" ? `${shownSummary.avg_pwin}%` : shownSummary.avg_pwin}
          </span>
        </div>
        <div style={S.summaryCard}>
          <span style={S.summaryLabel}>Total Value</span>
          <span style={S.summaryValue}>{fmtDollars(shownSummary.total_val)}</span>
        </div>
        <div style={{ ...S.summaryCard, marginLeft: "auto", borderColor: "#bfdbfe", backgroundColor: "#eff6ff" }}>
          <span style={{ ...S.summaryLabel, color: "#1e40af" }}>Pipeline Rule</span>
          <span style={{ ...S.summaryValue, color: "#1e40af", fontSize: 12 }}>Qualify to Add →</span>
        </div>
      </div>

      {/* ── Mock / live banner ───────────────────────────────────────────── */}
      {USE_MOCK ? (
        <div style={S.mockBanner}>
          ⚠ MOCK DATA — set <code>USE_MOCK = false</code> in GDAOpsTracker-7.jsx after Express API is live on :3001
        </div>
      ) : (
        <div style={{ ...S.mockBanner, backgroundColor: "#f0fdf4", borderColor: "#bbf7d0", color: "#166534" }}>
          ✓ LIVE DATA — <code>GET /api/opportunities/top10</code>
        </div>
      )}

      {/* ── Page Header ──────────────────────────────────────────────────── */}
      <div style={S.pageHeader}>
        <div>
          <h1 style={S.pageTitle}>Ops Tracker</h1>
          <div style={S.pageSubtitle}>
            Opportunity discovery and management · Qualify to move to Pipeline
          </div>
        </div>
        <a href="/" style={S.backLink} onClick={goToLaunchpad}>← Launchpad</a>
      </div>

      {/* ── Filter Bar ───────────────────────────────────────────────────── */}
      <div style={S.filterBar}>
        <span style={S.filterLabel}>Filter:</span>

        <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
          <label style={S.filterLabel} htmlFor="dept-filter">Dept</label>
          <select id="dept-filter" style={S.select} value={dept} onChange={e => setDept(e.target.value)}>
            {DEPTS.map(d => <option key={d}>{d}</option>)}
          </select>
        </div>

        <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
          <label style={S.filterLabel} htmlFor="status-filter">Status</label>
          <select id="status-filter" style={S.select} value={status} onChange={e => setStatus(e.target.value)}>
            {STATUSES.map(s => <option key={s}>{s}</option>)}
          </select>
        </div>

        <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
          <label style={S.filterLabel} htmlFor="pwin-filter">Min P(Win)</label>
          <select id="pwin-filter" style={S.select} value={minPwin} onChange={e => setMinPwin(Number(e.target.value))}>
            <option value={0}>Any</option>
            <option value={25}>≥ 25%</option>
            <option value={40}>≥ 40%</option>
            <option value={55}>≥ 55%</option>
            <option value={70}>≥ 70%</option>
          </select>
        </div>

        {(dept !== "All" || status !== "All" || minPwin > 0) && (
          <button
            style={{ ...S.select, backgroundColor: "#fee2e2", color: "#dc2626", border: "1px solid #fca5a5", cursor: "pointer" }}
            onClick={() => { setDept("All"); setStatus("All"); setMinPwin(0); }}
          >
            Clear
          </button>
        )}
      </div>

      {/* ── Table ────────────────────────────────────────────────────────── */}
      <div style={S.tableWrap}>

        {envError && (
          <div style={S.envErrBox}>
            <strong>API contract error:</strong> {envError}
            <div style={{ marginTop: 8, fontSize: 12 }}>
              Check <code>gda-api-routes.js</code> and Vite proxy config.
            </div>
          </div>
        )}

        {error && !envError && (
          <div style={S.errorBox}>
            <strong>Error loading opportunities:</strong> {error}
            <div style={{ marginTop: 8, fontSize: 12 }}>
              Check that Express is running on :3001 and <code>DATABASE_URL</code> is set.
            </div>
          </div>
        )}

        {loading && (
          <div style={{ padding: 32, textAlign: "center", color: "#64748b" }}>
            Loading opportunities…
          </div>
        )}

        {!loading && !error && !envError && (
          <>
            <table style={S.table}>
              <thead style={S.thead}>
                <tr>
                  {[
                    { key: "id",       label: "ID"       },
                    { key: "title",    label: "Title"    },
                    { key: "dept",     label: "Dept"     },
                    { key: "value",    label: "Value"    },
                    { key: "pwin",     label: "P(Win)"   },
                    { key: "score",    label: "Score"    },
                    { key: "status",   label: "Status"   },
                    { key: "due_date", label: "Due Date" },
                    { key: null,       label: "Actions"  },
                  ].map(col => (
                    <th
                      key={col.label}
                      style={{ ...S.th, cursor: col.key ? "pointer" : "default" }}
                      onClick={col.key ? () => handleSort(col.key) : undefined}
                    >
                      {col.label}{col.key ? sortIndicator(col.key) : ""}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {visible.length === 0 ? (
                  <tr>
                    <td colSpan={9} style={S.emptyRow}>
                      No opportunities match the current filters.
                    </td>
                  </tr>
                ) : (
                  visible.map(opp => {
                    const isOpen = openQualifyId === opp.id;
                    return (
                      <>
                        {/* ── Data row ────────────────────────────────── */}
                        <tr
                          key={opp.id}
                          style={hoveredRow === opp.id ? S.trHover : {}}
                          onMouseEnter={() => setHoveredRow(opp.id)}
                          onMouseLeave={() => setHoveredRow(null)}
                        >
                          <td style={{ ...S.td, fontFamily: "monospace", fontSize: 11, color: "#6b7280" }}>
                            {opp.id}
                          </td>
                          <td style={{ ...S.td, fontWeight: 500, maxWidth: 260 }}>{opp.title}</td>
                          <td style={S.td}>{opp.dept || "—"}</td>
                          <td style={{ ...S.td, fontWeight: 600, fontVariantNumeric: "tabular-nums" }}>
                            {fmtDollars(opp.value)}
                          </td>
                          <td style={S.td}><PwinBadge pwin={opp.pwin} /></td>
                          <td style={S.td}><ScoreBadge score={opp.score} /></td>
                          <td style={S.td}><StatusPill status={opp.status} /></td>
                          <td style={{ ...S.td, whiteSpace: "nowrap" }}>{fmtDate(opp.due_date)}</td>
                          <td style={S.td}>
                            {/* S-006 carry-forward: ref stored for focus-return on panel close */}
                            <button
                              ref={el => { qualifyBtnRefs.current[opp.id] = el; }}
                              style={{
                                ...S.qualifyBtn,
                                backgroundColor: isOpen ? "#e0f2fe" : "transparent",
                              }}
                              onClick={() => toggleQualify(opp.id)}
                              aria-expanded={isOpen}
                              aria-controls={`qualify-panel-${opp.id}`}
                              title="Preview qualification status — opens approve gate when would_change is true"
                            >
                              {isOpen ? "▲ Close" : "Preview Qualify"}
                            </button>
                          </td>
                        </tr>

                        {/* ── S-007: Inline qualify panel (preview + approve flow) ── */}
                        {isOpen && (
                          <tr key={`${opp.id}-panel`}>
                            <td
                              colSpan={9}
                              style={S.panelTd}
                              id={`qualify-panel-${opp.id}`}
                            >
                              <QualifyPanel
                                oppId={opp.id}
                                onClose={() => closePanel(opp.id)}
                                onRefresh={handleRefreshTop10}
                              />
                            </td>
                          </tr>
                        )}
                      </>
                    );
                  })
                )}
              </tbody>
            </table>

            {/* Pipeline rule callout */}
            <div style={{
              marginTop: 16, padding: "10px 16px",
              backgroundColor: "#eff6ff", border: "1px solid #bfdbfe",
              borderRadius: 8, fontSize: 12, color: "#1e40af",
            }}>
              <strong>Pipeline Rule:</strong> An opportunity does not become Pipeline until explicitly qualified.
              {" "}Use <em>Preview Qualify</em> per row to see what would change (dry run).
              {" "}When <em>would_change</em> is true, <em>Approve &amp; Qualify</em> becomes available —
              requires a two-step confirm. Enforced server-side with <code>QUALIFY_WRITES_ENABLED</code>.
            </div>
          </>
        )}
      </div>
    </div>
  );
}
