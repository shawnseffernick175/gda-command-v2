# S-007 Delivery Notes
GDA Rebuild — Sprint S-007 | Phase 1

---

## What shipped

### 1. `gda-api-routes-4-3.js` — Approval-gated qualify write path (UPDATED)

**Safety matrix (new):**

| Request | Response |
|---------|----------|
| `{ dryRun: true }` | 200 preview (unchanged) or 404 — no DB write |
| `{ dryRun: false }` (no approve) | **400** — safety gate |
| `{ dryRun: false, approve: false }` | **400** — safety gate |
| `{ dryRun: false, approve: true }` + `QUALIFY_WRITES_ENABLED=false` | **400** — writes disabled |
| `{ dryRun: false, approve: true }` + `QUALIFY_WRITES_ENABLED=true` | **200** — real write applied |

**dryRun:true path:** unchanged from S-006 — same fields, same envelope, same 404 behavior. QualifyPanel does not break.

**Real write path (`dryRun:false, approve:true, QUALIFY_WRITES_ENABLED=true`):**
- Looks up opportunity by id.
- If not found: 404 envelope.
- If found: updates `status = 'Pipeline'` and `qualified_at = NOW()` via Postgres.
- Returns envelope with `opportunity_id`, `title`, `previous_status`, `new_status`, `qualified_at`, and `note`.
- Logs: `[GDA QUALIFY WRITE] id=... | prev=... | new=... | qualified_at=... | triggered_by=GDA_REBUILD_UI`

**QUALIFY_WRITES_ENABLED env flag:**
```bash
export QUALIFY_WRITES_ENABLED=true   # development only — explicit opt-in required
```
- Defaults to `false` in all environments.
- Do not set in production without explicit operator sign-off.
- When `false`, `{ dryRun:false, approve:true }` returns HTTP 400 with a clear "disabled" message.

---

### 2. `GDAOpsTracker-7.jsx` — Two-step Approve & Qualify flow (UPDATED)

**New approve flow states:**

| State | What the user sees |
|-------|--------------------|
| `null` | Preview data + "Approve & Qualify" button (only when `would_change: true`) |
| `"confirm"` | Inline amber confirm panel: "Confirm Qualify" + "Cancel" |
| `"writing"` | "Applying qualification…" — buttons disabled |
| `"success"` | Green success banner, qualified_at, previous/new status |
| `"error"` | Red error, can retry from panel |
| `"disabled"` | Grey note: QUALIFY_WRITES_ENABLED=false on server |

**Safety invariants:**
- `APPROVE_PAYLOAD = { dryRun: false, approve: true }` — defined once, frozen, used only in `approveQualify()`.
- No code path can send `dryRun:false` without `approve:true`.
- `approveQualify()` is called only after the user completes both confirm steps.
- No single click can both preview and write.
- Preview panel cannot disappear mid-confirm.

**Post-write behavior:**
- On success: `onRefresh()` fires → re-fetches `GET /api/opportunities/top10` (live) or updates the row locally (mock).
- Panel shows success state with `qualified_at` timestamp.

**Accessibility (S-006 preserved + S-007 additions):**
- Panel gets focus on open (S-006).
- Confirm step: `confirmRef.current.focus()` fires when `approveState === "confirm"`.
- Cancel returns focus to the "Approve & Qualify" button via `approveRef`.
- Close returns focus to "Preview Qualify" trigger via `qualifyBtnRefs` (S-006).
- All new buttons are Tab-reachable and keyboard-activatable.

**Non-changes:**
- `GDAKpiContext.jsx` — not touched.
- `GDAFinancialBible.jsx` — not touched.
- `GDAHealthBadge.jsx` — not touched.
- `server-3-2.js` — not touched.
- Frozen workflows — not touched.

---

### 3. `gda-smoke-tests-7.js` — Write path tests with safe guard (UPDATED)

**New test suite: `testQualifyWritePath()`**

| Test | Safety | Default |
|------|--------|---------|
| `dryRun:false` no approve → HTTP 400 | Always safe | Always runs |
| `dryRun:false, approve:false` → HTTP 400 | Always safe | Always runs |
| `dryRun:false, approve:true` → real write | Dev only | **SKIPPED** |

**To enable real write test (dev only):**
```bash
export TEST_QUALIFY_WRITE=true
export TEST_QUALIFY_OPP_ID=TEST-OPP-001   # must exist in DB, not already Pipeline
export QUALIFY_WRITES_ENABLED=true         # on the server
node gda-smoke-tests-7.js http://localhost:3001
```

**Retained from S-004–S-006 (no regressions):**
- `/api/schema/check all_ok:false` → hard fail.
- `/api/qualify dryRun:false` (no approve) → hard 400 assertion (now in both `testQualifyWritePath` and `testQualifyDryRunFalseGate`).
- All envelope contract checks.
- All KPI key checks.
- All launchpad summary key checks.
- `data.note` soft warn from S-006.

---

## Files changed

| File | Status | Description |
|------|--------|-------------|
| `gda-api-routes-4-3.js` | UPDATED | Approval-gated write path + QUALIFY_WRITES_ENABLED flag |
| `GDAOpsTracker-7.jsx` | UPDATED | Two-step Approve & Qualify flow + onRefresh |
| `gda-smoke-tests-7.js` | UPDATED | Write path tests behind TEST_QUALIFY_WRITE guard |

**Not touched:** `server-3-2.js`, `GDAKpiContext.jsx`, `GDAFinancialBible.jsx`, `GDAHealthBadge.jsx`, `App-6.jsx`, frozen workflows.

---

## Toggle cheat sheet (S-007 additions)

| Flag | Where | Controls |
|------|-------|----------|
| `QUALIFY_WRITES_ENABLED=true` | Server env | Enables real DB qualify writes |
| `TEST_QUALIFY_WRITE=true` | Test runner env | Enables real write smoke test (dev only) |
| `TEST_QUALIFY_OPP_ID=<id>` | Test runner env | Test record id for real write test |
| `USE_MOCK = true` | GDAOpsTracker-7.jsx | Top10 table rows (unchanged) |
| `KPI_USE_MOCK = true` | GDAKpiContext.jsx | KPI strip values (unchanged) |

---

## How to run

```bash
# API (Express :3001)
cd api && npm run dev

# React (Vite :5173)
npm run dev

# Smoke tests — safe (skips real write test)
node gda-smoke-tests-7.js http://localhost:3001

# Smoke tests — with real write test (dev only)
QUALIFY_WRITES_ENABLED=true \
TEST_QUALIFY_WRITE=true \
TEST_QUALIFY_OPP_ID=TEST-OPP-001 \
node gda-smoke-tests-7.js http://localhost:3001
```

---

## App-6.jsx update needed

`App-6.jsx` currently imports `GDAOpsTracker-6`. To use S-007:

```jsx
// Change:
import GDAOpsTracker from "./GDAOpsTracker-6.jsx";
// To:
import GDAOpsTracker from "./GDAOpsTracker-7.jsx";
```

No other changes to `App-6.jsx` are required.

---

## RR-38 and RR-28

Both remain FROZEN. Not referenced. Not touched.

---

## S-008 candidates

1. Pipeline view — separate page showing only qualified (status = Pipeline) records.
2. Financial Bible drill-down: connect to real financial breakdown data.
3. Launchpad risks + decisions detail cards (beyond count display).
4. Proper audit log table for qualify writes (currently console.log placeholder).
