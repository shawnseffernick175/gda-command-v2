/**
 * GDA Rebuild — Smoke Test Runner
 * S-007 | Phase 1
 *
 * CHANGES vs S-006 (gda-smoke-tests-6.js)
 * -----------------------------------------
 * - Suite header updated to S-007.
 * - testQualifyWritePath(): NEW test suite for the approval-gated real write path.
 *   Tests the safety gate, approve:false gate, and (behind env guard) a real write.
 * - testQualifyDryRun(): unchanged — all S-006 assertions preserved.
 * - All other tests: unchanged — all S-004/S-005/S-006 hard gates preserved.
 *
 * S-007 QUALIFY WRITE TESTS — SAFETY NOTES
 * -----------------------------------------
 * The new testQualifyWritePath() suite tests:
 *
 *   1. dryRun:false with no approve → must return HTTP 400 (ALWAYS safe to run)
 *   2. dryRun:false with approve:false → must return HTTP 400 (ALWAYS safe to run)
 *   3. dryRun:false + approve:true → real write (GUARDED by TEST_QUALIFY_WRITE env flag)
 *
 * Test #3 (real write) is:
 *   - SKIPPED by default. It will not run unless TEST_QUALIFY_WRITE=true is set.
 *   - ONLY safe to run in a development environment with a known test record.
 *   - NEVER run against production without explicit operator approval.
 *   - Assumes a test opportunity with id TEST_QUALIFY_OPP_ID (default: "TEST-OPP-001")
 *     exists and is NOT already Pipeline. If the record doesn't exist, the test
 *     expects a 404 and will pass accordingly.
 *
 * To enable real write test (dev only):
 *   export TEST_QUALIFY_WRITE=true
 *   export TEST_QUALIFY_OPP_ID=TEST-OPP-001   # or your known test record id
 *   node gda-smoke-tests-7.js http://localhost:3001
 *
 * QUALIFY_WRITES_ENABLED SERVER FLAG
 * ------------------------------------
 * The server also requires QUALIFY_WRITES_ENABLED=true to allow real writes.
 * If the server has QUALIFY_WRITES_ENABLED=false, the write test will expect
 * the "writes disabled" 400 response and treat that as a conditional pass
 * (safe behavior confirmed, real write not tested).
 *
 * Usage:
 *   node gda-smoke-tests-7.js http://localhost:3001
 *   node gda-smoke-tests-7.js $GDA_PROD_URL
 *
 * Exit codes:
 *   0 — all tests passed
 *   1 — one or more tests failed
 */

"use strict";

// ─── Args ─────────────────────────────────────────────────────────────────────
const BASE = (process.argv[2] || "http://localhost:3001").replace(/\/$/, "");

// ─── S-007 real-write test guard ──────────────────────────────────────────────
// Real write test is skipped unless TEST_QUALIFY_WRITE=true is set.
// This env flag is the ONLY way to enable the write path in smoke tests.
const TEST_QUALIFY_WRITE   = process.env.TEST_QUALIFY_WRITE === "true";
const TEST_QUALIFY_OPP_ID  = process.env.TEST_QUALIFY_OPP_ID || "TEST-OPP-001";

// ─── Harness ──────────────────────────────────────────────────────────────────
let passed = 0, failed = 0;
const failures = [];

function pass(name) {
  console.log(`  ✓ ${name}`);
  passed++;
}

function fail(name, reason) {
  console.log(`  ✗ ${name}`);
  console.log(`      → ${reason}`);
  failed++;
  failures.push({ name, reason });
}

function warn(name, reason) {
  // Non-fatal: logged but does not increment failure count or affect exit code.
  console.log(`  ⚠ ${name} (non-fatal)`);
  console.log(`      → ${reason}`);
}

function skip(name, reason) {
  console.log(`  ○ ${name} (SKIPPED)`);
  console.log(`      → ${reason}`);
}

async function GET(path) {
  const r    = await fetch(`${BASE}${path}`);
  const body = await r.json().catch(() => null);
  return { status: r.status, body };
}

async function POST(path, payload) {
  const r = await fetch(`${BASE}${path}`, {
    method:  "POST",
    headers: { "Content-Type": "application/json" },
    body:    JSON.stringify(payload),
  });
  const body = await r.json().catch(() => null);
  return { status: r.status, body };
}

function checkEnvelope(name, body) {
  const required = ["success", "workflow", "action", "dryRun", "data", "meta", "error"];
  const missing  = required.filter(k => !(k in body));
  if (missing.length) {
    fail(`${name} — envelope contract`,
      `Missing fields: ${missing.join(", ")}. Every endpoint must return the full standard envelope.`
    );
    return false;
  }
  pass(`${name} — envelope contract`);
  return true;
}

// ─── Tests ────────────────────────────────────────────────────────────────────

// ── /api/health ───────────────────────────────────────────────────────────────
async function testHealth() {
  console.log("\n── /api/health");
  const { status, body } = await GET("/api/health");

  if (status === 200) pass("/api/health — status 200");
  else fail("/api/health — status 200", `Got HTTP ${status}`);

  if (!body) { fail("/api/health — body parseable", "Not valid JSON"); return; }

  checkEnvelope("/api/health", body);

  if (body.data?.db === "ok") pass("/api/health — db ok");
  else fail("/api/health — db ok",
    `db is "${body.data?.db}". Msg: ${body.data?.db_message}. Check DATABASE_URL + Postgres.`
  );
}

// ── /api/financial/kpis ───────────────────────────────────────────────────────
// S-006: GDAFinancialBible reads these keys via useKpi() context.
// All 7 must be present for the Financial Bible page to render correctly.
async function testFinancialKpis() {
  console.log("\n── /api/financial/kpis  [S-006: consumed by GDAFinancialBible]");
  const { status, body } = await GET("/api/financial/kpis");

  if (status === 200) pass("/api/financial/kpis — status 200");
  else fail("/api/financial/kpis — status 200", `Got HTTP ${status}`);

  if (!body) { fail("/api/financial/kpis — body parseable", "Not valid JSON"); return; }

  checkEnvelope("/api/financial/kpis", body);

  if (!body.success) {
    fail("/api/financial/kpis — success:true",
      `success is false. Error: ${body.error}. ` +
      "financial_kpis_current view may be missing or empty."
    );
    return;
  }
  pass("/api/financial/kpis — success:true");

  const required = ["orders", "sales", "ebit", "ros", "funded_backlog", "backlog", "gross_profit"];
  const kpis     = body.data?.kpis || {};
  const missing  = required.filter(k => !(k in kpis));
  if (missing.length) {
    fail("/api/financial/kpis — all 7 KPI keys under data.kpis",
      `Missing: ${missing.join(", ")}. ` +
      "GDAFinancialBible overview grid requires all 7 keys. Check financial_kpis_current view."
    );
  } else {
    pass("/api/financial/kpis — all 7 KPI keys present (orders, sales, ebit, ros, funded_backlog, backlog, gross_profit)");
  }
}

// ── /api/launchpad/summary ────────────────────────────────────────────────────
// S-006: GDALaunchpad secondary strip depends on these three keys.
async function testLaunchpadSummary() {
  console.log("\n── /api/launchpad/summary  [S-006: drives Launchpad secondary strip]");
  const { status, body } = await GET("/api/launchpad/summary");

  if (status === 200) pass("/api/launchpad/summary — status 200");
  else fail("/api/launchpad/summary — status 200", `Got HTTP ${status}`);

  if (!body) { fail("/api/launchpad/summary — body parseable", "Not valid JSON"); return; }

  checkEnvelope("/api/launchpad/summary", body);

  const d = body.data || {};
  const stripKeys = ["total_opportunities", "pipeline_count", "active_risks"];
  const missingStrip = stripKeys.filter(k => !(k in d));
  if (missingStrip.length) {
    fail("/api/launchpad/summary — S-006 strip keys present",
      `Missing: ${missingStrip.join(", ")}. ` +
      "GDALaunchpad secondary strip reads total_opportunities, pipeline_count, active_risks. " +
      `Got: ${Object.keys(d).join(", ")}`
    );
  } else {
    pass("/api/launchpad/summary — S-006 strip keys present (total_opportunities, pipeline_count, active_risks)");
  }
}

// ── /api/opportunities/top10 ──────────────────────────────────────────────────
async function testTop10() {
  console.log("\n── /api/opportunities/top10");
  const { status, body } = await GET("/api/opportunities/top10");

  if (status === 200) pass("/api/opportunities/top10 — status 200");
  else fail("/api/opportunities/top10 — status 200", `Got HTTP ${status}`);

  if (!body) { fail("/api/opportunities/top10 — body parseable", "Not valid JSON"); return; }

  checkEnvelope("/api/opportunities/top10", body);

  if (!body.success) {
    fail("/api/opportunities/top10 — success:true", `success false. Error: ${body.error}`);
    return;
  }
  pass("/api/opportunities/top10 — success:true");

  const opps = body.data?.opportunities;
  if (!Array.isArray(opps)) {
    fail("/api/opportunities/top10 — data.opportunities is array", `Got: ${typeof opps}`);
    return;
  }
  pass("/api/opportunities/top10 — data.opportunities is array");

  if (opps.length > 0) {
    const cols        = ["id", "title", "dept", "value", "pwin", "score", "status", "due_date"];
    const missingCols = cols.filter(c => !(c in opps[0]));
    if (missingCols.length)
      fail("/api/opportunities/top10 — row has required columns",
        `Missing: ${missingCols.join(", ")}.`
      );
    else
      pass("/api/opportunities/top10 — row has required columns");
  }

  pass(`/api/opportunities/top10 — returned ${opps.length} rows`);
}

// ── /api/opportunities/:id/qualify (dryRun:true) ──────────────────────────────
// S-006 suite carried forward in full. No assertions weakened.
async function testQualifyDryRun() {
  console.log("\n── /api/opportunities/:id/qualify (dryRun:true)  [S-006/S-007: panel note field]");

  const top10   = await GET("/api/opportunities/top10");
  const firstId = top10.body?.data?.opportunities?.[0]?.id;

  // ── 404 on missing ID ──────────────────────────────────────────────────────
  const { status: s404, body: b404 } = await POST(
    "/api/opportunities/NONEXISTENT-ID-999/qualify",
    { dryRun: true }
  );

  if (s404 === 404) pass("/api/qualify dryRun — 404 on missing ID");
  else fail("/api/qualify dryRun — 404 on missing ID", `Expected 404, got ${s404}`);

  if (b404) checkEnvelope("/api/qualify dryRun 404", b404);

  if (b404?.dryRun === true) pass("/api/qualify dryRun — dryRun:true in 404 envelope");
  else fail("/api/qualify dryRun — dryRun:true in 404 envelope", `dryRun: ${b404?.dryRun}`);

  // ── Real ID preview ────────────────────────────────────────────────────────
  if (firstId) {
    const { status: s200, body: b200 } = await POST(
      `/api/opportunities/${firstId}/qualify`,
      { dryRun: true }
    );

    if (s200 === 200) pass(`/api/qualify dryRun — 200 on real ID (${firstId})`);
    else fail(`/api/qualify dryRun — 200 on real ID (${firstId})`, `Got ${s200}`);

    if (b200) checkEnvelope("/api/qualify dryRun 200", b200);

    if (b200?.dryRun === true) pass("/api/qualify dryRun — dryRun:true confirmed");
    else fail("/api/qualify dryRun — dryRun:true confirmed", `dryRun: ${b200?.dryRun}`);

    const d = b200?.data || {};

    const panelFields   = ["current_status", "proposed_status", "would_change", "already_qualified"];
    const missingPanel  = panelFields.filter(f => !(f in d));
    if (missingPanel.length) {
      fail("/api/qualify dryRun — S-006/S-007 panel fields present",
        `Missing: ${missingPanel.join(", ")}. QualifyPanel requires all four.`
      );
    } else {
      pass("/api/qualify dryRun — panel fields present (current_status, proposed_status, would_change, already_qualified)");
    }

    if ("note" in d) {
      pass("/api/qualify dryRun — data.note field present (panel renders it)");
    } else {
      warn("/api/qualify dryRun — data.note field",
        "data.note not present in qualify response. " +
        "Panel renders it when available; absent is acceptable. " +
        "S-007 route handler should supply note for non-Pipeline rows."
      );
    }

    if ("fields_to_update" in d || "already_qualified" in d)
      pass("/api/qualify dryRun — preview data structure present");
    else
      fail("/api/qualify dryRun — preview data structure present",
        `Missing fields_to_update or already_qualified. Got: ${Object.keys(d).join(", ")}`
      );

  } else {
    console.log("  ⚠  Skipping real-ID qualify preview test — top10 returned no rows (DB may be empty)");
  }
}

// ── /api/opportunities/:id/qualify — S-007 write path safety tests ────────────
//
// TEST SAFETY CLASSIFICATION:
//   Tests 1 & 2 (missing/false approve): ALWAYS SAFE. Run in any environment.
//   Test 3 (real write):                 DEV ONLY. Requires TEST_QUALIFY_WRITE=true.
//
// WHEN IS TEST 3 SAFE?
//   - Only in a development environment with a known, disposable test record.
//   - The record id is TEST_QUALIFY_OPP_ID (default: TEST-OPP-001).
//   - The server must also have QUALIFY_WRITES_ENABLED=true.
//   - Never run test 3 in production without explicit operator approval.
//
async function testQualifyWritePath() {
  console.log("\n── /api/opportunities/:id/qualify (S-007 write path safety gate)");

  // ──────────────────────────────────────────────────────────────────────────
  // TEST 1: dryRun:false with NO approve field → must be HTTP 400
  // ALWAYS SAFE. The server must reject this regardless of any env flag.
  // ──────────────────────────────────────────────────────────────────────────
  console.log("  [Test 1] dryRun:false with no approve (ALWAYS SAFE — must 400)");
  const { status: s400a, body: b400a } = await POST(
    "/api/opportunities/NONEXISTENT-ID-999/qualify",
    { dryRun: false }   // ← no approve field
  );

  if (s400a === 400) pass("/api/qualify write — dryRun:false + no approve → HTTP 400");
  else fail("/api/qualify write — dryRun:false + no approve → HTTP 400",
    `Expected 400, got ${s400a}. S-007 safety gate: missing approve must always 400.`
  );

  if (b400a?.success === false) pass("/api/qualify write — success:false on missing approve");
  else fail("/api/qualify write — success:false on missing approve", `success: ${b400a?.success}`);

  const err1 = (b400a?.error || "").toLowerCase();
  if (err1.includes("approve") || err1.includes("safety gate")) {
    pass("/api/qualify write — error message mentions approve:true requirement");
  } else {
    fail("/api/qualify write — error message mentions approve:true requirement",
      `Error was: "${b400a?.error}". Must mention approve:true or safety gate.`
    );
  }

  if (b400a) checkEnvelope("/api/qualify write — no approve envelope", b400a);

  // ──────────────────────────────────────────────────────────────────────────
  // TEST 2: dryRun:false with approve:false → must be HTTP 400
  // ALWAYS SAFE. approve:false is NOT the same as approve:true.
  // ──────────────────────────────────────────────────────────────────────────
  console.log("  [Test 2] dryRun:false + approve:false (ALWAYS SAFE — must 400)");
  const { status: s400b, body: b400b } = await POST(
    "/api/opportunities/NONEXISTENT-ID-999/qualify",
    { dryRun: false, approve: false }   // ← approve is false, not true
  );

  if (s400b === 400) pass("/api/qualify write — dryRun:false + approve:false → HTTP 400");
  else fail("/api/qualify write — dryRun:false + approve:false → HTTP 400",
    `Expected 400, got ${s400b}. approve:false must never be treated as approval.`
  );

  if (b400b?.success === false) pass("/api/qualify write — success:false on approve:false");
  else fail("/api/qualify write — success:false on approve:false", `success: ${b400b?.success}`);

  const err2 = (b400b?.error || "").toLowerCase();
  if (err2.includes("approve") || err2.includes("safety gate")) {
    pass("/api/qualify write — approve:false error message correct");
  } else {
    fail("/api/qualify write — approve:false error message correct",
      `Error was: "${b400b?.error}". Must mention approve:true or safety gate.`
    );
  }

  if (b400b) checkEnvelope("/api/qualify write — approve:false envelope", b400b);

  // ──────────────────────────────────────────────────────────────────────────
  // TEST 3: dryRun:false + approve:true — REAL WRITE
  // DEV ONLY. Skipped unless TEST_QUALIFY_WRITE=true is set.
  // Requires: TEST_QUALIFY_OPP_ID record in DB + QUALIFY_WRITES_ENABLED=true on server.
  // ──────────────────────────────────────────────────────────────────────────
  if (!TEST_QUALIFY_WRITE) {
    skip(
      `/api/qualify write — real write test for ${TEST_QUALIFY_OPP_ID}`,
      "TEST_QUALIFY_WRITE is not set. Set TEST_QUALIFY_WRITE=true and " +
      "TEST_QUALIFY_OPP_ID=<test-record-id> to enable in development only. " +
      "Also requires QUALIFY_WRITES_ENABLED=true on the server."
    );
    return;
  }

  // ── Real write test begins — dev guard has passed ──────────────────────────
  console.log(`  [Test 3] dryRun:false + approve:true — real write for ${TEST_QUALIFY_OPP_ID} (DEV ONLY)`);
  console.log("  ⚠  WARNING: This test will attempt a real DB write.");

  const { status: sWrite, body: bWrite } = await POST(
    `/api/opportunities/${TEST_QUALIFY_OPP_ID}/qualify`,
    { dryRun: false, approve: true }
  );

  // If the server has QUALIFY_WRITES_ENABLED=false, we expect 400 with "disabled" message.
  // This is acceptable — it confirms server-side safety is working.
  if (sWrite === 400) {
    const errMsg = (bWrite?.error || "").toLowerCase();
    const isDisabled = errMsg.includes("qualify_writes_enabled") || errMsg.includes("disabled");
    if (isDisabled) {
      pass(`/api/qualify write [Test 3] — server has QUALIFY_WRITES_ENABLED=false, write safely rejected`);
      warn(`/api/qualify write [Test 3] — real write not tested`,
        "Server has QUALIFY_WRITES_ENABLED=false. Set it to true in dev to test the real write path."
      );
      return;
    }
    // Any other 400 is a failure
    fail(`/api/qualify write [Test 3] — unexpected 400`,
      `Error: ${bWrite?.error}. Expected 200 with QUALIFY_WRITES_ENABLED=true, or 400 with disabled message.`
    );
    return;
  }

  // 404 means the test record doesn't exist — fail with clear message
  if (sWrite === 404) {
    fail(`/api/qualify write [Test 3] — 404 for test record ${TEST_QUALIFY_OPP_ID}`,
      `Test record not found. Create a test opportunity with id=${TEST_QUALIFY_OPP_ID} ` +
      "in the DB before running this test. It must NOT be already Pipeline."
    );
    return;
  }

  // Expect 200 with success:true
  if (sWrite === 200 && bWrite?.success === true) {
    pass(`/api/qualify write [Test 3] — HTTP 200 + success:true`);

    checkEnvelope("/api/qualify write [Test 3]", bWrite);

    const d = bWrite?.data || {};

    if (d.opportunity_id) pass("/api/qualify write [Test 3] — data.opportunity_id present");
    else fail("/api/qualify write [Test 3] — data.opportunity_id present", "Missing opportunity_id");

    if (d.previous_status) pass(`/api/qualify write [Test 3] — previous_status present: ${d.previous_status}`);
    else fail("/api/qualify write [Test 3] — previous_status present", "Missing previous_status");

    if (d.new_status === "Pipeline") pass("/api/qualify write [Test 3] — new_status = Pipeline");
    else fail("/api/qualify write [Test 3] — new_status = Pipeline", `Got: ${d.new_status}`);

    if (d.previous_status !== d.new_status || d.previous_status === "Pipeline") {
      pass("/api/qualify write [Test 3] — status changed (or was already Pipeline)");
    } else {
      fail("/api/qualify write [Test 3] — status changed",
        `previous_status === new_status (${d.previous_status}). ` +
        "Use a non-Pipeline test record."
      );
    }

    if (d.qualified_at) pass(`/api/qualify write [Test 3] — qualified_at populated: ${d.qualified_at}`);
    else fail("/api/qualify write [Test 3] — qualified_at populated", "Missing qualified_at");

    if (bWrite?.dryRun === false) pass("/api/qualify write [Test 3] — dryRun:false in envelope");
    else fail("/api/qualify write [Test 3] — dryRun:false in envelope", `dryRun: ${bWrite?.dryRun}`);

    console.log(`  ⚠  REAL WRITE APPLIED to ${TEST_QUALIFY_OPP_ID}. Verify and reset the test record if needed.`);

  } else {
    fail(`/api/qualify write [Test 3] — unexpected response`,
      `HTTP ${sWrite}, success: ${bWrite?.success}, error: ${bWrite?.error}`
    );
  }
}

// ── /api/opportunities/:id/qualify (dryRun:false — legacy safety gate) ────────
// S-006 hard gate carried forward. Now the gate is more nuanced in S-007:
// - dryRun:false + approve:true is the real write path (tested in testQualifyWritePath)
// - dryRun:false without approve:true must STILL be HTTP 400
// This test retains the original S-006 hard assertion on the case without approve.
async function testQualifyDryRunFalseGate() {
  console.log("\n── /api/opportunities/:id/qualify (dryRun:false gate — S-004–S-007 hard assertion)");

  const { status: s400, body: b400 } = await POST(
    "/api/opportunities/NONEXISTENT-ID-999/qualify",
    { dryRun: false }
  );

  if (s400 === 400) pass("/api/qualify dryRun:false (no approve) — correctly returns HTTP 400");
  else fail("/api/qualify dryRun:false (no approve) — correctly returns HTTP 400",
    `Expected 400, got ${s400}. S-007 safety gate: dryRun:false without approve:true must always 400. ` +
    "Check gda-api-routes-4-3.js."
  );

  if (b400?.success === false) pass("/api/qualify dryRun:false — success:false");
  else fail("/api/qualify dryRun:false — success:false", `success was ${b400?.success}`);

  const errMsg = (b400?.error || "").toLowerCase();
  // S-007: acceptable error strings include approve:true reference or the old "not enabled" style.
  const hasExpectedMsg = errMsg.includes("approve")        ||
                         errMsg.includes("safety gate")    ||
                         errMsg.includes("not enabled")    ||
                         errMsg.includes("s-004")          ||
                         errMsg.includes("s-005")          ||
                         errMsg.includes("s-006")          ||
                         errMsg.includes("s-007")          ||
                         errMsg.includes("dry run");
  if (hasExpectedMsg) pass("/api/qualify dryRun:false — error message explains block reason");
  else fail("/api/qualify dryRun:false — error message explains block reason",
    `Error was: "${b400?.error}". Should mention approve:true, safety gate, sprint ref, or dry run.`
  );

  if (b400?.dryRun === false) pass("/api/qualify dryRun:false — dryRun:false echoed in envelope");
  else fail("/api/qualify dryRun:false — dryRun:false echoed in envelope",
    `dryRun was ${b400?.dryRun}`
  );

  if (b400) checkEnvelope("/api/qualify dryRun:false error response", b400);
}

// ── /api/schema/check ─────────────────────────────────────────────────────────
// Unchanged from S-005/S-006. all_ok:false is a hard suite failure.
// Do not set any USE_MOCK = false until this passes.
async function testSchemaCheck() {
  console.log("\n── /api/schema/check");
  const { status, body } = await GET("/api/schema/check");

  if (status === 200 || status === 500) pass(`/api/schema/check — responded (HTTP ${status})`);
  else fail("/api/schema/check — responded", `Unexpected ${status}`);

  if (!body) { fail("/api/schema/check — body parseable", "Not valid JSON"); return; }

  checkEnvelope("/api/schema/check", body);

  const checks = body.data?.checks;
  if (!Array.isArray(checks)) { fail("/api/schema/check — data.checks is array", `Got ${typeof checks}`); return; }
  pass("/api/schema/check — data.checks is array");

  const summary = body.data?.summary;
  if (Array.isArray(summary) && summary.length > 0)
    pass(`/api/schema/check — data.summary has ${summary.length} plain-English line(s)`);
  else
    fail("/api/schema/check — data.summary present", `Got: ${JSON.stringify(summary)}`);

  for (const c of checks) {
    if (c.error) {
      fail(`/api/schema/check — ${c.name} query ok`, `Error: ${c.error}`);
    } else if (!c.exists) {
      fail(`/api/schema/check — ${c.name} exists`,
        `"${c.name}" not found. Run schema setup SQL before going live.`
      );
    } else if (!c.has_rows) {
      fail(`/api/schema/check — ${c.name} has rows`,
        `"${c.name}" exists but is empty. Seed before going live.`
      );
    } else {
      pass(`/api/schema/check — ${c.name} exists and has rows`);
    }
  }

  if (body.data?.all_ok === true)
    pass("/api/schema/check — all_ok:true");
  else
    fail("/api/schema/check — all_ok:true",
      "all_ok is false — tables/views missing or empty. " +
      "Do not set USE_MOCK = false in any component until this passes."
    );
}

// ── Unknown route ──────────────────────────────────────────────────────────────
async function testNotFound() {
  console.log("\n── Unknown route → 404 JSON envelope");
  const { status, body } = await GET("/api/this-does-not-exist-s007");

  if (status === 404) pass("Unknown route — status 404");
  else fail("Unknown route — status 404", `Got ${status}`);

  if (body && typeof body === "object" && "success" in body)
    pass("Unknown route — returns JSON envelope (not HTML)");
  else
    fail("Unknown route — returns JSON envelope",
      "React should never receive HTML for missing API routes."
    );
}

// ─── Runner ───────────────────────────────────────────────────────────────────
async function run() {
  console.log(`\nGDA Smoke Tests — S-007`);
  console.log(`Target: ${BASE}`);
  if (TEST_QUALIFY_WRITE) {
    console.log(`⚠  TEST_QUALIFY_WRITE=true — real write test ENABLED for record: ${TEST_QUALIFY_OPP_ID}`);
  } else {
    console.log(`○  TEST_QUALIFY_WRITE not set — real write test will be SKIPPED (safe default)`);
  }
  console.log("─".repeat(60));

  try {
    await testHealth();
    await testFinancialKpis();
    await testLaunchpadSummary();
    await testTop10();
    await testQualifyDryRun();
    await testQualifyWritePath();       // S-007: new write path safety tests
    await testQualifyDryRunFalseGate(); // S-004–S-007 hard gate preserved
    await testSchemaCheck();
    await testNotFound();
  } catch (err) {
    console.error("\n[FATAL] Test runner threw an unexpected error:");
    console.error(err);
    console.error("\nIs Express running?\n  cd api && npm run dev\n");
    process.exit(1);
  }

  console.log("\n" + "─".repeat(60));
  console.log(`Results: ${passed} passed, ${failed} failed`);

  if (failed === 0) {
    console.log("\n✅  ALL TESTS PASSED — S-007 API layer is clean.\n");
    process.exit(0);
  } else {
    console.log("\n❌  FAILURES:\n");
    for (const f of failures) {
      console.log(`  • ${f.name}`);
      console.log(`      ${f.reason}`);
    }
    console.log();
    process.exit(1);
  }
}

run();
