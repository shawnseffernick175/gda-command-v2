/**
 * GDA Rebuild — API Layer (Production Proxy Stubs)
 * S-001 | Phase 1
 *
 * These are the Express route stubs that back the React /api/... calls.
 * Deploy these alongside the React build (Render, Railway, Fly.io, etc.)
 * All responses MUST use the standard envelope.
 *
 * Standard Envelope Contract:
 * {
 *   success:  boolean,
 *   workflow: string,   // n8n workflow identifier or "direct-db"
 *   action:   string,   // what action was performed
 *   dryRun:   boolean,  // true = preview only, no writes
 *   data:     any,      // the actual payload
 *   meta:     object,   // pagination, period, asOf, etc.
 *   error:    string|null
 * }
 */

const express = require("express");
const { Pool } = require("pg");
const router = express.Router();

const pool = new Pool({ connectionString: process.env.DATABASE_URL });

// ─── Envelope helper ─────────────────────────────────────────────────────────
function envelope({ success = true, workflow = "direct-db", action = "", dryRun = false, data = null, meta = {}, error = null }) {
  return { success, workflow, action, dryRun, data, meta, error };
}

function errEnvelope(action, msg, workflow = "direct-db") {
  return envelope({ success: false, workflow, action, data: null, error: msg });
}

// ─── GET /api/financial/kpis ─────────────────────────────────────────────────
// Returns the 7 persistent KPI values from the financial_kpis view.
// Click-through routes in the KPI strip navigate to /api/financial/:kpi
router.get("/financial/kpis", async (req, res) => {
  try {
    const { rows } = await pool.query(`
      SELECT
        kpi_key,
        display_value,
        raw_value,
        delta_pct,
        delta_positive,
        period_label,
        as_of_date
      FROM financial_kpis_current
      WHERE kpi_key IN (
        'orders', 'sales', 'ebit', 'ros',
        'funded_backlog', 'backlog', 'gross_profit'
      )
    `);

    const data = {};
    let period = null;
    let asOf = null;
    for (const row of rows) {
      data[row.kpi_key] = {
        value:    row.display_value,
        raw:      parseFloat(row.raw_value),
        delta:    row.delta_pct,
        positive: row.delta_positive,
      };
      period = period || row.period_label;
      asOf   = asOf   || row.as_of_date;
    }

    return res.json(envelope({
      action: "get_kpis",
      data,
      meta: { period, asOf },
    }));
  } catch (e) {
    return res.status(500).json(errEnvelope("get_kpis", e.message));
  }
});

// ─── GET /api/financial/:kpi ─────────────────────────────────────────────────
// Returns drill-down detail for a specific KPI (used by Financial Bible pages).
// React KPI strip click-throughs route here.
router.get("/financial/:kpi", async (req, res) => {
  const { kpi } = req.params;
  const VALID_KPIS = ["orders", "sales", "ebit", "ros", "funded_backlog", "backlog", "gross_profit"];
  if (!VALID_KPIS.includes(kpi)) {
    return res.status(400).json(errEnvelope("get_kpi_detail", `Invalid KPI key: ${kpi}`));
  }
  try {
    const { rows } = await pool.query(
      `SELECT * FROM financial_kpi_detail WHERE kpi_key = $1 ORDER BY period_date DESC LIMIT 24`,
      [kpi]
    );
    return res.json(envelope({
      action: "get_kpi_detail",
      data: rows,
      meta: { kpi },
    }));
  } catch (e) {
    return res.status(500).json(errEnvelope("get_kpi_detail", e.message));
  }
});

// ─── GET /api/launchpad/summary ───────────────────────────────────────────────
// Returns the Launchpad-specific summary strip counts.
router.get("/launchpad/summary", async (req, res) => {
  try {
    const { rows } = await pool.query(`
      SELECT
        (SELECT COUNT(*) FROM opportunities WHERE status = 'opportunity') AS opportunity_count,
        (SELECT COUNT(*) FROM opportunities WHERE status = 'pipeline')    AS pipeline_count,
        (SELECT COUNT(*) FROM risks WHERE resolved_at IS NULL)            AS active_risks,
        (SELECT COUNT(*) FROM decisions WHERE due_date <= CURRENT_DATE + 7 AND resolved_at IS NULL) AS decisions_due,
        (SELECT COUNT(*) FROM opportunities WHERE due_date <= CURRENT_DATE + 7 AND status = 'opportunity') AS due_soon,
        (SELECT COUNT(*) FROM opportunities WHERE fast_track = true AND status = 'opportunity') AS fast_track_signals
    `);
    const row = rows[0];
    return res.json(envelope({
      action: "get_launchpad_summary",
      data: {
        opportunityCount:  parseInt(row.opportunity_count),
        pipelineCount:     parseInt(row.pipeline_count),
        activeRisks:       parseInt(row.active_risks),
        decisionsDue:      parseInt(row.decisions_due),
        dueSoon:           parseInt(row.due_soon),
        fastTrackSignals:  parseInt(row.fast_track_signals),
      },
      meta: { asOf: new Date().toISOString().split("T")[0] },
    }));
  } catch (e) {
    return res.status(500).json(errEnvelope("get_launchpad_summary", e.message));
  }
});

// ─── GET /api/opportunities/top10 ────────────────────────────────────────────
// Returns top 10 scored opportunities (NOT pipeline).
// Scoring must come from the opportunities.score column (populated by n8n scoring workflow).
// status = 'opportunity' enforced — pipeline rows excluded.
router.get("/opportunities/top10", async (req, res) => {
  try {
    const { rows } = await pool.query(`
      SELECT
        id,
        title,
        department       AS dept,
        display_value    AS value,
        pwin,
        score,
        status,
        due_date
      FROM opportunities
      WHERE status = 'opportunity'
        AND score IS NOT NULL
      ORDER BY score DESC
      LIMIT 10
    `);
    return res.json(envelope({
      action: "get_top10_scored",
      workflow: "gda.ops.opportunities",
      data: rows,
      meta: {
        asOf: new Date().toISOString().split("T")[0],
        note: "Opportunities only. Pipeline excluded until explicitly qualified.",
      },
    }));
  } catch (e) {
    return res.status(500).json(errEnvelope("get_top10_scored", e.message, "gda.ops.opportunities"));
  }
});

// ─── GET /api/opportunities/:id ───────────────────────────────────────────────
// Opportunity detail (used by Ops Tracker click-through from Launchpad).
router.get("/opportunities/:id", async (req, res) => {
  try {
    const { rows } = await pool.query(
      `SELECT * FROM opportunities WHERE id = $1`,
      [req.params.id]
    );
    if (!rows.length) {
      return res.status(404).json(errEnvelope("get_opportunity", `Opportunity ${req.params.id} not found`));
    }
    return res.json(envelope({ action: "get_opportunity", data: rows[0] }));
  } catch (e) {
    return res.status(500).json(errEnvelope("get_opportunity", e.message));
  }
});

// ─── POST /api/opportunities/:id/qualify ──────────────────────────────────────
// Qualifies an opportunity into pipeline.
// REQUIRES: dryRun:true first — write-capable path.
// Approval required before any real write.
router.post("/opportunities/:id/qualify", async (req, res) => {
  const { dryRun = true } = req.body;
  const { id } = req.params;

  // Preview mode — always safe
  if (dryRun) {
    const { rows } = await pool.query(
      `SELECT id, title, status FROM opportunities WHERE id = $1`,
      [id]
    );
    if (!rows.length) {
      return res.status(404).json(errEnvelope("qualify_opportunity", `Opportunity ${id} not found`));
    }
    const opp = rows[0];
    if (opp.status === "pipeline") {
      return res.json(envelope({
        success: false, action: "qualify_opportunity", dryRun: true,
        data: null, error: `${id} is already pipeline`,
      }));
    }
    return res.json(envelope({
      action: "qualify_opportunity", dryRun: true,
      data: { id, title: opp.title, currentStatus: opp.status, projectedStatus: "pipeline" },
      meta: { note: "DRY RUN — no write performed. Set dryRun:false to execute." },
    }));
  }

  // Live write — requires explicit dryRun:false
  try {
    await pool.query(
      `UPDATE opportunities SET status = 'pipeline', qualified_at = NOW() WHERE id = $1`,
      [id]
    );
    return res.json(envelope({
      action: "qualify_opportunity", dryRun: false,
      data: { id, status: "pipeline" },
    }));
  } catch (e) {
    return res.status(500).json(errEnvelope("qualify_opportunity", e.message));
  }
});

// ─── Health check ─────────────────────────────────────────────────────────────
router.get("/health", async (req, res) => {
  try {
    await pool.query("SELECT 1");
    return res.json(envelope({
      action: "health_check",
      data: { db: "ok", api: "ok" },
      meta: { ts: new Date().toISOString() },
    }));
  } catch (e) {
    return res.status(503).json(errEnvelope("health_check", `DB unreachable: ${e.message}`));
  }
});

module.exports = router;

/*
 * Mount in your Express app:
 *
 *   const gdaApi = require('./routes/gda-api');
 *   app.use('/api', gdaApi);
 *
 * React calls:
 *   fetch('/api/financial/kpis')         → KPI strip data
 *   fetch('/api/launchpad/summary')      → Launchpad summary strip
 *   fetch('/api/opportunities/top10')    → Top 10 scored opportunities
 *   fetch('/api/opportunities/:id')      → Opportunity detail
 *   fetch('/api/financial/:kpi')         → Financial Bible drill-down
 *   fetch('/api/health')                 → Smoke check
 */
