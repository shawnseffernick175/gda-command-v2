/**
 * GDA Rebuild — API Routes
 * S-008 | Phase 2
 *
 * CHANGES vs S-007 (gda-api-routes-4-3.js)
 * ------------------------------------------
 * 1. GET /api/opportunities/pipeline — NEW (S-008 primary addition)
 *    - Returns all opportunities with status = 'Pipeline', ordered by qualified_at DESC.
 *    - Read-only. No write path. No dryRun parameter.
 *    - Standard envelope: { success, workflow, action, dryRun:false, data, meta, error }
 *    - data.opportunities: [ { id, title, dept, value, pwin, score, status, qualified_at, due_date } ]
 *    - meta: { count, generated_at, filters_applied }
 *    - Empty array (count:0) is a valid success:true response.
 *    - DB errors return 500 with envelope; raw SQL is never sent to client.
 *
 * 2. POST /api/opportunities/:id/qualify — strengthened audit log
 *    - Audit line now always includes a correlation_id (timestamp-based), plus
 *      opportunity_id, previous_status, new_status, qualified_at, and triggered_by.
 *    - Single line per write — grepping [GDA QUALIFY WRITE] gives one line per event.
 *    - No other changes. All S-007 safety gates are preserved byte-for-byte.
 *
 * QUALIFY_WRITES_ENABLED ENV FLAG — unchanged from S-007
 * -------------------------------------------------------
 * Server-side guard. Must be explicitly set to "true" in the environment to
 * allow real DB writes via the qualify endpoint.
 *
 *   export QUALIFY_WRITES_ENABLED=true   # development only, explicit opt-in
 *
 * Defaults to false. Do not set in production unless Shawn has explicitly
 * signed off on enabling live qualification writes.
 *
 * FROZEN WORKFLOWS — DO NOT TOUCH
 * --------------------------------
 * GDA.api.ingest  (MJapg8dGkvEzLn0K)
 * Frozen workflow 1 (1G4gw4N7DFtVZKF7)
 * Frozen workflow 2 (NQmaj5nu4TBQxBgD)
 */

"use strict";

const express = require("express");
const router  = express.Router();

// ─── Env flag: real writes require this to be explicitly enabled ───────────────
// Default: false. Operator must set QUALIFY_WRITES_ENABLED=true in dev env.
const QUALIFY_WRITES_ENABLED = process.env.QUALIFY_WRITES_ENABLED === "true";

// ─── Standard envelope ────────────────────────────────────────────────────────
function envelope({ success, workflow, action, dryRun, data, meta, error }) {
  return { success, workflow, action, dryRun, data, meta, error };
}

// ─── Correlation ID helper ────────────────────────────────────────────────────
// Timestamp-based correlation id suitable for log grep.
// Format: GDA-<epoch-ms>-<4-char-random-hex>
// Example: GDA-1714932811042-a3f7
function makeCorrelationId() {
  const rand = Math.floor(Math.random() * 0xffff).toString(16).padStart(4, "0");
  return `GDA-${Date.now()}-${rand}`;
}

// ─── GET /api/opportunities/pipeline ─────────────────────────────────────────
//
// Returns all opportunities with status = 'Pipeline'.
// Ordered by qualified_at DESC NULLS LAST, then id ASC for stable sort.
//
// This endpoint is READ-ONLY.
// No write parameters are accepted. No dryRun semantics apply.
//
router.get("/api/opportunities/pipeline", async (req, res) => {
  const db       = req.app.locals.db;
  const WORKFLOW = "gda-opportunities";
  const ACTION   = "pipeline-list";

  try {
    const result = await db.query(`
      SELECT
        id,
        title,
        dept,
        value,
        pwin,
        score,
        status,
        qualified_at,
        due_date
      FROM opportunities
      WHERE status = 'Pipeline'
      ORDER BY qualified_at DESC NULLS LAST, id ASC
    `);

    const opportunities = result.rows;
    const generatedAt   = new Date().toISOString();

    return res.status(200).json(envelope({
      success:  true,
      workflow: WORKFLOW,
      action:   ACTION,
      dryRun:   false,
      data: {
        opportunities,
      },
      meta: {
        count:           opportunities.length,
        generated_at:    generatedAt,
        filters_applied: {},
      },
      error: null,
    }));

  } catch (err) {
    // Never leak raw SQL error details to the client.
    console.error(`[GDA PIPELINE LIST ERROR] ${err.message}`);
    return res.status(500).json(envelope({
      success:  false,
      workflow: WORKFLOW,
      action:   ACTION,
      dryRun:   false,
      data:     null,
      meta: {
        count:           0,
        generated_at:    new Date().toISOString(),
        filters_applied: {},
      },
      error: "Failed to retrieve pipeline opportunities. Check DB connection and opportunities table.",
    }));
  }
});

// ─── POST /api/opportunities/:id/qualify ──────────────────────────────────────
//
// Safety matrix (unchanged from S-007):
//   { dryRun: true }                      → preview only, never writes, always safe
//   { dryRun: false, approve: true }       → real write (if QUALIFY_WRITES_ENABLED)
//   { dryRun: false, approve: !true }      → HTTP 400, safety gate
//   { dryRun: false }  (approve absent)   → HTTP 400, safety gate
//
router.post("/api/opportunities/:id/qualify", async (req, res) => {
  const { id }              = req.params;
  const { dryRun, approve } = req.body || {};
  const db                  = req.app.locals.db;
  const WORKFLOW            = "gda-qualify-opportunity";
  const ACTION              = "qualify";

  // ── 1. dryRun:true — preview path (unchanged from S-007) ──────────────────
  if (dryRun === true) {
    try {
      const result = await db.query(
        "SELECT id, title, status FROM opportunities WHERE id = $1",
        [id]
      );

      if (result.rows.length === 0) {
        return res.status(404).json(envelope({
          success:  false,
          workflow: WORKFLOW,
          action:   ACTION,
          dryRun:   true,
          data:     null,
          meta:     { id },
          error:    `Opportunity ${id} not found.`,
        }));
      }

      const opp              = result.rows[0];
      const alreadyQualified = opp.status === "Pipeline";
      const wouldChange      = !alreadyQualified;

      return res.status(200).json(envelope({
        success:  true,
        workflow: WORKFLOW,
        action:   ACTION,
        dryRun:   true,
        data: {
          opportunity_id:    opp.id,
          title:             opp.title,
          current_status:    opp.status,
          proposed_status:   "Pipeline",
          would_change:      wouldChange,
          already_qualified: alreadyQualified,
          fields_to_update:  wouldChange
            ? [
                { field: "status",       from: opp.status, to: "Pipeline" },
                { field: "qualified_at", to: "NOW()" },
              ]
            : [],
          note: alreadyQualified
            ? "This opportunity is already Pipeline — no changes would occur."
            : "Qualifying will set status = Pipeline and record qualified_at timestamp. " +
              "Approve & Qualify in the UI to apply.",
        },
        meta:  { id, preview_only: true },
        error: null,
      }));

    } catch (err) {
      return res.status(500).json(envelope({
        success:  false,
        workflow: WORKFLOW,
        action:   ACTION,
        dryRun:   true,
        data:     null,
        meta:     { id },
        error:    `DB error during qualify preview: ${err.message}`,
      }));
    }
  }

  // ── 2. dryRun:false path — requires approve:true ──────────────────────────

  // Safety gate: missing or non-true approve is always HTTP 400, regardless of
  // QUALIFY_WRITES_ENABLED. This cannot be bypassed by any env configuration.
  if (approve !== true) {
    return res.status(400).json(envelope({
      success:  false,
      workflow: WORKFLOW,
      action:   ACTION,
      dryRun:   false,
      data:     null,
      meta:     { id },
      error:    "Real write requires explicit approve:true — this is a safety gate. " +
                "Send { dryRun: false, approve: true } only after the user has confirmed " +
                "the Approve & Qualify action in the UI.",
    }));
  }

  // QUALIFY_WRITES_ENABLED guard: writes are off by default in all environments.
  // Set QUALIFY_WRITES_ENABLED=true in dev to enable real DB writes.
  if (!QUALIFY_WRITES_ENABLED) {
    return res.status(400).json(envelope({
      success:  false,
      workflow: WORKFLOW,
      action:   ACTION,
      dryRun:   false,
      data:     null,
      meta:     { id, qualify_writes_enabled: false },
      error:    "Real qualify writes are currently disabled on this server. " +
                "Set QUALIFY_WRITES_ENABLED=true in the server environment to enable " +
                "(development only — requires explicit operator opt-in).",
    }));
  }

  // ── 3. Real write: dryRun:false + approve:true + QUALIFY_WRITES_ENABLED ───
  try {
    // Look up the opportunity first to capture previous_status
    const lookupResult = await db.query(
      "SELECT id, title, status FROM opportunities WHERE id = $1",
      [id]
    );

    if (lookupResult.rows.length === 0) {
      return res.status(404).json(envelope({
        success:  false,
        workflow: WORKFLOW,
        action:   ACTION,
        dryRun:   false,
        data:     null,
        meta:     { id },
        error:    `Opportunity ${id} not found.`,
      }));
    }

    const opp            = lookupResult.rows[0];
    const previousStatus = opp.status;

    // Update status and qualified_at — only if not already Pipeline
    const qualifiedAt     = new Date().toISOString();
    const correlationId   = makeCorrelationId();

    if (previousStatus !== "Pipeline") {
      await db.query(
        "UPDATE opportunities SET status = $1, qualified_at = $2 WHERE id = $3",
        ["Pipeline", qualifiedAt, id]
      );
    }

    const newStatus = "Pipeline";

    // ── S-008: Strengthened audit log ─────────────────────────────────────────
    // Single line per write. Fields: correlation_id, opportunity_id, title (truncated),
    // previous_status, new_status, qualified_at, triggered_by.
    // Grep: grep "[GDA QUALIFY WRITE]" server.log
    const titleSnip = (opp.title || "").substring(0, 40).replace(/\s+/g, "_");
    console.log(
      `[GDA QUALIFY WRITE]` +
      ` correlation_id=${correlationId}` +
      ` | opportunity_id=${id}` +
      ` | title=${titleSnip}` +
      ` | prev_status=${previousStatus}` +
      ` | new_status=${newStatus}` +
      ` | qualified_at=${qualifiedAt}` +
      ` | triggered_by=GDA_REBUILD_UI`
    );

    return res.status(200).json(envelope({
      success:  true,
      workflow: WORKFLOW,
      action:   ACTION,
      dryRun:   false,
      data: {
        opportunity_id:  id,
        title:           opp.title,
        previous_status: previousStatus,
        new_status:      newStatus,
        qualified_at:    qualifiedAt,
        correlation_id:  correlationId,
        note: previousStatus === "Pipeline"
          ? "No change applied — opportunity was already Pipeline before this request."
          : "Qualification applied. status = Pipeline and qualified_at recorded. " +
            "The Ops Tracker table will reflect the updated status on next refresh.",
      },
      meta:  { id, triggered_by: "GDA_REBUILD_UI", qualify_writes_enabled: true, correlation_id: correlationId },
      error: null,
    }));

  } catch (err) {
    console.error(`[GDA QUALIFY WRITE ERROR] id=${id} | ${err.message}`);
    return res.status(500).json(envelope({
      success:  false,
      workflow: WORKFLOW,
      action:   ACTION,
      dryRun:   false,
      data:     null,
      meta:     { id },
      error:    `DB error during qualify write: ${err.message}`,
    }));
  }
});

module.exports = router;
