/**
 * GDA Rebuild — Smoke Test Runner
 * S-008 | Phase 2
 *
 * CHANGES vs S-007 (gda-smoke-tests-7.js)
 * -----------------------------------------
 * - Suite header updated to S-008.
 * - testPipelineView(): NEW test suite for GET /api/opportunities/pipeline.
 *   - HTTP 200 required.
 *   - Full envelope contract asserted.
 *   - success:true required (even if zero rows — empty pipeline is valid).
 *   - data.opportunities must be an array.
 *   - meta.count must be a number.
 *   - When array is non-empty: first row must include all required columns.
 *   - All status values in the array must equal 'Pipeline'.
 *   - This test is always READ-ONLY and always safe to run in any environment.
 * - All S-004 through S-007 tests are UNCHANGED. No assertions weakened. No gates removed.
 *
 * S-008 PIPELINE VIEW TEST — SAFETY NOTES
 * ----------------------------------------
 * testPipelineView() is purely a GET request — no writes, no dryRun parameters,
 * no approve payload. It is always safe to run against any environment.
 * If the pipeline is empty in the test environment, the test will still pass
 * (success:true + empty array is the correct server behavior per the S-008 spec).
 *
 * Usage:
 *   node gda-smoke-tests-8.js http://localhost:3001
 *   node gda-smoke-tests-8.js $GDA_PROD_URL
 *
 * Exit codes:
 *   0 — all tests passed
 *   1 — one or more tests failed
 */

"use strict";

// ─── Args ─────────────────────────────────────────────────────────────────────
const BASE = (process.argv[2] || "http://localhost:3001").replace(/\/$/, "");

// ─── S-007 real-write test guard (unchanged) ──────────────────────────────────
const TEST_QUALIFY_WRITE   = process.env.TEST_QUALIFY_WRITE === "true";
const TEST_QUALIFY_OPP_ID  = process.env.TEST_QUALIFY_OPP_ID || "TEST-OPP-001";

// ─── Harness ──────────────────────────────────────────────────────────────────
let passed = 0, failed = 0;
const failures = [];

function pass(name) {
  console.log(`  ✓ ${name}`);
  passed++;
}

function fail(name, reason) {
  console.log(`  ✗ ${name}`);
  console.log(`      → ${reason}`);
  failed++;
  failures.push({ name, reason });
}

function warn(name, reason) {
  console.log(`  ⚠ ${name} (non-fatal)`);
  console.log(`      → ${reason}`);
}

function skip(name, reason) {
  console.log(`  ○ ${name} (SKIPPED)`);
  console.log(`      → ${reason}`);
}

async function GET(path) {
  const r    = await fetch(`${BASE}${path}`);
  const body = await r.json().catch(() => null);
  return { status: r.status, body };
}

async function POST(path, payload) {
  const r = await fetch(`${BASE}${path}`, {
    method:  "POST",
    headers: { "Content-Type": "application/json" },
    body:    JSON.stringify(payload),
  });
  const body = await r.json().catch(() => null);
  return { status: r.status, body };
}

function checkEnvelope(name, body) {
  const required = ["success", "workflow", "action", "dryRun", "data", "meta", "error"];
  const missing  = required.filter(k => !(k in body));
  if (missing.length) {
    fail(`${name} — envelope contract`,
      `Missing fields: ${missing.join(", ")}. Every endpoint must return the full standard envelope.`
    );
    return false;
  }
  pass(`${name} — envelope contract`);
  return true;
}

// ─── Tests ────────────────────────────────────────────────────────────────────

// ── /api/health ───────────────────────────────────────────────────────────────
async function testHealth() {
  console.log("\n── /api/health");
  const { status, body } = await GET("/api/health");

  if (status === 200) pass("/api/health — status 200");
  else fail("/api/health — status 200", `Got HTTP ${status}`);

  if (!body) { fail("/api/health — body parseable", "Not valid JSON"); return; }

  checkEnvelope("/api/health", body);

  if (body.data?.db === "ok") pass("/api/health — db ok");
  else fail("/api/health — db ok",
    `db is "${body.data?.db}". Msg: ${body.data?.db_message}. Check DATABASE_URL + Postgres.`
  );
}

// ── /api/financial/kpis ───────────────────────────────────────────────────────
async function testFinancialKpis() {
  console.log("\n── /api/financial/kpis  [S-006: consumed by GDAFinancialBible]");
  const { status, body } = await GET("/api/financial/kpis");

  if (status === 200) pass("/api/financial/kpis — status 200");
  else fail("/api/financial/kpis — status 200", `Got HTTP ${status}`);

  if (!body) { fail("/api/financial/kpis — body parseable", "Not valid JSON"); return; }

  checkEnvelope("/api/financial/kpis", body);

  if (!body.success) {
    fail("/api/financial/kpis — success:true",
      `success is false. Error: ${body.error}. ` +
      "financial_kpis_current view may be missing or empty."
    );
    return;
  }
  pass("/api/financial/kpis — success:true");

  const required = ["orders", "sales", "ebit", "ros", "funded_backlog", "backlog", "gross_profit"];
  const kpis     = body.data?.kpis || {};
  const missing  = required.filter(k => !(k in kpis));
  if (missing.length) {
    fail("/api/financial/kpis — all 7 KPI keys under data.kpis",
      `Missing: ${missing.join(", ")}. ` +
      "GDAFinancialBible overview grid requires all 7 keys. Check financial_kpis_current view."
    );
  } else {
    pass("/api/financial/kpis — all 7 KPI keys present (orders, sales, ebit, ros, funded_backlog, backlog, gross_profit)");
  }
}

// ── /api/launchpad/summary ────────────────────────────────────────────────────
async function testLaunchpadSummary() {
  console.log("\n── /api/launchpad/summary  [S-006: drives Launchpad secondary strip]");
  const { status, body } = await GET("/api/launchpad/summary");

  if (status === 200) pass("/api/launchpad/summary — status 200");
  else fail("/api/launchpad/summary — status 200", `Got HTTP ${status}`);

  if (!body) { fail("/api/launchpad/summary — body parseable", "Not valid JSON"); return; }

  checkEnvelope("/api/launchpad/summary", body);

  const d = body.data || {};
  const stripKeys = ["total_opportunities", "pipeline_count", "active_risks"];
  const missingStrip = stripKeys.filter(k => !(k in d));
  if (missingStrip.length) {
    fail("/api/launchpad/summary — S-006 strip keys present",
      `Missing: ${missingStrip.join(", ")}. ` +
      "GDALaunchpad secondary strip reads total_opportunities, pipeline_count, active_risks. " +
      `Got: ${Object.keys(d).join(", ")}`
    );
  } else {
    pass("/api/launchpad/summary — S-006 strip keys present (total_opportunities, pipeline_count, active_risks)");
  }
}

// ── /api/opportunities/top10 ──────────────────────────────────────────────────
async function testTop10() {
  console.log("\n── /api/opportunities/top10");
  const { status, body } = await GET("/api/opportunities/top10");

  if (status === 200) pass("/api/opportunities/top10 — status 200");
  else fail("/api/opportunities/top10 — status 200", `Got HTTP ${status}`);

  if (!body) { fail("/api/opportunities/top10 — body parseable", "Not valid JSON"); return; }

  checkEnvelope("/api/opportunities/top10", body);

  if (!body.success) {
    fail("/api/opportunities/top10 — success:true", `success false. Error: ${body.error}`);
    return;
  }
  pass("/api/opportunities/top10 — success:true");

  const opps = body.data?.opportunities;
  if (!Array.isArray(opps)) {
    fail("/api/opportunities/top10 — data.opportunities is array", `Got: ${typeof opps}`);
    return;
  }
  pass("/api/opportunities/top10 — data.opportunities is array");

  if (opps.length > 0) {
    const cols        = ["id", "title", "dept", "value", "pwin", "score", "status", "due_date"];
    const missingCols = cols.filter(c => !(c in opps[0]));
    if (missingCols.length)
      fail("/api/opportunities/top10 — row has required columns",
        `Missing: ${missingCols.join(", ")}.`
      );
    else
      pass("/api/opportunities/top10 — row has required columns");
  }

  pass(`/api/opportunities/top10 — returned ${opps.length} rows`);
}

// ── /api/opportunities/pipeline — S-008 NEW ───────────────────────────────────
//
// SAFETY CLASSIFICATION: ALWAYS SAFE
// This is a GET request. No writes. No dryRun. No approve. Safe in any environment.
// An empty pipeline is a valid success:true response.
//
async function testPipelineView() {
  console.log("\n── /api/opportunities/pipeline  [S-008: read-only pipeline list]");

  const { status, body } = await GET("/api/opportunities/pipeline");

  // ── HTTP 200 ───────────────────────────────────────────────────────────────
  if (status === 200) pass("/api/opportunities/pipeline — status 200");
  else {
    fail("/api/opportunities/pipeline — status 200",
      `Got HTTP ${status}. Pipeline endpoint must exist and return 200. ` +
      "Check that GET /api/opportunities/pipeline is registered in gda-api-routes-4-3.js."
    );
    // If we didn't get a body we can check, abort this suite
    if (!body) {
      fail("/api/opportunities/pipeline — body parseable", "Not valid JSON — cannot continue suite.");
      return;
    }
  }

  if (!body) { fail("/api/opportunities/pipeline — body parseable", "Not valid JSON"); return; }

  // ── Envelope contract ──────────────────────────────────────────────────────
  const envelopeOk = checkEnvelope("/api/opportunities/pipeline", body);

  // ── success:true (even if zero rows) ──────────────────────────────────────
  if (body.success === true) {
    pass("/api/opportunities/pipeline — success:true");
  } else {
    fail("/api/opportunities/pipeline — success:true",
      `success is ${body.success}. Error: ${body.error}. ` +
      "An empty pipeline should still return success:true with an empty array. " +
      "Check DB connection and the WHERE status = 'Pipeline' query."
    );
    return; // can't check array shape if success is false
  }

  // ── workflow and action identity ───────────────────────────────────────────
  if (body.workflow === "gda-opportunities") {
    pass("/api/opportunities/pipeline — workflow: gda-opportunities");
  } else {
    fail("/api/opportunities/pipeline — workflow: gda-opportunities",
      `Got: "${body.workflow}". Must be "gda-opportunities".`
    );
  }

  if (body.action === "pipeline-list") {
    pass("/api/opportunities/pipeline — action: pipeline-list");
  } else {
    fail("/api/opportunities/pipeline — action: pipeline-list",
      `Got: "${body.action}". Must be "pipeline-list".`
    );
  }

  // dryRun must be false (this is a read endpoint, not a write path)
  if (body.dryRun === false) {
    pass("/api/opportunities/pipeline — dryRun:false");
  } else {
    fail("/api/opportunities/pipeline — dryRun:false",
      `Got dryRun: ${body.dryRun}. Read endpoints must have dryRun:false in the envelope.`
    );
  }

  // ── data.opportunities is an array ────────────────────────────────────────
  const opps = body.data?.opportunities;
  if (!Array.isArray(opps)) {
    fail("/api/opportunities/pipeline — data.opportunities is array",
      `Got: ${typeof opps}. Must be an array (can be empty). ` +
      "Check the pipeline endpoint response structure."
    );
    return;
  }
  pass("/api/opportunities/pipeline — data.opportunities is array");

  // ── meta.count is a number ────────────────────────────────────────────────
  const count = body.meta?.count;
  if (typeof count === "number") {
    pass(`/api/opportunities/pipeline — meta.count is a number (${count})`);
  } else {
    fail("/api/opportunities/pipeline — meta.count is a number",
      `Got: ${JSON.stringify(count)} (type: ${typeof count}). meta.count must be a number.`
    );
  }

  // meta.count should match the array length
  if (typeof count === "number" && count !== opps.length) {
    fail("/api/opportunities/pipeline — meta.count matches array length",
      `meta.count=${count} but data.opportunities.length=${opps.length}. These must agree.`
    );
  } else if (typeof count === "number") {
    pass(`/api/opportunities/pipeline — meta.count (${count}) matches array length`);
  }

  // ── meta.generated_at is present ──────────────────────────────────────────
  if (body.meta?.generated_at) {
    pass("/api/opportunities/pipeline — meta.generated_at present");
  } else {
    warn("/api/opportunities/pipeline — meta.generated_at",
      "meta.generated_at not present. Pipeline list should include generation timestamp."
    );
  }

  // ── Empty array is valid — count this as a pass ───────────────────────────
  if (opps.length === 0) {
    pass("/api/opportunities/pipeline — zero rows (empty pipeline is valid success response)");
    console.log("  ℹ  Pipeline is currently empty. This is valid — row-level assertions skipped.");
    console.log("     To test column shape, qualify at least one opportunity via Ops Tracker first.");
    return;
  }

  // ── Non-empty: assert required columns on first row ───────────────────────
  pass(`/api/opportunities/pipeline — ${opps.length} pipeline record(s) returned`);

  const REQUIRED_COLS = ["id", "title", "dept", "value", "pwin", "score", "status"];
  const OPTIONAL_COLS = ["qualified_at", "due_date"];
  const firstRow      = opps[0];

  const missingRequired = REQUIRED_COLS.filter(c => !(c in firstRow));
  if (missingRequired.length) {
    fail("/api/opportunities/pipeline — required columns on first row",
      `Missing: ${missingRequired.join(", ")}. ` +
      "SELECT clause must include all required columns."
    );
  } else {
    pass(`/api/opportunities/pipeline — required columns present on first row (${REQUIRED_COLS.join(", ")})`);
  }

  // Check optional columns — warn, don't fail
  const missingOptional = OPTIONAL_COLS.filter(c => !(c in firstRow));
  if (missingOptional.length) {
    warn("/api/opportunities/pipeline — optional columns on first row",
      `Missing: ${missingOptional.join(", ")}. ` +
      "GDAPipelineView renders these when available. Confirm SELECT includes them."
    );
  } else {
    pass(`/api/opportunities/pipeline — optional columns present (${OPTIONAL_COLS.join(", ")})`);
  }

  // ── Every row must have status = 'Pipeline' ───────────────────────────────
  const nonPipeline = opps.filter(o => o.status !== "Pipeline");
  if (nonPipeline.length > 0) {
    fail("/api/opportunities/pipeline — all rows have status = Pipeline",
      `${nonPipeline.length} row(s) have non-Pipeline status: ` +
      nonPipeline.map(o => `${o.id}(${o.status})`).join(", ") +
      ". The WHERE clause must filter to status = 'Pipeline' only."
    );
  } else {
    pass("/api/opportunities/pipeline — all rows have status = Pipeline");
  }
}

// ── /api/opportunities/:id/qualify (dryRun:true) ──────────────────────────────
async function testQualifyDryRun() {
  console.log("\n── /api/opportunities/:id/qualify (dryRun:true)  [S-006/S-007: panel note field]");

  const top10   = await GET("/api/opportunities/top10");
  const firstId = top10.body?.data?.opportunities?.[0]?.id;

  const { status: s404, body: b404 } = await POST(
    "/api/opportunities/NONEXISTENT-ID-999/qualify",
    { dryRun: true }
  );

  if (s404 === 404) pass("/api/qualify dryRun — 404 on missing ID");
  else fail("/api/qualify dryRun — 404 on missing ID", `Expected 404, got ${s404}`);

  if (b404) checkEnvelope("/api/qualify dryRun 404", b404);

  if (b404?.dryRun === true) pass("/api/qualify dryRun — dryRun:true in 404 envelope");
  else fail("/api/qualify dryRun — dryRun:true in 404 envelope", `dryRun: ${b404?.dryRun}`);

  if (firstId) {
    const { status: s200, body: b200 } = await POST(
      `/api/opportunities/${firstId}/qualify`,
      { dryRun: true }
    );

    if (s200 === 200) pass(`/api/qualify dryRun — 200 on real ID (${firstId})`);
    else fail(`/api/qualify dryRun — 200 on real ID (${firstId})`, `Got ${s200}`);

    if (b200) checkEnvelope("/api/qualify dryRun 200", b200);

    if (b200?.dryRun === true) pass("/api/qualify dryRun — dryRun:true confirmed");
    else fail("/api/qualify dryRun — dryRun:true confirmed", `dryRun: ${b200?.dryRun}`);

    const d = b200?.data || {};

    const panelFields  = ["current_status", "proposed_status", "would_change", "already_qualified"];
    const missingPanel = panelFields.filter(f => !(f in d));
    if (missingPanel.length) {
      fail("/api/qualify dryRun — S-006/S-007 panel fields present",
        `Missing: ${missingPanel.join(", ")}. QualifyPanel requires all four.`
      );
    } else {
      pass("/api/qualify dryRun — panel fields present (current_status, proposed_status, would_change, already_qualified)");
    }

    if ("note" in d) {
      pass("/api/qualify dryRun — data.note field present (panel renders it)");
    } else {
      warn("/api/qualify dryRun — data.note field",
        "data.note not present. Panel renders it when available; absent is acceptable."
      );
    }

    if ("fields_to_update" in d || "already_qualified" in d)
      pass("/api/qualify dryRun — preview data structure present");
    else
      fail("/api/qualify dryRun — preview data structure present",
        `Missing fields_to_update or already_qualified. Got: ${Object.keys(d).join(", ")}`
      );

  } else {
    console.log("  ⚠  Skipping real-ID qualify preview test — top10 returned no rows (DB may be empty)");
  }
}

// ── /api/opportunities/:id/qualify — S-007 write path safety tests ────────────
async function testQualifyWritePath() {
  console.log("\n── /api/opportunities/:id/qualify (S-007 write path safety gate)");

  console.log("  [Test 1] dryRun:false with no approve (ALWAYS SAFE — must 400)");
  const { status: s400a, body: b400a } = await POST(
    "/api/opportunities/NONEXISTENT-ID-999/qualify",
    { dryRun: false }
  );

  if (s400a === 400) pass("/api/qualify write — dryRun:false + no approve → HTTP 400");
  else fail("/api/qualify write — dryRun:false + no approve → HTTP 400",
    `Expected 400, got ${s400a}. S-007 safety gate: missing approve must always 400.`
  );

  if (b400a?.success === false) pass("/api/qualify write — success:false on missing approve");
  else fail("/api/qualify write — success:false on missing approve", `success: ${b400a?.success}`);

  const err1 = (b400a?.error || "").toLowerCase();
  if (err1.includes("approve") || err1.includes("safety gate")) {
    pass("/api/qualify write — error message mentions approve:true requirement");
  } else {
    fail("/api/qualify write — error message mentions approve:true requirement",
      `Error was: "${b400a?.error}". Must mention approve:true or safety gate.`
    );
  }

  if (b400a) checkEnvelope("/api/qualify write — no approve envelope", b400a);

  console.log("  [Test 2] dryRun:false + approve:false (ALWAYS SAFE — must 400)");
  const { status: s400b, body: b400b } = await POST(
    "/api/opportunities/NONEXISTENT-ID-999/qualify",
    { dryRun: false, approve: false }
  );

  if (s400b === 400) pass("/api/qualify write — dryRun:false + approve:false → HTTP 400");
  else fail("/api/qualify write — dryRun:false + approve:false → HTTP 400",
    `Expected 400, got ${s400b}. approve:false must never be treated as approval.`
  );

  if (b400b?.success === false) pass("/api/qualify write — success:false on approve:false");
  else fail("/api/qualify write — success:false on approve:false", `success: ${b400b?.success}`);

  const err2 = (b400b?.error || "").toLowerCase();
  if (err2.includes("approve") || err2.includes("safety gate")) {
    pass("/api/qualify write — approve:false error message correct");
  } else {
    fail("/api/qualify write — approve:false error message correct",
      `Error was: "${b400b?.error}". Must mention approve:true or safety gate.`
    );
  }

  if (b400b) checkEnvelope("/api/qualify write — approve:false envelope", b400b);

  if (!TEST_QUALIFY_WRITE) {
    skip(
      `/api/qualify write — real write test for ${TEST_QUALIFY_OPP_ID}`,
      "TEST_QUALIFY_WRITE is not set. Set TEST_QUALIFY_WRITE=true and " +
      "TEST_QUALIFY_OPP_ID=<test-record-id> to enable in development only. " +
      "Also requires QUALIFY_WRITES_ENABLED=true on the server."
    );
    return;
  }

  console.log(`  [Test 3] dryRun:false + approve:true — real write for ${TEST_QUALIFY_OPP_ID} (DEV ONLY)`);
  console.log("  ⚠  WARNING: This test will attempt a real DB write.");

  const { status: sWrite, body: bWrite } = await POST(
    `/api/opportunities/${TEST_QUALIFY_OPP_ID}/qualify`,
    { dryRun: false, approve: true }
  );

  if (sWrite === 400) {
    const errMsg    = (bWrite?.error || "").toLowerCase();
    const isDisabled = errMsg.includes("qualify_writes_enabled") || errMsg.includes("disabled");
    if (isDisabled) {
      pass(`/api/qualify write [Test 3] — server has QUALIFY_WRITES_ENABLED=false, write safely rejected`);
      warn(`/api/qualify write [Test 3] — real write not tested`,
        "Server has QUALIFY_WRITES_ENABLED=false. Set it to true in dev to test the real write path."
      );
      return;
    }
    fail(`/api/qualify write [Test 3] — unexpected 400`,
      `Error: ${bWrite?.error}. Expected 200 with QUALIFY_WRITES_ENABLED=true, or 400 with disabled message.`
    );
    return;
  }

  if (sWrite === 404) {
    fail(`/api/qualify write [Test 3] — 404 for test record ${TEST_QUALIFY_OPP_ID}`,
      `Test record not found. Create a test opportunity with id=${TEST_QUALIFY_OPP_ID} ` +
      "in the DB before running this test. It must NOT be already Pipeline."
    );
    return;
  }

  if (sWrite === 200 && bWrite?.success === true) {
    pass(`/api/qualify write [Test 3] — HTTP 200 + success:true`);
    checkEnvelope("/api/qualify write [Test 3]", bWrite);

    const d = bWrite?.data || {};

    if (d.opportunity_id) pass("/api/qualify write [Test 3] — data.opportunity_id present");
    else fail("/api/qualify write [Test 3] — data.opportunity_id present", "Missing opportunity_id");

    if (d.previous_status) pass(`/api/qualify write [Test 3] — previous_status present: ${d.previous_status}`);
    else fail("/api/qualify write [Test 3] — previous_status present", "Missing previous_status");

    if (d.new_status === "Pipeline") pass("/api/qualify write [Test 3] — new_status = Pipeline");
    else fail("/api/qualify write [Test 3] — new_status = Pipeline", `Got: ${d.new_status}`);

    if (d.qualified_at) pass(`/api/qualify write [Test 3] — qualified_at populated: ${d.qualified_at}`);
    else fail("/api/qualify write [Test 3] — qualified_at populated", "Missing qualified_at");

    // S-008: correlation_id is now part of the write response
    if (d.correlation_id) {
      pass(`/api/qualify write [Test 3] — correlation_id present: ${d.correlation_id}`);
    } else {
      warn("/api/qualify write [Test 3] — correlation_id",
        "correlation_id not present in write response. S-008 adds this for audit log correlation. " +
        "Check that makeCorrelationId() is wired into the write path."
      );
    }

    if (bWrite?.dryRun === false) pass("/api/qualify write [Test 3] — dryRun:false in envelope");
    else fail("/api/qualify write [Test 3] — dryRun:false in envelope", `dryRun: ${bWrite?.dryRun}`);

    console.log(`  ⚠  REAL WRITE APPLIED to ${TEST_QUALIFY_OPP_ID}. Verify and reset the test record if needed.`);

  } else {
    fail(`/api/qualify write [Test 3] — unexpected response`,
      `HTTP ${sWrite}, success: ${bWrite?.success}, error: ${bWrite?.error}`
    );
  }
}

// ── /api/opportunities/:id/qualify (dryRun:false — legacy safety gate) ────────
async function testQualifyDryRunFalseGate() {
  console.log("\n── /api/opportunities/:id/qualify (dryRun:false gate — S-004–S-008 hard assertion)");

  const { status: s400, body: b400 } = await POST(
    "/api/opportunities/NONEXISTENT-ID-999/qualify",
    { dryRun: false }
  );

  if (s400 === 400) pass("/api/qualify dryRun:false (no approve) — correctly returns HTTP 400");
  else fail("/api/qualify dryRun:false (no approve) — correctly returns HTTP 400",
    `Expected 400, got ${s400}. S-007/S-008 safety gate: dryRun:false without approve:true must always 400.`
  );

  if (b400?.success === false) pass("/api/qualify dryRun:false — success:false");
  else fail("/api/qualify dryRun:false — success:false", `success was ${b400?.success}`);

  const errMsg = (b400?.error || "").toLowerCase();
  const hasExpectedMsg =
    errMsg.includes("approve")     ||
    errMsg.includes("safety gate") ||
    errMsg.includes("not enabled") ||
    errMsg.includes("s-004")       ||
    errMsg.includes("s-005")       ||
    errMsg.includes("s-006")       ||
    errMsg.includes("s-007")       ||
    errMsg.includes("s-008")       ||
    errMsg.includes("dry run");
  if (hasExpectedMsg) pass("/api/qualify dryRun:false — error message explains block reason");
  else fail("/api/qualify dryRun:false — error message explains block reason",
    `Error was: "${b400?.error}". Should mention approve:true, safety gate, sprint ref, or dry run.`
  );

  if (b400?.dryRun === false) pass("/api/qualify dryRun:false — dryRun:false echoed in envelope");
  else fail("/api/qualify dryRun:false — dryRun:false echoed in envelope",
    `dryRun was ${b400?.dryRun}`
  );

  if (b400) checkEnvelope("/api/qualify dryRun:false error response", b400);
}

// ── /api/schema/check ─────────────────────────────────────────────────────────
async function testSchemaCheck() {
  console.log("\n── /api/schema/check");
  const { status, body } = await GET("/api/schema/check");

  if (status === 200 || status === 500) pass(`/api/schema/check — responded (HTTP ${status})`);
  else fail("/api/schema/check — responded", `Unexpected ${status}`);

  if (!body) { fail("/api/schema/check — body parseable", "Not valid JSON"); return; }

  checkEnvelope("/api/schema/check", body);

  const checks = body.data?.checks;
  if (!Array.isArray(checks)) { fail("/api/schema/check — data.checks is array", `Got ${typeof checks}`); return; }
  pass("/api/schema/check — data.checks is array");

  const summary = body.data?.summary;
  if (Array.isArray(summary) && summary.length > 0)
    pass(`/api/schema/check — data.summary has ${summary.length} plain-English line(s)`);
  else
    fail("/api/schema/check — data.summary present", `Got: ${JSON.stringify(summary)}`);

  for (const c of checks) {
    if (c.error) {
      fail(`/api/schema/check — ${c.name} query ok`, `Error: ${c.error}`);
    } else if (!c.exists) {
      fail(`/api/schema/check — ${c.name} exists`,
        `"${c.name}" not found. Run schema setup SQL before going live.`
      );
    } else if (!c.has_rows) {
      fail(`/api/schema/check — ${c.name} has rows`,
        `"${c.name}" exists but is empty. Seed before going live.`
      );
    } else {
      pass(`/api/schema/check — ${c.name} exists and has rows`);
    }
  }

  if (body.data?.all_ok === true)
    pass("/api/schema/check — all_ok:true");
  else
    fail("/api/schema/check — all_ok:true",
      "all_ok is false — tables/views missing or empty. " +
      "Do not set USE_MOCK = false in any component until this passes."
    );
}

// ── Unknown route ──────────────────────────────────────────────────────────────
async function testNotFound() {
  console.log("\n── Unknown route → 404 JSON envelope");
  const { status, body } = await GET("/api/this-does-not-exist-s008");

  if (status === 404) pass("Unknown route — status 404");
  else fail("Unknown route — status 404", `Got ${status}`);

  if (body && typeof body === "object" && "success" in body)
    pass("Unknown route — returns JSON envelope (not HTML)");
  else
    fail("Unknown route — returns JSON envelope",
      "React should never receive HTML for missing API routes."
    );
}

// ─── Runner ───────────────────────────────────────────────────────────────────
async function run() {
  console.log(`\nGDA Smoke Tests — S-008`);
  console.log(`Target: ${BASE}`);
  if (TEST_QUALIFY_WRITE) {
    console.log(`⚠  TEST_QUALIFY_WRITE=true — real write test ENABLED for record: ${TEST_QUALIFY_OPP_ID}`);
  } else {
    console.log(`○  TEST_QUALIFY_WRITE not set — real write test will be SKIPPED (safe default)`);
  }
  console.log("─".repeat(60));

  try {
    await testHealth();
    await testFinancialKpis();
    await testLaunchpadSummary();
    await testTop10();
    await testPipelineView();             // S-008: new pipeline list test (always safe)
    await testQualifyDryRun();
    await testQualifyWritePath();         // S-007: write path safety tests (preserved)
    await testQualifyDryRunFalseGate();   // S-004–S-008: hard gate preserved
    await testSchemaCheck();
    await testNotFound();
  } catch (err) {
    console.error("\n[FATAL] Test runner threw an unexpected error:");
    console.error(err);
    console.error("\nIs Express running?\n  cd api && npm run dev\n");
    process.exit(1);
  }

  console.log("\n" + "─".repeat(60));
  console.log(`Results: ${passed} passed, ${failed} failed`);

  if (failed === 0) {
    console.log("\n✅  ALL TESTS PASSED — S-008 API layer is clean.\n");
    process.exit(0);
  } else {
    console.log("\n❌  FAILURES:\n");
    for (const f of failures) {
      console.log(`  • ${f.name}`);
      console.log(`      ${f.reason}`);
    }
    console.log();
    process.exit(1);
  }
}

run();
