/**
 * GDA Rebuild — Pipeline View Page
 * S-008 | Phase 2
 *
 * PURPOSE
 * -------
 * Read-only view of all opportunities with status = 'Pipeline'.
 * An opportunity only appears here after it has been explicitly qualified
 * via the Approve & Qualify flow in Ops Tracker.
 *
 * THIS PAGE:
 *   - Fetches from GET /api/opportunities/pipeline
 *   - Renders a table with: id, title, dept, value, pwin, score, status, qualified_at, due_date
 *   - Supports basic client-side filtering: dept, min pwin, search by id/title
 *   - Has no write actions. No qualify, no approve, no edit.
 *   - Shows a clear empty state when no Pipeline opportunities exist.
 *   - Audit note is shown in the secondary strip to acknowledge server-side write logging.
 *
 * MOCK MODE
 * ---------
 * USE_MOCK = true renders mock pipeline data so the page works before the API is live.
 * Flip to false to use the real GET /api/opportunities/pipeline endpoint.
 *
 * SAFETY
 * ------
 * No writes. No calls to /qualify. No approval payloads. This file is purely read-only.
 *
 * ROUTES
 * ------
 * Add <Route path="/pipeline" element={<GDAPipelineView />} /> to App shell.
 */

import { useState, useEffect, useCallback } from "react";
import { GDAKpiStrip } from "./GDAKpiContext.jsx";

// ─── Config ───────────────────────────────────────────────────────────────────
export const USE_MOCK = true;

// ─── Mock data — qualified pipeline opportunities ─────────────────────────────
const MOCK_PIPELINE = [
  {
    id:           "OPP-002",
    title:        "AFRL Advanced ISR Platform Study",
    dept:         "Air Force",
    value:        1850000,
    pwin:         58,
    score:        84,
    status:       "Pipeline",
    qualified_at: "2026-04-28T14:22:00.000Z",
    due_date:     "2026-05-30",
  },
  {
    id:           "OPP-004",
    title:        "Navy C2 Comms Upgrade Phase II",
    dept:         "Navy",
    value:        7400000,
    pwin:         61,
    score:        78,
    status:       "Pipeline",
    qualified_at: "2026-04-20T09:11:00.000Z",
    due_date:     "2026-08-20",
  },
  {
    id:           "OPP-007",
    title:        "DISA Zero Trust Architecture BPA",
    dept:         "DISA",
    value:        890000,
    pwin:         68,
    score:        69,
    status:       "Pipeline",
    qualified_at: "2026-05-01T11:45:00.000Z",
    due_date:     "2026-05-22",
  },
];

const MOCK_SUMMARY = {
  pipeline_count: 3,
  total_pipeline_value: 10140000,
  avg_pwin: 62,
  avg_score: 77,
};

// ─── Helpers ──────────────────────────────────────────────────────────────────
function fmtDollars(n) {
  if (n == null) return "—";
  if (n >= 1_000_000) return `$${(n / 1_000_000).toFixed(1)}M`;
  if (n >= 1_000)     return `$${(n / 1_000).toFixed(0)}K`;
  return `$${n}`;
}

function fmtDate(d) {
  if (!d) return "—";
  try {
    return new Date(d).toLocaleDateString("en-US", {
      month: "short",
      day:   "numeric",
      year:  "numeric",
    });
  } catch {
    return d;
  }
}

function fmtQualifiedAt(iso) {
  if (!iso) return "—";
  try {
    return new Date(iso).toLocaleString("en-US", {
      month:  "short",
      day:    "numeric",
      year:   "numeric",
      hour:   "numeric",
      minute: "2-digit",
    });
  } catch {
    return iso;
  }
}

function PwinBadge({ pwin }) {
  const v  = Number(pwin) || 0;
  let bg   = "#fee2e2";
  let color = "#991b1b";
  if (v >= 65)      { bg = "#dcfce7"; color = "#166534"; }
  else if (v >= 45) { bg = "#fef9c3"; color = "#854d0e"; }
  return (
    <span style={{
      display:      "inline-block",
      background:   bg,
      color:        color,
      borderRadius: "4px",
      padding:      "2px 7px",
      fontSize:     "0.82rem",
      fontWeight:   600,
    }}>
      {v}%
    </span>
  );
}

function ScoreBadge({ score }) {
  const v   = Number(score) || 0;
  let color = "#6b7280";
  if (v >= 80)      color = "#1d4ed8";
  else if (v >= 65) color = "#7c3aed";
  return (
    <span style={{ fontWeight: 700, color, fontSize: "0.88rem" }}>{v}</span>
  );
}

// ─── Filter panel ─────────────────────────────────────────────────────────────
function FilterBar({ filters, onChange, allDepts }) {
  return (
    <div style={{
      display:    "flex",
      gap:        "12px",
      flexWrap:   "wrap",
      alignItems: "center",
      padding:    "10px 0 14px",
      borderBottom: "1px solid #e5e7eb",
      marginBottom: "8px",
    }}>
      <span style={{ fontSize: "0.8rem", color: "#6b7280", fontWeight: 600 }}>FILTER</span>

      {/* Search */}
      <input
        type="text"
        placeholder="ID or title…"
        value={filters.search}
        onChange={e => onChange({ ...filters, search: e.target.value })}
        style={inputStyle}
        aria-label="Search pipeline by ID or title"
      />

      {/* Dept */}
      <select
        value={filters.dept}
        onChange={e => onChange({ ...filters, dept: e.target.value })}
        style={inputStyle}
        aria-label="Filter by department"
      >
        <option value="">All Depts</option>
        {allDepts.map(d => <option key={d} value={d}>{d}</option>)}
      </select>

      {/* Min pwin */}
      <select
        value={filters.minPwin}
        onChange={e => onChange({ ...filters, minPwin: e.target.value })}
        style={inputStyle}
        aria-label="Filter by minimum Pwin"
      >
        <option value="">Min Pwin</option>
        <option value="25">≥ 25%</option>
        <option value="45">≥ 45%</option>
        <option value="65">≥ 65%</option>
      </select>

      {/* Clear */}
      {(filters.search || filters.dept || filters.minPwin) && (
        <button
          onClick={() => onChange({ search: "", dept: "", minPwin: "" })}
          style={{
            background:   "none",
            border:       "1px solid #d1d5db",
            borderRadius: "4px",
            padding:      "4px 10px",
            cursor:       "pointer",
            fontSize:     "0.8rem",
            color:        "#6b7280",
          }}
        >
          Clear
        </button>
      )}
    </div>
  );
}

const inputStyle = {
  border:       "1px solid #d1d5db",
  borderRadius: "4px",
  padding:      "4px 8px",
  fontSize:     "0.82rem",
  color:        "#1f2937",
  background:   "#fff",
  height:       "30px",
};

// ─── Pipeline table ───────────────────────────────────────────────────────────
const COL_HEADERS = [
  { key: "id",           label: "ID" },
  { key: "title",        label: "Opportunity" },
  { key: "dept",         label: "Dept" },
  { key: "value",        label: "Value" },
  { key: "pwin",         label: "Pwin" },
  { key: "score",        label: "Score" },
  { key: "qualified_at", label: "Qualified" },
  { key: "due_date",     label: "Due" },
];

function PipelineTable({ opportunities, sortConfig, onSort }) {
  return (
    <div style={{ overflowX: "auto" }}>
      <table style={{
        width:           "100%",
        borderCollapse:  "collapse",
        fontSize:        "0.875rem",
        tableLayout:     "auto",
      }}>
        <thead>
          <tr style={{ background: "#f1f5f9", borderBottom: "2px solid #e2e8f0" }}>
            {COL_HEADERS.map(col => (
              <th
                key={col.key}
                onClick={() => onSort(col.key)}
                style={{
                  padding:    "9px 12px",
                  textAlign:  "left",
                  fontWeight: 700,
                  fontSize:   "0.78rem",
                  color:      "#374151",
                  cursor:     "pointer",
                  whiteSpace: "nowrap",
                  userSelect: "none",
                }}
              >
                {col.label}
                {sortConfig.key === col.key && (
                  <span style={{ marginLeft: "4px", color: "#2563eb" }}>
                    {sortConfig.dir === "asc" ? "↑" : "↓"}
                  </span>
                )}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {opportunities.map((opp, i) => (
            <tr
              key={opp.id}
              style={{
                background:   i % 2 === 0 ? "#fff" : "#f8fafc",
                borderBottom: "1px solid #e5e7eb",
              }}
            >
              <td style={tdStyle}>
                <span style={{ fontFamily: "monospace", fontSize: "0.8rem", color: "#6b7280" }}>
                  {opp.id}
                </span>
              </td>
              <td style={{ ...tdStyle, maxWidth: "260px" }}>
                <span style={{ fontWeight: 500, color: "#111827" }}>{opp.title}</span>
              </td>
              <td style={tdStyle}>
                <span style={{
                  background: "#e0f2fe",
                  color:      "#075985",
                  padding:    "2px 7px",
                  borderRadius: "4px",
                  fontSize:   "0.78rem",
                  fontWeight: 600,
                }}>
                  {opp.dept}
                </span>
              </td>
              <td style={{ ...tdStyle, fontWeight: 600, color: "#1f2937" }}>
                {fmtDollars(opp.value)}
              </td>
              <td style={tdStyle}><PwinBadge pwin={opp.pwin} /></td>
              <td style={tdStyle}><ScoreBadge score={opp.score} /></td>
              <td style={{ ...tdStyle, color: "#374151", whiteSpace: "nowrap" }}>
                {fmtQualifiedAt(opp.qualified_at)}
              </td>
              <td style={{ ...tdStyle, color: "#6b7280", whiteSpace: "nowrap" }}>
                {fmtDate(opp.due_date)}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

const tdStyle = {
  padding:  "9px 12px",
  verticalAlign: "middle",
};

// ─── Empty state ──────────────────────────────────────────────────────────────
function EmptyState({ filtered }) {
  return (
    <div style={{
      textAlign:  "center",
      padding:    "60px 20px",
      color:      "#6b7280",
    }}>
      <div style={{ fontSize: "2.5rem", marginBottom: "12px" }}>📋</div>
      {filtered ? (
        <>
          <div style={{ fontWeight: 600, fontSize: "1rem", color: "#374151" }}>
            No results match the current filters.
          </div>
          <div style={{ fontSize: "0.875rem", marginTop: "6px" }}>
            Adjust the filters above to see pipeline opportunities.
          </div>
        </>
      ) : (
        <>
          <div style={{ fontWeight: 600, fontSize: "1rem", color: "#374151" }}>
            No qualified opportunities yet.
          </div>
          <div style={{ fontSize: "0.875rem", marginTop: "6px" }}>
            Opportunities appear here only after being explicitly qualified in the Ops Tracker.
          </div>
        </>
      )}
    </div>
  );
}

// ─── Secondary strip (pipeline-specific) ─────────────────────────────────────
function PipelineStrip({ summary, loading, error }) {
  const stripCells = [
    { label: "Pipeline Count", value: loading ? "—" : (summary?.pipeline_count ?? "—") },
    { label: "Total Value",    value: loading ? "—" : fmtDollars(summary?.total_pipeline_value) },
    { label: "Avg Pwin",       value: loading ? "—" : (summary?.avg_pwin != null ? `${summary.avg_pwin}%` : "—") },
    { label: "Avg Score",      value: loading ? "—" : (summary?.avg_score ?? "—") },
  ];

  return (
    <div style={{
      background:   "#1e3a5f",
      borderBottom: "1px solid #162d4a",
      padding:      "8px 20px",
      display:      "flex",
      gap:          "32px",
      alignItems:   "center",
      flexWrap:     "wrap",
    }}>
      {/* Label */}
      <span style={{
        color:      "#93c5fd",
        fontSize:   "0.72rem",
        fontWeight: 700,
        letterSpacing: "0.08em",
        textTransform: "uppercase",
      }}>
        Pipeline Summary
      </span>

      {error && (
        <span style={{ color: "#fca5a5", fontSize: "0.78rem" }}>
          Summary unavailable — {error}
        </span>
      )}

      {!error && stripCells.map(c => (
        <div key={c.label} style={{ display: "flex", flexDirection: "column", gap: "1px" }}>
          <span style={{ color: "#93c5fd", fontSize: "0.68rem", fontWeight: 600, textTransform: "uppercase", letterSpacing: "0.06em" }}>
            {c.label}
          </span>
          <span style={{ color: "#f0f9ff", fontSize: "0.95rem", fontWeight: 700 }}>
            {c.value}
          </span>
        </div>
      ))}

      {/* Audit acknowledgement */}
      <div style={{ marginLeft: "auto", color: "#64748b", fontSize: "0.72rem", lineHeight: 1.4, maxWidth: "340px" }}>
        Qualify actions are logged on the server with id, previous/new status, and timestamp.
        A future audit view will surface this history.
      </div>
    </div>
  );
}

// ─── Error banner ─────────────────────────────────────────────────────────────
function ErrorBanner({ error }) {
  return (
    <div style={{
      background:   "#fef2f2",
      border:       "1px solid #fecaca",
      borderRadius: "6px",
      padding:      "12px 16px",
      color:        "#991b1b",
      fontSize:     "0.875rem",
      margin:       "16px 0",
    }}>
      <strong>Failed to load pipeline data.</strong> {error}
    </div>
  );
}

// ─── Client-side sort ─────────────────────────────────────────────────────────
function sortOpportunities(list, { key, dir }) {
  if (!key) return list;
  return [...list].sort((a, b) => {
    let av = a[key], bv = b[key];
    // Dates
    if (key === "qualified_at" || key === "due_date") {
      av = av ? new Date(av).getTime() : 0;
      bv = bv ? new Date(bv).getTime() : 0;
    }
    // Numeric
    if (typeof av === "number" && typeof bv === "number") {
      return dir === "asc" ? av - bv : bv - av;
    }
    // String
    const as = String(av ?? "").toLowerCase();
    const bs = String(bv ?? "").toLowerCase();
    if (as < bs) return dir === "asc" ? -1 : 1;
    if (as > bs) return dir === "asc" ?  1 : -1;
    return 0;
  });
}

// ─── Main component ───────────────────────────────────────────────────────────
export default function GDAPipelineView() {
  const [opportunities, setOpportunities] = useState([]);
  const [summary,       setSummary]       = useState(null);
  const [loading,       setLoading]       = useState(true);
  const [error,         setError]         = useState(null);
  const [summaryError,  setSummaryError]  = useState(null);
  const [filters,       setFilters]       = useState({ search: "", dept: "", minPwin: "" });
  const [sortConfig,    setSortConfig]    = useState({ key: "qualified_at", dir: "desc" });
  const [lastFetched,   setLastFetched]   = useState(null);

  // ── Fetch pipeline list ────────────────────────────────────────────────────
  const fetchPipeline = useCallback(async () => {
    setLoading(true);
    setError(null);

    if (USE_MOCK) {
      // Simulate network latency in mock mode
      await new Promise(r => setTimeout(r, 300));
      setOpportunities(MOCK_PIPELINE);
      setSummary(MOCK_SUMMARY);
      setLastFetched(new Date().toISOString());
      setLoading(false);
      return;
    }

    try {
      const res  = await fetch("/api/opportunities/pipeline");
      const body = await res.json().catch(() => null);

      if (!body || !("success" in body)) {
        setError("Server returned a non-standard response. Check API health.");
        setLoading(false);
        return;
      }

      if (!body.success) {
        setError(body.error || "Unknown server error.");
        setLoading(false);
        return;
      }

      const opps = body.data?.opportunities;
      if (!Array.isArray(opps)) {
        setError("Response data.opportunities is not an array. Check the /api/opportunities/pipeline endpoint.");
        setLoading(false);
        return;
      }

      setOpportunities(opps);
      setLastFetched(body.meta?.generated_at || new Date().toISOString());

      // Build summary from returned data
      if (opps.length > 0) {
        const totalValue = opps.reduce((s, o) => s + (Number(o.value) || 0), 0);
        const avgPwin    = Math.round(opps.reduce((s, o) => s + (Number(o.pwin) || 0), 0) / opps.length);
        const avgScore   = Math.round(opps.reduce((s, o) => s + (Number(o.score) || 0), 0) / opps.length);
        setSummary({ pipeline_count: opps.length, total_pipeline_value: totalValue, avg_pwin: avgPwin, avg_score: avgScore });
        setSummaryError(null);
      } else {
        setSummary({ pipeline_count: 0, total_pipeline_value: 0, avg_pwin: null, avg_score: null });
      }

    } catch (err) {
      setError(`Network error: ${err.message}. Is the GDA API running?`);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { fetchPipeline(); }, [fetchPipeline]);

  // ── Sort handler ───────────────────────────────────────────────────────────
  function handleSort(key) {
    setSortConfig(prev =>
      prev.key === key
        ? { key, dir: prev.dir === "asc" ? "desc" : "asc" }
        : { key, dir: "desc" }
    );
  }

  // ── Derive unique depts for filter dropdown ────────────────────────────────
  const allDepts = [...new Set(opportunities.map(o => o.dept).filter(Boolean))].sort();

  // ── Apply filters ──────────────────────────────────────────────────────────
  const filtered = opportunities.filter(opp => {
    const q = filters.search.trim().toLowerCase();
    if (q && !opp.id?.toLowerCase().includes(q) && !opp.title?.toLowerCase().includes(q)) return false;
    if (filters.dept && opp.dept !== filters.dept) return false;
    if (filters.minPwin && Number(opp.pwin) < Number(filters.minPwin)) return false;
    return true;
  });

  // ── Apply sort ─────────────────────────────────────────────────────────────
  const sorted = sortOpportunities(filtered, sortConfig);

  const isFiltered = !!(filters.search || filters.dept || filters.minPwin);

  // ── Render ─────────────────────────────────────────────────────────────────
  return (
    <div style={{ minHeight: "100vh", background: "#f1f5f9", fontFamily: "'Inter', 'Segoe UI', sans-serif" }}>

      {/* ── Persistent financial KPI strip ── */}
      <GDAKpiStrip />

      {/* ── Pipeline-specific secondary strip ── */}
      <PipelineStrip
        summary={summary}
        loading={loading}
        error={summaryError}
      />

      {/* ── Page body ── */}
      <div style={{ maxWidth: "1280px", margin: "0 auto", padding: "20px 24px" }}>

        {/* Header row */}
        <div style={{
          display:        "flex",
          alignItems:     "center",
          justifyContent: "space-between",
          marginBottom:   "16px",
          flexWrap:       "wrap",
          gap:            "12px",
        }}>
          <div>
            <h1 style={{ margin: 0, fontSize: "1.25rem", fontWeight: 700, color: "#111827" }}>
              Pipeline
            </h1>
            <p style={{ margin: "2px 0 0", fontSize: "0.8rem", color: "#6b7280" }}>
              Qualified opportunities only — status = Pipeline.
              {USE_MOCK && (
                <span style={{
                  marginLeft:   "8px",
                  background:   "#fef3c7",
                  color:        "#92400e",
                  borderRadius: "4px",
                  padding:      "1px 6px",
                  fontSize:     "0.72rem",
                  fontWeight:   600,
                }}>
                  MOCK DATA
                </span>
              )}
              {lastFetched && !USE_MOCK && (
                <span style={{ marginLeft: "8px" }}>
                  as of {fmtQualifiedAt(lastFetched)}
                </span>
              )}
            </p>
          </div>

          <div style={{ display: "flex", gap: "10px", alignItems: "center" }}>
            {/* Record count */}
            {!loading && !error && (
              <span style={{
                background:   "#dbeafe",
                color:        "#1e40af",
                borderRadius: "12px",
                padding:      "3px 12px",
                fontSize:     "0.8rem",
                fontWeight:   600,
              }}>
                {sorted.length} of {opportunities.length}
              </span>
            )}

            {/* Refresh */}
            <button
              onClick={fetchPipeline}
              disabled={loading}
              style={{
                background:   loading ? "#f3f4f6" : "#1e3a5f",
                color:        loading ? "#9ca3af" : "#fff",
                border:       "none",
                borderRadius: "5px",
                padding:      "6px 14px",
                fontSize:     "0.82rem",
                fontWeight:   600,
                cursor:       loading ? "not-allowed" : "pointer",
              }}
            >
              {loading ? "Loading…" : "↻ Refresh"}
            </button>
          </div>
        </div>

        {/* Error */}
        {error && <ErrorBanner error={error} />}

        {/* Filters (always visible; only useful once data loads) */}
        {!error && (
          <FilterBar
            filters={filters}
            onChange={setFilters}
            allDepts={allDepts}
          />
        )}

        {/* Loading skeleton */}
        {loading && (
          <div style={{
            textAlign:  "center",
            padding:    "48px",
            color:      "#6b7280",
            fontSize:   "0.9rem",
          }}>
            Loading pipeline…
          </div>
        )}

        {/* Table or empty state */}
        {!loading && !error && (
          sorted.length > 0
            ? (
              <PipelineTable
                opportunities={sorted}
                sortConfig={sortConfig}
                onSort={handleSort}
              />
            )
            : <EmptyState filtered={isFiltered} />
        )}

        {/* Footer note */}
        {!loading && !error && opportunities.length > 0 && (
          <div style={{
            marginTop:  "16px",
            fontSize:   "0.76rem",
            color:      "#9ca3af",
            textAlign:  "right",
          }}>
            {opportunities.length} qualified {opportunities.length === 1 ? "opportunity" : "opportunities"} in pipeline
            {isFiltered ? ` · ${sorted.length} shown after filters` : ""}.
            Click any column header to sort.
          </div>
        )}

      </div>
    </div>
  );
}
