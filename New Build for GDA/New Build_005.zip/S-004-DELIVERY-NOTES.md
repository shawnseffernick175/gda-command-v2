# S-004 Delivery Notes

## Deliverables

| File | Status | Notes |
|------|--------|-------|
| `GDAOpsTracker-4.jsx` | ✅ Ready | USE_MOCK flag + real API wiring + envelope validation |
| `App.jsx` | ✅ Ready | React Router v6 shell: `/` → Launchpad, `/ops-tracker` → Ops Tracker |
| `gda-smoke-tests-4.js` | ✅ Ready | dryRun:false hard assertion + schema/check hard failure |

---

## Run Instructions

### 1. Start the API server
```bash
cd api
npm run dev
# Express starts on :3001
# Confirm: GET http://localhost:3001/api/health → { success: true, data: { db: "ok" } }
```

### 2. Start the React dev server (Vite)
```bash
cd client
npm run dev
# Vite starts on :5173
# /api/... calls are proxied to :3001 (see vite.config.js proxy block below)
```

### 3. Run smoke tests
```bash
# From the project root (or wherever gda-smoke-tests-4.js lives):
node gda-smoke-tests-4.js http://localhost:3001

# Or via package.json:
npm run smoke
```

---

## Vite Proxy Config (required for USE_MOCK = false)

Add to `vite.config.js` if not already present:

```js
import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

export default defineConfig({
  plugins: [react()],
  server: {
    proxy: {
      "/api": {
        target: "http://localhost:3001",
        changeOrigin: true,
      },
    },
  },
});
```

---

## Switching Ops Tracker to Live Data

1. Confirm `npm run smoke` passes — especially `/api/schema/check — all_ok:true`
2. In `GDAOpsTracker-4.jsx`, change line:
   ```js
   export const USE_MOCK = true;
   ```
   to:
   ```js
   export const USE_MOCK = false;
   ```
3. The amber banner will turn green (`✓ LIVE DATA — reading from GET /api/opportunities/top10`)

---

## What Changed in S-004 vs S-003

### GDAOpsTracker-4.jsx
- `USE_MOCK` flag: when `false`, calls `GET /api/opportunities/top10`
- Envelope validation: checks all 7 required fields; surfaces a distinct "API contract error"
  box (orange) separate from general DB/fetch errors (red)
- Content-type guard: if the proxy returns HTML instead of JSON, the error message says
  exactly why (wrong port, proxy misconfigured) instead of a generic parse failure
- `cancelled` flag in `useEffect` prevents state updates after unmount
- Back-link to `/` (Launchpad) in the page header
- KPI strip buttons wired to `console.info` with S-005 TODO comment (Financial Bible)
- Mock banner turns green when `USE_MOCK = false`

### App.jsx
- New file; provides the React Router v6 shell
- `/` → `GDALaunchpad`
- `/ops-tracker` → `GDAOpsTracker`
- `*` → redirect to `/`
- Inline comments explain Vite proxy config and the `<Link>` upgrade for Launchpad

### gda-smoke-tests-4.js
- `dryRun:false` test is now a **hard failure** (not just a warning):
  - Asserts HTTP 400
  - Asserts `success: false`
  - Asserts error message contains "not enabled", "S-004", or "dry run"
  - Asserts `dryRun: false` echoed in envelope
- `/api/schema/check` test is now a **hard failure** when `all_ok: false`:
  - Each missing/empty table listed individually with plain-English remediation
  - Explicitly tells operator: do not set `USE_MOCK = false` until this passes
  - `data.summary` array checked for presence

---

## What Was NOT Changed

- `gda-api-routes-4-3.js` — no changes needed; qualify dryRun:false already returns 400
  with the correct error message. The smoke test now enforces this contractually.
- `server-3-2.js` — no changes needed; the proxy and envelope wiring are correct.
- No dark theme, no charts, no new endpoints, no Retool references.
- Frozen workflow IDs not referenced anywhere.
