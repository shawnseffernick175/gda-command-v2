/**
 * GDA Rebuild — App Shell
 * S-004 | Phase 1
 *
 * React Router v6 setup.
 * Routes:
 *   /             → GDALaunchpad
 *   /ops-tracker  → GDAOpsTracker
 *
 * The "VIEW ALL →" link on Launchpad (pointing to /ops-tracker) will
 * resolve automatically once this router is in place.
 *
 * Install React Router v6 if not already present:
 *   npm install react-router-dom
 *
 * Usage: mount <App /> in main.jsx (or index.jsx):
 *   import { StrictMode } from "react";
 *   import { createRoot } from "react-dom/client";
 *   import App from "./App.jsx";
 *   createRoot(document.getElementById("root")).render(
 *     <StrictMode><App /></StrictMode>
 *   );
 */

import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import GDALaunchpad   from "./GDALaunchpad.jsx";
import GDAOpsTracker  from "./GDAOpsTracker-4.jsx";

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        {/* Front door — Launchpad */}
        <Route path="/"            element={<GDALaunchpad />} />

        {/* Ops Tracker — matches the "VIEW ALL →" href in Launchpad */}
        <Route path="/ops-tracker" element={<GDAOpsTracker />} />

        {/* Catch-all: redirect unknown paths back to Launchpad */}
        <Route path="*"            element={<Navigate to="/" replace />} />
      </Routes>
    </BrowserRouter>
  );
}

/*
 * ── Vite proxy config (vite.config.js) ────────────────────────────────────
 *
 * React must only call /api/... routes — never direct DB or n8n.
 * Add the proxy block if it isn't already in your vite.config.js:
 *
 *   import { defineConfig } from "vite";
 *   import react from "@vitejs/plugin-react";
 *
 *   export default defineConfig({
 *     plugins: [react()],
 *     server: {
 *       proxy: {
 *         "/api": {
 *           target:       "http://localhost:3001",
 *           changeOrigin: true,
 *         },
 *       },
 *     },
 *   });
 *
 * This forwards every /api/... request from the Vite dev server (:5173)
 * to the Express API server (:3001). In production, your reverse proxy
 * (nginx / Render / Railway) handles this instead.
 *
 * ── GDALaunchpad "VIEW ALL →" link ────────────────────────────────────────
 *
 * The Launchpad component should use React Router's <Link> (not <a href>)
 * so navigation stays client-side:
 *
 *   import { Link } from "react-router-dom";
 *   ...
 *   <Link to="/ops-tracker">VIEW ALL →</Link>
 *
 * If GDALaunchpad currently uses a plain <a href="/ops-tracker">, it works
 * (full page reload) but Link is preferred for SPA smoothness.
 */
