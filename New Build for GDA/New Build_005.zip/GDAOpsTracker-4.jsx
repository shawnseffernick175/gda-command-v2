/**
 * GDA Rebuild — Ops Tracker Page
 * S-004 | Phase 1
 *
 * Changes vs S-003:
 *   - USE_MOCK flag wires to real GET /api/opportunities/top10
 *   - Envelope handling: reads { success, data, error, meta }
 *   - Navigation: back link to / (Launchpad) via window.location or React Router Link
 *   - Qualify note updated: S-004 ships dryRun:true preview; real write gated
 *   - Mock banner shows API endpoint when USE_MOCK = false
 *
 * Switching to real API: set USE_MOCK = false after confirming Express is live.
 * The component also exports USE_MOCK so App.jsx can read it for diagnostics.
 */

import { useState, useEffect } from "react";

// ─── Mock data ────────────────────────────────────────────────────────────────
// Mirrors the shape of /api/opportunities/top10 envelope.data.opportunities
const MOCK_OPPORTUNITIES = [
  { id: "OPP-001", title: "Dept of Army SIGINT Modernization",  dept: "Army",      value: 4200000,  pwin: 72, score: 91, status: "Tracking",    due_date: "2026-06-15" },
  { id: "OPP-002", title: "AFRL Advanced ISR Platform Study",   dept: "Air Force", value: 1850000,  pwin: 58, score: 84, status: "Tracking",    due_date: "2026-05-30" },
  { id: "OPP-003", title: "DHS Border Surveillance Tech",       dept: "DHS",       value: 3100000,  pwin: 45, score: 79, status: "Tracking",    due_date: "2026-07-01" },
  { id: "OPP-004", title: "Navy C2 Comms Upgrade Phase II",     dept: "Navy",      value: 7400000,  pwin: 61, score: 78, status: "Tracking",    due_date: "2026-08-20" },
  { id: "OPP-005", title: "SOCOM Tactical Edge Computing",      dept: "SOCOM",     value: 2250000,  pwin: 55, score: 74, status: "Tracking",    due_date: "2026-06-05" },
  { id: "OPP-006", title: "NRO Ground Station Refresh",         dept: "NRO",       value: 5600000,  pwin: 40, score: 71, status: "Identifying", due_date: "2026-09-10" },
  { id: "OPP-007", title: "DISA Zero Trust Architecture BPA",   dept: "DISA",      value: 890000,   pwin: 68, score: 69, status: "Tracking",    due_date: "2026-05-22" },
  { id: "OPP-008", title: "Army Cyber Range Infrastructure",    dept: "Army",      value: 3350000,  pwin: 38, score: 65, status: "Identifying", due_date: "2026-10-01" },
  { id: "OPP-009", title: "NSA Analytics Modernization IDIQ",   dept: "NSA",       value: 12000000, pwin: 25, score: 62, status: "Identifying", due_date: "2026-11-15" },
  { id: "OPP-010", title: "USMC Logistics Automation Pilot",    dept: "USMC",      value: 640000,   pwin: 52, score: 58, status: "Tracking",    due_date: "2026-06-28" },
];

const MOCK_SUMMARY = {
  total_opportunities: 10,
  avg_score:  73,
  avg_pwin:   51,
  total_value: 41280000,
};

// ─── Config ───────────────────────────────────────────────────────────────────
// Set false after confirming Express is live and DATABASE_URL is set.
export const USE_MOCK = true;

// ─── Helpers ─────────────────────────────────────────────────────────────────
function fmtDollars(n) {
  if (n == null) return "—";
  if (n >= 1_000_000) return `$${(n / 1_000_000).toFixed(1)}M`;
  if (n >= 1_000)     return `$${(n / 1_000).toFixed(0)}K`;
  return `$${n}`;
}

function fmtDate(d) {
  if (!d) return "—";
  try {
    return new Date(d).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" });
  } catch {
    return d;
  }
}

function PwinBadge({ pwin }) {
  const v = Number(pwin) || 0;
  let bg = "#e5e7eb";
  if (v >= 65)      bg = "#dcfce7";
  else if (v >= 45) bg = "#fef9c3";
  else              bg = "#fee2e2";
  return (
    <span style={{
      display: "inline-block",
      padding: "2px 8px",
      borderRadius: 12,
      fontSize: 12,
      fontWeight: 600,
      backgroundColor: bg,
      color: "#1f2937",
      minWidth: 40,
      textAlign: "center",
    }}>
      {v}%
    </span>
  );
}

function ScoreBadge({ score }) {
  const v = Number(score) || 0;
  let color = "#6b7280";
  if (v >= 80)      color = "#15803d";
  else if (v >= 60) color = "#b45309";
  else              color = "#dc2626";
  return <span style={{ fontWeight: 700, color }}>{v}</span>;
}

function StatusPill({ status }) {
  const map = {
    Pipeline:    { bg: "#dbeafe", color: "#1e40af" },
    Tracking:    { bg: "#e0f2fe", color: "#0369a1" },
    Identifying: { bg: "#f3f4f6", color: "#374151" },
    Pursuing:    { bg: "#fef9c3", color: "#92400e" },
    Lost:        { bg: "#fee2e2", color: "#991b1b" },
    "No Bid":    { bg: "#f3f4f6", color: "#9ca3af" },
  };
  const s = map[status] || { bg: "#f3f4f6", color: "#374151" };
  return (
    <span style={{
      display: "inline-block",
      padding: "2px 10px",
      borderRadius: 12,
      fontSize: 12,
      fontWeight: 600,
      backgroundColor: s.bg,
      color: s.color,
    }}>
      {status || "—"}
    </span>
  );
}

// ─── Sort / Filter helpers ────────────────────────────────────────────────────
const DEPTS    = ["All", "Army", "Air Force", "Navy", "USMC", "SOCOM", "DHS", "DISA", "NRO", "NSA", "Other"];
const STATUSES = ["All", "Tracking", "Identifying", "Pursuing", "Pipeline", "Lost", "No Bid"];

function applyFilters(rows, { dept, status, minPwin, sortKey, sortDir }) {
  let out = [...rows];
  if (dept   !== "All") out = out.filter(r => r.dept   === dept);
  if (status !== "All") out = out.filter(r => r.status === status);
  if (minPwin > 0)      out = out.filter(r => (Number(r.pwin) || 0) >= minPwin);
  if (sortKey) {
    out.sort((a, b) => {
      let av = a[sortKey], bv = b[sortKey];
      if (typeof av === "string") av = av.toLowerCase();
      if (typeof bv === "string") bv = bv.toLowerCase();
      if (av < bv) return sortDir === "asc" ? -1 : 1;
      if (av > bv) return sortDir === "asc" ?  1 : -1;
      return 0;
    });
  }
  return out;
}

// ─── Styles (inline, consistent with GDALaunchpad light theme) ───────────────
const S = {
  page: {
    minHeight: "100vh",
    backgroundColor: "#f8fafc",
    fontFamily: "'Inter', 'Segoe UI', system-ui, sans-serif",
    color: "#1f2937",
  },
  kpiStrip: {
    display: "flex",
    gap: 0,
    backgroundColor: "#1e293b",
    padding: "0 24px",
    overflowX: "auto",
    borderBottom: "3px solid #0ea5e9",
  },
  kpiItem: {
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    padding: "10px 20px",
    minWidth: 110,
    cursor: "pointer",
    borderRight: "1px solid #334155",
    transition: "background 0.15s",
    textDecoration: "none",
    background: "transparent",
    border: "none",
    borderRight: "1px solid #334155",
  },
  kpiLabel: { fontSize: 10, fontWeight: 600, color: "#94a3b8", letterSpacing: "0.08em", textTransform: "uppercase" },
  kpiValue: { fontSize: 17, fontWeight: 700, color: "#f1f5f9", marginTop: 2 },
  summaryStrip: {
    display: "flex",
    gap: 16,
    backgroundColor: "#ffffff",
    borderBottom: "1px solid #e2e8f0",
    padding: "12px 24px",
    overflowX: "auto",
    alignItems: "center",
  },
  summaryCard: {
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    padding: "8px 20px",
    minWidth: 110,
    backgroundColor: "#f8fafc",
    border: "1px solid #e2e8f0",
    borderRadius: 8,
  },
  summaryLabel: { fontSize: 11, color: "#6b7280", fontWeight: 500 },
  summaryValue: { fontSize: 18, fontWeight: 700, color: "#0f172a", marginTop: 2 },
  pageHeader: {
    padding: "20px 24px 8px",
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    flexWrap: "wrap",
    gap: 12,
  },
  pageTitle:    { fontSize: 22, fontWeight: 700, color: "#0f172a", margin: 0 },
  pageSubtitle: { fontSize: 13, color: "#64748b", marginTop: 2 },
  backLink: {
    fontSize: 13,
    color: "#0369a1",
    textDecoration: "none",
    display: "flex",
    alignItems: "center",
    gap: 4,
    cursor: "pointer",
    background: "none",
    border: "none",
    padding: 0,
  },
  filterBar: {
    display: "flex",
    gap: 12,
    padding: "10px 24px",
    alignItems: "center",
    flexWrap: "wrap",
    backgroundColor: "#ffffff",
    borderBottom: "1px solid #e2e8f0",
  },
  filterLabel: { fontSize: 12, color: "#6b7280", fontWeight: 500 },
  select: {
    fontSize: 13,
    padding: "5px 10px",
    border: "1px solid #d1d5db",
    borderRadius: 6,
    backgroundColor: "#ffffff",
    color: "#1f2937",
    cursor: "pointer",
  },
  tableWrap: { padding: "16px 24px" },
  table:  { width: "100%", borderCollapse: "collapse", backgroundColor: "#ffffff", borderRadius: 10, overflow: "hidden", border: "1px solid #e2e8f0" },
  thead:  { backgroundColor: "#f1f5f9" },
  th: {
    padding: "10px 14px",
    textAlign: "left",
    fontSize: 11,
    fontWeight: 700,
    color: "#374151",
    textTransform: "uppercase",
    letterSpacing: "0.06em",
    borderBottom: "1px solid #e2e8f0",
    cursor: "pointer",
    userSelect: "none",
    whiteSpace: "nowrap",
  },
  td: {
    padding: "11px 14px",
    fontSize: 13,
    color: "#374151",
    borderBottom: "1px solid #f1f5f9",
    verticalAlign: "middle",
  },
  trHover:   { backgroundColor: "#f8fafc" },
  mockBanner: { backgroundColor: "#fef3c7", borderBottom: "1px solid #fcd34d", padding: "6px 24px", fontSize: 12, color: "#92400e" },
  errorBox:   { margin: "24px", padding: "16px", backgroundColor: "#fee2e2", borderRadius: 8, color: "#991b1b", fontSize: 13 },
  emptyRow:   { textAlign: "center", padding: 32, color: "#9ca3af", fontSize: 13 },
  envErrBox: {
    margin: "24px",
    padding: "16px",
    backgroundColor: "#fff7ed",
    border: "1px solid #fed7aa",
    borderRadius: 8,
    color: "#9a3412",
    fontSize: 13,
  },
};

// ─── KPI Strip data — replace with real /api/financial/kpis when live ─────────
const KPI_MOCK = [
  { label: "Orders",        value: "$42.1M", kpi: "orders"        },
  { label: "Sales",         value: "$38.7M", kpi: "sales"         },
  { label: "EBIT",          value: "$5.2M",  kpi: "ebit"          },
  { label: "ROS",           value: "13.4%",  kpi: "ros"           },
  { label: "Funded Backlog",value: "$18.9M", kpi: "funded_backlog"},
  { label: "Backlog",       value: "$61.3M", kpi: "backlog"       },
  { label: "Gross Profit",  value: "$9.8M",  kpi: "gross_profit"  },
];

// ─── API fetch ────────────────────────────────────────────────────────────────
async function fetchTop10() {
  const resp = await fetch("/api/opportunities/top10");

  // Enforce JSON — if we get HTML (proxy misconfigured, wrong port, etc.) surface it clearly
  const contentType = resp.headers.get("content-type") || "";
  if (!contentType.includes("application/json")) {
    throw new Error(
      `API returned non-JSON response (HTTP ${resp.status}, Content-Type: "${contentType}"). ` +
      "Check that Express is running on :3001 and Vite is proxying /api correctly."
    );
  }

  const env = await resp.json();

  // Standard envelope contract — every response must carry these fields
  const required = ["success", "workflow", "action", "dryRun", "data", "meta", "error"];
  const missing  = required.filter(k => !(k in env));
  if (missing.length > 0) {
    throw new Error(`API response is missing envelope fields: ${missing.join(", ")}. Check gda-api-routes.js.`);
  }

  if (!env.success) {
    throw new Error(env.error || "API returned success:false with no error message.");
  }

  return env;
}

// ─── Component ────────────────────────────────────────────────────────────────
export default function GDAOpsTracker() {
  const [opps,       setOpps]       = useState([]);
  const [summary,    setSummary]    = useState(null);
  const [loading,    setLoading]    = useState(true);
  const [error,      setError]      = useState(null);
  const [envError,   setEnvError]   = useState(null); // envelope / contract errors
  const [hoveredRow, setHoveredRow] = useState(null);

  // Filters + sort
  const [dept,    setDept]    = useState("All");
  const [status,  setStatus]  = useState("All");
  const [minPwin, setMinPwin] = useState(0);
  const [sortKey, setSortKey] = useState("score");
  const [sortDir, setSortDir] = useState("desc");

  // ── Data load ──────────────────────────────────────────────────────────────
  useEffect(() => {
    let cancelled = false;

    if (USE_MOCK) {
      // Simulate a short network delay so loading state renders correctly
      const timer = setTimeout(() => {
        if (cancelled) return;
        setOpps(MOCK_OPPORTUNITIES);
        setSummary(MOCK_SUMMARY);
        setLoading(false);
      }, 300);
      return () => { cancelled = true; clearTimeout(timer); };
    }

    // Real API path
    fetchTop10()
      .then(env => {
        if (cancelled) return;
        setOpps(env.data?.opportunities || []);
        setSummary(env.data?.summary    || null);
        setLoading(false);
      })
      .catch(err => {
        if (cancelled) return;
        // Separate envelope/contract errors from general fetch errors
        if (err.message.includes("envelope") || err.message.includes("non-JSON")) {
          setEnvError(err.message);
        } else {
          setError(err.message);
        }
        setLoading(false);
      });

    return () => { cancelled = true; };
  }, []);

  // ── Sort toggle ────────────────────────────────────────────────────────────
  function handleSort(key) {
    if (sortKey === key) setSortDir(d => (d === "asc" ? "desc" : "asc"));
    else { setSortKey(key); setSortDir("desc"); }
  }

  function sortIndicator(key) {
    if (sortKey !== key) return " ↕";
    return sortDir === "asc" ? " ↑" : " ↓";
  }

  const visible = applyFilters(opps, { dept, status, minPwin, sortKey, sortDir });

  // Summary numbers derived from visible set
  const shownSummary = {
    shown:     visible.length,
    total:     opps.length,
    avg_score: visible.length
      ? Math.round(visible.reduce((s, r) => s + (Number(r.score) || 0), 0) / visible.length)
      : "—",
    avg_pwin:  visible.length
      ? Math.round(visible.reduce((s, r) => s + (Number(r.pwin)  || 0), 0) / visible.length)
      : "—",
    total_val: visible.reduce((s, r) => s + (Number(r.value) || 0), 0),
  };

  // ── Navigate back to Launchpad ─────────────────────────────────────────────
  // Works with React Router (Link) or plain browser navigation.
  // If consuming via React Router, replace this with <Link to="/">
  function goToLaunchpad(e) {
    e.preventDefault();
    // React Router consumers: replace with navigate("/") or <Link to="/">
    window.location.href = "/";
  }

  // ── Render ─────────────────────────────────────────────────────────────────
  return (
    <div style={S.page}>

      {/* ── Persistent Financial KPI Strip ───────────────────────────────── */}
      <div style={S.kpiStrip}>
        {KPI_MOCK.map(k => (
          <button
            key={k.label}
            style={S.kpiItem}
            title={`View ${k.label} detail → Financial Bible`}
            onClick={() => {
              // TODO S-005: navigate(`/financial-bible?kpi=${k.kpi}`)
              console.info(`[GDA] KPI click: ${k.kpi} — Financial Bible drill-down ships in S-005`);
            }}
          >
            <span style={S.kpiLabel}>{k.label}</span>
            <span style={S.kpiValue}>{k.value}</span>
          </button>
        ))}
      </div>

      {/* ── Tool-specific Summary Strip ───────────────────────────────────── */}
      <div style={S.summaryStrip}>
        <div style={S.summaryCard}>
          <span style={S.summaryLabel}>Showing</span>
          <span style={S.summaryValue}>{shownSummary.shown}/{shownSummary.total}</span>
        </div>
        <div style={S.summaryCard}>
          <span style={S.summaryLabel}>Avg Score</span>
          <span style={S.summaryValue}>{shownSummary.avg_score}</span>
        </div>
        <div style={S.summaryCard}>
          <span style={S.summaryLabel}>Avg P(Win)</span>
          <span style={S.summaryValue}>
            {typeof shownSummary.avg_pwin === "number" ? `${shownSummary.avg_pwin}%` : shownSummary.avg_pwin}
          </span>
        </div>
        <div style={S.summaryCard}>
          <span style={S.summaryLabel}>Total Value</span>
          <span style={S.summaryValue}>{fmtDollars(shownSummary.total_val)}</span>
        </div>
        {/* Pipeline rule reminder */}
        <div style={{ ...S.summaryCard, marginLeft: "auto", borderColor: "#bfdbfe", backgroundColor: "#eff6ff" }}>
          <span style={{ ...S.summaryLabel, color: "#1e40af" }}>Pipeline Rule</span>
          <span style={{ ...S.summaryValue, color: "#1e40af", fontSize: 12 }}>Qualify to Add →</span>
        </div>
      </div>

      {/* ── Mock / live banner ───────────────────────────────────────────── */}
      {USE_MOCK ? (
        <div style={S.mockBanner}>
          ⚠ MOCK DATA — set <code>USE_MOCK = false</code> in GDAOpsTracker-4.jsx after confirming Express API is live on :3001
        </div>
      ) : (
        <div style={{ ...S.mockBanner, backgroundColor: "#f0fdf4", borderColor: "#bbf7d0", color: "#166534" }}>
          ✓ LIVE DATA — reading from <code>GET /api/opportunities/top10</code>
        </div>
      )}

      {/* ── Page Header ──────────────────────────────────────────────────── */}
      <div style={S.pageHeader}>
        <div>
          <h1 style={S.pageTitle}>Ops Tracker</h1>
          <div style={S.pageSubtitle}>
            Opportunity discovery and management · Qualify to move to Pipeline
          </div>
        </div>
        {/* Back to Launchpad */}
        <a href="/" style={S.backLink} onClick={goToLaunchpad} title="Back to Launchpad">
          ← Launchpad
        </a>
      </div>

      {/* ── Filter Bar ───────────────────────────────────────────────────── */}
      <div style={S.filterBar}>
        <span style={S.filterLabel}>Filter:</span>

        <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
          <label style={S.filterLabel} htmlFor="dept-filter">Dept</label>
          <select
            id="dept-filter"
            style={S.select}
            value={dept}
            onChange={e => setDept(e.target.value)}
          >
            {DEPTS.map(d => <option key={d}>{d}</option>)}
          </select>
        </div>

        <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
          <label style={S.filterLabel} htmlFor="status-filter">Status</label>
          <select
            id="status-filter"
            style={S.select}
            value={status}
            onChange={e => setStatus(e.target.value)}
          >
            {STATUSES.map(s => <option key={s}>{s}</option>)}
          </select>
        </div>

        <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
          <label style={S.filterLabel} htmlFor="pwin-filter">Min P(Win)</label>
          <select
            id="pwin-filter"
            style={S.select}
            value={minPwin}
            onChange={e => setMinPwin(Number(e.target.value))}
          >
            <option value={0}>Any</option>
            <option value={25}>≥ 25%</option>
            <option value={40}>≥ 40%</option>
            <option value={55}>≥ 55%</option>
            <option value={70}>≥ 70%</option>
          </select>
        </div>

        {(dept !== "All" || status !== "All" || minPwin > 0) && (
          <button
            style={{ ...S.select, backgroundColor: "#fee2e2", color: "#dc2626", border: "1px solid #fca5a5", cursor: "pointer" }}
            onClick={() => { setDept("All"); setStatus("All"); setMinPwin(0); }}
          >
            Clear
          </button>
        )}
      </div>

      {/* ── Table ────────────────────────────────────────────────────────── */}
      <div style={S.tableWrap}>

        {/* Envelope / contract error — distinct from DB errors */}
        {envError && (
          <div style={S.envErrBox}>
            <strong>API contract error:</strong> {envError}
            <div style={{ marginTop: 8, fontSize: 12 }}>
              This means the API returned a response that doesn't match the standard envelope.
              Check <code>gda-api-routes-4-3.js</code> and the Vite proxy config.
            </div>
          </div>
        )}

        {/* General fetch / DB error */}
        {error && !envError && (
          <div style={S.errorBox}>
            <strong>Error loading opportunities:</strong> {error}
            <div style={{ marginTop: 8, fontSize: 12 }}>
              Check that Express is running on :3001 and <code>DATABASE_URL</code> is set.
            </div>
          </div>
        )}

        {loading && (
          <div style={{ padding: 32, textAlign: "center", color: "#64748b" }}>
            Loading opportunities…
          </div>
        )}

        {!loading && !error && !envError && (
          <table style={S.table}>
            <thead style={S.thead}>
              <tr>
                {[
                  { key: "id",       label: "ID"       },
                  { key: "title",    label: "Title"    },
                  { key: "dept",     label: "Dept"     },
                  { key: "value",    label: "Value"    },
                  { key: "pwin",     label: "P(Win)"   },
                  { key: "score",    label: "Score"    },
                  { key: "status",   label: "Status"   },
                  { key: "due_date", label: "Due Date" },
                ].map(col => (
                  <th
                    key={col.key}
                    style={S.th}
                    onClick={() => handleSort(col.key)}
                    title={`Sort by ${col.label}`}
                  >
                    {col.label}{sortIndicator(col.key)}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {visible.length === 0 ? (
                <tr>
                  <td colSpan={8} style={S.emptyRow}>
                    No opportunities match the current filters.
                  </td>
                </tr>
              ) : (
                visible.map(opp => (
                  <tr
                    key={opp.id}
                    style={hoveredRow === opp.id ? S.trHover : {}}
                    onMouseEnter={() => setHoveredRow(opp.id)}
                    onMouseLeave={() => setHoveredRow(null)}
                  >
                    <td style={{ ...S.td, fontFamily: "monospace", fontSize: 11, color: "#6b7280" }}>{opp.id}</td>
                    <td style={{ ...S.td, fontWeight: 500, maxWidth: 260 }}>{opp.title}</td>
                    <td style={S.td}>{opp.dept || "—"}</td>
                    <td style={{ ...S.td, fontWeight: 600, fontVariantNumeric: "tabular-nums" }}>{fmtDollars(opp.value)}</td>
                    <td style={S.td}><PwinBadge pwin={opp.pwin} /></td>
                    <td style={S.td}><ScoreBadge score={opp.score} /></td>
                    <td style={S.td}><StatusPill status={opp.status} /></td>
                    <td style={{ ...S.td, whiteSpace: "nowrap" }}>{fmtDate(opp.due_date)}</td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        )}

        {/* Pipeline rule callout */}
        {!loading && !error && !envError && (
          <div style={{
            marginTop: 16,
            padding: "10px 16px",
            backgroundColor: "#eff6ff",
            border: "1px solid #bfdbfe",
            borderRadius: 8,
            fontSize: 12,
            color: "#1e40af",
          }}>
            <strong>Pipeline Rule:</strong> An opportunity does not become Pipeline until explicitly qualified.
            {" "}Qualify preview (dryRun:true) is available via <code>POST /api/opportunities/:id/qualify</code>.
            {" "}Real write requires approval gate — enforced server-side until S-005.
          </div>
        )}
      </div>
    </div>
  );
}
