# GDA Command Platform — S-163 Kickoff

**Last session:** S-162 — April 23, 2026
**Operator:** Shawn Seffernick, President EIS/GDA OU3
**Platform:** Retool — gdacommand.retool.com
**Editor:** https://gdacommand.retool.com/editor/9b2e8dbe-3f30-11f1-a98a-d30e2de07c9f/GDA%20Command%20Platform/dashboard

---

## Pre-Flight (Every Chat)
1. tool_search("n8n") — load MCP
2. Read this file
3. RR-38 and RR-28 are FROZEN — do not touch ever

---

## FIRST ACTION NEXT CHAT

S-162 completed the Retool rebuild nav restructure and 4 missing pages.
Ask Shawn if new items exist. Default priority if nothing new:

1. S-162-01 (Low): Launchpad opps table — wire getMegaDash .opps array to Retool table. Currently shows demo data.
2. S-162-02 (Low): E2E functional test all 25 pages.

---

## What Was Built S-162

- Nav restructured — 4 dropdown groups matching React app exactly: DONE
- Launchpad page — KPI cards (6), opps table, daily actions, intel feed: DONE
- Email Drafter page — 6 inputs, AI draft via gda-email-drafter, copy/save: DONE
- Prompt Architect page — 5 mode buttons, generate via gda-prompt-architect: DONE
- Platform Guide page — Quick Start / Page Reference / Webhook Reference tabs: DONE
- App.jsx read and mapped — 415KB, 5263 lines, full spec catalogued: DONE

---

## Nav Structure (Final)

INTELLIGENCE: Launchpad | AI Agent Chat | Daily SITREP | Morning Brief | Intel Feed | Deep Research | Meeting Notes | Prompt Architect
BUSINESS DEVELOPMENT: Competitive Intel | Bid Strategy | OODA Loop | Opportunity Tracker | PWin Calculator
CAPTURE & PROPOSALS: Capture Plans | Compliance Matrix | Document Hub | Email Drafter | Proposal Review | Proposal Factory | Risk Register
FINANCIAL & PLATFORM: Financial Bible | Platform Health | Platform Guide

---

## Open Debt

S-162-01 | Low | Launchpad opps table getMegaDash .opps binding needs Retool UI finalisation
S-162-02 | Low | E2E functional test all 25 pages not complete
RR-43 | Low | Bot dual-routing double-fire — fix when telegram-chat next touched
RR-36 | Med | Chrome MCP cross-origin — workaround in place
RR-44 | Low | Webhook headerAuth workaround documented
RR-38 | FROZEN | Do not touch
RR-28 | FROZEN | Do not touch

---

## Platform State

Retool app: LIVE — gdacommand.retool.com
Total pages: 25
n8n backend: https://n8n.csr-llc.tech/webhook
Auth header: x-gda-key: gda-api-2026-8ced0b75
GDA Postgres: Connected as "GDA Postgres" in Retool
n8n active workflows: ~156
React source (VPS): /opt/gda-command/src/App.jsx — 415KB
n8n: https://n8n.csr-llc.tech (v2.37.1)
MCP: https://mcp.csr-llc.tech/mcp

---

## Key Credentials

VPS SSH cred: VqYFb1aRGJa8UfBc
GDA webhook auth cred: fTrhOzBkjS1s67bm (x-gda-key: gda-api-2026-8ced0b75)
Anthropic: direct HTTP with $env.ANTHROPIC_API_KEY (model: claude-sonnet-4-20250514)
LangChain cred d92MU0tRK7bEGV83: BROKEN — never use
GDA.bot.telegram-chat: 1ItrrFxGI3L43Pdv
GDA.dev.deploy: 8GnGxnBL9TJjj1i2
GDA.intel.morning-briefing-v1: YIvCdrOgF1LGmFNL

---

## Rules

- Claude executes via MCP only. Never tell Shawn to manually do things.
- RR-38 and RR-28 are FROZEN. Do not touch.
- End every session: R-SR-09 (4 artifacts: Session Delta DOCX, DevOps Report DOCX, Master Build XLSX, Kickoff MD).
- Retool AI: Chrome MCP, Prompt Assist input is ref_1013 or find "Prompt Assist" textbox.
- Webhook auth workaround (RR-44): temp set to none, fire, restore headerAuth.
- Large file read from VPS: temp disable Read Webhook auth, run, restore.
