# GDA Command Platform — S-159 Chat 16 Kickoff
**Generated:** S-159 Chat 15 Close — April 21, 2026
**Operator:** Shawn Seffernick, President, Envision Innovative Solutions (OU3)

---

## Pre-Flight (Every Chat)
1. `tool_search("n8n")` — load MCP
2. Read project files (Session State, Master Build)
3. **RR-38 and RR-28 are FROZEN** — do not touch ever

---

## FIRST ACTION NEXT CHAT

All Med+ debt resolved. Only Low items remain:

| Priority | Item | Notes |
|---|---|---|
| Low | RR-43 — Bot dual-routing double-fire | Fix only when touching telegram-chat for another reason |
| Low | RR-44 — test webhook 403 workaround | Documented, no action needed |

**Ask Shawn if there are new S-159 items or new queue for S-160. Otherwise standing by.**

---

## What Was Fixed This Session (Chat 15)

| Item | Result |
|---|---|
| AN-2 | CLOSED — all 25 remaining incumbents resolved. gda_incumbent_log fully populated. |
| L-1 | CLOSED — 3 bugs in launchpad-funnel query fixed (wrong JSONB key, wrong TCV source, range value cast). 60 null stages patched to Go/No-Go. KPI bar now shows live values. |

---

## Deploy Webhook Auth Note (RR-44)
Temp patch `authentication` to `none` on Webhook node → fire → restore to `headerAuth`.

---

## Platform State

| Item | Status |
|---|---|
| Active workflows | ~151 |
| Frontend (gda.csr-llc.tech) | LIVE |
| GDA.api.launchpad-funnel | ACTIVE — L-1 FIXED, alloc_revenue_value key correct |
| GDA.api.capture-plan | ACTIVE — 23 nodes, kpis block in Respond List, LIMIT 100 |
| GDA.api.dashboard-mega | ACTIVE — 10 nodes, 1hr cache |
| GDA.intel.morning-briefing-v1 | ACTIVE — 16 nodes, data-learn wire LIVE |
| GDA.api.daily-actions | ACTIVE — 17 nodes |
| GDA.api.pwin-calculator | ACTIVE — loads learned weights from DB |
| GDA.api.win-loss-db | ACTIVE — auto-posts W/L to feedback-collector |
| GDA.api.capture-plan | ACTIVE — 23 nodes, RR-42 FIXED, kpis block added |
| GDA.cron.recompete-early-warning | ACTIVE — daily 7am ET |
| GDA.cron.win-rate-weekly-digest | ACTIVE — Mondays 8am ET |
| GDA.cron.idiq-task-order-alert | ACTIVE — daily 8am ET |
| GDA.cron.capture-opp-sync | ACTIVE — nightly 2am ET |
| GDA.api.platform-health | ACTIVE |
| GDA.api.bd-activity-log | ACTIVE |
| GDA.api.teaming-scorer | ACTIVE |
| GDA.cron.capture-milestone-alerts | ACTIVE — daily 9am ET |
| GDA.auto.feedback-collector | ACTIVE |
| GDA.cron.learning-engine | ACTIVE — nightly 3am ET |
| GDA.agent.opp-classifier | ACTIVE — 6 nodes, feedback wire LIVE |

---

## Key Workflow IDs

| Workflow | ID |
|---|---|
| GDA.dev.deploy | 8GnGxnBL9TJjj1i2 |
| GDA.bot.telegram-chat | 1ItrrFxGI3L43Pdv |
| GDA.api.daily-actions | C7Bh7KcAl1IgSTRr |
| GDA.api.ooda-loop 2 | pkPpMhiz8IdRy7To |
| GDA.intel.morning-briefing-v1 | YIvCdrOgF1LGmFNL |
| GDA.api.launchpad-funnel | vaRzM1Jl6HcXjuxs |
| GDA.api.dashboard-mega | UYGJPu7N5YZblvEU |
| GDA.api.opp-tracker 2 | SEJLE89wZa1yfQyB |
| GDA.api.capture-plan | QgperN6cuOpfnb09 |
| GDA.sched.opp-refresh | PeLGDqgLAsEh5Gsd |
| GDA.research.deep-research | q9YWVQCwnJGqmrO7 |
| GDA.auto.gist-update | djgOV2vX3PIv9cvm |
| GDA.api.aop-tracker | P8AfP8P84xi33auD |
| GDA.api.win-loss-db | SpU3znFHHABYNmb9 |
| GDA.cron.recompete-early-warning | MtcQwAgm1zHYXNfB |
| GDA.cron.win-rate-weekly-digest | ZuQkz1HrMONclkFm |
| GDA.cron.idiq-task-order-alert | DeSN1t1swXX14xTc |
| GDA.cron.capture-opp-sync | 0E3lCtWt2rdJlMPY |
| GDA.api.platform-health | UBgoJGxZro834RbT |
| GDA.api.bd-activity-log | 9qrsria0fy719T98 |
| GDA.api.teaming-scorer | jQvgX6SD1RhARG3F |
| GDA.cron.capture-milestone-alerts | Kk7O8Bw2FOe41M9l |
| GDA.auto.feedback-collector | aCrxoe1rCuIbsnC4 |
| GDA.cron.learning-engine | fZpqchmmPnqAmiMq |
| GDA.api.pwin-calculator | 81m1Zl9xjM6L8HQb |
| GDA.agent.opp-classifier | hWCP9NLXxtCOrppu |

---

## Infrastructure

| Resource | Detail |
|---|---|
| Frontend source | /opt/gda-command/src/App.jsx |
| Deploy webhook | POST https://n8n.csr-llc.tech/webhook/gda-deploy |
| Deploy auth | Header: x-gda-auth: gda-deploy-2026-secure |
| Deploy MCP pattern | Temp set Webhook auth to none → fire → restore headerAuth |
| SSH webhook (read) | POST https://n8n.csr-llc.tech/webhook/gda-read |
| SSH auth | Header: x-gda-key: gda-api-2026-secure |
| Postgres cred | HwronxMmGY5XDGEt |
| VPS | 187.77.206.105 |
| n8n | https://n8n.csr-llc.tech (v2.37.1) |
| Frontend | https://gda.csr-llc.tech |
| MCP | https://mcp.csr-llc.tech/mcp |
| SSH exec workflow | IcD4K740vpWSIuaZ |

---

## Open Debt

| ID | Sev | Summary |
|---|---|---|
| RR-36 | Med | Chrome MCP cross-origin — workaround in place |
| RR-43 | Low | Bot dual-routing double-fire — fix when telegram-chat next touched |
| RR-44 | Low | n8n_test_workflow 403 on headerAuth — workaround documented |
| RR-38 | FROZEN | Do not touch |
| RR-28 | FROZEN | Do not touch |

---

## Rules

- Claude executes everything via MCP. Never tell Shawn to manually do things.
- RR-38 and RR-28 are FROZEN. Do not touch.
- Show broken vs fixed BEFORE deploying (R-SR-04).
- Spot-check 2 items before any batch operation (R-SR-13).
- End every session: overwrite these 3 project files with updated versions.
- DevOps report is CONDITIONAL — only for major fix waves. Most sessions skip it.
- Bot rollback: n8n_workflow_versions(mode=rollback, workflowId=1ItrrFxGI3L43Pdv) to v4

---

## Schema (Canonical)

- `gda_intelligence_log` time column: **timestamp** (created_at also present)
- Allocation revenue: `gda_capture_plans.plan_data->>'allocated_revenue_value'` (JSONB — confirmed canonical key S-159 C15)
- `opp-tracker 2` and `ooda-loop 2` are LIVE CANONICAL — do not delete
- Anthropic API: direct HTTP with $env.ANTHROPIC_API_KEY. LangChain cred d92MU0tRK7bEGV83 is BROKEN.
- `gda_mega_cache` — id=1 singleton, 60min TTL (currently empty — launchpad-funnel is the live summary source)
- `gda_feedback` event_types: win, loss, pwin_outcome, opp_label_correction, action_completed, actions_generated, opp_classified, briefing_sent
- `gda_learned_weights` keys: pwin.* (6), briefing.* (3), actions.* (3) — 12 total
- capture-plan Postgres nodes use `queryValues` arrays — queryReplacement fully removed S-158 Chat 2
- `gda_capture_plans.plan_data->>'stage'` — all 98 rows populated (no nulls as of S-159 C15)
- `gda_incumbent_log` — fully populated as of S-159 C15, all opps resolved
- TCV in plan_data is sparse (most plans lack total_contract_value); alloc_revenue_value is the real pipeline signal ($792M active)
