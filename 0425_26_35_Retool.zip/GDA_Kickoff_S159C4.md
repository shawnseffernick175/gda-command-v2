# GDA Command Platform — S-159 Chat 4 Kickoff
**Date:** Next session after 2026-04-25
**Operator:** Shawn Seffernick, President, Envision Innovative Solutions (OU3)
**Mode:** Pure-MCP

---

## Pre-Flight Checklist
1. `tool_search("n8n")` — load MCP toolset
2. Read this file
3. **RR-38 and RR-28 are FROZEN** — do not touch under any circumstances

---

## FIRST ACTION NEXT CHAT

Check for new items from Shawn. No hardening queue remains. No critical debt.

Default: Shawn-directed work. Platform is fully hardened and clean.

---

## Key Credentials (Current)

| Resource | Value |
|---|---|
| API key (all webhooks) | `gda-api-2026-f584dae2` |
| Deploy key | `gda-deploy-2026-34a11f91` |
| Webhook header | `x-gda-key` (x-gda-auth retired) |
| Credential ID | `fTrhOzBkjS1s67bm` |

---

## Platform State at S-159 Chat 3 Close

| Item | Status |
|---|---|
| Active workflows | ~155 |
| Frontend | LIVE |
| All hardening items | COMPLETE |
| weekly-comp-scan | FIXED — auth key updated, queryValues bug patched |
| queryReplacement | ZERO platform-wide |
| Rate limiting | LIVE — Traefik 300r/min |

---

## Open Debt

| ID | Sev | Summary |
|---|---|---|
| RR-36 | Med | Chrome MCP cross-origin — workaround in place |
| RR-43 | Low | Bot dual-routing — fix when telegram-chat next touched |
| RR-44 | Low | n8n_test_workflow 403 on headerAuth — workaround documented |
| RR-38 | FROZEN | Do not touch |
| RR-28 | FROZEN | Do not touch |

---

## Platform Rules
- Claude executes everything via MCP. Never tell Shawn to manually do things.
- RR-38 and RR-28 are FROZEN.
- All webhooks: `x-gda-key` header only.
- Postgres: inline `{{ }}` expressions — no queryValues arrays, no queryReplacement.
- Switch node broken — use IF nodes.
- LangChain cred `d92MU0tRK7bEGV83` BROKEN — use direct HTTP with `$env.ANTHROPIC_API_KEY`.
- headerAuth test pattern: temp none → fire → restore (RR-44).
- End every session with R-SR-09.

---

*— GDA Command Platform S-159 Chat 4 Kickoff —*
