# GDA Command Platform — S-159 Chat 11 Kickoff

**Last session:** S-159 Chat 10, April 20, 2026
**Status:** A-2 CLOSED. L-2 CLOSED. O-4 CLOSED.

---

## Pre-Flight
1. `tool_search("n8n")` — load MCP
2. Read this file
3. RR-38 and RR-28 FROZEN

---

## FIRST ACTION NEXT SESSION

### O-1 — Numbers inconsistent platform-wide (HIGH)

Audit KPI/count values across the three data sources and find mismatches:
- `GDA.api.dashboard-mega` (UYGJPu7N5YZblvEU) — `stats` block: total_opps, pursue, pipeline_value
- `GDA.api.launchpad-funnel` (vaRzM1Jl6HcXjuxs) — `summary.totalOpps`, `totalValue`, `totalCapture`
- `GDA.api.opp-tracker 2` (SEJLE89wZa1yfQyB) — direct opp counts by stage

Run SSH queries against `gda_opportunity_tracker` and `gda_capture_plans` to establish ground truth, then compare to what each API returns. Fix whichever query is wrong.

---

## Context
- AIAgentPage.jsx: Array.isArray guards built and deployed (A-2 CLOSED)
- Top Opps table: contract_value xM cast fixed in launchpad-funnel nodes (L-2 CLOSED)
- Intel Feed dropdowns: sec_latest + sec_pred now default open (O-4 CLOSED)
- ssh-read-file: headerAuth restored at session close — confirmed

## Full Backlog
See GDA_Master_Build_v159c10.xlsx — Backlog tab. 40+ items.

## Key Notes
- Correct auth header: `x-gda-key: gda-api-2026-secure`
- Postgres inline template rule (typeVersion 2.5/2.6): `{{ $json.field }}` inline — never queryValues/queryReplacement
- Switch node broken — use IF or Code
- LangChain cred d92MU0tRK7bEGV83 BROKEN — use direct HTTP + $env.ANTHROPIC_API_KEY
- contract_value in gda_capture_plans: 57 rows use xM text format — always use CASE WHEN ILIKE '%M' cast
- Docker Postgres DB name: `n8n` (not `gda`)
- RR-44 pattern: set Webhook auth to none → fire → restore headerAuth
