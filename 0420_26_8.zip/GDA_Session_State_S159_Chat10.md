# GDA Command Platform — Session State
**Last Updated:** S-159 Chat 10 — April 20, 2026
**Operator:** Shawn Seffernick, President, Envision Innovative Solutions (OU3)

---

## Pre-Flight (Every Chat)
1. `tool_search("n8n")` — load MCP
2. Read this file
3. **RR-38 and RR-28 are FROZEN** — do not touch ever

---

## FIRST ACTION NEXT CHAT
O-1 — Numbers inconsistent platform-wide. Audit dashboard-mega stats block, launchpad-funnel summary, and opp-tracker counts against ground-truth DB queries. Find and fix the discrepancy.

---

## CRITICAL: Auth Header
**Correct header is `x-gda-key: gda-api-2026-secure`** — NOT x-gda-auth.

## CRITICAL: App.jsx encoding rule
**Always write App.jsx / component files with UTF-8 encoding.**

## CRITICAL: contract_value cast
**gda_capture_plans.contract_value is TEXT, 57+ rows use xM format (e.g. '1.5M').** Always use:
`CASE WHEN contract_value ILIKE '%M' THEN REPLACE(contract_value,'M','')::numeric * 1000000 ELSE NULLIF(contract_value,'')::numeric END`

## Deploy pattern
`{"auth_key": "gda-deploy-2026-secure", "mode": "build_only", "msg": "description"}` → deploy webhook.
Deploy webhook RR-44 workaround: set both Webhook + Read Webhook auth to none → fire → restore headerAuth.
MCP test_workflow cannot pass deploy Auth Guard Code node — use SSH build path for frontend changes.

## SSH Read/Write Note
ssh-read-file (IcD4K740vpWSIuaZ) accepts `body.cmd` or `body.command`. RR-44 pattern: auth none → fire → restore.
Docker Postgres: `n8n-envision-postgres-1`. DB name: `n8n`.

---

## Platform State

| Item | Status |
|---|---|
| Active workflows | ~151 |
| Frontend (gda.csr-llc.tech) | LIVE — S-159C10 build deployed |
| Auth header | FIXED — x-gda-key in gda.jsx + E2E checker |
| Intel Feed | FIXED — 28 results live (I-1 CLOSED S-159 C9) |
| Deep Research | FIXED — queryReplacement removed (D-1 CLOSED S-159 C9) |
| AI Agent history | BUILT — Array.isArray guards live (A-2 CLOSED S-159 C10) |
| Top Opps table | FIXED — xM cast corrected, 10 rows returning (L-2 CLOSED S-159 C10) |
| Intel Feed dropdowns | FIXED — sec_latest + sec_pred open by default (O-4 CLOSED S-159 C10) |
| E2E checker | Auth fixed — x-gda-key in HEADERS |
| weekly-comp-scan | FIXED — queryReplacement removed |
| embed-and-store | FIXED S-159C7 |
| Vector store | SEEDED — 94 plans |
| Morning Brief | FIXED endpoint/renderer |
| All cron workflows | ACTIVE |

---

## Key Workflow IDs

| Workflow | ID |
|---|---|
| GDA.dev.deploy | 8GnGxnBL9TJjj1i2 |
| GDA.bot.telegram-chat | 1ItrrFxGI3L43Pdv |
| GDA.api.daily-actions | C7Bh7KcAl1IgSTRr |
| GDA.api.action-history | 1OPkoA5e8DYVQKm1 |
| GDA.intel.morning-briefing-v1 | YIvCdrOgF1LGmFNL |
| GDA.api.morning-briefing (read) | 0zVPgmYsvcqhyyo6 |
| GDA.api.dashboard-mega | UYGJPu7N5YZblvEU |
| GDA.api.opp-tracker 2 | SEJLE89wZa1yfQyB |
| GDA.api.capture-plan | QgperN6cuOpfnb09 |
| GDA.api.intel-feed | KIT8cj4V2cMFdSkA |
| GDA.research.deep-research | q9YWVQCwnJGqmrO7 |
| GDA.api.platform-health | UBgoJGxZro834RbT |
| GDA.util.ssh-read-file | IcD4K740vpWSIuaZ |
| GDA.api.embed-and-store | yA4NHeu0ctVVxzYg |
| GDA.auto.e2e-gemini-report | BLS36QTOznJ8mJlC |
| GDA.cron.weekly-comp-scan | uQ5cZ97cCrx5iIXk |
| GDA.auto.gist-update | djgOV2vX3PIv9cvm |
| GDA.api.aop-tracker | P8AfP8P84xi33auD |
| GDA.api.win-loss-db | SpU3znFHHABYNmb9 |
| GDA.cron.recompete-early-warning | MtcQwAgm1zHYXNfB |
| GDA.cron.win-rate-weekly-digest | ZuQkz1HrMONclkFm |
| GDA.cron.idiq-task-order-alert | DeSN1t1swXX14xTc |
| GDA.cron.capture-opp-sync | 0E3lCtWt2rdJlMPY |
| GDA.api.bd-activity-log | 9qrsria0fy719T98 |
| GDA.api.teaming-scorer | jQvgX6SD1RhARG3F |
| GDA.cron.capture-milestone-alerts | Kk7O8Bw2FOe41M9l |
| GDA.auto.feedback-collector | aCrxoe1rCuIbsnC4 |
| GDA.cron.learning-engine | fZpqchmmPnqAmiMq |
| GDA.api.pwin-calculator | 81m1Zl9xjM6L8HQb |
| GDA.agent.opp-classifier | hWCP9NLXxtCOrppu |
| GDA.sched.opp-refresh | PeLGDqgLAsEh5Gsd |
| GDA.api.launchpad-funnel | vaRzM1Jl6HcXjuxs |

---

## Infrastructure

| Resource | Detail |
|---|---|
| Frontend source | /opt/gda-command/src/App.jsx |
| AIAgentPage source | /opt/gda-command/src/components/pages/AIAgentPage.jsx |
| Deploy webhook | POST https://n8n.csr-llc.tech/webhook/gda-deploy |
| Deploy auth | body.auth_key: gda-deploy-2026-secure |
| Deploy MCP pattern | Temp set both Webhook + Read Webhook auth to none → fire → restore headerAuth |
| Deploy SSH pattern | Use ssh-read-file to run build command directly (bypasses Code node auth check) |
| SSH webhook (read/write) | POST https://n8n.csr-llc.tech/webhook/gda-read (ssh-read-file) |
| SSH auth | Header: x-gda-key: gda-api-2026-secure |
| Postgres cred | HwronxMmGY5XDGEt |
| Docker Postgres container | n8n-envision-postgres-1 |
| Docker Postgres DB | n8n |
| VPS | 187.77.206.105 |
| n8n | https://n8n.csr-llc.tech (v2.37.1) |
| Frontend | https://gda.csr-llc.tech |
| MCP | https://mcp.csr-llc.tech/mcp |
| Feedback endpoint | POST https://n8n.csr-llc.tech/webhook/gda-feedback |
| Data-learn endpoint | POST https://n8n.csr-llc.tech/webhook/gda-data-learn |

---

## Open Debt (Priority Order)

| ID | Sev | Summary |
|---|---|---|
| O-1 | HIGH | Numbers inconsistent platform-wide |
| A-1 | HIGH | AI Agent missing GDA platform context |
| S-7 | HIGH | Morning Brief empty — RSS not pulling real data |
| AN-1 | HIGH | Real analysis: incumbent, win themes |
| AN-2 | HIGH | Ingest competitive intel from internet |
| L-1 | MED | KPI numbers mismatch capture plan |
| L-3 | MED | 63 overdue opps never auto-moved to Pass |
| L-4 | MED | Qualified bar chart text invisible |
| L-5 | MED | Capture Plan Stages right side empty |
| L-6 | MED | Deadline list no dollar value no analysis |
| L-7 | MED | GovTribe links 404 |
| L-8 | MED | SITREP not auto-generated |
| L-9 | MED | Predictive analysis empty |
| L-10 | MED | Action items <30d should auto-Pass |
| S-1 | MED | World News no sources one sentence filler |
| S-2 | MED | DoD News source links to Launchpad |
| S-3 | MED | Other Dept News all filler |
| S-4 | MED | Acquisition News recycled stats |
| S-5 | MED | Opportunities/Risks cards duplicate Launchpad |
| S-6 | MED | Merge Morning Brief + SITREP |
| I-2 | MED | Intel Feed history renders blank |
| D-2 | MED | Deep Research history empty |
| C-1 | MED | Comp Intel — opening one card expands whole row |
| C-2 | MED | Comp Intel — no so-what vs GDA |
| C-3 | MED | Comp Intel — no threat mapping per agency |
| C-4 | MED | Comp Intel — data static needs daily update |
| C-5 | MED | Comp Intel — missing INSCOM/TRADOC/PEO Soldier/PEO STRI/APG/Army Futures/Fort Liberty |
| C-6 | MED | Comp Intel — no AI threat narrative |
| N-1 | MED | Merge Wargame + Incumbent + Teaming → Bid Strategy |
| O-2 | MED | Opp Tracker sub-rows missing columns |
| O-7 | MED | NDAA Intel placeholder needs real ingestion |
| P-1 | MED | Smoke test never run |
| O-3 | LOW | Remove Unassigned category |
| O-5 | LOW | Department of War wrong name |
| O-6 | LOW | IDIQ vehicles duplicated |
| RR-43 | LOW | Bot dual-routing |
| RR-44 | LOW | headerAuth 403 workaround documented |
| RR-36 | MED | Chrome MCP cross-origin — workaround in place |
| RR-38 | FROZEN | Do not touch |
| RR-28 | FROZEN | Do not touch |

---

## Rules
- Claude executes everything via MCP. Never tell Shawn to manually do things.
- RR-38 and RR-28 are FROZEN. Do not touch.
- Correct auth: `x-gda-key: gda-api-2026-secure`
- Anthropic API: direct HTTP with $env.ANTHROPIC_API_KEY — LangChain d92MU0tRK7bEGV83 BROKEN
- Postgres inline template rule (typeVersion 2.5/2.6): `{{ $json.field }}` inline — never queryValues/queryReplacement
- Switch node broken — use IF or Code
- No filler content anywhere in this platform
- Bot rollback: n8n_workflow_versions(mode=rollback, workflowId=1ItrrFxGI3L43Pdv) to v4
- contract_value: always safe-cast with CASE WHEN ILIKE '%M' pattern

## Schema (Canonical)
- gda_morning_briefings.briefing = plain markdown TEXT
- deadline-escalation writes to `risk_register`
- embed-and-store outbound: header `x-gda-auth: gda-deploy-2026-secure`
- capture-plan Postgres nodes use `queryValues` arrays
- gda_intelligence_log time column: timestamp (created_at also present)
- Allocation revenue: gda_capture_plans.plan_data->>'allocated_revenue' (JSONB, dollars, clean numeric)
- contract_value: TEXT column, 57+ rows use xM format — always safe-cast
- gda_mega_cache — id=1 singleton, 60min TTL
- gda_feedback event_types: win, loss, pwin_outcome, opp_label_correction, action_completed, actions_generated, opp_classified, briefing_sent
- gda_learned_weights keys: pwin.* (6), briefing.* (3), actions.* (3) — 12 total
