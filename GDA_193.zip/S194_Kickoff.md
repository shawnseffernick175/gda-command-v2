# S-194 Kickoff — GDA Command Platform
**Date:** Next session after May 3, 2026
**Operator:** Claude (Anthropic)
**Platform:** GDA OU3 / Envision Innovative Solutions

---

## Session Open Protocol (MANDATORY)
1. `tool_search("n8n")` — load MCP context
2. Read this file
3. Execute top item from queue below without interrogating

---

## Platform State at S-193 Close
| Component | State |
|---|---|
| VPS 187.77.206.105 | ONLINE — stable post S-192 reboot |
| n8n.csr-llc.tech | ONLINE — {status:ok} confirmed |
| gda.csr-llc.tech | LIVE — React SPA 23 pages |
| API Gateway | ACTIVE — gda-gateway.service :8788 |
| AN-1 Workflow | ACTIVE — yMo7WrELV8JVOi2M — first run confirmed S-193 |
| QA fix-runner | ACTIVE — aAVitXXjGWaP7bb2 — health {ok:true} |
| GIST-01 | ACTIVE — 4bhVvKvVgLXcX6AZ — rebuilt + verified |
| North Star | ~92% |

---

## S-194 Priority Queue

### **RANK 1 — Block D: Rescue Map Audit (MANDATORY)**
Six workflows claimed fixed in earlier sessions but never verified via live execution.
Trigger each, inspect executions for errors, document result.

```
Workflows to verify:
| ID                | Name                    |
|-------------------|-------------------------|
| uQ5cZ97cCrx5iIXk  | weekly-comp-scan        |
| YIvCdrOgF1LGmFNL  | morning-briefing-v1     |
| EGQzp92GxbjTJ03X  | nightly-fy-revenue-calc |
| LzjiBI80aDAZgDIp  | data-retention          |
| BLS36QTOznJ8mJlC  | e2e-gemini-report       |
| JRnWGEH9cesb8f3w  | dept-opp-sweep          |

For each:
1. n8n_test_workflow <id> with appropriate payload + x-gda-key header
2. n8n_executions list workflowId=<id> status=error
3. If errors → fix and re-test
4. Mark VERIFIED or NEEDS-FIX
```

### **RANK 2 — AN-1 DB Seeding**
`gda_win_loss_db` has only 1 entry — insufficient for meaningful win theme analysis.
```
1. Query gda_win_loss_db for current schema
2. Identify top 5-10 historical GDA wins from gda_opportunity_tracker (stage='Won')
3. INSERT into gda_win_loss_db with incumbent_displaced, win_themes, agency fields
4. Re-trigger AN-1 and verify richer analysis in Telegram
```

### **RANK 3 — North Star Push to 95%**
After Block D closes, platform should be at ~95%.
```
1. Re-read North Star Progress sheet from Master Build
2. Identify remaining 3-5% gap items
3. Execute any quick wins
4. Update North Star % in Master Build
```

### **RANK 4 — IEW&S SETA RS3-25-0034 PM Years Fix**
MUST-WIN. Known discrepancy: Table 1.2.4-1 says 10yr, Att 0005 requires 14yr.
```
RR-FROZEN — do NOT touch unless Shawn explicitly lifts freeze.
```

---

## Key Credentials (S-193 canonical — unchanged)
```
x-gda-key:                gda-api-2027-AWqjhbxDYNcyV1mr
GDA Webhook Auth cred:    fTrhOzBkjS1s67bm  (primary)
GDA Webhook Auth cred:    1pNPY36DDz49OtKL  (alternate)
VPS SSH Key cred:         NKOxLo5F81sRNPua
Telegram cred:            Jr8OOsZqc9DarQE6  (GDA Telegram Bot)
Postgres cred:            HwronxMmGY5XDGEt  (GDA Postgres)
GitHub Gist PAT:          sKJFLNzetK86JnvO
QA Agent key:             qa-agent-test-2026-adlkjfn7987-srkigio-99-eatshit
```

## Key Workflow IDs (S-193 additions)
```
AN-1 Win Themes:          yMo7WrELV8JVOi2M  (ACTIVE — first run S-193)
QA fix-runner:            aAVitXXjGWaP7bb2  (ACTIVE — verified S-193)
Gist session-update:      4bhVvKvVgLXcX6AZ  (ACTIVE — NEW S-193, path: gda-gist-session-update)
SSH Exec:                 IcD4K740vpWSIuaZ
Deploy:                   8GnGxnBL9TJjj1i2
Dashboard-mega:           UYGJPu7N5YZblvEU
opp-tracker 2:            SEJLE89wZa1yfQyB  (CANONICAL)
ooda-loop 2:              pkPpMhiz8IdRy7To  (CANONICAL)
Morning briefing:         YIvCdrOgF1LGmFNL  (UNVERIFIED — Block D)
Capture-plan:             QgperN6cuOpfnb09
pwin-daily-loop:          LOaS0qrkHi1dLSLZ  (FIXED S-192)
recompete-warning:        MtcQwAgm1zHYXNfB
error-handler:            2Swf6LP9AzFjHFYU
```

## Hard Rules (S-193 canonical)
- Switch node → broken → use IF or Code nodes
- LangChain cred d92MU0tRK7bEGV83 → permanently broken → HTTP + $env.ANTHROPIC_API_KEY
- Postgres typeVersion 2.5/2.6 → inline `{{ $json.field }}` in SQL; no queryValues; dollar-quoting for JSON strings
- App.jsx writes → UTF-8 only; backup at /opt/gda-command/src/App.jsx.bak-s158-kpi
- Deploy: vite build → cp -r dist/. /root/gda-frontend/dist/ → docker exec nginx -s reload
- N8N_ENCRYPTION_KEY → must persist in /root/n8n-envision/.env
- SSH Guard allows: bash -c, python3, cat, grep, sed, tee, tail, find, ls
- Code nodes: use native fetch() — never $helpers.httpRequest (CODE-01)
- RR-38 and RR-28 are FROZEN until Shawn personally lifts
- Bulk MCP ops: throttle to ~20 workflows/batch, 30s pause between batches
- Never mention Retool
- Canonical opp table: gda_opportunity_tracker; PURSUE label: gda_label = 'PURSUE'
- Canonical active pipeline: stage NOT IN ('No-Bid','Cancelled','No-Go','Lost','Won')

---

## North Star Gap (post S-193)
| Remaining | Effort |
|---|------|
| Block D: Rescue Map Audit (6 workflows) | S-194 Rank 1 — trigger + inspect |
| AN-1 DB Seeding | S-194 Rank 2 — SQL inserts |
| North Star push to 95% | S-194 Rank 3 |

Platform is ~92% of North Star. Remaining items are verification + data seeding.

---
*Generated by R-SR-09 close protocol at end of S-193 — May 3, 2026*
