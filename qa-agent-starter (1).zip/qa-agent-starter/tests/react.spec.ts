import { test } from "@playwright/test";
import { loadTestCases } from "../src/config.js";
import { replaceTokens } from "../src/env.js";
import { runUiCase } from "../src/ui-steps.js";
import { captureDiagnostics } from "./helpers.js";

const runId = `react-${new Date().toISOString().replaceAll(/[:.]/g, "-")}`;
const testCases = loadTestCases().react.map((testCase) => replaceTokens(testCase, runId));

for (const testCase of testCases) {
  test.describe("React app QA", () => {
    test(testCase.name, async ({ page }, testInfo) => {
      test.skip(!testCase.enabled, "Test case disabled in config/test-cases.json");
      const diagnostics = captureDiagnostics(page);
      try {
        await runUiCase(page, testCase);
      } finally {
        await diagnostics.write(testInfo);
      }
    });
  });
}
