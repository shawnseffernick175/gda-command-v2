import fs from "node:fs";
import path from "node:path";
import type { Page, TestInfo } from "@playwright/test";
import { artifactPath } from "../src/artifacts.js";

export function captureDiagnostics(page: Page) {
  const consoleMessages: unknown[] = [];
  const failedRequests: unknown[] = [];

  page.on("console", (message) => {
    if (["error", "warning"].includes(message.type())) {
      consoleMessages.push({
        type: message.type(),
        text: message.text(),
        location: message.location()
      });
    }
  });

  page.on("requestfailed", (request) => {
    failedRequests.push({
      url: request.url(),
      method: request.method(),
      failure: request.failure()
    });
  });

  return {
    async write(testInfo: TestInfo): Promise<string> {
      const safeTitle = testInfo.title.replaceAll(/[^a-z0-9-_]+/gi, "-").toLowerCase();
      const logPath = artifactPath("logs", `${safeTitle}-browser-diagnostics.json`);
      fs.mkdirSync(path.dirname(logPath), { recursive: true });
      fs.writeFileSync(
        logPath,
        `${JSON.stringify(
          {
            test: testInfo.title,
            status: testInfo.status,
            consoleMessages,
            failedRequests
          },
          null,
          2
        )}\n`
      );
      return logPath;
    }
  };
}
