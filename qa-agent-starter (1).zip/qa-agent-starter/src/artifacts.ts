import fs from "node:fs";
import path from "node:path";
import { env } from "./env.js";

export type CheckStatus = "passed" | "failed" | "skipped";

export interface CheckResult {
  suite: "n8n" | "react" | "retool" | "retool-deploy" | "ai-reviewer";
  name: string;
  status: CheckStatus;
  durationMs: number;
  description?: string;
  details?: unknown;
  error?: string;
  artifacts?: string[];
}

export interface QaRunSummary {
  runId: string;
  startedAt: string;
  finishedAt: string;
  status: CheckStatus;
  results: CheckResult[];
}

export function artifactPath(...parts: string[]): string {
  return path.resolve(process.cwd(), env.artifactDir, ...parts);
}

export function ensureArtifactDirs(): void {
  for (const dir of ["", "logs", "reports", "screenshots"]) {
    fs.mkdirSync(artifactPath(dir), { recursive: true });
  }
}

export function writeJsonArtifact(relativePath: string, data: unknown): string {
  ensureArtifactDirs();
  const fullPath = artifactPath(relativePath);
  fs.mkdirSync(path.dirname(fullPath), { recursive: true });
  fs.writeFileSync(fullPath, `${JSON.stringify(data, null, 2)}\n`);
  return fullPath;
}

export function writeTextArtifact(relativePath: string, data: string): string {
  ensureArtifactDirs();
  const fullPath = artifactPath(relativePath);
  fs.mkdirSync(path.dirname(fullPath), { recursive: true });
  fs.writeFileSync(fullPath, data);
  return fullPath;
}

export function summarizeStatus(results: CheckResult[]): CheckStatus {
  if (results.some((result) => result.status === "failed")) return "failed";
  if (results.length > 0 && results.every((result) => result.status === "skipped")) return "skipped";
  return "passed";
}

export async function timedCheck(
  suite: CheckResult["suite"],
  name: string,
  description: string | undefined,
  fn: () => Promise<Omit<CheckResult, "suite" | "name" | "description" | "durationMs">>
): Promise<CheckResult> {
  const start = Date.now();
  try {
    const result = await fn();
    return {
      suite,
      name,
      description,
      durationMs: Date.now() - start,
      ...result
    };
  } catch (error) {
    return {
      suite,
      name,
      description,
      status: "failed",
      durationMs: Date.now() - start,
      error: error instanceof Error ? error.stack ?? error.message : String(error)
    };
  }
}
