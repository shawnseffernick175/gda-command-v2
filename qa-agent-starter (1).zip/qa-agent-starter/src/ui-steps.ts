import { expect, type Page } from "@playwright/test";
import type { UiCase, UiStep } from "./config.js";

export async function runUiCase(page: Page, testCase: UiCase): Promise<void> {
  await page.goto(testCase.url, { waitUntil: "domcontentloaded", timeout: 30000 });

  for (const step of testCase.steps) {
    await runUiStep(page, step);
  }
}

async function runUiStep(page: Page, step: UiStep): Promise<void> {
  const timeout = step.timeoutMs ?? 10000;

  switch (step.action) {
    case "goto": {
      if (!step.value) throw new Error("goto step requires value");
      await page.goto(step.value, { waitUntil: "domcontentloaded", timeout });
      break;
    }
    case "fill": {
      if (!step.selector || step.value === undefined) throw new Error("fill step requires selector and value");
      await page.locator(step.selector).fill(step.value, { timeout });
      break;
    }
    case "click": {
      if (!step.selector) throw new Error("click step requires selector");
      await page.locator(step.selector).click({ timeout });
      break;
    }
    case "press": {
      if (!step.selector || !step.value) throw new Error("press step requires selector and value");
      await page.locator(step.selector).press(step.value, { timeout });
      break;
    }
    case "selectOption": {
      if (!step.selector || step.value === undefined) throw new Error("selectOption step requires selector and value");
      await page.locator(step.selector).selectOption(step.value, { timeout });
      break;
    }
    case "expectText": {
      if (!step.selector || step.value === undefined) throw new Error("expectText step requires selector and value");
      await expect(page.locator(step.selector)).toContainText(step.value, { timeout });
      break;
    }
    case "expectVisible": {
      if (!step.selector) throw new Error("expectVisible step requires selector");
      await expect(page.locator(step.selector)).toBeVisible({ timeout });
      break;
    }
    case "expectTitle": {
      if (!step.value) throw new Error("expectTitle step requires value");
      await expect(page).toHaveTitle(new RegExp(step.value), { timeout });
      break;
    }
    case "expectValue": {
      if (!step.selector || step.value === undefined) throw new Error("expectValue step requires selector and value");
      await expect(page.locator(step.selector)).toHaveValue(step.value, { timeout });
      break;
    }
    case "expectDisabled": {
      if (!step.selector) throw new Error("expectDisabled step requires selector");
      await expect(page.locator(step.selector)).toBeDisabled({ timeout });
      break;
    }
    case "wait": {
      await page.waitForTimeout(timeout);
      break;
    }
    default: {
      const exhaustive: never = step.action;
      throw new Error(`Unsupported UI step: ${exhaustive}`);
    }
  }
}
