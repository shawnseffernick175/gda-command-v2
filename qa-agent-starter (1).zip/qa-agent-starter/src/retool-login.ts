import type { Page } from "@playwright/test";
import { env } from "./env.js";

export async function loginToRetool(page: Page): Promise<void> {
  if (!env.retoolBaseUrl || !env.retoolTestEmail || !env.retoolTestPassword) {
    throw new Error(
      "Retool login requires RETOOL_BASE_URL, RETOOL_TEST_EMAIL, and RETOOL_TEST_PASSWORD. Use a limited-permission test user."
    );
  }

  await page.goto(`${env.retoolBaseUrl.replace(/\/$/, "")}/auth/login`, {
    waitUntil: "domcontentloaded",
    timeout: 30000
  });

  await page.locator("input[type='email'], input[name='email']").first().fill(env.retoolTestEmail, { timeout: 15000 });
  await page.locator("input[type='password'], input[name='password']").first().fill(env.retoolTestPassword, { timeout: 15000 });
  await page.locator("button[type='submit'], button:has-text('Log in'), button:has-text('Sign in')").first().click({
    timeout: 15000
  });

  await page.waitForLoadState("domcontentloaded", { timeout: 30000 }).catch(() => undefined);

  if (env.retoolTestTotpSecret) {
    throw new Error(
      "TOTP login is not implemented in the starter kit. Add otplib and fill this helper if your Retool test user requires 2FA."
    );
  }
}
