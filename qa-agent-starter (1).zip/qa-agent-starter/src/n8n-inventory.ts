import { ensureArtifactDirs, writeJsonArtifact, writeTextArtifact } from "./artifacts.js";
import { requireEnv } from "./env.js";

interface N8nWorkflowListResponse {
  data?: N8nWorkflow[];
  nextCursor?: string;
}

interface N8nWorkflow {
  id: string;
  name: string;
  active?: boolean;
  nodes?: N8nNode[];
  tags?: Array<{ id?: string; name?: string }>;
  updatedAt?: string;
  createdAt?: string;
}

interface N8nNode {
  id?: string;
  name: string;
  type: string;
  typeVersion?: number;
  disabled?: boolean;
  parameters?: Record<string, unknown>;
}

interface WorkflowInventoryItem {
  id: string;
  name: string;
  active: boolean;
  nodeCount: number;
  triggerNodes: Array<{
    name: string;
    type: string;
    disabled: boolean;
    webhookPath?: string;
    httpMethod?: string;
  }>;
  likelyWebhookUrls: string[];
  tags: string[];
  updatedAt?: string;
}

function getStringParameter(parameters: Record<string, unknown> | undefined, key: string): string | undefined {
  const value = parameters?.[key];
  return typeof value === "string" && value.trim() ? value : undefined;
}

function getHttpMethod(parameters: Record<string, unknown> | undefined): string | undefined {
  return (
    getStringParameter(parameters, "httpMethod") ??
    getStringParameter(parameters, "method") ??
    getStringParameter(parameters, "requestMethod")
  );
}

function getWebhookPath(parameters: Record<string, unknown> | undefined): string | undefined {
  return (
    getStringParameter(parameters, "path") ??
    getStringParameter(parameters, "webhookPath") ??
    getStringParameter(parameters, "endpoint") ??
    getStringParameter(parameters, "url")
  );
}

function isTriggerNode(node: N8nNode): boolean {
  const type = node.type.toLowerCase();
  return type.includes("trigger") || type.includes("webhook") || type.includes("schedule") || type.includes("cron");
}

function isWebhookNode(node: N8nNode): boolean {
  return node.type.toLowerCase().includes("webhook");
}

async function fetchWorkflows(): Promise<N8nWorkflow[]> {
  const baseUrl = requireEnv("n8nBaseUrl", "Set N8N_BASE_URL in .env.");
  const apiKey = requireEnv("n8nApiKey", "Set N8N_API_KEY in .env.");
  const workflows: N8nWorkflow[] = [];
  let cursor: string | undefined;

  do {
    const url = new URL(`${baseUrl.replace(/\/$/, "")}/api/v1/workflows`);
    url.searchParams.set("limit", "100");
    if (cursor) url.searchParams.set("cursor", cursor);

    const response = await fetch(url, {
      headers: {
        Accept: "application/json",
        "X-N8N-API-KEY": apiKey
      }
    });

    const json = (await response.json().catch(async () => ({ rawText: await response.text() }))) as N8nWorkflowListResponse;
    if (!response.ok) {
      throw new Error(`Failed to fetch n8n workflows: HTTP ${response.status} ${JSON.stringify(json)}`);
    }

    workflows.push(...(json.data ?? []));
    cursor = json.nextCursor;
  } while (cursor);

  return workflows;
}

function buildInventory(workflows: N8nWorkflow[], baseUrl: string): WorkflowInventoryItem[] {
  return workflows.map((workflow) => {
    const triggerNodes = (workflow.nodes ?? []).filter(isTriggerNode).map((node) => {
      const webhookPath = getWebhookPath(node.parameters);
      const httpMethod = getHttpMethod(node.parameters);
      return {
        name: node.name,
        type: node.type,
        disabled: Boolean(node.disabled),
        webhookPath,
        httpMethod
      };
    });

    const likelyWebhookUrls = (workflow.nodes ?? [])
      .filter((node) => isWebhookNode(node) && !node.disabled)
      .map((node) => getWebhookPath(node.parameters))
      .filter((path): path is string => Boolean(path))
      .flatMap((webhookPath) => {
        const normalizedPath = webhookPath.startsWith("/") ? webhookPath.slice(1) : webhookPath;
        return [
          `${baseUrl.replace(/\/$/, "")}/webhook-test/${normalizedPath}`,
          `${baseUrl.replace(/\/$/, "")}/webhook/${normalizedPath}`
        ];
      });

    return {
      id: workflow.id,
      name: workflow.name,
      active: Boolean(workflow.active),
      nodeCount: workflow.nodes?.length ?? 0,
      triggerNodes,
      likelyWebhookUrls,
      tags: workflow.tags?.map((tag) => tag.name).filter((name): name is string => Boolean(name)) ?? [],
      updatedAt: workflow.updatedAt
    };
  });
}

function buildMarkdown(inventory: WorkflowInventoryItem[]): string {
  const webhookWorkflows = inventory.filter((workflow) => workflow.likelyWebhookUrls.length > 0);
  const activeWorkflows = inventory.filter((workflow) => workflow.active);
  const triggerWorkflows = inventory.filter((workflow) => workflow.triggerNodes.length > 0);

  const rows = webhookWorkflows
    .map((workflow) => {
      const triggers = workflow.triggerNodes.map((node) => `${node.name} (${node.type.split(".").pop()})`).join("; ");
      const urls = workflow.likelyWebhookUrls.map((url) => `\`${url}\``).join("<br>");
      return `| ${workflow.name} | ${workflow.active ? "Yes" : "No"} | ${workflow.nodeCount} | ${triggers || "None"} | ${urls || "None"} |`;
    })
    .join("\n");

  return `# n8n Workflow Inventory

## Summary
- Total workflows: ${inventory.length}
- Active workflows: ${activeWorkflows.length}
- Workflows with trigger-like nodes: ${triggerWorkflows.length}
- Workflows with likely webhook URLs: ${webhookWorkflows.length}

## How to prioritize tests
Start with:
- Workflows called by the React launchpad.
- Workflows called by the Retool dashboard.
- Active webhooks that create, update, or fetch business-critical data.
- Workflows that have failed recently in n8n execution history.

Do not try to smoke-test all ${inventory.length} workflows first. Pick the top 5 to 10 critical workflows, then expand.

## Likely webhook workflows
| Workflow | Active | Nodes | Trigger nodes | Likely URLs |
|---|---:|---:|---|---|
${rows || "| None found | | | | |"}
`;
}

function buildSuggestedTestCases(inventory: WorkflowInventoryItem[]) {
  return inventory
    .filter((workflow) => workflow.likelyWebhookUrls.length > 0)
    .slice(0, 25)
    .map((workflow) => {
      const url = new URL(workflow.likelyWebhookUrls[0]);
      return {
        name: workflow.name.toLowerCase().replaceAll(/[^a-z0-9]+/g, "-").replaceAll(/(^-|-$)/g, ""),
        description: `Auto-generated placeholder for n8n workflow "${workflow.name}". Replace body and responseSchemaName with the real test contract.`,
        enabled: false,
        method: workflow.triggerNodes.find((node) => node.httpMethod)?.httpMethod?.toUpperCase() ?? "POST",
        webhookPath: `${url.pathname}`,
        headers: {
          "Content-Type": "application/json"
        },
        body: {
          testRunId: "{{RUN_ID}}",
          source: "qa-agent"
        },
        expectedStatus: 200,
        responseSchemaName: "workflowResult"
      };
    });
}

async function main(): Promise<void> {
  ensureArtifactDirs();
  const baseUrl = requireEnv("n8nBaseUrl");
  const workflows = await fetchWorkflows();
  const inventory = buildInventory(workflows, baseUrl);
  const suggested = buildSuggestedTestCases(inventory);

  const rawPath = writeJsonArtifact("logs/n8n-workflows-raw.json", workflows);
  const inventoryPath = writeJsonArtifact("logs/n8n-workflow-inventory.json", inventory);
  const suggestedPath = writeJsonArtifact("logs/n8n-suggested-test-cases.json", suggested);
  const reportPath = writeTextArtifact("reports/n8n-workflow-inventory.md", buildMarkdown(inventory));

  console.log(
    JSON.stringify(
      {
        totalWorkflows: workflows.length,
        workflowsWithLikelyWebhookUrls: inventory.filter((workflow) => workflow.likelyWebhookUrls.length > 0).length,
        rawPath,
        inventoryPath,
        suggestedPath,
        reportPath
      },
      null,
      2
    )
  );
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});
