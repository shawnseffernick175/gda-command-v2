import fs from "node:fs";
import path from "node:path";
import { artifactPath, ensureArtifactDirs, writeTextArtifact } from "./artifacts.js";
import { env } from "./env.js";

interface ArtifactBundle {
  generatedAt: string;
  files: Array<{
    path: string;
    content: string;
  }>;
}

function collectTextArtifacts(): ArtifactBundle {
  ensureArtifactDirs();
  const logsDir = artifactPath("logs");
  const files: ArtifactBundle["files"] = [];

  if (!fs.existsSync(logsDir)) {
    return { generatedAt: new Date().toISOString(), files };
  }

  for (const file of fs.readdirSync(logsDir)) {
    if (!file.endsWith(".json") && !file.endsWith(".txt") && !file.endsWith(".log")) continue;
    const fullPath = path.join(logsDir, file);
    const stat = fs.statSync(fullPath);
    if (!stat.isFile()) continue;
    const raw = fs.readFileSync(fullPath, "utf8");
    files.push({
      path: fullPath,
      content: raw.length > 20_000 ? `${raw.slice(0, 20_000)}\n\n[TRUNCATED]` : raw
    });
  }

  return { generatedAt: new Date().toISOString(), files };
}

function deterministicReport(bundle: ArtifactBundle): string {
  const failedSignals: string[] = [];
  const passedSignals: string[] = [];

  for (const file of bundle.files) {
    const lower = file.content.toLowerCase();
    if (lower.includes('"status": "failed"') || lower.includes('"status":"failed"') || lower.includes('"error"')) {
      failedSignals.push(file.path);
    } else if (lower.includes('"status": "passed"') || lower.includes('"status":"passed"')) {
      passedSignals.push(file.path);
    }
  }

  const status = failedSignals.length > 0 ? "Fail" : "Needs review";

  return `# QA Agent Report

## Overall status
${status}

## Summary
The deterministic reporter reviewed ${bundle.files.length} artifact file(s). ${failedSignals.length} file(s) contain failure or error signals, and ${passedSignals.length} file(s) contain passing signals.

## Failed or suspicious artifacts
${failedSignals.length ? failedSignals.map((file) => `- ${file}`).join("\n") : "- No explicit failure artifacts found."}

## Passing artifacts
${passedSignals.length ? passedSignals.map((file) => `- ${file}`).join("\n") : "- No explicit passing artifacts found."}

## Recommended next steps
- Open the failed or suspicious artifact files first.
- Review browser diagnostics for console errors and failed network requests.
- Review n8n response artifacts for HTTP status mismatches or schema validation failures.
- Configure AI_PROVIDER and AI_API_KEY to enable root-cause analysis in natural language.

## AI reviewer status
AI review was not enabled. Set AI_PROVIDER=openai or AI_PROVIDER=anthropic and provide AI_API_KEY to generate a richer diagnosis.
`;
}

async function callOpenAi(prompt: string): Promise<string> {
  const model = env.aiModel || "gpt-4.1-mini";
  const response = await fetch("https://api.openai.com/v1/responses", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${env.aiApiKey}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      model,
      input: prompt
    })
  });

  const json = await response.json();
  if (!response.ok) {
    throw new Error(`OpenAI reviewer failed: ${JSON.stringify(json)}`);
  }

  return json.output_text ?? JSON.stringify(json, null, 2);
}

async function callAnthropic(prompt: string): Promise<string> {
  const model = env.aiModel || "claude-3-5-sonnet-latest";
  const response = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "x-api-key": env.aiApiKey,
      "anthropic-version": "2023-06-01",
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      model,
      max_tokens: 4000,
      messages: [
        {
          role: "user",
          content: prompt
        }
      ]
    })
  });

  const json = await response.json();
  if (!response.ok) {
    throw new Error(`Anthropic reviewer failed: ${JSON.stringify(json)}`);
  }

  return json.content?.map((item: { type: string; text?: string }) => (item.type === "text" ? item.text : "")).join("\n") ?? JSON.stringify(json, null, 2);
}

function buildPrompt(bundle: ArtifactBundle): string {
  return `You are a senior QA automation agent reviewing a tool with three layers:
- n8n backend workflows
- React frontend
- Retool frontend

Your job is to review test artifacts and produce a concise, practical QA report. Do not claim a test passed unless the artifacts show it. Focus on root causes and next actions.

Return markdown with these sections:
# QA Agent Report
## Overall status
Pass, Fail, or Needs review.
## What was tested
List n8n, React, Retool, and Retool deploy checks that appear in the artifacts.
## Failures
For each failure, include test name, evidence, likely root cause, and recommended fix.
## Risks
Mention flakiness, missing coverage, unsafe production dependencies, auth issues, data issues, or schema drift.
## Next actions
Prioritized checklist.

Artifacts:
${bundle.files
  .map(
    (file) => `\n--- FILE: ${file.path} ---\n${file.content}`
  )
  .join("\n")}
`;
}

export async function generateAiReview(): Promise<string> {
  const bundle = collectTextArtifacts();
  const bundlePath = path.relative(process.cwd(), artifactPath("logs", "ai-review-input.json"));
  fs.writeFileSync(artifactPath("logs", "ai-review-input.json"), `${JSON.stringify(bundle, null, 2)}\n`);

  if (!env.aiApiKey || env.aiProvider === "none") {
    return deterministicReport(bundle);
  }

  const prompt = buildPrompt(bundle);

  try {
    if (env.aiProvider === "openai") return await callOpenAi(prompt);
    if (env.aiProvider === "anthropic") return await callAnthropic(prompt);
    return `${deterministicReport(bundle)}\n\nUnknown AI_PROVIDER "${env.aiProvider}". Review input saved to ${bundlePath}.\n`;
  } catch (error) {
    return `${deterministicReport(bundle)}\n\nAI reviewer call failed: ${error instanceof Error ? error.message : String(error)}\n`;
  }
}

generateAiReview()
  .then((report) => {
    const reportPath = writeTextArtifact("reports/qa-report.md", report);
    console.log(`QA report written to ${reportPath}`);
    console.log(report);
  })
  .catch((error) => {
    console.error(error);
    process.exit(1);
  });
