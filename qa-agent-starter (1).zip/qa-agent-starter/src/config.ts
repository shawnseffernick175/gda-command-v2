import fs from "node:fs";
import path from "node:path";
import { z } from "zod";

const stepSchema = z.object({
  action: z.enum([
    "fill",
    "click",
    "expectText",
    "expectVisible",
    "expectTitle",
    "expectValue",
    "expectDisabled",
    "wait",
    "goto",
    "press",
    "selectOption"
  ]),
  selector: z.string().optional(),
  value: z.string().optional(),
  timeoutMs: z.number().int().positive().optional()
});

const uiCaseSchema = z.object({
  name: z.string(),
  description: z.string().optional(),
  enabled: z.boolean().default(true),
  url: z.string(),
  requiresLogin: z.boolean().optional(),
  steps: z.array(stepSchema)
});

const n8nCaseSchema = z.object({
  name: z.string(),
  description: z.string().optional(),
  enabled: z.boolean().default(true),
  method: z.enum(["GET", "POST", "PUT", "PATCH", "DELETE"]).default("POST"),
  webhookPath: z.string(),
  headers: z.record(z.string()).optional(),
  body: z.unknown().optional(),
  expectedStatus: z.number().int().positive().default(200),
  responseSchemaName: z.string().optional()
});

const testCasesSchema = z.object({
  n8n: z.array(n8nCaseSchema).default([]),
  react: z.array(uiCaseSchema).default([]),
  retool: z.array(uiCaseSchema).default([])
});

export type UiStep = z.infer<typeof stepSchema>;
export type UiCase = z.infer<typeof uiCaseSchema>;
export type N8nCase = z.infer<typeof n8nCaseSchema>;
export type TestCases = z.infer<typeof testCasesSchema>;

export function readJsonFile<T>(relativePath: string): T {
  const fullPath = path.resolve(process.cwd(), relativePath);
  return JSON.parse(fs.readFileSync(fullPath, "utf8")) as T;
}

export function loadTestCases(): TestCases {
  return testCasesSchema.parse(readJsonFile("config/test-cases.json"));
}

export function loadContracts(): Record<string, unknown> {
  return readJsonFile<Record<string, unknown>>("config/expected-contracts.json");
}
