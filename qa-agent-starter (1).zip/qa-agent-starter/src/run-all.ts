import { spawn } from "node:child_process";

async function runCommand(name: string, command: string, args: string[]): Promise<number> {
  return new Promise((resolve) => {
    console.log(`\n=== ${name} ===`);
    const child = spawn(command, args, {
      stdio: "inherit",
      shell: process.platform === "win32"
    });

    child.on("close", (code) => resolve(code ?? 1));
  });
}

async function main(): Promise<void> {
  const steps: Array<[string, string, string[]]> = [
    ["n8n checks", "npm", ["run", "test:n8n"]],
    ["UI checks", "npm", ["run", "test:ui"]],
    ["AI report", "npm", ["run", "report"]]
  ];

  let exitCode = 0;

  for (const [name, command, args] of steps) {
    const code = await runCommand(name, command, args);
    if (code !== 0 && name !== "AI report") {
      exitCode = code;
    }
  }

  process.exit(exitCode);
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});
