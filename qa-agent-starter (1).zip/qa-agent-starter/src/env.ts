import dotenv from "dotenv";

dotenv.config();

export const env = {
  reactAppUrl: process.env.REACT_APP_URL ?? "",
  retoolAppUrl: process.env.RETOOL_APP_URL ?? "",
  n8nBaseUrl: process.env.N8N_BASE_URL ?? "",
  n8nApiKey: process.env.N8N_API_KEY ?? "",
  retoolBaseUrl: process.env.RETOOL_BASE_URL ?? "",
  retoolTestDeployApiKey: process.env.RETOOL_TEST_DEPLOY_API_KEY ?? "",
  commitSha: process.env.COMMIT_SHA ?? "",
  retoolTestEmail: process.env.RETOOL_TEST_EMAIL ?? "",
  retoolTestPassword: process.env.RETOOL_TEST_PASSWORD ?? "",
  retoolTestTotpSecret: process.env.RETOOL_TEST_TOTP_SECRET ?? "",
  aiProvider: process.env.AI_PROVIDER ?? "none",
  aiApiKey: process.env.AI_API_KEY ?? "",
  aiModel: process.env.AI_MODEL ?? "",
  headless: (process.env.HEADLESS ?? "true").toLowerCase() !== "false",
  artifactDir: process.env.ARTIFACT_DIR ?? "artifacts"
};

export function requireEnv(name: keyof typeof env, help?: string): string {
  const value = env[name];
  if (typeof value !== "string" || !value.trim()) {
    throw new Error(`Missing required environment variable for ${name}.${help ? ` ${help}` : ""}`);
  }
  return value;
}

export function replaceTokens<T>(input: T, runId: string): T {
  const serialized = JSON.stringify(input)
    .replaceAll("{{RUN_ID}}", runId)
    .replaceAll("{{REACT_APP_URL}}", env.reactAppUrl)
    .replaceAll("{{RETOOL_APP_URL}}", env.retoolAppUrl)
    .replaceAll("{{N8N_BASE_URL}}", env.n8nBaseUrl);
  return JSON.parse(serialized) as T;
}
