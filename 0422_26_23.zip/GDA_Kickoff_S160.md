# GDA Command Platform — S-160 Kickoff
**Prepared:** S-159 close | April 22, 2026
**Next operator:** Shawn Seffernick, EIS/GDA OU3

---

## Pre-Flight (Every Chat)
1. `tool_search("n8n")` — load MCP
2. Read this file
3. **No frozen items** — RR-38 and RR-28 are CLOSED

---

## FIRST ACTION NEXT CHAT

All High/Med debt resolved. Low items remain. Ask Shawn what S-160 queue looks like. If no new items, top candidates are:

1. **Hardening Plan — Item 1** (HIGH): Add headerAuth to SSH read endpoint `IcD4K740vpWSIuaZ` — highest risk item open
2. **RR-43** (Low): Bot dual-routing double-fire — only if touching telegram-chat
3. **Cleanup**: Delete oneshot workflow `eggRyGUueMkIJxgf` (migration done, inactive)

---

## Platform State

| Item | Status |
|---|---|
| Active workflows | ~151 |
| Frontend (gda.csr-llc.tech) | LIVE |
| GDA.api.intel-feed (KIT8cj4V2cMFdSkA) | ACTIVE — 10 nodes, cron 0 */4 * * *, RR-38+RR-28 CLOSED |
| gda_intelligence_log | CLEAN — columns: id, timestamp, source, agency, finding, category, priority |
| GDA.api.capture-plan (QgperN6cuOpfnb09) | ACTIVE — 23 nodes, RR-42 CLOSED |
| GDA.util.oneshot-schema-fix-rr38 (eggRyGUueMkIJxgf) | INACTIVE — safe to delete |
| All other workflows | As per S-158 state |

---

## Open Debt

| ID | Sev | Summary |
|---|---|---|
| RR-36 | Med | Chrome MCP cross-origin — workaround in place |
| RR-43 | Low | Bot dual-routing double-fire — fix when telegram-chat next touched |
| RR-44 | Low | n8n_test_workflow 403 on headerAuth — workaround documented |

---

## Key Workflow IDs

| Workflow | ID |
|---|---|
| GDA.api.intel-feed | KIT8cj4V2cMFdSkA |
| GDA.dev.deploy | 8GnGxnBL9TJjj1i2 |
| GDA.bot.telegram-chat | 1ItrrFxGI3L43Pdv |
| GDA.intel.morning-briefing-v1 | YIvCdrOgF1LGmFNL |
| GDA.api.capture-plan | QgperN6cuOpfnb09 |
| GDA.api.dashboard-mega | UYGJPu7N5YZblvEU |
| GDA.util.oneshot-schema-fix-rr38 | eggRyGUueMkIJxgf |
| SSH read workflow | IcD4K740vpWSIuaZ |
| Error handler | 2Swf6LP9AzFjHFYU |

---

## Infrastructure

| Resource | Detail |
|---|---|
| Frontend source | /opt/gda-command/src/App.jsx |
| Deploy webhook | POST https://n8n.csr-llc.tech/webhook/gda-deploy |
| Deploy auth | Header: x-gda-auth: gda-deploy-2026-secure |
| SSH webhook (read) | POST https://n8n.csr-llc.tech/webhook/gda-read |
| API auth | Header: x-gda-key: gda-api-2026-secure |
| Postgres cred | HwronxMmGY5XDGEt |
| VPS | 187.77.206.105 |
| n8n | https://n8n.csr-llc.tech (v2.37.1) |
| MCP | https://mcp.csr-llc.tech/mcp |

---

## Critical Rules

- Claude executes everything via MCP. Never tell Shawn to manually do things.
- Show broken vs fixed BEFORE deploying (R-SR-04).
- All Postgres nodes at typeVersion 2.5/2.6: use inline `{{ $json.field }}` expressions — never queryValues arrays or queryReplacement strings.
- Switch node is broken — use IF nodes or Code nodes for routing.
- LangChain cred d92MU0tRK7bEGV83 is BROKEN — all Anthropic calls via direct HTTP with $env.ANTHROPIC_API_KEY.
- Webhook test pattern (RR-44): temp set auth to none → fire → restore headerAuth.
- SSH deploy pattern: `PATH=/root/.nvm/versions/node/v20.20.0/bin:$PATH vite build → cp -r dist/. /root/gda-frontend/dist/`

---

## Schema (Canonical)

- `gda_intelligence_log` time column: **timestamp only** — created_at column DROPPED S-159
- Allocation revenue: `gda_capture_plans.plan_data->>'allocated_revenue'` (JSONB, dollars)
- `opp-tracker 2` and `ooda-loop 2` are LIVE CANONICAL — do not delete
- `gda_mega_cache` — id=1 singleton, 60min TTL
- capture-plan Postgres nodes use `queryValues` arrays — queryReplacement fully removed S-158 Chat 2

---

*— GDA S-160 Kickoff | Prepared at S-159 close | April 22, 2026 —*
