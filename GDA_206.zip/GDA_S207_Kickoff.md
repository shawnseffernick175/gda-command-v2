# GDA Command Platform — S-207 Kickoff

**Baseline:** v206  
**Target:** v207  
**Date:** Next session after 2026-05-05  

---

## Session Open Protocol

1. `tool_search("n8n")` — load MCP
2. Check VPS memory: `free -m` and `docker ps | grep n8n`  
   - If MCP zombie processes reappear: `pkill -f n8n-mcp && swapoff -a && swapon -a && docker restart n8n-envision-mcp-1`
3. Pull this kickoff doc and confirm carry-forward queue

---

## S-206 Canonical Close State

- **Frontend:** gda.csr-llc.tech LIVE — DEPLOY_COMPLETE_1777997604
- **GDA.dev.deploy (8GnGxnBL9TJjj1i2):** ACTIVE, versionCounter 942, headerAuth restored, continueOnFail on Notify TG Deploy
- **GDA.util.gist-update (t2209zk3c9x0OS9S):** ACTIVE, PATCH Gist wired to genericCredentialType/httpHeaderAuth/sKJFLNzetK86JnvO — VERIFIED LIVE
- **QACenterPage.jsx:** export default appended and deployed, build clean
- **gda_feedback:** 8 rows | **gda_learned_weights:** 12 rows calibrated
- **All 2027 keys active:** gda-deploy-2027-AWqjhbxDYNcyV1mr, gda-api-2027-AWqjhbxDYNcyV1mr

---

## S-207 Priority Queue

### P1 — Fix gda-tg-notify (S-206-02) [MED]
**Debt:** `gda-tg-notify` webhook returns 500 "No authentication data defined on node!" — bypassed via continueOnFail but TG deploy notifications are not reaching Telegram.

**Required:**
- Identify which workflow hosts the gda-tg-notify webhook
- Check its authentication configuration — likely requires a credential that the caller is not providing
- Fix so Telegram deploy notifications fire correctly end-to-end
- Verify a Telegram message reaches chat_id 8631035943 on next deploy

### P2 — Duplicate Keys App.jsx (S-206-01) [LOW]
**Debt:** Two duplicate keys in agency map (National Aeronautics and Space Administration, General Services Administration) — esbuild warnings on every build.

**Required:**
- Remove duplicate entries via patch_script deploy
- Confirm clean build with zero esbuild warnings
- No functional change — cosmetic cleanup only

### P3 — HP-7 nginx Rate Limiting
**Debt:** VPS has no nginx rate limiting in place.

**Required:**
- SSH to VPS, configure nginx rate limiting for API endpoints
- Test that legitimate traffic is not throttled
- Verify config survives nginx reload

### P4 — Zombie Process Prevention
**Debt:** MCP container spawns unbounded n8n-mcp node processes that accumulate across sessions and eventually OOM the server.

**Required:**
- Inspect MCP container entrypoint/config for process cleanup
- Add max process limit or process recycling to prevent recurrence
- Consider cron job or docker healthcheck to detect zombie accumulation

---

## Hard Rules Reminder

- Switch nodes broken platform-wide — use IF or Code
- Postgres typeVersion 2.5/2.6: inline `{{ $json.field }}` only, no queryValues/queryReplacement
- LangChain cred d92MU0tRK7bEGV83 dead — use HTTP Request + $env.ANTHROPIC_API_KEY
- Do NOT touch: MJapg8dGkvEzLn0K, 1G4gw4N7DFtVZKF7, NQmaj5nu4TBQxBgD
- Do NOT run docker compose up -d n8n from within n8n
- N8N_ENCRYPTION_KEY must persist in /root/n8n-envision/.env
- App.jsx writes: UTF-8 only; backup at /opt/gda-command/src/App.jsx.bak-s158-kpi
- Webhook auth test pattern (RR-44): patch to none → fire → restore headerAuth

---

## Key IDs Quick Reference

| Item | ID |
|------|----|
| GDA.dev.deploy | 8GnGxnBL9TJjj1i2 |
| GDA.util.gist-update | t2209zk3c9x0OS9S |
| GDA.util.ssh-read-file | IcD4K740vpWSIuaZ |
| GDA.api.launchpad | GrbSQxeJs7ag6zXx |
| GDA.api.pipeline | f4PLgyzEu0tj3R5Y |
| GDA.cron.learning-engine | fZpqchmmPnqAmiMq |
| GDA Webhook Auth cred | 1pNPY36DDz49OtKL |
| GitHub Gist PAT cred | sKJFLNzetK86JnvO |
| Gist ID | dd562918f676affd62153a5f06e7d7d9 |
| Telegram bot | @gda_command_bot |
| Shawn chat_id | 8631035943 |
| Deploy key | gda-deploy-2027-AWqjhbxDYNcyV1mr |
| API key | gda-api-2027-AWqjhbxDYNcyV1mr |
