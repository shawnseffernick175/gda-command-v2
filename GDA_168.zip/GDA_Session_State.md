# GDA Command Platform — Session State
**Last Updated:** S-168 — April 29, 2026
**Operator:** Shawn Seffernick, President, Envision Innovative Solutions (OU3)

---

## Pre-Flight (Every Chat)
1. `tool_search("n8n")` — load MCP
2. Read this file
3. Read ALL uploaded documents before taking any action
4. RR-38 and RR-28 are RESOLVED — do not reference as frozen

---

## FIRST ACTION NEXT CHAT (S-169)

Proceed to S-169-01 (API Gateway v1 VPS deploy). No credential confirmation needed — WEBHOOK_HEADER_VALUE is `gda-api-2026-f584dae2` (hardcoded in agent-runner).

**S-169 Priority Queue:**
1. S-169-01 (Med) — Deploy API Gateway v1: gda-api-gateway-v1.zip → /opt/gda-api-gateway-v1/, port 8787, nginx /api/qa/* /api/workflows/* /api/failures/*
2. S-169-02 (Med) — Strip auth_key from 5 React pages: IdiqOnRampPage, IncumbentAnalysisPage, BlackHatPage, WargamePage, TeamingFinderPage. Build + deploy.
3. S-169-03 (Med) — Activate fix-runner (aAVitXXjGWaP7bb2), keep dry-run, health check.
4. S-169-04 (Low) — Audit 6 Rescue Map workflows: weekly-comp-scan, morning-briefing-v1, nightly-fy-revenue-calc, data-retention, e2e-gemini-report, dept-opp-sweep.

---

## Platform State

| Item | Status |
|---|---|
| Active workflows | 156 |
| Frontend (gda.csr-llc.tech) | LIVE |
| GDA.qa.agent-runner (TxcPdvx2Ld9rE9er) | FIXED — native fetch(), health {ok:true} confirmed 199ms |
| Auth Guard nodes (8 workflows) | REMOVED — S-168-02 complete |
| API Gateway v1 | NOT YET ON VPS |
| GDA.qa.fix-runner | EXISTS (aAVitXXjGWaP7bb2) — INACTIVE |
| GDA.controlled-fix-agent | ACTIVE (akvlbmdUBCgx58PC) |
| WEBHOOK_HEADER_VALUE | gda-api-2026-f584dae2 |

---

## Key Workflow IDs

| Workflow | ID |
|---|---|
| GDA.dev.deploy | 8GnGxnBL9TJjj1i2 |
| GDA.util.ssh-read-file | IcD4K740vpWSIuaZ |
| GDA.bot.telegram-chat | 1ItrrFxGI3L43Pdv |
| GDA.api.dashboard-mega | UYGJPu7N5YZblvEU |
| GDA.api.opp-tracker 2 | SEJLE89wZa1yfQyB |
| GDA.api.ooda-loop 2 | pkPpMhiz8IdRy7To |
| GDA.api.launchpad-funnel | vaRzM1Jl6HcXjuxs |
| GDA.api.platform-health | UBgoJGxZro834RbT |
| GDA.api.daily-actions | C7Bh7KcAl1IgSTRr |
| GDA.api.intel-feed | KIT8cj4V2cMFdSkA |
| GDA.api.data-learn | Fn02pKArk2YcyQp5 |
| GDA.api.ndaa-far-ingest | afjmc6tOjffkEC3k |
| GDA.api.morning-briefing | 0zVPgmYsvcqhyyo6 |
| GDA.sched.golden-dome-monitor | bFF0oopmkhP6cnau |
| GDA.sched.dept-market-refresh | AqWz367raGvlgIhp |
| GDA.qa.agent-runner | TxcPdvx2Ld9rE9er |
| GDA.qa.fix-runner | aAVitXXjGWaP7bb2 |
| GDA.controlled-fix-agent | akvlbmdUBCgx58PC |
| GDA.error.handler | 2Swf6LP9AzFjHFYU |
| GDA.intel.morning-briefing-v1 | YIvCdrOgF1LGmFNL |

---

## Credential Reference

| Credential | ID | Notes |
|---|---|---|
| GDA Webhook Auth | fTrhOzBkjS1s67bm | Key in agent-runner: gda-api-2026-f584dae2 |
| VPS Root SSH | VqYFb1aRGJa8UfBc | Used by ssh-read-file workflow |
| Anthropic API | $env.ANTHROPIC_API_KEY | Direct HTTP only — LangChain cred d92MU0tRK7bEGV83 is BROKEN |

---

## Infrastructure

| Resource | Detail |
|---|---|
| Frontend source | /opt/gda-command/src/App.jsx |
| Deploy webhook | POST https://n8n.csr-llc.tech/webhook/gda-deploy |
| Deploy auth | Header: x-gda-auth: gda-deploy-2026-secure |
| SSH webhook (read) | POST https://n8n.csr-llc.tech/webhook/gda-read |
| SSH auth | Header: x-gda-key: gda-api-2026-secure |
| Postgres cred | HwronxMmGY5XDGEt |
| VPS | 187.77.206.105 |
| n8n | https://n8n.csr-llc.tech (v2.37.1) |
| Frontend | https://gda.csr-llc.tech |
| MCP | https://mcp.csr-llc.tech/mcp |

---

## Rules

- Read ALL documents before acting — no exceptions
- Claude executes everything via MCP. Never tell Shawn to manually do things.
- Show broken vs fixed BEFORE deploying (R-SR-04)
- Spot-check 2 items before any batch operation (R-SR-13)
- End every session: 4 R-SR-09 artifacts
- RR-38 and RR-28 are RESOLVED
- Auth standard: n8n webhook credential-level auth only; no Code-node inline auth guards
- opp-tracker 2 and ooda-loop 2 are LIVE CANONICAL — do not delete
- Anthropic API: direct HTTP with $env.ANTHROPIC_API_KEY — LangChain cred d92MU0tRK7bEGV83 BROKEN
- Department of War (not DoD) correct top-level hierarchy name
- Platform is React-only going forward — Retool archived/reference only
- this.helpers.httpRequest UNAVAILABLE in Code nodes — always use native fetch()

---

## Schema (Canonical)

- `gda_intelligence_log` time column: timestamp (created_at also present)
- Allocation revenue: `gda_capture_plans.plan_data->>'allocated_revenue'` (JSONB, dollars)
- `gda_mega_cache` — id=1 singleton, 60min TTL
- Postgres `queryValues` arrays canonical — queryReplacement fully removed
- n8n Response Standard envelope: {success, workflow, action, dryRun, data, meta, error}
