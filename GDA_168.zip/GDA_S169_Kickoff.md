# GDA Command Platform — S-169 Kickoff
**Prepared:** S-168 close | April 29, 2026
**Operator:** Shawn Seffernick, President EIS/GDA OU3

---

## Pre-Flight (Every Chat)
1. `tool_search("n8n")` — load MCP
2. Read this file
3. Read ALL uploaded documents before taking any action
4. RR-38 and RR-28 are RESOLVED — never reference as frozen

---

## FIRST ACTION
Proceed directly to S-169-01 (was S-168-03). No credential confirmation needed — WEBHOOK_HEADER_VALUE is hardcoded in agent-runner as `gda-api-2026-f584dae2`.

---

## S-169 Priority Queue

1. **S-169-01 (Med)** — Deploy API Gateway v1 to VPS
   - Source: gda-api-gateway-v1.zip (user must upload if not present)
   - Target: /opt/gda-api-gateway-v1/ on VPS 187.77.206.105
   - Port: 8787
   - nginx: proxy /api/qa/* /api/workflows/* /api/failures/* → localhost:8787
   - Env: N8N_BASE_URL=https://n8n.csr-llc.tech, N8N_API_KEY=<jwt from agent-runner>, WEBHOOK_HEADER_VALUE=gda-api-2026-f584dae2
   - Use GDA.util.ssh-read-file (IcD4K740vpWSIuaZ) for all VPS ops

2. **S-169-02 (Med)** — Strip auth_key from 5 React pages
   - Files: IdiqOnRampPage.jsx, IncumbentAnalysisPage.jsx, BlackHatPage.jsx, WargamePage.jsx, TeamingFinderPage.jsx
   - Remove: auth_key: 'gda-api-2026-f584dae2' from POST request bodies
   - Build + deploy via GDA.dev.deploy (8GnGxnBL9TJjj1i2)

3. **S-169-03 (Med)** — Activate fix-runner
   - Workflow: aAVitXXjGWaP7bb2
   - Keep GDA_QA_FIX_MODE=dry-run
   - Run health check after activation

4. **S-169-04 (Low)** — Audit 6 remaining Rescue Map workflows
   - weekly-comp-scan (uQ5cZ97cCrx5iIXk) — verify SQL parameterization
   - morning-briefing-v1 (YIvCdrOgF1LGmFNL) — verify stale key fix
   - nightly-fy-revenue-calc (EGQzp92GxbjTJ03X) — verify cache fix
   - data-retention (LzjiBI80aDAZgDIp) — verify timestamp fix
   - e2e-gemini-report (BLS36QTOznJ8mJlC) — verify key removal
   - dept-opp-sweep (JRnWGEH9cesb8f3w) — verify auth fix

---

## Platform State (post S-168)

| Item | Status |
|---|---|
| Active workflows | 156 |
| Frontend (gda.csr-llc.tech) | LIVE |
| GDA.qa.agent-runner (TxcPdvx2Ld9rE9er) | FIXED — fetch-based, health {ok:true} confirmed |
| 8 Auth Guard nodes | REMOVED — dashboard-mega, platform-health, intel-feed, data-learn, ndaa-far-ingest, morning-briefing, golden-dome-monitor, dept-market-refresh |
| API Gateway v1 | NOT YET ON VPS |
| GDA.qa.fix-runner (aAVitXXjGWaP7bb2) | EXISTS — INACTIVE |
| WEBHOOK_HEADER_VALUE canonical | gda-api-2026-f584dae2 |

---

## Key Workflow IDs

| Workflow | ID |
|---|---|
| GDA.dev.deploy | 8GnGxnBL9TJjj1i2 |
| GDA.util.ssh-read-file | IcD4K740vpWSIuaZ |
| GDA.bot.telegram-chat | 1ItrrFxGI3L43Pdv |
| GDA.api.dashboard-mega | UYGJPu7N5YZblvEU |
| GDA.api.opp-tracker 2 | SEJLE89wZa1yfQyB |
| GDA.api.ooda-loop 2 | pkPpMhiz8IdRy7To |
| GDA.api.platform-health | UBgoJGxZro834RbT |
| GDA.qa.agent-runner | TxcPdvx2Ld9rE9er |
| GDA.qa.fix-runner | aAVitXXjGWaP7bb2 |
| GDA.controlled-fix-agent | akvlbmdUBCgx58PC |

---

## Rules

- Read ALL documents before acting — no exceptions
- Claude executes everything via MCP. Never tell Shawn to manually do things.
- Show broken vs fixed BEFORE deploying (R-SR-04)
- Spot-check 2 items before any batch operation (R-SR-13)
- End every session: 4 R-SR-09 artifacts
- RR-38 and RR-28 are RESOLVED
- Auth standard: n8n webhook credential-level auth only; no Code-node inline auth guards
- opp-tracker 2 and ooda-loop 2 are LIVE CANONICAL — do not delete
- Anthropic API: direct HTTP with $env.ANTHROPIC_API_KEY — LangChain cred d92MU0tRK7bEGV83 BROKEN
- Department of War (not DoD) correct top-level hierarchy name
- Platform is React-only going forward — Retool archived/reference only
- this.helpers.httpRequest is UNAVAILABLE in Code nodes — always use native fetch()

---

## Schema (Canonical)

- `gda_intelligence_log` time column: timestamp (created_at also present)
- Allocation revenue: `gda_capture_plans.plan_data->>'allocated_revenue'` (JSONB, dollars)
- `gda_mega_cache` — id=1 singleton, 60min TTL
- Postgres `queryValues` arrays canonical — queryReplacement fully removed
- n8n Response Standard envelope: {success, workflow, action, dryRun, data, meta, error}
- WEBHOOK_HEADER_VALUE: gda-api-2026-f584dae2 (hardcoded in agent-runner)

*— End of S-169 Kickoff —*
