# GDA Command Platform — Session State
**Last Updated:** S-159 Chat 14 — April 21, 2026
**Operator:** Shawn Seffernick, President, Envision Innovative Solutions (OU3)

---

## Pre-Flight (Every Chat)
1. `tool_search("n8n")` — load MCP
2. Read this file
3. **RR-38 and RR-28 are FROZEN** — do not touch ever

---

## FIRST ACTION NEXT CHAT

AN-2 is PARTIAL. 25 opps still Unknown. Next session: continue targeted GovTribe lookups for remaining opps:
- id=17 FORCE (RS3-26-0010, Army CECOM) — search prior RS3 FORCE task orders
- id=18 PM Special Programs SETA (RS3-25-0057) — search CECOM PM Special Programs incumbents
- id=19 C2SD Division Support (RS3-25-0047) — search C2SD Army
- id=20 Counter-UAS CETS (RS3-26-0016) — Counter-UAS CETS CECOM
- id=22 PdM M2S2 SETA (RS3-25-0035) — PdM M2S2 SETA Army
- id=14 C2 Digital Simulation Support (W911S726RA009) — specific sol number search
- id=37 MSCoE C2 Digital — MSCoE C2 digital support
- id=34 Tradewind (W519TC-23-S-CTSM) — Tradewind vehicle task order
- id=96 CSC III — search CECOM CSC III incumbent

After AN-2 resolved → proceed to next HIGH item (none remaining) → top MED: L-1 (KPI numbers mismatch).

---

## CRITICAL: Auth Header
**Correct header is `x-gda-key: gda-api-2026-secure`** — NOT x-gda-auth.

## CRITICAL: App.jsx encoding rule
**Always write App.jsx / component files with UTF-8 encoding.**

## CRITICAL: contract_value cast
**gda_capture_plans.contract_value is TEXT, 57+ rows use xM format (e.g. '1.5M').** Always use:
`CASE WHEN contract_value ILIKE '%M' THEN REPLACE(contract_value,'M','')::numeric * 1000000 ELSE NULLIF(contract_value,'')::numeric END`

## CRITICAL: Schema corrections
- gda_capture_plans column is `opportunity` (not opportunity_name) and `opp_title`
- `stage` is in `plan_data->>'stage'` (JSONB), not a top-level column

## Deploy pattern
`{"auth_key": "gda-deploy-2026-secure", "mode": "build_only", "msg": "description"}` → deploy webhook.
Deploy webhook RR-44 workaround: set both Webhook + Read Webhook auth to none → fire → restore headerAuth.
MCP test_workflow cannot pass deploy Auth Guard Code node — use SSH build path for frontend changes.

## SSH Read/Write Note
ssh-read-file (IcD4K740vpWSIuaZ) accepts `body.cmd` or `body.command`. RR-44 pattern: auth none → fire → restore.
Docker Postgres: `n8n-envision-postgres-1`. DB name: `n8n`. PG user: `n8n`.

---

## Platform State

| Item | Status |
|---|---|
| Active workflows | ~152 |
| Frontend (gda.csr-llc.tech) | LIVE — S-159C10 build deployed |
| Auth header | FIXED — x-gda-key in gda.jsx + E2E checker |
| Numbers consistency | FIXED — all APIs: 205 opps / $2.30B / 103 pursuing (O-1 CLOSED S-159C11) |
| AI Agent context | FIXED — live DB snapshot in every call (A-1 CLOSED S-159C11) |
| Incumbent + Win Themes | FIXED — known_incumbents + win_themes wired into chat-simple context (AN-1 CLOSED S-159C13) |
| Morning Brief | FIXED — Merge append + 72h fallback. Real briefings generating. (S-7 CLOSED S-159C12) |
| Intel Feed | FIXED — 28 results live (I-1 CLOSED S-159C9) |
| Deep Research | FIXED — queryReplacement removed (D-1 CLOSED S-159C9) |
| AI Agent history | BUILT — Array.isArray guards live (A-2 CLOSED S-159C10) |
| Top Opps table | FIXED — xM cast corrected (L-2 CLOSED S-159C10) |
| Intel Feed dropdowns | FIXED — sec_latest + sec_pred open by default (O-4 CLOSED S-159C10) |
| gda_incumbent_log | CREATED — S-159C14 |
| GDA.auto.incumbent-enrichment | BUILT — oYwPpPdNCixRKItz, INACTIVE, 9 nodes |
| All cron workflows | ACTIVE |

---

## Incumbent Data State (updated S-159C14)
- `plan_data->>'incumbent'`: 95 rows populated (active stages)
- Active opps with Unknown incumbents: **25 remaining** (was 28, 3 resolved this session)
- Confirmed this session: id=16 → Jeppesen Foreflight Inc. (AF flight scheduling)
- Cleared this session: id=38 (SEWP VI new solicitation), id=12 (HUD ODIS sources sought)
- Remaining unknown: RS3 TOs (id=17,18,19,20,22), OASIS+ (id=24,25,26,28), internal vehicle TOs, misc

---

## Key Workflow IDs

| Workflow | ID |
|---|---|
| GDA.dev.deploy | 8GnGxnBL9TJjj1i2 |
| GDA.bot.telegram-chat | 1ItrrFxGI3L43Pdv |
| GDA.api.daily-actions | C7Bh7KcAl1IgSTRr |
| GDA.api.action-history | 1OPkoA5e8DYVQKm1 |
| GDA.intel.morning-briefing-v1 | YIvCdrOgF1LGmFNL |
| GDA.api.morning-briefing (read) | 0zVPgmYsvcqhyyo6 |
| GDA.api.dashboard-mega | UYGJPu7N5YZblvEU |
| GDA.api.opp-tracker 2 | SEJLE89wZa1yfQyB |
| GDA.api.capture-plan | QgperN6cuOpfnb09 |
| GDA.api.intel-feed | KIT8cj4V2cMFdSkA |
| GDA.research.deep-research | q9YWVQCwnJGqmrO7 |
| GDA.api.platform-health | UBgoJGxZro834RbT |
| GDA.util.ssh-read-file | IcD4K740vpWSIuaZ |
| GDA.api.embed-and-store | yA4NHeu0ctVVxzYg |
| GDA.auto.e2e-gemini-report | BLS36QTOznJ8mJlC |
| GDA.cron.weekly-comp-scan | uQ5cZ97cCrx5iIXk |
| GDA.auto.gist-update | djgOV2vX3PIv9cvm |
| GDA.api.aop-tracker | P8AfP8P84xi33auD |
| GDA.api.win-loss-db | SpU3znFHHABYNmb9 |
| GDA.cron.recompete-early-warning | MtcQwAgm1zHYXNfB |
| GDA.cron.win-rate-weekly-digest | ZuQkz1HrMONclkFm |
| GDA.cron.idiq-task-order-alert | DeSN1t1swXX14xTc |
| GDA.cron.capture-opp-sync | 0E3lCtWt2rdJlMPY |
| GDA.api.bd-activity-log | 9qrsria0fy719T98 |
| GDA.api.teaming-scorer | jQvgX6SD1RhARG3F |
| GDA.cron.capture-milestone-alerts | Kk7O8Bw2FOe41M9l |
| GDA.auto.feedback-collector | aCrxoe1rCuIbsnC4 |
| GDA.cron.learning-engine | fZpqchmmPnqAmiMq |
| GDA.api.pwin-calculator | 81m1Zl9xjM6L8HQb |
| GDA.agent.opp-classifier | hWCP9NLXxtCOrppu |
| GDA.sched.opp-refresh | PeLGDqgLAsEh5Gsd |
| GDA.api.launchpad-funnel | vaRzM1Jl6HcXjuxs |
| GDA.api.chat-simple | b8ldzYA5LNM9Gz00 |
| GDA.api.agentic-chat | jalin8peBLddjsEa |
| GDA.auto.incumbent-enrichment | oYwPpPdNCixRKItz |

---

## Infrastructure

| Resource | Detail |
|---|---|
| Frontend source | /opt/gda-command/src/App.jsx |
| AIAgentPage source | /opt/gda-command/src/components/pages/AIAgentPage.jsx |
| Deploy webhook | POST https://n8n.csr-llc.tech/webhook/gda-deploy |
| Deploy auth | body.auth_key: gda-deploy-2026-secure |
| Deploy MCP pattern | Temp set both Webhook + Read Webhook auth to none → fire → restore headerAuth |
| Deploy SSH pattern | Use ssh-read-file to run build command directly (bypasses Code node auth check) |
| SSH webhook (read/write) | POST https://n8n.csr-llc.tech/webhook/gda-read (ssh-read-file) |
| SSH auth | Header: x-gda-key: gda-api-2026-secure |
| Postgres cred | HwronxMmGY5XDGEt |
| Docker Postgres container | n8n-envision-postgres-1 |
| Docker Postgres DB | n8n |
| Docker Postgres user | n8n |
| VPS | 187.77.206.105 |
| n8n | https://n8n.csr-llc.tech (v2.37.1) |
| Frontend | https://gda.csr-llc.tech |
| MCP | https://mcp.csr-llc.tech/mcp |

---

## Open Debt (Priority Order)

| ID | Sev | Summary |
|---|---|---|
| AN-2 | HIGH | PARTIAL — 25 opps still Unknown. Continue targeted GovTribe lookups next session. |
| L-1 | MED | KPI numbers mismatch capture plan |
| L-3 | MED | 63 overdue opps never auto-moved to Pass |
| L-4 | MED | Qualified bar chart text invisible |
| L-5 | MED | Capture Plan Stages right side empty |
| L-6 | MED | Deadline list no dollar value no analysis |
| L-7 | MED | GovTribe links 404 |
| L-8 | MED | SITREP not auto-generated |
| L-9 | MED | Predictive analysis empty |
| L-10 | MED | Action items <30d should auto-Pass |
| S-1 | MED | World News no sources one sentence filler |
| S-2 | MED | DoD News source links to Launchpad |
| S-3 | MED | Other Dept News all filler |
| S-4 | MED | Acquisition News recycled stats |
| S-5 | MED | Opportunities/Risks cards duplicate Launchpad |
| S-6 | MED | Merge Morning Brief + SITREP |
| I-2 | MED | Intel Feed history renders blank |
| D-2 | MED | Deep Research history empty |
| C-1 | MED | Comp Intel — opening one card expands whole row |
| C-2 | MED | Comp Intel — no so-what vs GDA |
| C-3 | MED | Comp Intel — no threat mapping per agency |
| C-4 | MED | Comp Intel — data static needs daily update |
| C-5 | MED | Comp Intel — missing INSCOM/TRADOC/PEO Soldier/PEO STRI/APG/Army Futures/Fort Liberty |
| C-6 | MED | Comp Intel — no AI threat narrative |
| N-1 | MED | Merge Wargame + Incumbent + Teaming → Bid Strategy |
| O-2 | MED | Opp Tracker sub-rows missing columns |
| O-7 | MED | NDAA Intel placeholder needs real ingestion |
| P-1 | MED | Smoke test never run |
| O-3 | LOW | Remove Unassigned category |
| O-5 | LOW | Department of War wrong name |
| O-6 | LOW | IDIQ vehicles duplicated |
| RR-43 | LOW | Bot dual-routing |
| RR-44 | LOW | headerAuth 403 workaround documented |
| RR-36 | MED | Chrome MCP cross-origin — workaround in place |
| RR-38 | FROZEN | Do not touch |
| RR-28 | FROZEN | Do not touch |

---

## Rules
- Claude executes everything via MCP. Never tell Shawn to manually do things.
- RR-38 and RR-28 are FROZEN. Do not touch.
- Correct auth: `x-gda-key: gda-api-2026-secure`
- Anthropic API: direct HTTP with $env.ANTHROPIC_API_KEY — LangChain d92MU0tRK7bEGV83 BROKEN
- Postgres inline template rule (typeVersion 2.5/2.6): `{{ $json.field }}` inline — never queryValues/queryReplacement
- Switch node broken — use IF or Code
- No filler content anywhere in this platform
- Bot rollback: n8n_workflow_versions(mode=rollback, workflowId=1ItrrFxGI3L43Pdv) to v4
- contract_value: always safe-cast with CASE WHEN ILIKE '%M' pattern
- Active opp filter: `stage NOT IN ('No-Bid','Cancelled','No-Go','Lost','Won')` via `plan_data->>'stage'` — 205 opps, $2.30B
- gda_capture_plans columns: `opportunity`, `opp_title` (not opportunity_name)

## Schema (Canonical)
- gda_morning_briefings.briefing = plain markdown TEXT
- deadline-escalation writes to `risk_register`
- embed-and-store outbound: header `x-gda-auth: gda-deploy-2026-secure`
- capture-plan Postgres nodes use `queryValues` arrays
- gda_intelligence_log time column: timestamp (created_at also present)
- Allocation revenue: gda_capture_plans.plan_data->>'allocated_revenue' (JSONB, dollars, clean numeric)
- contract_value: TEXT column, 57+ rows use xM format — always safe-cast
- gda_mega_cache — id=1 singleton, 60min TTL
- gda_feedback event_types: win, loss, pwin_outcome, opp_label_correction, action_completed, actions_generated, opp_classified, briefing_sent
- gda_learned_weights keys: pwin.* (6), briefing.* (3), actions.* (3) — 12 total
- Docker Postgres user: n8n (not postgres, not envision, not root)
- gda_incumbent_log: opp_id, opportunity_name, incumbent_found, incumbent_name, source, award_date, contracting_agency, note, created_at
