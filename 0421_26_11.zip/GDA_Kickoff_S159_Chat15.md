# GDA Command Platform — S-159 Chat 15 Kickoff

**Last session:** S-159 Chat 14, April 21, 2026
**Status:** AN-2 PARTIAL — 25 opps still Unknown.

---

## Pre-Flight
1. `tool_search("n8n")` — load MCP
2. Read this file
3. RR-38 and RR-28 FROZEN

---

## FIRST ACTION NEXT SESSION

### AN-2 (PARTIAL) — Continue incumbent lookups for remaining 25 Unknown opps

Run targeted GovTribe searches for these specific opps in priority order:

| DB ID | Opp Title | Agency | Sol # | Search Strategy |
|---|---|---|---|---|
| 17 | FORCE | Army CECOM | RS3-26-0010 | Search "FORCE program Army CECOM" awards |
| 18 | PM Special Programs SETA | Army CECOM | RS3-25-0057 | Search "PM Special Programs SETA CECOM" |
| 19 | C2SD Division Support | Army CECOM | RS3-25-0047 | Search "C2SD division support CECOM" |
| 20 | Counter-UAS CETS | Army CECOM | RS3-26-0016 | Search "Counter-UAS CETS training" |
| 22 | PdM M2S2 SETA | Army PdM M2S2 | RS3-25-0035 | Search "PdM M2S2 SETA" |
| 14 | C2 Digital and Simulation Support | Army | W911S726RA009 | Sol# keyword search in awards |
| 37 | MSCoE C2 Digital | Army MSCoE | — | Search "MSCoE C2 digital support" |
| 34 | Tradewind | Army Tradewind | W519TC-23-S-CTSM | Tradewind vehicle task order search |
| 96 | CSC III | (unknown) | — | Search "CSC III" Army CECOM |
| 2 | AF MSTK | AFLCMC | MAS-AFLCMC-MSTK-2026 | Search "modeling simulation training toolkit AFLCMC" |
| 3 | Systems Engineering Support Navy | Navy | N0017827SN3101 | Search sol# in IDVs/awards |
| 6 | Cybersecurity IA Risk Reduction | DODEA | MAS-DODEA-CGIA-2026 | Search "cybersecurity DODEA" |
| 7 | Agile System Coordinator AFLCMC | AFLCMC | MAS-AFLCMC-ASC-2026 | Search "agile system coordinator AFLCMC" |
| 8 | SISO Risk Management Navy | NAVSUP | MAS-NAVSUP-SISO-2026 | Search "SISO risk management NAVSUP" |

After confirmed results → write directly to Postgres via SSH (same pattern as this session).
After AN-2 fully resolved (or all exhausted) → L-1 (KPI numbers mismatch, MED).

---

## Context from This Session
- Active Unknown incumbents: 28 at session start → **25 remaining** (3 resolved)
- id=16 → Jeppesen Foreflight Inc. (Automated Flight Scheduling AF) — WRITTEN
- id=38 → New Requirement - No Prior Incumbent (NASA SEWP VI still in solicitation) — WRITTEN
- id=12 → New Requirement - No Prior Incumbent (HUD ODIS Sources Sought Mar 2026) — WRITTEN
- GDA.auto.incumbent-enrichment built (oYwPpPdNCixRKItz, INACTIVE) — workflow column names patched
- gda_incumbent_log table created in Postgres
- CRITICAL schema correction: gda_capture_plans columns are `opportunity` + `opp_title` (NOT opportunity_name); `plan_data->>'stage'` for stage filter
- GovTribe MCP SSE protocol issue: n8n HTTP Request node can't consume SSE stream cleanly — automated nightly enrichment workflow needs redesign (Code node or REST adapter)
- Active opp count (Unknown incumbents): query via `plan_data->>'stage' NOT IN (...)` — 28 active rows found

## Key Notes
- Correct auth header: `x-gda-key: gda-api-2026-secure`
- Postgres inline template rule (typeVersion 2.5/2.6): `{{ $json.field }}` inline — never queryValues/queryReplacement
- Switch node broken — use IF or Code
- LangChain cred d92MU0tRK7bEGV83 BROKEN — use direct HTTP + $env.ANTHROPIC_API_KEY
- contract_value: TEXT, 57 rows use xM format — always CASE WHEN ILIKE '%M' cast
- Docker Postgres DB: `n8n`, user: `n8n`, container: `n8n-envision-postgres-1`
- RR-44 pattern: set Webhook auth to none → fire → restore headerAuth
- GovTribe MCP connected — use for targeted per-opp incumbent lookups
