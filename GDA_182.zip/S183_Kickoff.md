# S-183 SESSION KICKOFF
**GDA Command Platform | EIS / GDA OU3 | Shawn Seffernick**
**Generated: 2026-05-01 (S-182 Close)**

---

## MANDATORY FIRST ACTION
```
tool_search("n8n")   ← load MCP before ANY other action
```

---

## CARRY-FORWARD STATUS
- R-SR-09 artifacts from S-182: COMPLETE (Session Delta DOCX, DevOps Report DOCX, Master Build XLSX v4.182, this Kickoff MD)
- SSH-CLEANUP COMPLETE: Orphan creds fiCbDZ3ahacK6FCA and VqYFb1aRGJa8UfBc deleted. 16 → 14 credentials. Zero workflow impact confirmed.
- GIST-UPDATE COMPLETE: PoOofuf0OgaYJCBN verified OPERATIONAL with 2027 key. Gist updated 2026-05-01T21:56:57Z.

---

## S-183 PRIORITY QUEUE (Execute in Order)

| Rank | ID | Priority | Description |
|------|----|----------|-------------|
| 1 | **NEXT-FEATURE** | ⬜ LOW | Pull next feature/fix from platform backlog — confirm with Shawn |

---

## PLATFORM SNAPSHOT (entering S-183)

| Component | Status |
|-----------|--------|
| n8n | OPERATIONAL (2.49.0) |
| Frontend (gda.csr-llc.tech) | OPERATIONAL |
| Postgres | OPERATIONAL |
| Traefik | OPERATIONAL — rate limiting active |
| Gist-update (PoOofuf0OgaYJCBN) | OPERATIONAL — verified S-182 |
| capture-plan AI agent | UPGRADED — EIS win themes + incumbent intel live (v404) |
| MCP Server | ✅ OPERATIONAL — 2027 key active |
| SSH auth | ✅ Key-based (ed25519, NKOxLo5F81sRNPua) |
| Credential inventory | 14 active (orphans cleared S-182) |

---

## CANONICAL KEYS (post S-178/S-181 rotation)

```
x-gda-key:     gda-api-2027-AWqjhbxDYNcyV1mr
deploy-key:    gda-deploy-2027-a4zslQ79hn9A9UIi
GDA Webhook Auth cred ID: 1pNPY36DDz49OtKL
GitHub Gist PAT cred ID:  sKJFLNzetK86JnvO
VPS SSH Key cred ID:      NKOxLo5F81sRNPua   ← CANONICAL (ed25519)
Postgres cred ID:         HwronxMmGY5XDGEt
```

---

## STANDING HARD RULES (never break)
- **Switch node** → broken platform-wide → use IF or Code nodes
- **LangChain cred `d92MU0tRK7bEGV83`** → permanently broken → use HTTP + `$env.ANTHROPIC_API_KEY`
- **Postgres typeVersion 2.5/2.6** → inline `{{ $json.field }}` in SQL only
- **App.jsx / GDALaunchpad.jsx source** → lives as base64 in gist → edit gist, redeploy
- **n8n container restart** → never `docker compose up -d n8n` from within n8n
- **N8N_ENCRYPTION_KEY** → must persist in `/root/n8n-envision/.env`
- **MCP test trigger** → does NOT pass x-gda-key → use temporary auth bypass pattern
- **RR-38, RR-28** → FROZEN
- **nginx.conf** → mounted volume, cannot docker cp — edit on host, restart container

---

## KEY IDs (quick reference)
```
Dashboard-Mega:    UYGJPu7N5YZblvEU
SSH Exec:          IcD4K740vpWSIuaZ
Deploy:            8GnGxnBL9TJjj1i2
Gist-update:       PoOofuf0OgaYJCBN  ← verified S-182
Morning Briefing:  YIvCdrOgF1LGmFNL
Briefing API:      0zVPgmYsvcqhyyo6
Capture-Plan:      QgperN6cuOpfnb09  ← v404, AN-1 complete
GDA Webhook Cred:  1pNPY36DDz49OtKL
GitHub Gist PAT:   sKJFLNzetK86JnvO
VPS SSH Key:       NKOxLo5F81sRNPua
Postgres:          HwronxMmGY5XDGEt
MCP Proxy:         8r0ss5z6X3i0yuqi
```

---

## SESSION PROTOCOL REMINDER
- Do not interrogate. Do not run in circles. Do not contradict prior sessions.
- If Shawn says "continue" / "go" / anything ambiguous → execute top item from queue above.
- Close every session with R-SR-09 (4 artifacts).
- AUTONOMY RULE: Claude executes everything via MCP. Never ask Shawn to manually edit files.

---
*S-183 Kickoff | GDA Command Platform | EIS / GDA OU3 | CONFIDENTIAL*
