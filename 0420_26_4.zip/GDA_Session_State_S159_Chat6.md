# GDA Command Platform — Session State
**Last Updated:** S-159 Chat 6 — April 20, 2026
**Operator:** Shawn Seffernick, President, Envision Innovative Solutions (OU3)

---

## Pre-Flight (Every Chat)
1. `tool_search("n8n")` — load MCP
2. Read this file
3. **RR-38 and RR-28 are FROZEN** — do not touch ever

---

## FIRST ACTION NEXT CHAT
Fix RR-60 (Intel Feed / embed-and-store pipeline) then RR-63 (Platform Guide crash).

---

## CRITICAL: App.jsx encoding rule
**Always write App.jsx with UTF-8 encoding.**

## Deploy pattern
`{"mode": "build_only", "msg": "description"}` → deploy webhook → builds + copies + restarts container.

## SSH Read Note
ssh-read-file expects `body.command` or `body.cmd` — NOT `body.file`. Docker Postgres container: `n8n-envision-postgres-1`, user: `$POSTGRES_USER`, db: `$POSTGRES_DB`.

---

## Platform State

| Item | Status |
|---|---|
| Active workflows | ~151 |
| Frontend (gda.csr-llc.tech) | LIVE — commit b9262cd |
| **Intel Feed** | ❌ RR-60 — embed-and-store vector pipeline broken 13d. GDA.api.embed-and-store errors: Tenant not found + process undefined. No vectors stored = 0 results from gda-intel-feed. |
| **Platform Guide** | ❌ RR-63 — React #300 crash. Blank page. Object rendered as React child in PlatformGuidePage component. |
| Platform Health E2E | ⚠️ 32 FAIL — E2E checker uses wrong auth. All actual endpoints confirmed working via browser. Not a real outage. |
| Morning Brief | FIXED — endpoint, response key, date, renderer. b9262cd. |
| GDA.api.daily-actions | ACTIVE — Switch→IF + Write Cache inline + Save Actions inline. |
| GDA.api.action-history | FIXED — RR-62: Save Action SQL corruption. |
| GDA.api.capture-plan | ACTIVE — RR-42+RR-55+RR-56+RR-57-B1 FIXED |
| GDA.cron.auto-capture-plan | ACTIVE — schedule 10 */4 * * * |
| GDA.cron.auto-opp-analysis | ACTIVE — schedule 5,35 * * * * |
| GDA.cron.deadline-escalation | ACTIVE — table name corrected |
| GDA.cron.nightly-fy-revenue-calc | ACTIVE — direct Postgres calc |
| All other workflows | ACTIVE |

---

## RR-60 Intel Feed Root Cause
- Frontend calls `api.post('gda-intel-feed', ...)` via `gda.jsx` `api.post()`
- `api.post` sends only `Content-Type` header — no `X-GDA-Key`
- Most endpoints pass because their Auth Guard checks `origin` header (gda.csr-llc.tech trusted)
- `gda-intel-feed` backend may have stricter auth OR returns 0 because vector store is empty
- `GDA.api.embed-and-store` error log (13d ago): "Tenant or user not found" on Insert Vectors node + "process is not defined [line 7]" — vector ingestion pipeline broken
- `GDA.cron.weekly-comp-scan` also broken: "there is no parameter $2" — queryReplacement bug
- Fix path: (1) Find gda-intel-feed workflow ID, (2) Fix embed-and-store, (3) Re-run ingestion to populate vectors

---

## RR-63 Platform Guide Root Cause
- React error #300: "Objects are not valid as a React child"
- Occurs when navigating to #platform-guide or #platform-health
- Component file: separate PlatformGuidePage (not in App.jsx directly)
- Fix: find object being rendered as JSX child in the component

---

## Key Workflow IDs

| Workflow | ID |
|---|---|
| GDA.dev.deploy | 8GnGxnBL9TJjj1i2 |
| GDA.api.daily-actions | C7Bh7KcAl1IgSTRr |
| GDA.api.action-history | 1OPkoA5e8DYVQKm1 |
| GDA.intel.morning-briefing-v1 | YIvCdrOgF1LGmFNL |
| GDA.api.morning-briefing (read) | 0zVPgmYsvcqhyyo6 |
| GDA.api.dashboard-mega | UYGJPu7N5YZblvEU |
| GDA.api.opp-tracker 2 | SEJLE89wZa1yfQyB |
| GDA.api.capture-plan | QgperN6cuOpfnb09 |
| GDA.api.platform-health | UBgoJGxZro834RbT |
| GDA.util.ssh-read-file | IcD4K740vpWSIuaZ |
| GDA.cron.auto-capture-plan | 7gERqvfD6THg1gWf |
| GDA.cron.auto-opp-analysis | IGw8FBZhZwnwiIe1 |
| GDA.cron.deadline-escalation | Qg55lRKjubgsvD28 |
| GDA.cron.nightly-fy-revenue-calc | EGQzp92GxbjTJ03X |
| GDA.cron.learning-engine | fZpqchmmPnqAmiMq |

---

## Open Debt

| ID | Sev | Summary |
|---|---|---|
| RR-60 | High | Intel Feed: embed-and-store pipeline broken 13d. Tenant not found + process undefined. Fix pipeline + re-index vectors. |
| RR-63 | Med | Platform Guide: React #300 — object as React child. Blank page on load. |
| RR-62 | CLOSED | action-history Save Action SQL corruption. Fixed S-159C6. |
| RR-57-B2 | Low | Sidebar dropdowns — retest |
| RR-36 | Med | Chrome MCP cross-origin — workaround in place |
| RR-43 | Low | Bot dual-routing double-fire |
| RR-44 | Low | n8n_test_workflow 403 on headerAuth |
| RR-38 | FROZEN | Do not touch |
| RR-28 | FROZEN | Do not touch |

---

## Schema (Canonical)
- Anthropic API: direct HTTP with $env.ANTHROPIC_API_KEY — LangChain d92MU0tRK7bEGV83 BROKEN
- Postgres inline template rule: ALL nodes use `{{ $json.field }}` inline — never queryValues/queryReplacement at typeVersion 2.5/2.6
- Switch node broken — use IF or Code
- gda_morning_briefings.briefing = plain markdown TEXT
- deadline-escalation writes to `risk_register` (NOT gda_risk_register)
- Risk register: 247 risks are legitimate — 241 from auto-risk-cron, 6 from deadline-escalation
- gda.jsx AUTH constant has no X-GDA-Key — most endpoints pass via origin-check in Auth Guard
