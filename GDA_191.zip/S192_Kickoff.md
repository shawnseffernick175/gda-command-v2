# S-192 Kickoff — GDA Command Platform
**Date:** Next session after May 3, 2026
**Operator:** Claude (Anthropic)
**Platform:** GDA OU3 / Envision Innovative Solutions

---

## Session Open Protocol (MANDATORY)
1. `tool_search("n8n")` — load MCP context
2. Read this file
3. Execute top item from queue below without interrogating

---

## Platform State at S-191 Close
| Component | State |
|---|---|
| VPS 187.77.206.105 | ONLINE |
| n8n.csr-llc.tech | 502 AT CLOSE — self-recovery in progress (restart=always; expect ONLINE at S-192 open) |
| gda.csr-llc.tech | LIVE — React SPA operational |
| API Gateway | ACTIVE — gda-gateway.service systemd, :8788 |
| QA Test Suite | 10/10 PASS (S-190 baseline) |
| Reboot Survival | ALL SERVICES — 7/7 Docker containers restart=always, systemd enabled |
| nginx Rate Limiting | ACTIVE |
| saveDataSuccessExecution | 61/62 workflows patched to none — 1 tail remaining (chat-simple) |

---

## S-192 Priority Queue

### **RANK 1 — HP-4 Tail: chat-simple patch**
One workflow skipped due to webhook conflict during bulk patch. Fix:
```
1. n8n_update_partial_workflow b8ldzYA5LNM9Gz00 → type: deactivateWorkflow
2. n8n_update_partial_workflow b8ldzYA5LNM9Gz00 → type: updateSettings → saveDataSuccessExecution: none
3. n8n_update_partial_workflow b8ldzYA5LNM9Gz00 → type: activateWorkflow
4. Verify: n8n_get_workflow b8ldzYA5LNM9Gz00 mode: minimal → confirm active=true
```

### **RANK 2 — Block F: OODA Auto-Trigger**
When an opp enters PURSUE stage, auto-trigger OODA analysis and Telegram Shawn.

Wire:
- Source: opp-tracker 2 (SEJLE89wZa1yfQyB) — add a stage-change event webhook or use the existing opp-cross-wire (pkhbZBYzr6O93XAs)
- IF node: stage == 'PURSUE'
- HTTP Request → gda-ooda-loop (pkPpMhiz8IdRy7To) with opp context
- Telegram node → chat_id 8631035943 with OODA result summary

### **RANK 3 — Block F: Pwin Daily Loop**
GDA.cron.pwin-daily-loop (LOaS0qrkHi1dLSLZ) — verify it:
1. Pulls all PURSUE opps with no/stale gda_score from gda_opportunity_tracker
2. Batch calls gda-pwin-calculator
3. UPDATEs gda_score in gda_opportunity_tracker
4. Telegrams summary to 8631035943

If not fully wired, build it now.

### **RANK 4 — Block F: Recompete Alert Verify**
GDA.cron.recompete-early-warning (MtcQwAgm1zHYXNfB):
1. n8n_get_workflow MtcQwAgm1zHYXNfB mode: structure
2. Confirm Telegram node wired to chat_id 8631035943
3. If missing, add Telegram node
4. Confirm active=true

### **RANK 5 — Block F: Capture AI Assist**
When a capture plan is created (QgperN6cuOpfnb09), auto-trigger:
- Incumbent analysis (GDA.api.comp-intel 2)
- Teaming recommendations (GDA.api.teaming-scorer)
- Append results to plan_data in gda_capture_plans

### **RANK 6 — AN-1: Incumbent Analysis Win Themes**
Pull all WON entries from gda_win_loss_db → extract agency/teaming/NAICS patterns → seed gda_learned_weights → Telegram summary.

---

## Key Credentials (S-191 canonical)
```
x-gda-key:                gda-api-2027-AWqjhbxDYNcyV1mr
GDA Webhook Auth cred:    fTrhOzBkjS1s67bm  (headerAuth on all webhooks)
GDA Webhook Auth cred:    1pNPY36DDz49OtKL  (alternate — some older workflows)
VPS SSH Key cred:         NKOxLo5F81sRNPua
QA Agent key:             qa-agent-test-2026-adlkjfn7987-srkigio-99-eatshit
```

## Key Workflow IDs
```
SSH Exec:             IcD4K740vpWSIuaZ
Deploy:               8GnGxnBL9TJjj1i2
Dashboard-mega:       UYGJPu7N5YZblvEU
opp-tracker 2:        SEJLE89wZa1yfQyB  (CANONICAL)
ooda-loop 2:          pkPpMhiz8IdRy7To  (CANONICAL)
agent-runner:         TxcPdvx2Ld9rE9er
Morning briefing:     YIvCdrOgF1LGmFNL
Capture-plan:         QgperN6cuOpfnb09
platform-health:      UBgoJGxZro834RbT
daily-actions:        C7Bh7KcAl1IgSTRr
action-history:       1OPkoA5e8DYVQKm1
recompete-warning:    MtcQwAgm1zHYXNfB
error-handler:        2Swf6LP9AzFjHFYU
pwin-daily-loop:      LOaS0qrkHi1dLSLZ
opp-cross-wire:       pkhbZBYzr6O93XAs
```

## Hard Rules (S-191 additions + all prior)
- Switch node → broken → use IF or Code nodes
- LangChain cred d92MU0tRK7bEGV83 → permanently broken → HTTP + $env.ANTHROPIC_API_KEY
- Postgres typeVersion 2.5/2.6 → inline `{{ $json.field }}` in SQL; no queryValues; dollar-quoting ($tag$...$tag$) for JSON strings
- App.jsx writes → UTF-8 only; backup at /opt/gda-command/src/App.jsx.bak-s158-kpi
- Deploy sequence: vite build → cp -r dist/. /root/gda-frontend/dist/ → docker exec nginx -s reload
- N8N_ENCRYPTION_KEY → must persist in /root/n8n-envision/.env
- nginx config: bind-mounted from /root/gda-frontend/nginx.conf; reload via docker exec nginx -s reload
- Gateway: /opt/gda-command/gateway/src/server.js; running as gda-gateway.service; PORT=8788
- SSH Guard allows: bash -c, python3 (any), cat, grep, sed, tee, tail, find, ls
- MCP prefix: fuck-this-shit: exclusively for live ops. n8n: may timeout.
- errorWorkflow: 2Swf6LP9AzFjHFYU set on 25 workflows (S-190)
- Canonical active pipeline: stage NOT IN ('No-Bid','Cancelled','No-Go','Lost','Won')
- Canonical opp table: gda_opportunity_tracker
- RR-38 and RR-28 are RESOLVED.
- Never mention Retool.
- **Bulk MCP ops: throttle to ~20 workflows/batch, 30s pause between batches to prevent 502**

---

## North Star Gap (post S-191)
| Remaining | Effort |
|---|------|
| HP-4 tail: chat-simple | S-192 Rank 1 — 3 MCP calls |
| Block F: OODA Auto-Trigger | S-192 Rank 2 |
| Block F: Pwin Loop | S-192 Rank 3 |
| Block F: Recompete Alert verify | S-192 Rank 4 — quick check |
| Block F: Capture AI Assist | S-192 Rank 5 |
| AN-1: Incumbent analysis win themes | S-192 Rank 6 |

Platform is ~87% of North Star. Block F is the final autonomous BD ops layer.

---
*Generated by R-SR-09 close protocol at end of S-191 — May 3, 2026*
