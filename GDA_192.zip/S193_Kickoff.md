# S-193 Kickoff — GDA Command Platform
**Date:** Next session after May 2, 2026
**Operator:** Claude (Anthropic)
**Platform:** GDA OU3 / Envision Innovative Solutions

---

## Session Open Protocol (MANDATORY)
1. `tool_search("n8n")` — load MCP context
2. Read this file
3. Execute top item from queue below without interrogating

---

## Platform State at S-192 Close
| Component | State |
|---|---|
| VPS 187.77.206.105 | ONLINE — hard reboot required S-192 (Docker daemon deadlock) |
| n8n.csr-llc.tech | ONLINE — {status:ok} confirmed post-reboot |
| gda.csr-llc.tech | LIVE — React SPA 23 pages |
| API Gateway | ACTIVE — gda-gateway.service :8788 |
| Block F | COMPLETE — all 5 automation items wired |
| AN-1 Workflow | CREATED — yMo7WrELV8JVOi2M — inactive, needs first run |
| North Star | ~90% |

---

## S-193 Priority Queue

### **RANK 1 — AN-1: First Run + Activation**
Activate `GDA.intel.an1-incumbent-win-themes` (yMo7WrELV8JVOi2M) and trigger it:
```
1. n8n_update_partial_workflow yMo7WrELV8JVOi2M → type: activateWorkflow
2. n8n_test_workflow yMo7WrELV8JVOi2M (manual trigger)
3. Check execution result — if gda_win_loss_db empty, note and move on
4. Verify Telegram message received
```

### **RANK 2 — QA-01: Activate fix-runner**
```
1. n8n_update_partial_workflow aAVitXXjGWaP7bb2 → type: activateWorkflow
2. n8n_test_workflow aAVitXXjGWaP7bb2 with {action: "health"}
3. Confirm {ok: true} response
```

### **RANK 3 — GIST-01: Rebuild Gist Update Workflow**
Rebuild the dead Gist update workflow (t85atQIzsTajgUre no longer exists).
New workflow: webhook-triggered, posts session state JSON to master Gist at:
https://gist.github.com/shawnseffernick175/dd562918f676affd62153a5f06e7d7d9
Use GitHub PAT credential sKJFLNzetK86JnvO.

### **RANK 4 — Capture AI Assist: Wire Update Branch**
Current patch wired AI Assist off `Insert Plan PG` only. Also need it off `Update Plan PG` for plan updates.
```
1. n8n_update_partial_workflow QgperN6cuOpfnb09
2. addConnection: Update Plan PG → AI Assist: Comp Intel + Teaming
```

### **RANK 5 — Block D: Rescue Map Audit Closure**
Six workflows claimed fixed but never verified via live execution:
| Workflow | ID |
|---|---|
| weekly-comp-scan | uQ5cZ97cCrx5iIXk |
| morning-briefing-v1 | YIvCdrOgF1LGmFNL |
| nightly-fy-revenue-calc | EGQzp92GxbjTJ03X |
| data-retention | LzjiBI80aDAZgDIp |
| e2e-gemini-report | BLS36QTOznJ8mJlC |
| dept-opp-sweep | JRnWGEH9cesb8f3w |

Trigger each → inspect executions for errors.

---

## Key Credentials (S-192 canonical — unchanged)
```
x-gda-key:                gda-api-2027-AWqjhbxDYNcyV1mr
GDA Webhook Auth cred:    fTrhOzBkjS1s67bm
GDA Webhook Auth cred:    1pNPY36DDz49OtKL  (alternate)
VPS SSH Key cred:         NKOxLo5F81sRNPua
Telegram cred:            Jr8OOsZqc9DarQE6  (GDA Telegram Bot)
Postgres cred:            HwronxMmGY5XDGEt  (GDA Postgres)
GitHub Gist PAT:          sKJFLNzetK86JnvO
QA Agent key:             qa-agent-test-2026-adlkjfn7987-srkigio-99-eatshit
```

## Key Workflow IDs (S-192 additions)
```
AN-1 Win Themes:          yMo7WrELV8JVOi2M  (NEW — inactive)
SSH Exec:                 IcD4K740vpWSIuaZ
Deploy:                   8GnGxnBL9TJjj1i2
Dashboard-mega:           UYGJPu7N5YZblvEU
opp-tracker 2:            SEJLE89wZa1yfQyB  (CANONICAL)
ooda-loop 2:              pkPpMhiz8IdRy7To  (CANONICAL)
Morning briefing:         YIvCdrOgF1LGmFNL
Capture-plan:             QgperN6cuOpfnb09
opp-cross-wire:           pkhbZBYzr6O93XAs
pwin-daily-loop:          LOaS0qrkHi1dLSLZ  (FIXED S-192)
recompete-warning:        MtcQwAgm1zHYXNfB
error-handler:            2Swf6LP9AzFjHFYU
fix-runner:               aAVitXQjGWaP7bb2  (QA-01 — activate S-193)
```

## Hard Rules (unchanged + S-192 additions)
- Switch node → broken → use IF or Code nodes
- LangChain cred d92MU0tRK7bEGV83 → permanently broken → HTTP + $env.ANTHROPIC_API_KEY
- Postgres typeVersion 2.5/2.6 → inline `{{ $json.field }}` in SQL; no queryValues; dollar-quoting for JSON strings
- App.jsx writes → UTF-8 only; backup at /opt/gda-command/src/App.jsx.bak-s158-kpi
- Deploy: vite build → cp -r dist/. /root/gda-frontend/dist/ → docker exec nginx -s reload
- N8N_ENCRYPTION_KEY → must persist in /root/n8n-envision/.env
- SSH Guard allows: bash -c, python3, cat, grep, sed, tee, tail, find, ls
- MCP prefix: fuck-this-shit: exclusively for live ops
- Canonical active pipeline: stage NOT IN ('No-Bid','Cancelled','No-Go','Lost','Won')
- Canonical opp table: gda_opportunity_tracker; PURSUE label: gda_label = 'PURSUE'
- Code nodes: use native fetch() — never $helpers.httpRequest (CODE-01)
- RR-38 and RR-28 are RESOLVED
- Never mention Retool
- Bulk MCP ops: throttle to ~20 workflows/batch, 30s pause between batches
- Docker daemon deadlock risk: avoid high-volume MCP batch ops in single session

---

## North Star Gap (post S-192)
| Remaining | Effort |
|---|------|
| AN-1: Activate + first run | S-193 Rank 1 — 3 MCP calls |
| QA-01: fix-runner activation | S-193 Rank 2 — 2 MCP calls |
| GIST-01: Rebuild Gist update workflow | S-193 Rank 3 |
| Capture AI Assist: Update branch wiring | S-193 Rank 4 — 1 MCP call |
| Block D: Rescue Map audit (6 workflows) | S-193 Rank 5 |

Platform is ~90% of North Star. Remaining items are cleanup + validation.

---
*Generated by R-SR-09 close protocol at end of S-192 — May 2, 2026*
