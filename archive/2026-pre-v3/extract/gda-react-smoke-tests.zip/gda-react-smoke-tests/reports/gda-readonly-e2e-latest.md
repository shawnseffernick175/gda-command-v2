# GDA Read-Only E2E Report

Generated: 2026-04-27T17:58:19.289Z

Overall: **PASS**

Safety: read-only; no saves, sends, deletes, or production data changes

| Metric | Value |
|---|---:|
| Journeys tested | 5 |
| Journeys passed | 5 |
| Journeys failed | 0 |
| API checks | 7 |
| API checks passed | 7 |
| Direct n8n webhook calls | 0 |
| Browser console errors | 0 |
| Blocking failed requests | 0 |
| API auth failures | 0 |

## Journey Results

| Journey | Status | React route | API checks passed | Flags |
|---|---:|---|---:|---|
| Launchpad dashboard E2E | PASS | #launchpad | 3/3 |  |
| Semantic search E2E | PASS | #launchpad | 1/1 |  |
| Opportunity tracker read/search E2E | PASS | #opp-tracker | 1/1 |  |
| Morning briefing latest E2E | PASS | #daily-brief | 1/1 |  |
| Platform health summary E2E | PASS | #platform-health | 1/1 |  |

## Interpretation

This is the first business-journey E2E layer. It is stronger than the basic smoke tests because it checks both the React page and the matching server-side API proxy path for each read-only journey.

It still does not test write actions, sends, paid API-heavy actions, or opportunity-stage changes. Those require dry-run mode or human approval.
