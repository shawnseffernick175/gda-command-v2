import { chromium } from "playwright";
import fs from "fs";
import path from "path";

const BASE_URL = process.env.GDA_REACT_URL || "https://gda.csr-llc.tech";
const REPORT_DIR = path.resolve(process.cwd(), "reports");

const journeys = [
  {
    name: "Launchpad dashboard E2E",
    route: "#launchpad",
    purpose: "Proves the executive dashboard loads through React and the server-side API proxy.",
    expectedText: ["Command Center", "ACTIVE OPPORTUNITIES", "OPPORTUNITY VALUE", "Market Analysis"],
    forbiddenText: ["Failed to load funnel", "Authorization data is wrong", "Unauthorized"],
    apiChecks: [
      { name: "dashboard mega", method: "POST", path: "/api/gda-dashboard-mega", body: { source: "gda-readonly-e2e", mode: "smoke" } },
      { name: "launchpad funnel", method: "POST", path: "/api/gda-launchpad-funnel", body: { source: "gda-readonly-e2e", mode: "smoke" } },
      { name: "trends", method: "POST", path: "/api/gda-trends", body: { source: "gda-readonly-e2e", mode: "smoke" } }
    ]
  },
  {
    name: "Semantic search E2E",
    route: "#launchpad",
    purpose: "Proves the global semantic-search path is available without exposing webhook keys in the browser.",
    expectedText: ["Command Center"],
    forbiddenText: ["Authorization data is wrong", "Unauthorized"],
    apiChecks: [
      { name: "semantic search", method: "POST", path: "/api/gda-semantic-search", body: { source: "gda-readonly-e2e", query: "training", limit: 5 } }
    ],
    browserAction: "semanticSearch"
  },
  {
    name: "Opportunity tracker read/search E2E",
    route: "#opp-tracker",
    purpose: "Proves opportunities can be read from React through the proxy without changing data.",
    expectedText: ["Opportunity"],
    forbiddenText: ["Authorization data is wrong", "Unauthorized"],
    apiChecks: [
      { name: "opportunity tracker", method: "POST", path: "/api/gda-opp-tracker", body: { source: "gda-readonly-e2e", mode: "list", limit: 5 } }
    ]
  },
  {
    name: "Morning briefing latest E2E",
    route: "#daily-brief",
    purpose: "Proves the latest morning briefing path loads without the stale auth/data-learn failure.",
    expectedText: ["Morning", "Brief"],
    forbiddenText: ["Authorization data is wrong", "Unauthorized", "Forbidden"],
    apiChecks: [
      { name: "morning briefing", method: "GET", path: "/api/gda-morning-briefing" }
    ]
  },
  {
    name: "Platform health summary E2E",
    route: "#platform-health",
    purpose: "Proves the platform health page and health endpoint are available for the future QA Center.",
    expectedText: ["Platform", "Health"],
    forbiddenText: ["Authorization data is wrong", "Unauthorized"],
    apiChecks: [
      { name: "platform health", method: "POST", path: "/api/gda-platform-health", body: { source: "gda-readonly-e2e", mode: "smoke" } }
    ]
  }
];

function mdEscape(value) {
  return String(value ?? "").replaceAll("|", "\\|").replaceAll("\n", " ");
}

function looksLikeAuthFailure(text) {
  const lower = String(text || "").toLowerCase();
  return (
    lower.includes("authorization data is wrong") ||
    lower.includes("unauthorized") ||
    lower.includes("forbidden") ||
    lower.includes("missing or invalid")
  );
}

function isNavigationAbort(requestFailure) {
  return String(requestFailure.errorText || "").includes("ERR_ABORTED");
}

async function callApi(check) {
  const startedAt = Date.now();
  const url = `${BASE_URL}${check.path}`;
  let httpStatus = 0;
  let responseText = "";
  let contentType = "";
  let error = "";

  try {
    const response = await fetch(url, {
      method: check.method || "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json"
      },
      body: check.method === "GET" ? undefined : JSON.stringify(check.body || {})
    });
    httpStatus = response.status;
    contentType = response.headers.get("content-type") || "";
    responseText = await response.text();
  } catch (err) {
    error = String(err.message || err);
  }

  let parsed = null;
  if (responseText) {
    try {
      parsed = JSON.parse(responseText);
    } catch {
      parsed = null;
    }
  }

  const emptyResponse = !responseText || responseText.trim().length === 0;
  const htmlResponse = responseText.trim().toLowerCase().startsWith("<!doctype") || responseText.trim().toLowerCase().startsWith("<html");
  const authFailure = looksLikeAuthFailure(responseText || error);
  const passed = httpStatus >= 200 && httpStatus < 300 && !emptyResponse && !htmlResponse && !authFailure;

  return {
    name: check.name,
    method: check.method || "POST",
    path: check.path,
    passed,
    httpStatus,
    durationMs: Date.now() - startedAt,
    contentType,
    emptyResponse,
    htmlResponse,
    authFailure,
    error,
    responsePreview: parsed ?? responseText.slice(0, 800)
  };
}

async function runBrowserJourney(browser, journey) {
  const context = await browser.newContext({ viewport: { width: 1440, height: 1000 } });
  const page = await context.newPage();
  const consoleMessages = [];
  const failedRequests = [];
  const requests = [];

  page.on("console", (msg) => {
    if (["error", "warning"].includes(msg.type())) {
      consoleMessages.push({ type: msg.type(), text: msg.text(), location: msg.location() });
    }
  });

  page.on("request", (req) => {
    const url = req.url();
    if (url.includes("n8n.csr-llc.tech/webhook") || url.includes("gda.csr-llc.tech/api/")) {
      requests.push({ method: req.method(), url });
    }
  });

  page.on("requestfailed", (req) => {
    const url = req.url();
    if (url.includes("n8n.csr-llc.tech") || url.includes("gda.csr-llc.tech/api/")) {
      failedRequests.push({ url, errorText: req.failure()?.errorText || "" });
    }
  });

  let loadStatus = "loaded";
  let bodyText = "";
  let actionStatus = "not_applicable";

  try {
    await page.goto(`${BASE_URL}/?v=${Date.now()}${journey.route}`, { waitUntil: "domcontentloaded", timeout: 30000 });
    await page.waitForLoadState("networkidle", { timeout: 15000 }).catch(() => {});
    await page.waitForTimeout(1500);

    if (journey.browserAction === "semanticSearch") {
      const searchBox = page.getByPlaceholder(/Semantic search/i);
      if (await searchBox.count()) {
        await searchBox.first().fill("training");
        await searchBox.first().press("Enter").catch(() => {});
        await page.waitForTimeout(1500);
        actionStatus = "attempted";
      } else {
        actionStatus = "search_box_not_found";
      }
    }

    bodyText = await page.locator("body").innerText({ timeout: 5000 });
  } catch (err) {
    loadStatus = `failed: ${String(err.message || err).split("\n")[0]}`;
    bodyText = await page.locator("body").innerText({ timeout: 3000 }).catch(() => "");
  }

  await context.close();

  const missingExpectedText = journey.expectedText.filter((text) => !bodyText.toLowerCase().includes(text.toLowerCase()));
  const foundForbiddenText = journey.forbiddenText.filter((text) => bodyText.toLowerCase().includes(text.toLowerCase()));
  const directCalls = requests.filter((request) => request.url.includes("n8n.csr-llc.tech/webhook"));
  const consoleErrors = consoleMessages.filter((message) => message.type === "error");
  const blockingFailedRequests = failedRequests.filter((request) => !isNavigationAbort(request));

  return {
    loadStatus,
    actionStatus,
    missingExpectedText,
    foundForbiddenText,
    directCallCount: directCalls.length,
    directCalls,
    apiCallCount: requests.filter((request) => request.url.includes("gda.csr-llc.tech/api/")).length,
    consoleErrorCount: consoleErrors.length,
    consoleWarningCount: consoleMessages.filter((message) => message.type === "warning").length,
    consoleMessages,
    failedRequests,
    blockingFailedRequests,
    bodyPreview: bodyText.slice(0, 500)
  };
}

async function runJourney(browser, journey) {
  const browserResult = await runBrowserJourney(browser, journey);
  const apiResults = [];
  for (const check of journey.apiChecks) {
    apiResults.push(await callApi(check));
  }

  const passed =
    browserResult.loadStatus === "loaded" &&
    browserResult.missingExpectedText.length === 0 &&
    browserResult.foundForbiddenText.length === 0 &&
    browserResult.directCallCount === 0 &&
    browserResult.consoleErrorCount === 0 &&
    browserResult.blockingFailedRequests.length === 0 &&
    apiResults.every((result) => result.passed);

  return {
    name: journey.name,
    route: journey.route,
    purpose: journey.purpose,
    passed,
    status: passed ? "PASS" : "FAIL",
    browser: browserResult,
    apiResults
  };
}

async function main() {
  fs.mkdirSync(REPORT_DIR, { recursive: true });
  const browser = await chromium.launch({ headless: true });
  const results = [];

  for (const journey of journeys) {
    results.push(await runJourney(browser, journey));
  }

  await browser.close();

  const totals = {
    journeysTested: results.length,
    journeysPassed: results.filter((result) => result.passed).length,
    journeysFailed: results.filter((result) => !result.passed).length,
    apiChecks: results.reduce((sum, result) => sum + result.apiResults.length, 0),
    apiChecksPassed: results.reduce((sum, result) => sum + result.apiResults.filter((api) => api.passed).length, 0),
    directN8nWebhookCalls: results.reduce((sum, result) => sum + result.browser.directCallCount, 0),
    consoleErrors: results.reduce((sum, result) => sum + result.browser.consoleErrorCount, 0),
    blockingFailedRequests: results.reduce((sum, result) => sum + result.browser.blockingFailedRequests.length, 0),
    apiAuthFailures: results.reduce((sum, result) => sum + result.apiResults.filter((api) => api.authFailure).length, 0)
  };

  const report = {
    ok: totals.journeysFailed === 0,
    overallStatus: totals.journeysFailed === 0 ? "PASS" : "FAIL",
    testedAt: new Date().toISOString(),
    baseUrl: BASE_URL,
    safety: "read-only; no saves, sends, deletes, or production data changes",
    totals,
    results
  };

  const jsonPath = path.join(REPORT_DIR, "gda-readonly-e2e-latest.json");
  const mdPath = path.join(REPORT_DIR, "gda-readonly-e2e-latest.md");
  fs.writeFileSync(jsonPath, JSON.stringify(report, null, 2), "utf8");

  const rows = results
    .map((result) => {
      const apiSummary = `${result.apiResults.filter((api) => api.passed).length}/${result.apiResults.length}`;
      const flags = [
        result.browser.missingExpectedText.length ? `missing: ${result.browser.missingExpectedText.join(", ")}` : "",
        result.browser.foundForbiddenText.length ? `forbidden: ${result.browser.foundForbiddenText.join(", ")}` : "",
        result.browser.consoleErrorCount ? `console errors: ${result.browser.consoleErrorCount}` : "",
        result.browser.directCallCount ? `direct n8n calls: ${result.browser.directCallCount}` : "",
        result.browser.blockingFailedRequests.length ? `failed requests: ${result.browser.blockingFailedRequests.length}` : "",
        result.apiResults.some((api) => !api.passed) ? `api failed: ${result.apiResults.filter((api) => !api.passed).map((api) => {
          const reasons = [
            `HTTP ${api.httpStatus}`,
            api.emptyResponse ? "empty response body" : "",
            api.htmlResponse ? "HTML response" : "",
            api.authFailure ? "auth failure" : ""
          ].filter(Boolean).join(", ");
          return `${api.name} ${reasons}`;
        }).join(", ")}` : ""
      ].filter(Boolean).join("; ");
      return `| ${mdEscape(result.name)} | ${result.status} | ${mdEscape(result.route)} | ${apiSummary} | ${mdEscape(flags)} |`;
    })
    .join("\n");

  const markdown = `# GDA Read-Only E2E Report

Generated: ${report.testedAt}

Overall: **${report.overallStatus}**

Safety: ${report.safety}

| Metric | Value |
|---|---:|
| Journeys tested | ${totals.journeysTested} |
| Journeys passed | ${totals.journeysPassed} |
| Journeys failed | ${totals.journeysFailed} |
| API checks | ${totals.apiChecks} |
| API checks passed | ${totals.apiChecksPassed} |
| Direct n8n webhook calls | ${totals.directN8nWebhookCalls} |
| Browser console errors | ${totals.consoleErrors} |
| Blocking failed requests | ${totals.blockingFailedRequests} |
| API auth failures | ${totals.apiAuthFailures} |

## Journey Results

| Journey | Status | React route | API checks passed | Flags |
|---|---:|---|---:|---|
${rows}

## Interpretation

This is the first business-journey E2E layer. It is stronger than the basic smoke tests because it checks both the React page and the matching server-side API proxy path for each read-only journey.

It still does not test write actions, sends, paid API-heavy actions, or opportunity-stage changes. Those require dry-run mode or human approval.
`;

  fs.writeFileSync(mdPath, markdown, "utf8");

  console.log(`Overall: ${report.overallStatus}`);
  console.log(`Journeys: ${totals.journeysPassed}/${totals.journeysTested}`);
  console.log(`API checks: ${totals.apiChecksPassed}/${totals.apiChecks}`);
  console.log(`Direct n8n webhook calls: ${totals.directN8nWebhookCalls}`);
  console.log(`Browser console errors: ${totals.consoleErrors}`);
  console.log(`Blocking failed requests: ${totals.blockingFailedRequests}`);
  console.log(`API auth failures: ${totals.apiAuthFailures}`);
  console.log(`JSON report: ${jsonPath}`);
  console.log(`Markdown report: ${mdPath}`);

  if (!report.ok) {
    process.exitCode = 1;
  }
}

main().catch((err) => {
  console.error(err);
  process.exitCode = 1;
});
