import fs from "fs";
import path from "path";

const BASE_URL = process.env.GDA_REACT_URL || "https://gda.csr-llc.tech";
const REPORT_DIR = path.resolve(process.cwd(), "reports");

const checks = [
  {
    name: "Save opportunity dry-run",
    purpose: "Proves the save-opportunity workflow can be exercised through React's API proxy without writing a real saved opportunity.",
    method: "POST",
    path: "/api/gda-save-opp",
    body: {
      action: "save",
      dryRun: true,
      title: "QA DRY RUN - Do Not Save",
      agency: "QA",
      dept: "QA",
      need_score: 1,
      source: "gda-phase-b-e2e"
    },
    assertions: {
      success: true,
      dryRun: true,
      action: "save"
    }
  },
  {
    name: "Risk register create dry-run",
    purpose: "Proves the risk-register workflow can be exercised through React's API proxy without creating a real risk record.",
    method: "POST",
    path: "/api/gda-risk",
    body: {
      action: "create",
      dryRun: true,
      title: "QA DRY RUN - Do Not Save",
      description: "Phase B E2E risk dry-run",
      category: "QA",
      severity: "LOW",
      likelihood: "LOW",
      impact: "LOW",
      source: "gda-phase-b-e2e"
    },
    assertions: {
      success: true,
      dryRun: true,
      action: "create"
    }
  }
];

function mdEscape(value) {
  return String(value ?? "").replaceAll("|", "\\|").replaceAll("\n", " ");
}

function looksLikeAuthFailure(text) {
  const lower = String(text || "").toLowerCase();
  return (
    lower.includes("authorization data is wrong") ||
    lower.includes("unauthorized") ||
    lower.includes("forbidden") ||
    lower.includes("missing or invalid")
  );
}

function assertResponse(parsed, assertions) {
  const failures = [];
  for (const [key, expected] of Object.entries(assertions || {})) {
    if (!parsed || parsed[key] !== expected) {
      failures.push(`${key} expected ${JSON.stringify(expected)} but got ${JSON.stringify(parsed?.[key])}`);
    }
  }
  return failures;
}

async function callApi(check) {
  const startedAt = Date.now();
  const url = `${BASE_URL}${check.path}`;
  let httpStatus = 0;
  let responseText = "";
  let contentType = "";
  let error = "";

  try {
    const response = await fetch(url, {
      method: check.method || "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json"
      },
      body: check.method === "GET" ? undefined : JSON.stringify(check.body || {})
    });
    httpStatus = response.status;
    contentType = response.headers.get("content-type") || "";
    responseText = await response.text();
  } catch (err) {
    error = String(err.message || err);
  }

  let parsed = null;
  if (responseText) {
    try {
      parsed = JSON.parse(responseText);
    } catch {
      parsed = null;
    }
  }

  const emptyResponse = !responseText || responseText.trim().length === 0;
  const htmlResponse = responseText.trim().toLowerCase().startsWith("<!doctype") || responseText.trim().toLowerCase().startsWith("<html");
  const authFailure = looksLikeAuthFailure(responseText || error);
  const assertionFailures = assertResponse(parsed, check.assertions);
  const passed =
    httpStatus >= 200 &&
    httpStatus < 300 &&
    !emptyResponse &&
    !htmlResponse &&
    !authFailure &&
    assertionFailures.length === 0;

  return {
    name: check.name,
    purpose: check.purpose,
    method: check.method || "POST",
    path: check.path,
    passed,
    status: passed ? "PASS" : "FAIL",
    httpStatus,
    durationMs: Date.now() - startedAt,
    contentType,
    emptyResponse,
    htmlResponse,
    authFailure,
    assertionFailures,
    error,
    responsePreview: parsed ?? responseText.slice(0, 800)
  };
}

async function main() {
  fs.mkdirSync(REPORT_DIR, { recursive: true });

  const results = [];
  for (const check of checks) {
    results.push(await callApi(check));
  }

  const totals = {
    checksTested: results.length,
    checksPassed: results.filter((result) => result.passed).length,
    checksFailed: results.filter((result) => !result.passed).length,
    dryRunChecks: results.filter((result) => result.responsePreview?.dryRun === true).length,
    authFailures: results.filter((result) => result.authFailure).length,
    emptyResponses: results.filter((result) => result.emptyResponse).length,
    htmlResponses: results.filter((result) => result.htmlResponse).length
  };

  const report = {
    ok: totals.checksFailed === 0,
    overallStatus: totals.checksFailed === 0 ? "PASS" : "FAIL",
    testedAt: new Date().toISOString(),
    baseUrl: BASE_URL,
    safety: "dry-run only; no production save, update, delete, send, or stage-change actions",
    totals,
    results
  };

  const jsonPath = path.join(REPORT_DIR, "gda-phaseb-dryrun-e2e-latest.json");
  const mdPath = path.join(REPORT_DIR, "gda-phaseb-dryrun-e2e-latest.md");
  fs.writeFileSync(jsonPath, JSON.stringify(report, null, 2), "utf8");

  const rows = results
    .map((result) => {
      const flags = [
        result.authFailure ? "auth failure" : "",
        result.emptyResponse ? "empty response" : "",
        result.htmlResponse ? "HTML response" : "",
        result.assertionFailures.length ? result.assertionFailures.join("; ") : "",
        result.error
      ].filter(Boolean).join("; ");
      return `| ${mdEscape(result.name)} | ${result.status} | ${result.httpStatus} | ${result.durationMs} | ${mdEscape(flags)} |`;
    })
    .join("\n");

  const markdown = `# GDA Phase B Dry-Run E2E Report

Generated: ${report.testedAt}

Overall: **${report.overallStatus}**

Safety: ${report.safety}

| Metric | Value |
|---|---:|
| Checks tested | ${totals.checksTested} |
| Checks passed | ${totals.checksPassed} |
| Checks failed | ${totals.checksFailed} |
| Dry-run confirmations | ${totals.dryRunChecks} |
| Auth failures | ${totals.authFailures} |
| Empty responses | ${totals.emptyResponses} |
| HTML responses | ${totals.htmlResponses} |

## Check Results

| Check | Status | HTTP | Duration ms | Flags |
|---|---:|---:|---:|---|
${rows}

## Interpretation

This is the first Phase B E2E layer. It tests write-capable business workflows only after each workflow has an explicit dry-run path.

Passing means React can call the tested write-capable workflows through the server-side API proxy and receive responses that confirm dry-run mode. It does not prove real writes should be trusted yet; real writes stay outside automation until each workflow has rollback/cleanup rules or human approval.
`;

  fs.writeFileSync(mdPath, markdown, "utf8");

  console.log(`Overall: ${report.overallStatus}`);
  console.log(`Checks: ${totals.checksPassed}/${totals.checksTested}`);
  console.log(`Dry-run confirmations: ${totals.dryRunChecks}`);
  console.log(`Auth failures: ${totals.authFailures}`);
  console.log(`JSON report: ${jsonPath}`);
  console.log(`Markdown report: ${mdPath}`);

  if (!report.ok) {
    process.exitCode = 1;
  }
}

main().catch((err) => {
  console.error(err);
  process.exitCode = 1;
});
