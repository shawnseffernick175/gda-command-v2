/*
GDA Controlled n8n Fix Agent

Purpose:
- Inspect workflows
- Propose safe node patches
- Apply only explicitly approved patches
- Return execution failures and workflow details

Intended n8n workflow shape:
Webhook -> Code node with this file -> Respond to Webhook

Required setup inside this code before saving:
- Set N8N_API_KEY to your real n8n API key, or replace with env lookup if your n8n supports env access.
- Set FIX_AGENT_KEY to a private key you choose.

Security:
- Requests must include header x-gda-fix-key matching FIX_AGENT_KEY.
- apply_patch requires approved: true and an exact patch object.
- This agent does not execute workflows directly.
*/

const body = $input.first().json.body || $input.first().json || {};
const headers = $input.first().json.headers || {};

function headerValue(name) {
  const lower = name.toLowerCase();
  for (const key of Object.keys(headers)) {
    if (key.toLowerCase() === lower) return headers[key];
  }
  return '';
}

function env(name, fallback = '') {
  try {
    if (typeof $env !== 'undefined' && $env[name]) return $env[name];
  } catch (error) {}
  return fallback;
}

// REQUIRED: Put a private key here, or use env('GDA_FIX_AGENT_KEY')
const FIX_AGENT_KEY = '';

// REQUIRED: Put your n8n API key here, or use env('GDA_QA_N8N_API_KEY')
const N8N_API_KEY = '';

const N8N_BASE_URL = env('GDA_QA_N8N_BASE_URL', 'https://n8n.csr-llc.tech').replace(/\/$/, '');

if (FIX_AGENT_KEY && headerValue('x-gda-fix-key') !== FIX_AGENT_KEY) {
  return [{ json: { ok: false, statusCode: 403, error: 'Unauthorized fix-agent request. Missing or invalid x-gda-fix-key.' } }];
}

function requireN8nApiKey() {
  if (!N8N_API_KEY) throw new Error('N8N_API_KEY is not configured in the fix agent.');
}

async function n8nApi(path, options = {}) {
  requireN8nApiKey();
  const response = await this.helpers.httpRequest({
    method: options.method || 'GET',
    url: `${N8N_BASE_URL}${path}`,
    headers: {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      'X-N8N-API-KEY': N8N_API_KEY,
      ...(options.headers || {})
    },
    body: options.body,
    json: true,
    returnFullResponse: true,
    ignoreHttpStatusErrors: true
  });

  const status = response.statusCode || response.status || 200;
  return {
    status,
    ok: status >= 200 && status < 300,
    body: response.body ?? response
  };
}

function clone(value) {
  return JSON.parse(JSON.stringify(value));
}

function findNode(workflow, nodeName) {
  const node = (workflow.nodes || []).find((n) => n.name === nodeName);
  if (!node) throw new Error(`Node not found: ${nodeName}`);
  return node;
}

function summarizeNode(node) {
  const parameters = node.parameters || {};
  return {
    id: node.id,
    name: node.name,
    type: node.type,
    disabled: Boolean(node.disabled),
    credentialTypes: node.credentials ? Object.keys(node.credentials) : [],
    parameterKeys: Object.keys(parameters),
    queryPreview: parameters.query ? String(parameters.query).slice(0, 2000) : undefined,
    jsCodePreview: parameters.jsCode ? String(parameters.jsCode).slice(0, 2000) : undefined,
    url: parameters.url,
    method: parameters.method
  };
}

function safeWorkflowSummary(workflow) {
  return {
    id: workflow.id,
    name: workflow.name,
    active: Boolean(workflow.active),
    nodeCount: (workflow.nodes || []).length,
    nodes: (workflow.nodes || []).map(summarizeNode)
  };
}

function buildPatchId(patch) {
  const raw = JSON.stringify({
    workflowId: patch.workflowId,
    nodeName: patch.nodeName,
    parameterPath: patch.parameterPath,
    newValue: patch.newValue
  });
  let hash = 0;
  for (let i = 0; i < raw.length; i += 1) {
    hash = ((hash << 5) - hash) + raw.charCodeAt(i);
    hash |= 0;
  }
  return `patch_${Math.abs(hash)}`;
}

function setParameterByPath(node, parameterPath, newValue) {
  if (!parameterPath || !parameterPath.startsWith('parameters.')) {
    throw new Error('parameterPath must start with parameters.');
  }
  const parts = parameterPath.split('.').slice(1);
  if (parts.length < 1) throw new Error('Invalid parameterPath.');
  let cursor = node.parameters || {};
  node.parameters = cursor;
  for (let i = 0; i < parts.length - 1; i += 1) {
    const part = parts[i];
    if (typeof cursor[part] !== 'object' || cursor[part] === null) cursor[part] = {};
    cursor = cursor[part];
  }
  cursor[parts[parts.length - 1]] = newValue;
}

function getParameterByPath(node, parameterPath) {
  if (!parameterPath || !parameterPath.startsWith('parameters.')) {
    throw new Error('parameterPath must start with parameters.');
  }
  const parts = parameterPath.split('.').slice(1);
  let cursor = node.parameters || {};
  for (const part of parts) {
    if (cursor == null) return undefined;
    cursor = cursor[part];
  }
  return cursor;
}

async function getWorkflow(workflowId) {
  if (!workflowId) throw new Error('workflowId is required.');
  const result = await n8nApi.call(this, `/api/v1/workflows/${encodeURIComponent(workflowId)}`);
  if (!result.ok) throw new Error(`Failed to get workflow: HTTP ${result.status} ${JSON.stringify(result.body).slice(0, 500)}`);
  return result.body;
}

async function updateWorkflow(workflow) {
  const workflowId = workflow.id;
  const result = await n8nApi.call(this, `/api/v1/workflows/${encodeURIComponent(workflowId)}`, {
    method: 'PUT',
    body: workflow
  });
  if (!result.ok) throw new Error(`Failed to update workflow: HTTP ${result.status} ${JSON.stringify(result.body).slice(0, 1000)}`);
  return result.body;
}

async function listWorkflows() {
  const workflows = [];
  let cursor = undefined;
  for (let page = 0; page < 25; page += 1) {
    const query = cursor ? `?limit=100&cursor=${encodeURIComponent(cursor)}` : '?limit=100';
    const result = await n8nApi.call(this, `/api/v1/workflows${query}`);
    if (!result.ok) throw new Error(`Workflow inventory failed: HTTP ${result.status} ${JSON.stringify(result.body).slice(0, 500)}`);
    const data = Array.isArray(result.body) ? result.body : (result.body.data || []);
    workflows.push(...data);
    cursor = result.body.nextCursor;
    if (!cursor) break;
  }
  return workflows;
}

function proposeNodeParameterPatch({ workflow, nodeName, parameterPath, newValue, reason }) {
  const node = findNode(workflow, nodeName);
  const oldValue = getParameterByPath(node, parameterPath);
  const patch = {
    workflowId: workflow.id,
    workflowName: workflow.name,
    nodeName,
    nodeId: node.id,
    parameterPath,
    oldValue,
    newValue,
    reason: reason || '',
    createdAt: new Date().toISOString()
  };
  patch.patchId = buildPatchId(patch);
  return patch;
}

async function applyNodeParameterPatch(patch) {
  if (!patch || !patch.workflowId || !patch.nodeName || !patch.parameterPath) {
    throw new Error('patch with workflowId, nodeName, and parameterPath is required.');
  }
  if (body.approved !== true) {
    throw new Error('apply_patch requires approved: true.');
  }
  const expectedPatchId = buildPatchId(patch);
  if (patch.patchId !== expectedPatchId) {
    throw new Error(`Patch ID mismatch. Expected ${expectedPatchId}, received ${patch.patchId || 'missing'}.`);
  }
  const workflow = await getWorkflow.call(this, patch.workflowId);
  const updated = clone(workflow);
  const node = findNode(updated, patch.nodeName);
  const currentValue = getParameterByPath(node, patch.parameterPath);

  if (patch.oldValue !== undefined && JSON.stringify(currentValue) !== JSON.stringify(patch.oldValue)) {
    throw new Error('Current value does not match patch.oldValue. Workflow may have changed. Refusing to apply.');
  }

  setParameterByPath(node, patch.parameterPath, patch.newValue);
  const result = await updateWorkflow.call(this, updated);
  return {
    ok: true,
    applied: true,
    patchId: patch.patchId,
    workflowId: patch.workflowId,
    workflowName: patch.workflowName,
    nodeName: patch.nodeName,
    parameterPath: patch.parameterPath,
    resultSummary: {
      id: result.id,
      name: result.name,
      active: result.active
    },
    rollbackPatch: {
      workflowId: patch.workflowId,
      workflowName: patch.workflowName,
      nodeName: patch.nodeName,
      parameterPath: patch.parameterPath,
      oldValue: patch.newValue,
      newValue: patch.oldValue,
      reason: `Rollback for ${patch.patchId}`
    }
  };
}

async function latestFailedExecutions(limit = 25) {
  const result = await n8nApi.call(this, `/api/v1/executions?status=error&limit=${encodeURIComponent(limit)}`);
  if (!result.ok) throw new Error(`Execution query failed: HTTP ${result.status} ${JSON.stringify(result.body).slice(0, 500)}`);
  return result.body;
}

async function executionDetails(executionId) {
  if (!executionId) throw new Error('executionId is required.');
  const result = await n8nApi.call(this, `/api/v1/executions/${encodeURIComponent(executionId)}`);
  if (!result.ok) throw new Error(`Execution detail failed: HTTP ${result.status} ${JSON.stringify(result.body).slice(0, 500)}`);
  return result.body;
}

async function main() {
  const action = body.action || 'health';

  if (action === 'health') {
    return {
      ok: true,
      agent: 'GDA.controlled-fix-agent',
      mode: 'human-in-the-loop',
      n8nBaseConfigured: Boolean(N8N_BASE_URL),
      n8nApiKeyConfigured: Boolean(N8N_API_KEY),
      fixAgentKeyConfigured: Boolean(FIX_AGENT_KEY),
      supportedActions: [
        'health',
        'inventory_workflows',
        'workflow_details',
        'node_details',
        'propose_node_parameter_patch',
        'apply_node_parameter_patch',
        'latest_failed_executions',
        'execution_details'
      ]
    };
  }

  if (action === 'inventory_workflows') {
    const workflows = await listWorkflows.call(this);
    return {
      ok: true,
      totalWorkflows: workflows.length,
      activeWorkflows: workflows.filter((w) => w.active).length,
      workflows: workflows.map((w) => ({
        id: w.id,
        name: w.name,
        active: Boolean(w.active),
        nodeCount: (w.nodes || []).length
      }))
    };
  }

  if (action === 'workflow_details') {
    const workflow = await getWorkflow.call(this, body.workflowId);
    return { ok: true, workflow: safeWorkflowSummary(workflow) };
  }

  if (action === 'node_details') {
    const workflow = await getWorkflow.call(this, body.workflowId);
    const node = findNode(workflow, body.nodeName);
    return { ok: true, workflowId: workflow.id, workflowName: workflow.name, node: summarizeNode(node), fullParameters: node.parameters || {} };
  }

  if (action === 'propose_node_parameter_patch') {
    const workflow = await getWorkflow.call(this, body.workflowId);
    const patch = proposeNodeParameterPatch({
      workflow,
      nodeName: body.nodeName,
      parameterPath: body.parameterPath,
      newValue: body.newValue,
      reason: body.reason
    });
    return { ok: true, patch, approvalRequired: true };
  }

  if (action === 'apply_node_parameter_patch') {
    return await applyNodeParameterPatch.call(this, body.patch);
  }

  if (action === 'latest_failed_executions') {
    return { ok: true, executions: await latestFailedExecutions.call(this, body.limit || 25) };
  }

  if (action === 'execution_details') {
    return { ok: true, execution: await executionDetails.call(this, body.executionId) };
  }

  return { ok: false, statusCode: 400, error: `Unsupported action: ${action}` };
}

try {
  const result = await main.call(this);
  return [{ json: result }];
} catch (error) {
  return [{ json: { ok: false, statusCode: 500, error: error.stack || error.message || String(error) } }];
}
