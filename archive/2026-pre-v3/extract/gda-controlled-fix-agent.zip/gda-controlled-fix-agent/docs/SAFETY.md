# Safety Rules

The controlled fix agent can update live n8n workflows. Treat it as powerful.

## Required Human Approval

Always require approval before:

- changing a workflow
- activating or deactivating a workflow
- editing credentials
- changing webhooks
- running workflows that write data
- running workflows that send Telegram/email/Slack
- running workflows that call paid APIs

## Allowed Without Approval

The agent may inspect:

- workflow list
- workflow details
- node details
- latest failed executions
- execution details

## Not Included By Design

This package does not include a generic "run workflow" action.

Running workflows should remain separate because many GDA workflows have side effects.

## Rollback

When a patch is applied, the response includes a rollback patch. Save it if the change is important.

## Protect The Webhook

Use both if possible:

1. n8n webhook Header Auth
2. `x-gda-fix-key` checked by the Code node

Do not expose the fix agent without auth.
