param(
  [Parameter(Mandatory=$true)]
  [string]$Action,

  [string]$WebhookUrl = "",
  [string]$Key = "",
  [string]$WorkflowId = "",
  [string]$NodeName = "",
  [string]$ParameterPath = "",
  [string]$NewValueFile = "",
  [string]$PatchFile = "",
  [switch]$Approved,
  [int]$Limit = 25,
  [string]$ExecutionId = ""
)

$ErrorActionPreference = "Stop"

if (-not $WebhookUrl) {
  $WebhookUrl = $env:GDA_FIX_AGENT_WEBHOOK_URL
}

if (-not $WebhookUrl) {
  throw "Missing WebhookUrl. Pass -WebhookUrl or set `$env:GDA_FIX_AGENT_WEBHOOK_URL."
}

if (-not $Key) {
  $Key = $env:GDA_FIX_AGENT_KEY
}

$headers = @{
  "Content-Type" = "application/json"
}

if ($Key) {
  $headers["x-gda-fix-key"] = $Key
}

$body = @{
  action = $Action
}

if ($WorkflowId) { $body.workflowId = $WorkflowId }
if ($NodeName) { $body.nodeName = $NodeName }
if ($ParameterPath) { $body.parameterPath = $ParameterPath }
if ($Limit) { $body.limit = $Limit }
if ($ExecutionId) { $body.executionId = $ExecutionId }

if ($NewValueFile) {
  if (-not (Test-Path $NewValueFile)) {
    throw "NewValueFile not found: $NewValueFile"
  }
  $body.newValue = Get-Content $NewValueFile -Raw
}

if ($PatchFile) {
  if (-not (Test-Path $PatchFile)) {
    throw "PatchFile not found: $PatchFile"
  }
  $body.patch = Get-Content $PatchFile -Raw | ConvertFrom-Json
}

if ($Approved) {
  $body.approved = $true
}

$jsonBody = $body | ConvertTo-Json -Depth 50
$response = Invoke-RestMethod -Uri $WebhookUrl -Method POST -Headers $headers -Body $jsonBody
$response | ConvertTo-Json -Depth 100
