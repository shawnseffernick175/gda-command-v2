SELECT id, crawl_data, created_at
FROM gda_competitor_crawls
WHERE competitor_name = '{{ ($json.name || "").replace(/'/g, "''") }}'
ORDER BY created_at DESC
LIMIT 1
