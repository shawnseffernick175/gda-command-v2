INSERT INTO gda_competitor_crawls (
  competitor_name,
  crawl_data,
  changes_detected,
  change_count,
  significance,
  previous_crawl_id
)
VALUES (
  '{{ ($json.name || $json.competitor_name || "Unknown").replace(/'/g, "''") }}',
  '{{ JSON.stringify($json.crawl_data || $json).replace(/'/g, "''") }}'::jsonb,
  '{{ JSON.stringify($json.changes_detected || $json.changes || []).replace(/'/g, "''") }}'::jsonb,
  {{ Number($json.change_count || $json.changeCount || 0) }},
  '{{ ($json.significance || "LOW").replace(/'/g, "''") }}',
  {{ $json.previous_crawl_id || $json.previousCrawlId || 'NULL' }}
)
RETURNING id, competitor_name, change_count, significance
