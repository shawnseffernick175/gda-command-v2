# GDA Controlled n8n Fix Agent

This package creates a human-in-the-loop n8n fix agent.

It is designed so Computer can inspect and propose workflow edits, but actual workflow changes require approval.

## What It Does

Supported actions:

- `health`
- `inventory_workflows`
- `workflow_details`
- `node_details`
- `propose_node_parameter_patch`
- `apply_node_parameter_patch`
- `latest_failed_executions`
- `execution_details`

## What It Does Not Do

By default, this agent does not execute workflows.

That is intentional. Workflow execution can call paid APIs, write records, send Telegram messages, or change business data.

## Safety Model

The safe flow is:

1. Inspect workflow.
2. Inspect node.
3. Propose patch.
4. Shawn approves.
5. Apply patch.
6. Verify latest failures.

## n8n Setup

Create a new workflow:

```text
GDA.controlled-fix-agent
```

Recommended nodes:

```text
Webhook -> Code -> Respond to Webhook
```

### Webhook Node

Use:

```text
Method: POST
Path: gda-controlled-fix-agent
Response: Using Respond to Webhook node
```

You may also enable n8n Header Auth on the webhook if you want an additional auth layer.

### Code Node

Copy the full contents of:

```text
n8n/controlled-fix-agent-code.js
```

Paste it into the Code node.

At the top of the code, fill in:

```js
const FIX_AGENT_KEY = '';
const N8N_API_KEY = '';
```

Use:

```js
const FIX_AGENT_KEY = 'your-private-fix-agent-key';
const N8N_API_KEY = 'your-n8n-api-key';
```

Do not paste these keys into chat.

### Respond Node

Set Respond With:

```text
JSON
```

Response body:

```text
{{ $json }}
```

Save and activate the workflow.

## PowerShell Setup

In PowerShell, go to this folder:

```powershell
cd "C:\Users\shawn\OneDrive\Desktop\QA\Agents\Controlled_Fix_Agent\gda-controlled-fix-agent"
```

Set the webhook URL:

```powershell
$env:GDA_FIX_AGENT_WEBHOOK_URL = "https://n8n.csr-llc.tech/webhook/gda-controlled-fix-agent"
```

Set the fix-agent key:

```powershell
$env:GDA_FIX_AGENT_KEY = "your-private-fix-agent-key"
```

## Test Health

```powershell
.\scripts\call-fix-agent.ps1 -Action health
```

Expected:

```json
{
  "ok": true,
  "agent": "GDA.controlled-fix-agent",
  "mode": "human-in-the-loop"
}
```

## Inspect a Workflow

```powershell
.\scripts\call-fix-agent.ps1 -Action workflow_details -WorkflowId "WORKFLOW_ID_HERE"
```

## Inspect a Node

```powershell
.\scripts\call-fix-agent.ps1 -Action node_details -WorkflowId "WORKFLOW_ID_HERE" -NodeName "Store Crawl"
```

## Propose a Patch

Save the new query into a file, for example:

```powershell
notepad .\examples\competitor-crawler-store-crawl.sql
```

Then propose the patch:

```powershell
.\scripts\call-fix-agent.ps1 `
  -Action propose_node_parameter_patch `
  -WorkflowId "bTE4k631s6JqZMiG" `
  -NodeName "Store Crawl" `
  -ParameterPath "parameters.query" `
  -NewValueFile ".\examples\competitor-crawler-store-crawl.sql" `
  | Out-File ".\store-crawl-patch.json" -Encoding utf8
```

Review:

```powershell
Get-Content ".\store-crawl-patch.json" -Raw
```

## Apply an Approved Patch

Only do this after reviewing the patch.

```powershell
.\scripts\call-fix-agent.ps1 `
  -Action apply_node_parameter_patch `
  -PatchFile ".\store-crawl-patch.json" `
  -Approved
```

## Latest Failures

```powershell
.\scripts\call-fix-agent.ps1 -Action latest_failed_executions -Limit 10
```

## Execution Details

```powershell
.\scripts\call-fix-agent.ps1 -Action execution_details -ExecutionId "12345"
```

## Important Rules

- Do not leave `FIX_AGENT_KEY` blank.
- Do not paste API keys into chat.
- Do not run API-heavy workflows without approval.
- Do not use this as an open public endpoint.
- Keep the existing read-only QA agent separate from this controlled fix agent.

## Recommended Long-Term Use

Use this fix agent for approved workflow edits only.

Use the read-only QA agent for:

- inventory
- tests
- latest failures
- workflow details

Use this controlled fix agent for:

- patching stale auth code
- patching SQL queries
- patching node parameters
- generating rollback patches

