/**
 * GDA Rebuild — API Layer
 * S-001 | Phase 1
 *
 * Express route stubs backing React /api/... calls.
 * Mount with: app.use('/api', require('./gda-api-routes'))
 *
 * FIRST-RUN FIXES (S-001):
 * - KPI response: snake_case keys from Postgres remapped to camelCase
 *   before return so React KPI_DEFS (fundedBacklog, grossProfit) resolve correctly.
 * - qualify dry-run branch: wrapped in try/catch so a DB error returns
 *   a proper envelope instead of an unhandled crash.
 * - Route order preserved: /financial/kpis MUST stay above /financial/:kpi
 *   to prevent the param route from swallowing the kpis endpoint.
 *
 * Standard Envelope Contract:
 * {
 *   success:  boolean,
 *   workflow: string,   // n8n workflow identifier or "direct-db"
 *   action:   string,   // what action was performed
 *   dryRun:   boolean,  // true = preview only, no writes
 *   data:     any,      // the actual payload
 *   meta:     object,   // pagination, period, asOf, etc.
 *   error:    string|null
 * }
 */

const express = require("express");
const { Pool } = require("pg");
const router = express.Router();

const pool = new Pool({ connectionString: process.env.DATABASE_URL });

// ─── Envelope helpers ─────────────────────────────────────────────────────────
function envelope({ success = true, workflow = "direct-db", action = "", dryRun = false, data = null, meta = {}, error = null }) {
  return { success, workflow, action, dryRun, data, meta, error };
}

function errEnvelope(action, msg, workflow = "direct-db") {
  return envelope({ success: false, workflow, action, data: null, error: msg });
}

// ─── KPI key normalizer ───────────────────────────────────────────────────────
// FIX (Issue 1): Postgres returns snake_case. React KPI_DEFS use camelCase.
// Remap the two compound keys before returning the response.
function normalizekpiKeys(rawData) {
  if (!rawData) return rawData;
  const out = { ...rawData };
  if ("funded_backlog" in out) { out.fundedBacklog = out.funded_backlog; delete out.funded_backlog; }
  if ("gross_profit"   in out) { out.grossProfit   = out.gross_profit;   delete out.gross_profit;   }
  return out;
}

// ─── GET /api/financial/kpis ──────────────────────────────────────────────────
// IMPORTANT: This route MUST stay above /financial/:kpi.
// Express matches routes in declaration order; if :kpi came first, "kpis"
// would be captured as a param value and fail the VALID_KPIS guard.
router.get("/financial/kpis", async (req, res) => {
  try {
    const { rows } = await pool.query(`
      SELECT
        kpi_key,
        display_value,
        raw_value,
        delta_pct,
        delta_positive,
        period_label,
        as_of_date
      FROM financial_kpis_current
      WHERE kpi_key IN (
        'orders', 'sales', 'ebit', 'ros',
        'funded_backlog', 'backlog', 'gross_profit'
      )
    `);

    const rawData = {};
    let period = null;
    let asOf   = null;

    for (const row of rows) {
      rawData[row.kpi_key] = {
        value:    row.display_value,
        raw:      parseFloat(row.raw_value),
        delta:    row.delta_pct,
        positive: row.delta_positive,
      };
      period = period || row.period_label;
      asOf   = asOf   || row.as_of_date;
    }

    // FIX (Issue 1): remap snake_case keys to camelCase for React
    const data = normalizekpiKeys(rawData);

    return res.json(envelope({
      action: "get_kpis",
      data,
      meta: { period, asOf },
    }));
  } catch (e) {
    return res.status(500).json(errEnvelope("get_kpis", e.message));
  }
});

// ─── GET /api/financial/:kpi ──────────────────────────────────────────────────
// Drill-down detail for a specific KPI (Financial Bible pages).
// React KPI strip click-throughs route here via /financial-bible/:kpi.
// NOTE: stays BELOW /financial/kpis — do not reorder.
router.get("/financial/:kpi", async (req, res) => {
  const { kpi } = req.params;
  const VALID_KPIS = ["orders", "sales", "ebit", "ros", "funded_backlog", "backlog", "gross_profit"];

  // Also accept camelCase variants from React routes
  const CAMEL_TO_SNAKE = {
    fundedBacklog: "funded_backlog",
    grossProfit:   "gross_profit",
  };
  const resolvedKpi = CAMEL_TO_SNAKE[kpi] || kpi;

  if (!VALID_KPIS.includes(resolvedKpi)) {
    return res.status(400).json(errEnvelope("get_kpi_detail", `Invalid KPI key: ${kpi}`));
  }

  try {
    const { rows } = await pool.query(
      `SELECT * FROM financial_kpi_detail WHERE kpi_key = $1 ORDER BY period_date DESC LIMIT 24`,
      [resolvedKpi]
    );
    return res.json(envelope({
      action: "get_kpi_detail",
      data: rows,
      meta: { kpi: resolvedKpi },
    }));
  } catch (e) {
    return res.status(500).json(errEnvelope("get_kpi_detail", e.message));
  }
});

// ─── GET /api/launchpad/summary ───────────────────────────────────────────────
// Launchpad-specific summary strip counts.
router.get("/launchpad/summary", async (req, res) => {
  try {
    const { rows } = await pool.query(`
      SELECT
        (SELECT COUNT(*) FROM opportunities WHERE status = 'opportunity')                                         AS opportunity_count,
        (SELECT COUNT(*) FROM opportunities WHERE status = 'pipeline')                                            AS pipeline_count,
        (SELECT COUNT(*) FROM risks WHERE resolved_at IS NULL)                                                    AS active_risks,
        (SELECT COUNT(*) FROM decisions WHERE due_date <= CURRENT_DATE + 7 AND resolved_at IS NULL)               AS decisions_due,
        (SELECT COUNT(*) FROM opportunities WHERE due_date <= CURRENT_DATE + 7 AND status = 'opportunity')        AS due_soon,
        (SELECT COUNT(*) FROM opportunities WHERE fast_track = true AND status = 'opportunity')                   AS fast_track_signals
    `);
    const row = rows[0];
    return res.json(envelope({
      action: "get_launchpad_summary",
      data: {
        opportunityCount: parseInt(row.opportunity_count),
        pipelineCount:    parseInt(row.pipeline_count),
        activeRisks:      parseInt(row.active_risks),
        decisionsDue:     parseInt(row.decisions_due),
        dueSoon:          parseInt(row.due_soon),
        fastTrackSignals: parseInt(row.fast_track_signals),
      },
      meta: { asOf: new Date().toISOString().split("T")[0] },
    }));
  } catch (e) {
    return res.status(500).json(errEnvelope("get_launchpad_summary", e.message));
  }
});

// ─── GET /api/opportunities/top10 ────────────────────────────────────────────
// Top 10 scored opportunities (NOT pipeline).
// status = 'opportunity' enforced — pipeline rows excluded.
// FIX (Issue 2): aliased due_date → dueDate for React consistency.
router.get("/opportunities/top10", async (req, res) => {
  try {
    const { rows } = await pool.query(`
      SELECT
        id,
        title,
        department          AS dept,
        display_value       AS value,
        pwin,
        score,
        status,
        due_date            AS "dueDate"
      FROM opportunities
      WHERE status = 'opportunity'
        AND score IS NOT NULL
      ORDER BY score DESC
      LIMIT 10
    `);
    return res.json(envelope({
      action:   "get_top10_scored",
      workflow: "gda.ops.opportunities",
      data:     rows,
      meta: {
        asOf: new Date().toISOString().split("T")[0],
        note: "Opportunities only. Pipeline excluded until explicitly qualified.",
      },
    }));
  } catch (e) {
    return res.status(500).json(errEnvelope("get_top10_scored", e.message, "gda.ops.opportunities"));
  }
});

// ─── GET /api/opportunities/:id ───────────────────────────────────────────────
// Opportunity detail (Ops Tracker click-through from Launchpad).
// NOTE: keep below /opportunities/top10 — do not reorder.
router.get("/opportunities/:id", async (req, res) => {
  try {
    const { rows } = await pool.query(
      `SELECT * FROM opportunities WHERE id = $1`,
      [req.params.id]
    );
    if (!rows.length) {
      return res.status(404).json(errEnvelope("get_opportunity", `Opportunity ${req.params.id} not found`));
    }
    return res.json(envelope({ action: "get_opportunity", data: rows[0] }));
  } catch (e) {
    return res.status(500).json(errEnvelope("get_opportunity", e.message));
  }
});

// ─── POST /api/opportunities/:id/qualify ─────────────────────────────────────
// Qualifies an opportunity into pipeline.
// Write-capable — dryRun:true is the safe path and is the default.
// Set dryRun:false only after explicit user approval.
router.post("/opportunities/:id/qualify", async (req, res) => {
  const { dryRun = true } = req.body;
  const { id } = req.params;

  // ── Dry-run (preview) ──
  if (dryRun) {
    // FIX (Issue 7): wrap dry-run DB read in try/catch so a DB error
    // returns a proper envelope instead of an unhandled crash.
    try {
      const { rows } = await pool.query(
        `SELECT id, title, status FROM opportunities WHERE id = $1`,
        [id]
      );
      if (!rows.length) {
        return res.status(404).json(errEnvelope("qualify_opportunity", `Opportunity ${id} not found`));
      }
      const opp = rows[0];
      if (opp.status === "pipeline") {
        return res.json(envelope({
          success: false,
          action:  "qualify_opportunity",
          dryRun:  true,
          data:    null,
          error:   `${id} is already pipeline`,
        }));
      }
      return res.json(envelope({
        action: "qualify_opportunity",
        dryRun: true,
        data:   { id, title: opp.title, currentStatus: opp.status, projectedStatus: "pipeline" },
        meta:   { note: "DRY RUN — no write performed. Set dryRun:false to execute." },
      }));
    } catch (e) {
      return res.status(500).json(errEnvelope("qualify_opportunity", e.message));
    }
  }

  // ── Live write — requires explicit dryRun:false ──
  try {
    await pool.query(
      `UPDATE opportunities SET status = 'pipeline', qualified_at = NOW() WHERE id = $1`,
      [id]
    );
    return res.json(envelope({
      action: "qualify_opportunity",
      dryRun: false,
      data:   { id, status: "pipeline" },
    }));
  } catch (e) {
    return res.status(500).json(errEnvelope("qualify_opportunity", e.message));
  }
});

// ─── GET /api/health ──────────────────────────────────────────────────────────
router.get("/health", async (req, res) => {
  try {
    await pool.query("SELECT 1");
    return res.json(envelope({
      action: "health_check",
      data:   { db: "ok", api: "ok" },
      meta:   { ts: new Date().toISOString() },
    }));
  } catch (e) {
    return res.status(503).json(errEnvelope("health_check", `DB unreachable: ${e.message}`));
  }
});

module.exports = router;

/*
 * Mount in your Express app:
 *
 *   const gdaApi = require('./routes/gda-api-routes');
 *   app.use('/api', gdaApi);
 *
 * React calls (all relative, no secrets in browser):
 *   GET  /api/health                      → smoke check
 *   GET  /api/financial/kpis              → KPI strip (camelCase keys)
 *   GET  /api/financial/:kpi              → Financial Bible drill-down
 *   GET  /api/launchpad/summary           → Launchpad summary strip
 *   GET  /api/opportunities/top10         → Top 10 scored opportunities
 *   GET  /api/opportunities/:id           → Opportunity detail
 *   POST /api/opportunities/:id/qualify   → Qualify (dryRun:true required first)
 *
 * Route ordering is load-order dependent in Express — do not reorder:
 *   /financial/kpis    MUST be above /financial/:kpi
 *   /opportunities/top10 MUST be above /opportunities/:id
 */
