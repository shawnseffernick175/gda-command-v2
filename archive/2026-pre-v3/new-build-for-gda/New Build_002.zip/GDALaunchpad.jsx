/**
 * GDA Command Center — Launchpad
 * S-001 | Phase 1 | Rebuild
 *
 * Architecture rules enforced:
 * - All data calls go through /api/... routes (mockApi active for local dev)
 * - Standard JSON envelope: { success, workflow, action, dryRun, data, meta, error }
 * - No direct webhook calls from the browser
 * - No charts (Phase 1 constraint)
 * - Persistent financial KPI strip on every page
 * - Launchpad-specific summary strip below KPI strip
 * - Top 10 scoring opportunities (opportunities ≠ pipeline until qualified)
 * - Core tool navigation
 *
 * FIRST-RUN FIXES (S-001):
 * - KPI keys: reads both camelCase (mock) and snake_case (real API) — safe for either
 * - dueDate: reads both camelCase and snake_case from opportunity rows
 * - dry-run qualify: survives 404 response cleanly
 * - Production fetch wrappers are written and commented in; swap USE_MOCK to false to activate
 *
 * Production TODO:
 * - Set USE_MOCK = false to switch from mockApi to real fetch('/api/...')
 * - Wire KPI click-throughs to Financial Bible routes via React Router
 * - Wire opportunity rows to Ops Tracker detail routes
 * - Add React Router for full shell navigation
 */

import { useState, useEffect, useCallback } from "react";

// ─── Toggle: set false to use real /api/... endpoints ────────────────────────
const USE_MOCK = true;

// ─── Design tokens ──────────────────────────────────────────────────────────
const C = {
  bg:         "#070c14",
  surface:    "#0c1420",
  border:     "#1a2535",
  accent:     "#22c55e",
  accentDim:  "#15803d",
  warn:       "#f59e0b",
  danger:     "#ef4444",
  muted:      "#4a5568",
  text:       "#c8d6e5",
  textDim:    "#6a7a8a",
  textBright: "#e2eaf4",
  blue:       "#38bdf8",
  purple:     "#a78bfa",
  orange:     "#f97316",
};

const MONO = "'IBM Plex Mono', 'Courier New', monospace";
const SANS = "'IBM Plex Sans', system-ui, sans-serif";

// ─── Standard response envelope parser ──────────────────────────────────────
// Every API call must return: { success, workflow, action, dryRun, data, meta, error }
// This helper ensures React never guesses at blank/HTML/malformed responses.
function parseEnvelope(raw) {
  if (!raw || typeof raw !== "object") {
    return { success: false, data: null, error: "Malformed response (non-object)" };
  }
  if (raw.success === false) {
    return { success: false, data: null, error: raw.error || "Unknown API error" };
  }
  return { success: true, data: raw.data ?? null, meta: raw.meta ?? {}, error: null };
}

// ─── Mock API layer ──────────────────────────────────────────────────────────
// Active when USE_MOCK = true. Returns camelCase keys matching KPI_DEFS.
const mockApi = {
  async getKpis() {
    await new Promise(r => setTimeout(r, 600));
    return {
      success: true,
      workflow: "gda.financial.kpi",
      action:   "get_kpis",
      dryRun:   false,
      data: {
        orders:        { value: "$24.7M",  delta: "+8.2%",  positive: true  },
        sales:         { value: "$18.3M",  delta: "+3.1%",  positive: true  },
        ebit:          { value: "$2.1M",   delta: "-0.4%",  positive: false },
        ros:           { value: "11.5%",   delta: "+0.2pt", positive: true  },
        fundedBacklog: { value: "$41.2M",  delta: "+12.1%", positive: true  },
        backlog:       { value: "$67.8M",  delta: "+5.7%",  positive: true  },
        grossProfit:   { value: "$5.8M",   delta: "+1.9%",  positive: true  },
      },
      meta:  { asOf: "2026-05-05", period: "FY26 YTD" },
      error: null,
    };
  },

  async getLaunchpadSummary() {
    await new Promise(r => setTimeout(r, 400));
    return {
      success: true,
      workflow: "gda.launchpad.summary",
      action:   "get_summary",
      dryRun:   false,
      data: {
        activeRisks:      3,
        decisionsDue:     2,
        dueSoon:          5,
        fastTrackSignals: 1,
        pipelineCount:    7,
        opportunityCount: 43,
      },
      meta:  { asOf: "2026-05-05" },
      error: null,
    };
  },

  async getTop10Opportunities() {
    await new Promise(r => setTimeout(r, 800));
    return {
      success: true,
      workflow: "gda.ops.opportunities",
      action:   "get_top10_scored",
      dryRun:   false,
      data: [
        { id: "OPP-0041", title: "SOCOM SEAL Delivery Vehicle Systems Support",        dept: "SOCOM",    value: "$8.2M",  pwin: 72, score: 94, status: "opportunity", dueDate: "2026-06-15" },
        { id: "OPP-0038", title: "TRADOC Training Systems Modernization — Ft. Eustis", dept: "TRADOC",   value: "$5.6M",  pwin: 68, score: 91, status: "opportunity", dueDate: "2026-07-02" },
        { id: "OPP-0035", title: "PEO STRI Simulation Range Support Services",         dept: "PEO STRI", value: "$3.9M",  pwin: 81, score: 89, status: "opportunity", dueDate: "2026-05-28" },
        { id: "OPP-0029", title: "Army Futures Command Data Analytics BPA",            dept: "AFC",      value: "$12.1M", pwin: 45, score: 85, status: "opportunity", dueDate: "2026-08-10" },
        { id: "OPP-0044", title: "CYBERCOM Zero Trust Network Architecture",           dept: "CYBERCOM", value: "$6.7M",  pwin: 59, score: 83, status: "opportunity", dueDate: "2026-06-30" },
        { id: "OPP-0022", title: "INDOPACOM ISR Integration Technical Support",        dept: "INDOPACOM",value: "$4.1M",  pwin: 77, score: 81, status: "opportunity", dueDate: "2026-07-18" },
        { id: "OPP-0051", title: "DLA Logistics Automation & AI Services IDIQ",        dept: "DLA",      value: "$9.3M",  pwin: 38, score: 78, status: "opportunity", dueDate: "2026-09-01" },
        { id: "OPP-0033", title: "SOCOM Irregular Warfare Analytics Support",          dept: "SOCOM",    value: "$2.8M",  pwin: 84, score: 76, status: "opportunity", dueDate: "2026-05-30" },
        { id: "OPP-0047", title: "Army G-6 Network Operations Center Staffing",        dept: "ARMY G-6", value: "$1.9M",  pwin: 91, score: 74, status: "opportunity", dueDate: "2026-06-05" },
        { id: "OPP-0039", title: "TRADOC Synthetic Training Environment Integration",  dept: "TRADOC",   value: "$7.4M",  pwin: 52, score: 71, status: "opportunity", dueDate: "2026-08-22" },
      ],
      meta:  { totalScored: 43, asOf: "2026-05-05" },
      error: null,
    };
  },
};

// ─── Production API layer ─────────────────────────────────────────────────────
// Active when USE_MOCK = false. Calls real /api/... routes only.
// The API normalizes snake_case DB keys to camelCase before returning.
const realApi = {
  async getKpis() {
    const res = await fetch("/api/financial/kpis");
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return res.json();
  },
  async getLaunchpadSummary() {
    const res = await fetch("/api/launchpad/summary");
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return res.json();
  },
  async getTop10Opportunities() {
    const res = await fetch("/api/opportunities/top10");
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return res.json();
  },
};

// Active API — swap USE_MOCK to change source
const api = USE_MOCK ? mockApi : realApi;

// ─── KPI key normalizer ───────────────────────────────────────────────────────
// FIX (Issue 1): The real API may return snake_case keys from Postgres.
// This function reads either shape so KPI_DEFS (camelCase) always resolves.
function normalizeKpiData(raw) {
  if (!raw) return raw;
  const MAP = {
    funded_backlog: "fundedBacklog",
    gross_profit:   "grossProfit",
  };
  const out = { ...raw };
  for (const [snake, camel] of Object.entries(MAP)) {
    if (snake in raw && !(camel in raw)) {
      out[camel] = raw[snake];
    }
  }
  return out;
}

// ─── Opportunity due date normalizer ─────────────────────────────────────────
// FIX (Issue 2): Real API returns due_date (snake_case). Mock returns dueDate.
// Read whichever is present.
function getDueDate(opp) {
  return opp.dueDate || opp.due_date || null;
}

// ─── KPI definitions ─────────────────────────────────────────────────────────
// Click-through routes wired for React Router in production.
const KPI_DEFS = [
  { key: "orders",        label: "ORDERS",         route: "/financial-bible/orders"         },
  { key: "sales",         label: "SALES",          route: "/financial-bible/sales"          },
  { key: "ebit",          label: "EBIT",           route: "/financial-bible/ebit"           },
  { key: "ros",           label: "ROS",            route: "/financial-bible/ros"            },
  { key: "fundedBacklog", label: "FUNDED BACKLOG", route: "/financial-bible/funded-backlog" },
  { key: "backlog",       label: "BACKLOG",        route: "/financial-bible/backlog"        },
  { key: "grossProfit",   label: "GROSS PROFIT",   route: "/financial-bible/gross-profit"   },
];

// ─── Core tool nav definitions ────────────────────────────────────────────────
const CORE_TOOLS = [
  { id: "ops-tracker",       label: "Ops Tracker",       icon: "◈", desc: "Opportunity discovery & management", route: "/ops-tracker"       },
  { id: "financial-bible",   label: "Financial Bible",   icon: "◉", desc: "KPI drill-downs & financial detail", route: "/financial-bible"   },
  { id: "prompt-architect",  label: "Prompt Architect",  icon: "◆", desc: "Operational prompt generation",      route: "/prompt-architect"  },
  { id: "compliance-matrix", label: "Compliance Matrix", icon: "◇", desc: "Compliance workspace",               route: "/compliance-matrix" },
  { id: "proposal-review",   label: "Proposal Review",   icon: "◐", desc: "Proposal evaluation & review",       route: "/proposal-review"   },
];

// ─── Dept color map ───────────────────────────────────────────────────────────
const DEPT_COLORS = {
  "SOCOM":    "#38bdf8",
  "TRADOC":   "#a78bfa",
  "PEO STRI": "#f97316",
  "AFC":      "#22c55e",
  "CYBERCOM": "#ef4444",
  "INDOPACOM":"#f59e0b",
  "DLA":      "#34d399",
  "ARMY G-6": "#c084fc",
};

// ─── Inline styles ────────────────────────────────────────────────────────────
const s = {
  page: {
    minHeight: "100vh",
    background: C.bg,
    color: C.text,
    fontFamily: MONO,
    overflowX: "hidden",
  },
  kpiStrip: {
    background: C.surface,
    borderBottom: `1px solid ${C.border}`,
    display: "flex",
    alignItems: "stretch",
    overflow: "auto",
  },
  kpiCell: {
    flex: "1 0 auto",
    minWidth: 130,
    padding: "10px 18px",
    borderRight: `1px solid ${C.border}`,
    cursor: "pointer",
    transition: "background 0.15s",
  },
  summaryStrip: {
    background: "#0a111e",
    borderBottom: `1px solid ${C.border}`,
    display: "flex",
    alignItems: "center",
    gap: 0,
    overflow: "auto",
  },
  summaryCell: {
    flex: "1 0 auto",
    minWidth: 140,
    padding: "8px 18px",
    borderRight: `1px solid ${C.border}`,
  },
  main: {
    maxWidth: 1200,
    margin: "0 auto",
    padding: "28px 24px 60px",
  },
  card: {
    background: C.surface,
    border: `1px solid ${C.border}`,
    borderRadius: 4,
    marginBottom: 20,
    overflow: "hidden",
  },
  cardHeader: {
    padding: "12px 20px",
    borderBottom: `1px solid ${C.border}`,
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
  },
  tableRow: (i) => ({
    display: "grid",
    gridTemplateColumns: "90px 1fr 120px 80px 60px 70px 80px",
    alignItems: "center",
    padding: "10px 20px",
    borderBottom: `1px solid ${C.border}`,
    background: i % 2 === 0 ? "transparent" : "rgba(255,255,255,0.015)",
    gap: 12,
    cursor: "pointer",
    transition: "background 0.1s",
  }),
};

// ─── Reusable components ──────────────────────────────────────────────────────

function Label({ children, color = C.accent, small }) {
  return (
    <span style={{
      fontFamily: MONO,
      fontSize: small ? 9 : 10,
      fontWeight: 700,
      letterSpacing: "0.15em",
      color,
      textTransform: "uppercase",
    }}>{children}</span>
  );
}

function Spinner() {
  return <span style={{ display: "inline-block", animation: "spin 1s linear infinite" }}>⟳</span>;
}

function ErrorBadge({ msg }) {
  return (
    <span style={{
      fontFamily: MONO, fontSize: 10, color: C.danger,
      background: `${C.danger}18`, border: `1px solid ${C.danger}44`,
      padding: "2px 8px", borderRadius: 2, letterSpacing: "0.08em",
    }}>
      ⚠ {msg}
    </span>
  );
}

function ScoreBar({ score }) {
  const color = score >= 85 ? C.accent : score >= 70 ? C.warn : C.danger;
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
      <div style={{ flex: 1, height: 4, background: C.border, borderRadius: 2, overflow: "hidden" }}>
        <div style={{ width: `${score}%`, height: "100%", background: color, transition: "width 0.8s ease" }} />
      </div>
      <span style={{ fontFamily: MONO, fontSize: 10, color, fontWeight: 700, minWidth: 26 }}>{score}</span>
    </div>
  );
}

// ─── KPI Strip (persistent, financial-only) ───────────────────────────────────
function KpiStrip({ kpis, loading, error, period, onNavigate }) {
  const [hovered, setHovered] = useState(null);

  return (
    <div style={s.kpiStrip}>
      {/* Period tag */}
      <div style={{
        display: "flex", alignItems: "center", padding: "0 16px",
        borderRight: `1px solid ${C.border}`, flexShrink: 0,
      }}>
        <div>
          <Label color={C.accentDim} small>GDA</Label>
          <div style={{ fontFamily: MONO, fontSize: 9, color: C.muted, letterSpacing: "0.1em", marginTop: 1 }}>
            {period || "FY26 YTD"}
          </div>
        </div>
      </div>

      {KPI_DEFS.map(def => {
        const kpi = kpis?.[def.key];
        const pos = kpi?.positive;
        return (
          <div
            key={def.key}
            style={{
              ...s.kpiCell,
              background: hovered === def.key ? "rgba(34,197,94,0.04)" : "transparent",
            }}
            onMouseEnter={() => setHovered(def.key)}
            onMouseLeave={() => setHovered(null)}
            onClick={() => onNavigate(def.route)}
            title={`Navigate to ${def.label} detail`}
          >
            <Label color={C.textDim} small>{def.label}</Label>
            <div style={{
              fontFamily: MONO, fontSize: 15, fontWeight: 700,
              color: C.textBright, marginTop: 3, letterSpacing: "0.02em",
            }}>
              {loading ? <Spinner /> : error ? "—" : kpi?.value ?? "—"}
            </div>
            {!loading && !error && kpi?.delta && (
              <div style={{
                fontFamily: MONO, fontSize: 9, fontWeight: 600, marginTop: 2,
                color: pos ? C.accent : C.danger, letterSpacing: "0.08em",
              }}>
                {kpi.delta}
              </div>
            )}
          </div>
        );
      })}

      {error && (
        <div style={{ display: "flex", alignItems: "center", padding: "0 16px" }}>
          <ErrorBadge msg="KPI load failed" />
        </div>
      )}
    </div>
  );
}

// ─── Launchpad Summary Strip ──────────────────────────────────────────────────
function LaunchpadSummaryStrip({ summary, loading, error }) {
  const cells = [
    { label: "OPPORTUNITIES", value: summary?.opportunityCount, color: C.blue   },
    { label: "PIPELINE",      value: summary?.pipelineCount,    color: C.accent },
    { label: "ACTIVE RISKS",  value: summary?.activeRisks,      color: C.danger },
    { label: "DECISIONS DUE", value: summary?.decisionsDue,     color: C.warn   },
    { label: "DUE SOON",      value: summary?.dueSoon,          color: C.orange },
    { label: "FAST TRACK",    value: summary?.fastTrackSignals, color: C.purple },
  ];

  return (
    <div style={s.summaryStrip}>
      <div style={{
        padding: "6px 14px",
        borderRight: `1px solid ${C.border}`,
        flexShrink: 0,
        display: "flex", alignItems: "center",
      }}>
        <Label color={C.muted} small>LAUNCHPAD</Label>
      </div>
      {cells.map(c => (
        <div key={c.label} style={s.summaryCell}>
          <Label color={c.color} small>{c.label}</Label>
          <div style={{
            fontFamily: MONO, fontSize: 14, fontWeight: 700,
            color: c.color, marginTop: 1,
          }}>
            {loading ? "—" : error ? "—" : c.value ?? "—"}
          </div>
        </div>
      ))}
    </div>
  );
}

// ─── Top 10 Opportunities table ───────────────────────────────────────────────
function Top10Table({ opps, loading, error, onNavigate }) {
  if (loading) {
    return (
      <div style={{ padding: "32px 20px", textAlign: "center", color: C.muted }}>
        <Spinner /> <span style={{ fontFamily: MONO, fontSize: 11, marginLeft: 8 }}>FETCHING SCORED OPPORTUNITIES...</span>
      </div>
    );
  }
  if (error) {
    return <div style={{ padding: "20px" }}><ErrorBadge msg={error} /></div>;
  }
  if (!opps?.length) {
    return <div style={{ padding: "20px", fontFamily: MONO, fontSize: 11, color: C.muted }}>No opportunities found.</div>;
  }

  return (
    <div>
      {/* Table header */}
      <div style={{
        display: "grid",
        gridTemplateColumns: "90px 1fr 120px 80px 60px 70px 80px",
        padding: "8px 20px",
        borderBottom: `1px solid ${C.border}`,
        gap: 12,
        background: "rgba(0,0,0,0.2)",
      }}>
        {["ID", "OPPORTUNITY", "DEPARTMENT", "VALUE", "PWIN", "SCORE", "DUE"].map(h => (
          <Label key={h} color={C.muted} small>{h}</Label>
        ))}
      </div>

      {opps.map((opp, i) => {
        const deptColor = DEPT_COLORS[opp.dept] || C.muted;
        const pwinColor = opp.pwin >= 70 ? C.accent : opp.pwin >= 50 ? C.warn : C.danger;
        // FIX (Issue 2): read either dueDate or due_date from the row
        const rawDate = getDueDate(opp);
        const dueParts = rawDate?.split("-") || [];
        const dueDisplay = dueParts.length === 3 ? `${dueParts[1]}/${dueParts[2]}` : rawDate;

        return (
          <div
            key={opp.id}
            style={s.tableRow(i)}
            onClick={() => onNavigate(`/ops-tracker/${opp.id}`)}
            onMouseEnter={e => e.currentTarget.style.background = "rgba(34,197,94,0.04)"}
            onMouseLeave={e => e.currentTarget.style.background = i % 2 === 0 ? "transparent" : "rgba(255,255,255,0.015)"}
          >
            <span style={{ fontFamily: MONO, fontSize: 10, color: C.muted, letterSpacing: "0.04em" }}>{opp.id}</span>
            <span style={{ fontFamily: SANS, fontSize: 11, color: C.textBright, lineHeight: 1.4, fontWeight: 500 }}>
              {opp.title}
            </span>
            <span style={{
              fontFamily: MONO, fontSize: 9, fontWeight: 700,
              color: deptColor, letterSpacing: "0.08em",
              background: `${deptColor}18`,
              padding: "2px 6px", borderRadius: 2,
              whiteSpace: "nowrap",
            }}>
              {opp.dept}
            </span>
            <span style={{ fontFamily: MONO, fontSize: 11, color: C.text, fontWeight: 600 }}>{opp.value}</span>
            <span style={{ fontFamily: MONO, fontSize: 11, color: pwinColor, fontWeight: 700 }}>{opp.pwin}%</span>
            <ScoreBar score={opp.score} />
            <span style={{ fontFamily: MONO, fontSize: 10, color: C.muted }}>{dueDisplay || "—"}</span>
          </div>
        );
      })}

      {/* Footer — opportunity ≠ pipeline guard */}
      <div style={{
        padding: "8px 20px",
        borderTop: `1px solid ${C.border}`,
        fontFamily: MONO, fontSize: 9, color: C.muted,
        letterSpacing: "0.08em",
        background: "rgba(0,0,0,0.15)",
      }}>
        ◈ OPPORTUNITIES ONLY — AN OPPORTUNITY DOES NOT BECOME PIPELINE UNTIL EXPLICITLY QUALIFIED
      </div>
    </div>
  );
}

// ─── Core Tool Nav ────────────────────────────────────────────────────────────
function CoreToolNav({ onNavigate }) {
  const [hovered, setHovered] = useState(null);
  return (
    <div style={{
      display: "grid",
      gridTemplateColumns: "repeat(auto-fill, minmax(200px, 1fr))",
      gap: 12,
    }}>
      {CORE_TOOLS.map(tool => (
        <div
          key={tool.id}
          onClick={() => onNavigate(tool.route)}
          onMouseEnter={() => setHovered(tool.id)}
          onMouseLeave={() => setHovered(null)}
          style={{
            background: hovered === tool.id ? "rgba(34,197,94,0.06)" : C.surface,
            border: `1px solid ${hovered === tool.id ? C.accent + "66" : C.border}`,
            borderRadius: 4,
            padding: "16px 18px",
            cursor: "pointer",
            transition: "all 0.15s",
          }}
        >
          <div style={{ fontFamily: MONO, fontSize: 18, color: C.accent, marginBottom: 8 }}>{tool.icon}</div>
          <div style={{ fontFamily: SANS, fontSize: 12, fontWeight: 700, color: C.textBright, marginBottom: 4 }}>
            {tool.label}
          </div>
          <div style={{ fontFamily: SANS, fontSize: 11, color: C.textDim, lineHeight: 1.5 }}>{tool.desc}</div>
          <div style={{
            marginTop: 10, fontFamily: MONO, fontSize: 9,
            color: C.accentDim, letterSpacing: "0.12em",
          }}>
            ENTER →
          </div>
        </div>
      ))}
    </div>
  );
}

// ─── Main Launchpad Component ─────────────────────────────────────────────────
export default function GDALaunchpad({ onNavigate: navProp }) {
  // Default nav handler — replace with React Router's navigate() in production
  const onNavigate = navProp || ((route) => console.log("[GDA Navigate]", route));

  const [kpis,     setKpis]     = useState(null);
  const [kpiMeta,  setKpiMeta]  = useState(null);
  const [kpiErr,   setKpiErr]   = useState(null);
  const [kpiLoad,  setKpiLoad]  = useState(true);

  const [summary,  setSummary]  = useState(null);
  const [sumErr,   setSumErr]   = useState(null);
  const [sumLoad,  setSumLoad]  = useState(true);

  const [opps,     setOpps]     = useState(null);
  const [oppsErr,  setOppsErr]  = useState(null);
  const [oppsLoad, setOppsLoad] = useState(true);

  const [now, setNow] = useState(new Date());

  // Clock
  useEffect(() => {
    const t = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(t);
  }, []);

  const loadKpis = useCallback(async () => {
    setKpiLoad(true); setKpiErr(null);
    try {
      const raw = await api.getKpis();
      const { success, data, meta, error } = parseEnvelope(raw);
      if (success) {
        // FIX (Issue 1): normalize snake_case API keys to camelCase
        setKpis(normalizeKpiData(data));
        setKpiMeta(meta);
      } else {
        setKpiErr(error);
      }
    } catch (e) {
      setKpiErr(e.message);
    } finally {
      setKpiLoad(false);
    }
  }, []);

  const loadSummary = useCallback(async () => {
    setSumLoad(true); setSumErr(null);
    try {
      const raw = await api.getLaunchpadSummary();
      const { success, data, error } = parseEnvelope(raw);
      if (success) setSummary(data);
      else setSumErr(error);
    } catch (e) {
      setSumErr(e.message);
    } finally {
      setSumLoad(false);
    }
  }, []);

  const loadOpps = useCallback(async () => {
    setOppsLoad(true); setOppsErr(null);
    try {
      const raw = await api.getTop10Opportunities();
      const { success, data, error } = parseEnvelope(raw);
      if (success) setOpps(data);
      else setOppsErr(error);
    } catch (e) {
      setOppsErr(e.message);
    } finally {
      setOppsLoad(false);
    }
  }, []);

  useEffect(() => {
    loadKpis();
    loadSummary();
    loadOpps();
  }, [loadKpis, loadSummary, loadOpps]);

  const timeStr = now.toLocaleTimeString("en-US", { hour12: false });
  const dateStr = now.toLocaleDateString("en-US", {
    weekday: "short", month: "short", day: "numeric", year: "numeric",
  }).toUpperCase();

  return (
    <div style={s.page}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@400;500;600;700&family=IBM+Plex+Sans:wght@400;500;600;700&display=swap');
        * { box-sizing: border-box; }
        @keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
        @keyframes fadeUp { from { opacity: 0; transform: translateY(8px); } to { opacity: 1; transform: translateY(0); } }
        .gda-fade { animation: fadeUp 0.4s ease both; }
      `}</style>

      {/* ── Persistent KPI Strip ── */}
      <KpiStrip
        kpis={kpis}
        loading={kpiLoad}
        error={kpiErr}
        period={kpiMeta?.period}
        onNavigate={onNavigate}
      />

      {/* ── Launchpad Summary Strip ── */}
      <LaunchpadSummaryStrip
        summary={summary}
        loading={sumLoad}
        error={sumErr}
      />

      {/* ── Page Header ── */}
      <div style={{
        background: C.surface,
        borderBottom: `1px solid ${C.border}`,
        padding: "14px 24px",
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center",
      }}>
        <div>
          <div style={{ fontFamily: MONO, fontSize: 9, color: C.muted, letterSpacing: "0.2em", marginBottom: 3 }}>
            ENVISION INNOVATIVE SOLUTIONS · EIS/PD SYSTEMS · GEORGETOWN DEFENSE ANALYTICS
          </div>
          <div style={{ fontFamily: SANS, fontSize: 18, fontWeight: 700, color: C.textBright, letterSpacing: "0.02em" }}>
            GDA Command Center
          </div>
        </div>
        <div style={{ textAlign: "right" }}>
          <div style={{ fontFamily: MONO, fontSize: 18, fontWeight: 700, color: C.accent, letterSpacing: "0.04em" }}>
            {timeStr}
          </div>
          <div style={{ fontFamily: MONO, fontSize: 9, color: C.muted, letterSpacing: "0.1em", marginTop: 2 }}>
            {dateStr}
          </div>
        </div>
      </div>

      {/* ── Main Content ── */}
      <div style={s.main}>

        {/* Top 10 Opportunities */}
        <div className="gda-fade" style={{ ...s.card, animationDelay: "0.05s" }}>
          <div style={s.cardHeader}>
            <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
              <Label>TOP 10 SCORED OPPORTUNITIES</Label>
              {oppsLoad && <Spinner />}
            </div>
            <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
              <Label color={C.muted} small>SCORED · NOT PIPELINE</Label>
              <button
                onClick={loadOpps}
                style={{
                  fontFamily: MONO, fontSize: 9, color: C.accent,
                  background: "transparent", border: `1px solid ${C.accent}44`,
                  padding: "3px 8px", borderRadius: 2, cursor: "pointer",
                  letterSpacing: "0.1em",
                }}
              >
                REFRESH
              </button>
              <button
                onClick={() => onNavigate("/ops-tracker")}
                style={{
                  fontFamily: MONO, fontSize: 9, color: C.textDim,
                  background: "transparent", border: `1px solid ${C.border}`,
                  padding: "3px 8px", borderRadius: 2, cursor: "pointer",
                  letterSpacing: "0.1em",
                }}
              >
                VIEW ALL →
              </button>
            </div>
          </div>
          <Top10Table opps={opps} loading={oppsLoad} error={oppsErr} onNavigate={onNavigate} />
        </div>

        {/* Platform Summary & Alerts row */}
        <div className="gda-fade" style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16, animationDelay: "0.1s" }}>

          {/* Active risks / decisions / due-soon */}
          <div style={s.card}>
            <div style={s.cardHeader}>
              <Label>PLATFORM ALERTS</Label>
              {sumLoad && <Spinner />}
            </div>
            <div style={{ padding: "16px 20px" }}>
              {[
                { label: "Active Risks",      value: summary?.activeRisks,      color: C.danger, route: "/ops-tracker?filter=risks"      },
                { label: "Decisions Due",     value: summary?.decisionsDue,     color: C.warn,   route: "/ops-tracker?filter=decisions"  },
                { label: "Due Soon (7 days)", value: summary?.dueSoon,          color: C.orange, route: "/ops-tracker?filter=due-soon"   },
                { label: "Fast Track Signals",value: summary?.fastTrackSignals, color: C.purple, route: "/ops-tracker?filter=fast-track" },
              ].map(item => (
                <div
                  key={item.label}
                  onClick={() => onNavigate(item.route)}
                  style={{
                    display: "flex", justifyContent: "space-between", alignItems: "center",
                    padding: "9px 0", borderBottom: `1px solid ${C.border}`,
                    cursor: "pointer",
                  }}
                  onMouseEnter={e => e.currentTarget.style.opacity = "0.75"}
                  onMouseLeave={e => e.currentTarget.style.opacity = "1"}
                >
                  <span style={{ fontFamily: SANS, fontSize: 11, color: C.textDim }}>{item.label}</span>
                  <span style={{
                    fontFamily: MONO, fontSize: 14, fontWeight: 700, color: item.color,
                    minWidth: 32, textAlign: "right",
                  }}>
                    {sumLoad ? "—" : item.value ?? "—"}
                  </span>
                </div>
              ))}
              <div style={{ paddingTop: 8 }}>
                <div style={{ fontFamily: MONO, fontSize: 9, color: C.muted, letterSpacing: "0.1em" }}>
                  OPPORTUNITIES: {sumLoad ? "—" : summary?.opportunityCount ?? "—"} &nbsp;·&nbsp;
                  PIPELINE: {sumLoad ? "—" : summary?.pipelineCount ?? "—"}
                </div>
              </div>
            </div>
          </div>

          {/* Business news placeholder */}
          <div style={s.card}>
            <div style={s.cardHeader}>
              <Label>RELEVANT NEWS</Label>
              <Label color={C.muted} small>PLACEHOLDER · INTEL FEED IN PHASE 5</Label>
            </div>
            <div style={{ padding: "16px 20px" }}>
              {[
                "DoD releases FY27 budget request — S&T funding up 12%",
                "SOCOM announces next-gen ISR vehicle RFP pre-solicitation",
                "TRADOC Synthetic Training Env expansion accelerates",
                "Army OTA pipeline — AFC awards 23 prototype agreements",
              ].map((headline, i) => (
                <div key={i} style={{
                  padding: "8px 0",
                  borderBottom: i < 3 ? `1px solid ${C.border}` : "none",
                  display: "flex", gap: 10, alignItems: "flex-start",
                }}>
                  <span style={{ fontFamily: MONO, fontSize: 10, color: C.muted, flexShrink: 0, marginTop: 1 }}>
                    {String(i + 1).padStart(2, "0")}
                  </span>
                  <span style={{ fontFamily: SANS, fontSize: 11, color: C.textDim, lineHeight: 1.5 }}>
                    {headline}
                  </span>
                </div>
              ))}
              <div style={{ paddingTop: 10 }}>
                <span style={{
                  fontFamily: MONO, fontSize: 9, color: C.muted,
                  background: `${C.muted}18`, border: `1px solid ${C.border}`,
                  padding: "3px 8px", borderRadius: 2, letterSpacing: "0.1em",
                }}>
                  STATIC PLACEHOLDER — LIVE INTEL WIRED IN PHASE 5
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Core Tools Nav */}
        <div className="gda-fade" style={{ animationDelay: "0.15s" }}>
          <div style={{ marginBottom: 12, display: "flex", alignItems: "center", justifyContent: "space-between" }}>
            <Label>CORE TOOLS</Label>
            <Label color={C.muted} small>PHASE 1 — 5 PRIMARY MODULES</Label>
          </div>
          <CoreToolNav onNavigate={onNavigate} />
        </div>

      </div>

      {/* Footer */}
      <div style={{
        borderTop: `1px solid ${C.border}`,
        padding: "10px 24px",
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center",
        background: C.surface,
      }}>
        <span style={{ fontFamily: MONO, fontSize: 9, color: C.muted, letterSpacing: "0.12em" }}>
          GDA COMMAND CENTER · EIS/PD SYSTEMS · RIVERSTONE ENTERPRISE SOLUTIONS
        </span>
        <span style={{ fontFamily: MONO, fontSize: 9, color: C.muted, letterSpacing: "0.1em" }}>
          UNCLASSIFIED // FOR OFFICIAL USE ONLY
        </span>
      </div>
    </div>
  );
}
