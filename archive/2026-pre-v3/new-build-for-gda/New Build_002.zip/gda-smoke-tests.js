#!/usr/bin/env node
/**
 * GDA Rebuild — Smoke + API Contract Tests
 * S-001 | Phase 1
 *
 * Run: node gda-smoke-tests.js [base_url]
 * Example: node gda-smoke-tests.js https://gda.yourdomain.com
 * Default: http://localhost:3001
 *
 * REQUIRES: Node 18+ (uses global fetch).
 * If on Node 16 or older: npm install node-fetch and add:
 *   const fetch = require('node-fetch');
 *
 * Test classes covered:
 *  1. Smoke    — endpoints respond, no 5xx
 *  2. Contract — every response has all standard envelope fields
 *  3. Data     — shape and business rules (≤10 rows, no pipeline in top10, 7 KPI keys)
 *  4. Guard    — invalid KPI returns 400 with success:false
 *  5. Dry-run  — qualify endpoint tested with dryRun:true (write-capable, safe path)
 *
 * Failures print in plain English.
 * Exit code 0 = all pass. Exit code 1 = one or more failures.
 *
 * FIRST-RUN FIXES (S-001):
 * - KPI key check accepts both camelCase (fundedBacklog) and snake_case
 *   (funded_backlog) so the test survives either API normalization state.
 * - Node version guard added with clear plain-English message.
 * - All test blocks already had try/catch — confirmed clean.
 */

// ─── Node version guard ───────────────────────────────────────────────────────
const [major] = process.versions.node.split(".").map(Number);
if (major < 18) {
  console.error(
    `\nERROR: Node ${process.versions.node} detected. This test runner requires Node 18+\n` +
    `       because it uses the built-in global fetch API.\n` +
    `       Either upgrade Node or add node-fetch:\n` +
    `         npm install node-fetch\n` +
    `       Then add at the top of this file:\n` +
    `         const fetch = require('node-fetch');\n`
  );
  process.exit(1);
}

const BASE = process.argv[2] || "http://localhost:3001";

let passed = 0;
let failed = 0;
const failures = [];

// ─── Helpers ──────────────────────────────────────────────────────────────────
function pass(name) {
  passed++;
  console.log(`  ✓  ${name}`);
}

function fail(name, reason) {
  failed++;
  failures.push({ name, reason });
  console.log(`  ✗  ${name}`);
  console.log(`     → ${reason}`);
}

async function get(path) {
  const res = await fetch(`${BASE}${path}`);
  const json = await res.json();
  return { status: res.status, body: json };
}

async function post(path, body) {
  const res = await fetch(`${BASE}${path}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  const json = await res.json();
  return { status: res.status, body: json };
}

// ─── Contract validator ───────────────────────────────────────────────────────
function checkEnvelope(name, body) {
  const required = ["success", "workflow", "action", "dryRun", "data", "meta", "error"];
  const missing = required.filter(k => !(k in body));
  if (missing.length) {
    fail(`${name} — envelope contract`, `Missing fields: ${missing.join(", ")}`);
    return false;
  }
  pass(`${name} — envelope contract`);
  return true;
}

// ─── Tests ────────────────────────────────────────────────────────────────────
async function runTests() {
  console.log(`\nGDA Smoke + API Contract Tests`);
  console.log(`Base: ${BASE}`);
  console.log(`Node: ${process.versions.node}`);
  console.log(`${"─".repeat(60)}\n`);

  // ── 1. Health check ──
  console.log("[1] Health check");
  try {
    const { status, body } = await get("/api/health");
    if (status !== 200) fail("GET /api/health — status", `Expected 200, got ${status}`);
    else pass("GET /api/health — status 200");
    checkEnvelope("GET /api/health", body);
    if (body.data?.db !== "ok") fail("GET /api/health — db", `db field not 'ok': ${body.data?.db}`);
    else pass("GET /api/health — db ok");
  } catch (e) {
    fail("GET /api/health", `Request failed: ${e.message}`);
  }
  console.log();

  // ── 2. KPI strip ──
  console.log("[2] Financial KPIs");
  try {
    const { status, body } = await get("/api/financial/kpis");
    if (status !== 200) fail("GET /api/financial/kpis — status", `Expected 200, got ${status}`);
    else pass("GET /api/financial/kpis — status 200");
    if (checkEnvelope("GET /api/financial/kpis", body)) {
      // Accept both camelCase (normalized by API) and snake_case (raw DB)
      // so this test survives either state during transition.
      const REQUIRED_KPIS = ["orders", "sales", "ebit", "ros", "funded_backlog", "backlog", "gross_profit"];
      const keys = Object.keys(body.data || {});
      const missing = REQUIRED_KPIS.filter(snake => {
        const camel = snake.replace(/_([a-z])/g, (_, c) => c.toUpperCase());
        return !keys.includes(snake) && !keys.includes(camel);
      });
      if (missing.length) {
        fail("GET /api/financial/kpis — KPI keys", `Missing (checked both snake_case and camelCase): ${missing.join(", ")}`);
      } else {
        pass("GET /api/financial/kpis — all 7 KPI keys present");
      }
    }
  } catch (e) {
    fail("GET /api/financial/kpis", `Request failed: ${e.message}`);
  }
  console.log();

  // ── 3. Launchpad summary ──
  console.log("[3] Launchpad Summary Strip");
  try {
    const { status, body } = await get("/api/launchpad/summary");
    if (status !== 200) fail("GET /api/launchpad/summary — status", `Expected 200, got ${status}`);
    else pass("GET /api/launchpad/summary — status 200");
    if (checkEnvelope("GET /api/launchpad/summary", body)) {
      const d = body.data || {};
      const REQUIRED = ["opportunityCount", "pipelineCount", "activeRisks", "decisionsDue", "dueSoon", "fastTrackSignals"];
      const missing = REQUIRED.filter(k => !(k in d));
      if (missing.length) fail("GET /api/launchpad/summary — fields", `Missing: ${missing.join(", ")}`);
      else pass("GET /api/launchpad/summary — all fields present");
    }
  } catch (e) {
    fail("GET /api/launchpad/summary", `Request failed: ${e.message}`);
  }
  console.log();

  // ── 4. Top 10 opportunities ──
  console.log("[4] Top 10 Opportunities");
  try {
    const { status, body } = await get("/api/opportunities/top10");
    if (status !== 200) fail("GET /api/opportunities/top10 — status", `Expected 200, got ${status}`);
    else pass("GET /api/opportunities/top10 — status 200");
    if (checkEnvelope("GET /api/opportunities/top10", body)) {
      const data = body.data;
      if (!Array.isArray(data)) {
        fail("GET /api/opportunities/top10 — data type", "data is not an array");
      } else {
        pass("GET /api/opportunities/top10 — data is array");
        if (data.length > 10) {
          fail("GET /api/opportunities/top10 — count", `Returned ${data.length} items, expected ≤10`);
        } else {
          pass(`GET /api/opportunities/top10 — count: ${data.length} (≤10)`);
        }
        // Core business rule: opportunity ≠ pipeline until explicitly qualified
        const pipelineRows = data.filter(r => r.status === "pipeline");
        if (pipelineRows.length) {
          fail(
            "GET /api/opportunities/top10 — pipeline guard",
            `${pipelineRows.length} pipeline row(s) returned — opportunities and pipeline must not be mixed`
          );
        } else {
          pass("GET /api/opportunities/top10 — pipeline guard: no pipeline rows in top10");
        }
      }
    }
  } catch (e) {
    fail("GET /api/opportunities/top10", `Request failed: ${e.message}`);
  }
  console.log();

  // ── 5. Qualify dry-run (write-capable safe path) ──
  console.log("[5] Qualify Opportunity (dry-run)");
  try {
    const { status, body } = await post("/api/opportunities/OPP-0041/qualify", { dryRun: true });
    if (status === 404) {
      // Acceptable in test env if opp doesn't exist yet — verify envelope is still correct shape
      const envelopeOk = checkEnvelope("POST /api/opportunities/OPP-0041/qualify dryRun — 404", body);
      if (envelopeOk) {
        pass("POST qualify dryRun — 404 with valid envelope (opp may not exist in test DB)");
      }
    } else {
      if (status !== 200) fail("POST qualify dryRun — status", `Expected 200 or 404, got ${status}`);
      else pass("POST qualify dryRun — status 200");
      if (checkEnvelope("POST qualify dryRun", body)) {
        if (body.dryRun !== true) {
          fail("POST qualify dryRun — dryRun flag", `dryRun should be true, got ${body.dryRun}`);
        } else {
          pass("POST qualify dryRun — dryRun:true confirmed in response");
        }
      }
    }
  } catch (e) {
    fail("POST qualify dryRun", `Request failed: ${e.message}`);
  }
  console.log();

  // ── 6. Invalid KPI guard ──
  console.log("[6] Invalid KPI guard");
  try {
    const { status, body } = await get("/api/financial/invalid_kpi");
    if (status !== 400) fail("GET /api/financial/invalid_kpi — guard", `Expected 400, got ${status}`);
    else pass("GET /api/financial/invalid_kpi — returns 400 as expected");
    if (body.success !== false) {
      fail("GET /api/financial/invalid_kpi — envelope success", "success should be false for invalid KPI");
    } else {
      pass("GET /api/financial/invalid_kpi — success:false confirmed");
    }
  } catch (e) {
    fail("GET /api/financial/invalid_kpi", `Request failed: ${e.message}`);
  }
  console.log();

  // ── Summary ──
  console.log("─".repeat(60));
  console.log(`Results: ${passed} passed, ${failed} failed\n`);
  if (failures.length) {
    console.log("FAILURES:");
    failures.forEach(f => console.log(`  ✗ ${f.name}\n    ${f.reason}`));
    process.exit(1);
  } else {
    console.log("ALL TESTS PASSED — Launchpad API layer is clean.\n");
    process.exit(0);
  }
}

runTests().catch(e => {
  console.error("Test runner error:", e);
  process.exit(1);
});
