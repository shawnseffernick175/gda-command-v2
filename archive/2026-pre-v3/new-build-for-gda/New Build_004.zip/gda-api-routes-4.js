/**
 * GDA Rebuild — API Route Registry
 * S-003 | Phase 1
 *
 * All React-facing routes live here.
 * Every handler returns the standard JSON envelope:
 *   { success, workflow, action, dryRun, data, meta, error }
 *
 * S-003 additions vs S-001/S-002:
 *   - GET /api/schema/check    — DB table/view presence check (debug only)
 *   - POST /api/opportunities/:id/qualify — dryRun:true path complete
 *
 * Frozen workflow IDs are not referenced anywhere in this file.
 * No direct n8n calls from the API layer without explicit approval.
 */

"use strict";

const express = require("express");
const { Pool } = require("pg");

const router = express.Router();

// ─── DB Pool ──────────────────────────────────────────────────────────────────
// Shared pool — created once when routes are loaded.
// DATABASE_URL is validated in server.js before this module loads.
const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.DATABASE_SSL === "false"
    ? false
    : { rejectUnauthorized: false },
  max:             5,
  idleTimeoutMillis: 30_000,
  connectionTimeoutMillis: 5_000,
});

// ─── Envelope builder ─────────────────────────────────────────────────────────
function envelope({ success, workflow, action, dryRun = false, data = null, meta = {}, error = null, res, status = 200 }) {
  return res.status(success ? status : (status === 200 ? 500 : status)).json({
    success,
    workflow,
    action,
    dryRun,
    data,
    meta:  { ts: new Date().toISOString(), ...meta },
    error: error || null,
  });
}

// ─── GET /api/health ──────────────────────────────────────────────────────────
// Returns DB reachability status. Never throws — always returns an envelope.
router.get("/health", async (req, res) => {
  let dbOk = false;
  let dbMsg = "not checked";

  try {
    const result = await pool.query("SELECT NOW() AS ts");
    dbOk  = true;
    dbMsg = result.rows[0]?.ts?.toISOString() ?? "ok";
  } catch (err) {
    dbMsg = err.message;
  }

  return envelope({
    res,
    success:  dbOk,
    workflow: "health",
    action:   "check",
    data:     { db: dbOk ? "ok" : "error", db_message: dbMsg },
    meta:     { service: "GDA Rebuild API", version: "S-003" },
    error:    dbOk ? null : `DB unreachable: ${dbMsg}`,
  });
});

// ─── GET /api/financial/kpis ──────────────────────────────────────────────────
// Returns all 7 KPIs from financial_kpis_current view.
router.get("/financial/kpis", async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT kpi_name, kpi_value, kpi_label, updated_at
      FROM   financial_kpis_current
      ORDER  BY sort_order
    `);

    const kpis = {};
    for (const row of result.rows) {
      kpis[row.kpi_name] = {
        value:      row.kpi_value,
        label:      row.kpi_label,
        updated_at: row.updated_at,
      };
    }

    const required = ["orders", "sales", "ebit", "ros", "funded_backlog", "backlog", "gross_profit"];
    const missing  = required.filter(k => !(k in kpis));

    if (missing.length > 0) {
      return envelope({
        res, status: 500,
        success:  false,
        workflow: "financial",
        action:   "kpis",
        data:     null,
        meta:     { missing },
        error:    `Missing KPIs from financial_kpis_current: ${missing.join(", ")}`,
      });
    }

    return envelope({
      res,
      success:  true,
      workflow: "financial",
      action:   "kpis",
      data:     { kpis, row_count: result.rowCount },
    });
  } catch (err) {
    return envelope({
      res, status: 500,
      success:  false,
      workflow: "financial",
      action:   "kpis",
      error:    err.message,
    });
  }
});

// ─── GET /api/financial/:kpi ──────────────────────────────────────────────────
// KPI drill-down detail — placeholder until Financial Bible is built (S-005).
router.get("/financial/:kpi", async (req, res) => {
  const VALID_KPIS = ["orders", "sales", "ebit", "ros", "funded_backlog", "backlog", "gross_profit"];
  const { kpi } = req.params;

  if (!VALID_KPIS.includes(kpi)) {
    return envelope({
      res, status: 404,
      success:  false,
      workflow: "financial",
      action:   "detail",
      error:    `Unknown KPI: ${kpi}. Valid values: ${VALID_KPIS.join(", ")}`,
    });
  }

  // TODO S-005: Query real drill-down tables per KPI
  return envelope({
    res,
    success:  true,
    workflow: "financial",
    action:   "detail",
    data:     { kpi, rows: [], note: "Financial Bible drill-down — implemented in S-005" },
    meta:     { kpi },
  });
});

// ─── GET /api/launchpad/summary ───────────────────────────────────────────────
// Launchpad summary cards — opportunity counts, risk flags, fast-track signals.
router.get("/launchpad/summary", async (req, res) => {
  try {
    const [oppCount, pipelineCount, riskCount] = await Promise.all([
      pool.query("SELECT COUNT(*) AS n FROM opportunities"),
      pool.query("SELECT COUNT(*) AS n FROM opportunities WHERE status = 'Pipeline'"),
      pool.query(`
        SELECT COUNT(*) AS n
        FROM   opportunities
        WHERE  risk_flag = true
           OR  (due_date - CURRENT_DATE) <= 30
      `).catch(() => ({ rows: [{ n: 0 }] })), // graceful if column missing
    ]);

    return envelope({
      res,
      success:  true,
      workflow: "launchpad",
      action:   "summary",
      data: {
        total_opportunities: parseInt(oppCount.rows[0].n, 10),
        pipeline_count:      parseInt(pipelineCount.rows[0].n, 10),
        active_risks:        parseInt(riskCount.rows[0].n, 10),
        decisions_due_soon:  0, // populated once decisions table exists
        fast_track_signals:  0, // populated once fast_track view exists
      },
    });
  } catch (err) {
    return envelope({
      res, status: 500,
      success:  false,
      workflow: "launchpad",
      action:   "summary",
      error:    err.message,
    });
  }
});

// ─── GET /api/opportunities/top10 ────────────────────────────────────────────
// Top 10 scoring opportunities (not top 10 pipeline items).
// An opportunity is not pipeline until qualified — rule enforced here.
router.get("/opportunities/top10", async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT
        id,
        title,
        dept,
        value,
        pwin,
        score,
        status,
        due_date
      FROM   opportunities
      ORDER  BY score DESC NULLS LAST,
               pwin  DESC NULLS LAST
      LIMIT  10
    `);

    return envelope({
      res,
      success:  true,
      workflow: "launchpad",
      action:   "top10",
      data: {
        opportunities: result.rows,
        count:         result.rowCount,
        summary: {
          avg_score: result.rows.length
            ? Math.round(result.rows.reduce((s, r) => s + (Number(r.score) || 0), 0) / result.rows.length)
            : null,
          avg_pwin: result.rows.length
            ? Math.round(result.rows.reduce((s, r) => s + (Number(r.pwin) || 0), 0) / result.rows.length)
            : null,
          total_value: result.rows.reduce((s, r) => s + (Number(r.value) || 0), 0),
        },
      },
      meta: { note: "Opportunities only. Pipeline requires explicit qualify action." },
    });
  } catch (err) {
    return envelope({
      res, status: 500,
      success:  false,
      workflow: "launchpad",
      action:   "top10",
      error:    err.message,
    });
  }
});

// ─── GET /api/opportunities/:id ───────────────────────────────────────────────
// Single opportunity detail.
router.get("/opportunities/:id", async (req, res) => {
  try {
    const result = await pool.query(
      "SELECT * FROM opportunities WHERE id = $1",
      [req.params.id]
    );

    if (result.rowCount === 0) {
      return envelope({
        res, status: 404,
        success:  false,
        workflow: "opportunities",
        action:   "detail",
        error:    `Opportunity not found: ${req.params.id}`,
      });
    }

    return envelope({
      res,
      success:  true,
      workflow: "opportunities",
      action:   "detail",
      data:     { opportunity: result.rows[0] },
      meta:     { id: req.params.id },
    });
  } catch (err) {
    return envelope({
      res, status: 500,
      success:  false,
      workflow: "opportunities",
      action:   "detail",
      error:    err.message,
    });
  }
});

// ─── POST /api/opportunities/:id/qualify ─────────────────────────────────────
// Qualify flow — dryRun:true path fully implemented.
// Real write (dryRun:false) is stubbed and requires explicit approval in S-004.
//
// dryRun:true behavior:
//   - Looks up the opportunity
//   - Returns what WOULD change (status → Pipeline, qualified_at timestamp)
//   - Makes NO writes to DB
//   - Returns 200 (found) or 404 (not found)
//
// dryRun:false behavior (S-004):
//   - Requires explicit human approval flag in request body
//   - Will write status = 'Pipeline' and qualified_at = NOW()
//   - Currently returns 400 "Real write not yet enabled" for safety
//
router.post("/opportunities/:id/qualify", async (req, res) => {
  const { id } = req.params;
  const dryRun = req.body?.dryRun !== false; // default true — safe by default

  // Safety: refuse real writes until S-004 UI + approval flow is built
  if (!dryRun) {
    return envelope({
      res, status: 400,
      success:  false,
      workflow: "qualify",
      action:   "qualify",
      dryRun:   false,
      error:    "Real write (dryRun:false) is not enabled yet. S-004 will implement the full qualify UI with approval gate. Use dryRun:true to preview.",
    });
  }

  // dryRun:true — look up the opportunity, return preview
  try {
    const result = await pool.query(
      "SELECT id, title, dept, status, pwin, score FROM opportunities WHERE id = $1",
      [id]
    );

    if (result.rowCount === 0) {
      return envelope({
        res, status: 404,
        success:  false,
        workflow: "qualify",
        action:   "qualify",
        dryRun:   true,
        data:     null,
        meta:     { id },
        error:    `Opportunity not found: ${id}`,
      });
    }

    const opp = result.rows[0];
    const alreadyPipeline = opp.status === "Pipeline";

    return envelope({
      res,
      success:  true,
      workflow: "qualify",
      action:   "qualify",
      dryRun:   true,
      data: {
        opportunity_id:    opp.id,
        title:             opp.title,
        current_status:    opp.status,
        proposed_status:   alreadyPipeline ? "Pipeline" : "Pipeline",
        would_change:      !alreadyPipeline,
        already_qualified: alreadyPipeline,
        fields_to_update: alreadyPipeline ? [] : [
          { field: "status",       from: opp.status, to: "Pipeline" },
          { field: "qualified_at", from: null,        to: "<NOW()>"  },
        ],
        note: alreadyPipeline
          ? "Already in Pipeline — no change would occur."
          : "DRY RUN: No write made. Set dryRun:false with approval to execute.",
      },
      meta: { id, dryRun: true },
    });
  } catch (err) {
    return envelope({
      res, status: 500,
      success:  false,
      workflow: "qualify",
      action:   "qualify",
      dryRun:   true,
      error:    err.message,
    });
  }
});

// ─── GET /api/schema/check ────────────────────────────────────────────────────
// Server-side debug helper — not wired into React UI in S-003.
// Reports whether required tables/views exist and have at least one row.
// Safe: read-only, SELECT only, no writes.
router.get("/schema/check", async (req, res) => {
  // Tables and views required for Launchpad + Ops Tracker
  const REQUIRED = [
    { name: "opportunities",        type: "table" },
    { name: "financial_kpis_current", type: "view"  },
  ];

  const results = [];
  let allOk = true;

  for (const item of REQUIRED) {
    const check = { name: item.name, type: item.type, exists: false, has_rows: false, error: null };

    try {
      // Check existence via information_schema — works for both tables and views
      const existsQ = await pool.query(`
        SELECT table_name
        FROM   information_schema.tables
        WHERE  table_schema = 'public'
          AND  table_name   = $1
      `, [item.name]);

      check.exists = existsQ.rowCount > 0;

      if (check.exists) {
        // Check row presence — deliberately catches empty views/tables
        const rowQ = await pool.query(
          `SELECT 1 FROM "${item.name}" LIMIT 1`
        );
        check.has_rows = rowQ.rowCount > 0;
      }
    } catch (err) {
      check.error = err.message;
    }

    if (!check.exists || !check.has_rows) allOk = false;
    results.push(check);
  }

  // Plain-English summary for each item
  const summary = results.map(r => {
    if (!r.exists)   return `MISSING  — ${r.name} (${r.type}) does not exist in public schema`;
    if (!r.has_rows) return `EMPTY    — ${r.name} exists but has no rows`;
    return                  `OK       — ${r.name} exists and has rows`;
  });

  return envelope({
    res,
    success:  allOk,
    workflow: "schema",
    action:   "check",
    data: {
      all_ok:  allOk,
      checks:  results,
      summary,
    },
    meta: { checked: REQUIRED.map(r => r.name) },
    error: allOk ? null : "One or more required tables/views are missing or empty. See data.checks for details.",
  });
});

module.exports = router;
