/**
 * GDA Rebuild — Smoke Test Runner
 * S-003 | Phase 1
 *
 * Tests every /api/... endpoint against the running Express server.
 * All tests are read-only or dryRun — no writes, no real side effects.
 *
 * Usage:
 *   node gda-smoke-tests.js http://localhost:3001
 *   node gda-smoke-tests.js $GDA_PROD_URL
 *
 * Or via package.json scripts:
 *   npm run smoke            (targets http://localhost:3001)
 *   npm run smoke:prod       (targets $GDA_PROD_URL)
 *
 * Exit codes:
 *   0 — all tests passed
 *   1 — one or more tests failed
 */

"use strict";

// ─── Args ─────────────────────────────────────────────────────────────────────
const BASE = (process.argv[2] || "http://localhost:3001").replace(/\/$/, "");

// ─── Test harness ─────────────────────────────────────────────────────────────
let passed = 0;
let failed = 0;
const failures = [];

function pass(name) {
  console.log(`  ✓ ${name}`);
  passed++;
}

function fail(name, reason) {
  console.log(`  ✗ ${name}`);
  console.log(`      → ${reason}`);
  failed++;
  failures.push({ name, reason });
}

async function GET(path) {
  const url = `${BASE}${path}`;
  const r = await fetch(url);
  const body = await r.json().catch(() => null);
  return { status: r.status, body };
}

async function POST(path, payload) {
  const url = `${BASE}${path}`;
  const r = await fetch(url, {
    method:  "POST",
    headers: { "Content-Type": "application/json" },
    body:    JSON.stringify(payload),
  });
  const body = await r.json().catch(() => null);
  return { status: r.status, body };
}

// ─── Envelope contract check ──────────────────────────────────────────────────
// Every endpoint must return all 7 required fields regardless of success/failure.
function checkEnvelope(name, body) {
  const required = ["success", "workflow", "action", "dryRun", "data", "meta", "error"];
  const missing  = required.filter(k => !(k in body));
  if (missing.length > 0) {
    fail(`${name} — envelope contract`, `Missing fields: ${missing.join(", ")}`);
    return false;
  }
  pass(`${name} — envelope contract`);
  return true;
}

// ─── Test suites ──────────────────────────────────────────────────────────────

// ── /api/health ───────────────────────────────────────────────────────────────
async function testHealth() {
  console.log("\n── /api/health");
  const { status, body } = await GET("/api/health");

  if (status === 200) pass("/api/health — status 200");
  else fail("/api/health — status 200", `Got HTTP ${status}`);

  if (!body) { fail("/api/health — body parseable", "Response was not valid JSON"); return; }

  checkEnvelope("/api/health", body);

  if (body.data?.db === "ok") pass("/api/health — db ok");
  else fail("/api/health — db ok", `db field is "${body.data?.db}". Message: ${body.data?.db_message}. Check DATABASE_URL and Postgres connectivity.`);
}

// ── /api/financial/kpis ───────────────────────────────────────────────────────
async function testFinancialKpis() {
  console.log("\n── /api/financial/kpis");
  const { status, body } = await GET("/api/financial/kpis");

  if (status === 200) pass("/api/financial/kpis — status 200");
  else fail("/api/financial/kpis — status 200", `Got HTTP ${status}`);

  if (!body) { fail("/api/financial/kpis — body parseable", "Response was not valid JSON"); return; }

  checkEnvelope("/api/financial/kpis", body);

  if (!body.success) {
    fail("/api/financial/kpis — success:true", `success is false. Error: ${body.error}. The financial_kpis_current view may not exist or may be missing rows.`);
    return;
  }
  pass("/api/financial/kpis — success:true");

  const required = ["orders", "sales", "ebit", "ros", "funded_backlog", "backlog", "gross_profit"];
  const kpis = body.data?.kpis || {};
  const missing = required.filter(k => !(k in kpis));
  if (missing.length > 0)
    fail("/api/financial/kpis — all 7 KPI keys present", `Missing: ${missing.join(", ")}. Check the financial_kpis_current view has all required rows.`);
  else
    pass("/api/financial/kpis — all 7 KPI keys present");
}

// ── /api/launchpad/summary ────────────────────────────────────────────────────
async function testLaunchpadSummary() {
  console.log("\n── /api/launchpad/summary");
  const { status, body } = await GET("/api/launchpad/summary");

  if (status === 200) pass("/api/launchpad/summary — status 200");
  else fail("/api/launchpad/summary — status 200", `Got HTTP ${status}`);

  if (!body) { fail("/api/launchpad/summary — body parseable", "Response was not valid JSON"); return; }

  checkEnvelope("/api/launchpad/summary", body);

  const d = body.data || {};
  const hasKeys = ["total_opportunities", "pipeline_count", "active_risks"].every(k => k in d);
  if (hasKeys) pass("/api/launchpad/summary — required keys present");
  else fail("/api/launchpad/summary — required keys present", `Missing one or more of: total_opportunities, pipeline_count, active_risks. Got: ${Object.keys(d).join(", ")}`);
}

// ── /api/opportunities/top10 ──────────────────────────────────────────────────
async function testTop10() {
  console.log("\n── /api/opportunities/top10");
  const { status, body } = await GET("/api/opportunities/top10");

  if (status === 200) pass("/api/opportunities/top10 — status 200");
  else fail("/api/opportunities/top10 — status 200", `Got HTTP ${status}`);

  if (!body) { fail("/api/opportunities/top10 — body parseable", "Response was not valid JSON"); return; }

  checkEnvelope("/api/opportunities/top10", body);

  if (!body.success) {
    fail("/api/opportunities/top10 — success:true", `success is false. Error: ${body.error}`);
    return;
  }
  pass("/api/opportunities/top10 — success:true");

  const opps = body.data?.opportunities;
  if (!Array.isArray(opps))
    fail("/api/opportunities/top10 — data.opportunities is array", `Got: ${typeof opps}`);
  else
    pass("/api/opportunities/top10 — data.opportunities is array");

  if (Array.isArray(opps) && opps.length > 0) {
    const first = opps[0];
    const cols = ["id", "title", "dept", "value", "pwin", "score", "status", "due_date"];
    const missingCols = cols.filter(c => !(c in first));
    if (missingCols.length > 0)
      fail("/api/opportunities/top10 — row has required columns", `Missing columns: ${missingCols.join(", ")}. Check the opportunities table schema.`);
    else
      pass("/api/opportunities/top10 — row has required columns");
  }

  // Verify pipeline rule: none of top10 should be forced into pipeline-only view
  if (Array.isArray(opps)) {
    pass(`/api/opportunities/top10 — returned ${opps.length} rows (max 10)`);
  }
}

// ── /api/opportunities/:id/qualify (dryRun:true) ──────────────────────────────
async function testQualifyDryRun() {
  console.log("\n── /api/opportunities/:id/qualify (dryRun:true)");

  // First, grab a real ID from top10 if possible
  const top10 = await GET("/api/opportunities/top10");
  const firstId = top10.body?.data?.opportunities?.[0]?.id;

  // Test with a known-bad ID — must return 404 envelope, not crash
  const { status: s404, body: b404 } = await POST("/api/opportunities/NONEXISTENT-ID-999/qualify", { dryRun: true });

  if (s404 === 404) pass("/api/qualify dryRun — 404 on missing ID");
  else fail("/api/qualify dryRun — 404 on missing ID", `Expected HTTP 404, got ${s404}`);

  if (b404) checkEnvelope("/api/qualify dryRun 404", b404);

  if (b404?.dryRun === true) pass("/api/qualify dryRun — dryRun:true in 404 envelope");
  else fail("/api/qualify dryRun — dryRun:true in 404 envelope", `dryRun field is ${b404?.dryRun}`);

  // Test with real ID if available
  if (firstId) {
    const { status: s200, body: b200 } = await POST(`/api/opportunities/${firstId}/qualify`, { dryRun: true });

    if (s200 === 200) pass(`/api/qualify dryRun — 200 on real ID (${firstId})`);
    else fail(`/api/qualify dryRun — 200 on real ID (${firstId})`, `Got HTTP ${s200}`);

    if (b200) checkEnvelope("/api/qualify dryRun 200", b200);

    if (b200?.success === true) pass("/api/qualify dryRun — success:true on real ID");
    else fail("/api/qualify dryRun — success:true on real ID", `success is false. Error: ${b200?.error}`);

    if (b200?.dryRun === true) pass("/api/qualify dryRun — dryRun:true confirmed in response");
    else fail("/api/qualify dryRun — dryRun:true confirmed in response", `dryRun field is ${b200?.dryRun}`);

    const d = b200?.data || {};
    if ("fields_to_update" in d || "already_qualified" in d)
      pass("/api/qualify dryRun — preview data structure present");
    else
      fail("/api/qualify dryRun — preview data structure present", `Missing fields_to_update or already_qualified in data. Got: ${Object.keys(d).join(", ")}`);
  } else {
    console.log("  ⚠  Skipping real-ID qualify test — top10 returned no rows (DB may be empty)");
  }

  // Test that dryRun:false is rejected
  const { status: s400, body: b400 } = await POST("/api/opportunities/NONEXISTENT-ID-999/qualify", { dryRun: false });

  if (s400 === 400) pass("/api/qualify — dryRun:false correctly rejected (400)");
  else fail("/api/qualify — dryRun:false correctly rejected (400)", `Expected 400, got ${s400}. Real writes must not be enabled until S-004.`);

  if (b400?.success === false) pass("/api/qualify — dryRun:false returns success:false");
  else fail("/api/qualify — dryRun:false returns success:false", `success was ${b400?.success}`);
}

// ── /api/schema/check ─────────────────────────────────────────────────────────
async function testSchemaCheck() {
  console.log("\n── /api/schema/check");
  const { status, body } = await GET("/api/schema/check");

  if (status === 200 || status === 500) pass(`/api/schema/check — responded (HTTP ${status})`);
  else fail("/api/schema/check — responded", `Unexpected HTTP status ${status}`);

  if (!body) { fail("/api/schema/check — body parseable", "Response was not valid JSON"); return; }

  checkEnvelope("/api/schema/check", body);

  const checks = body.data?.checks;
  if (!Array.isArray(checks)) {
    fail("/api/schema/check — data.checks is array", `Got: ${typeof checks}`);
    return;
  }
  pass("/api/schema/check — data.checks is array");

  // Report each table check in plain English
  for (const c of checks) {
    if (c.exists && c.has_rows) {
      pass(`/api/schema/check — ${c.name} exists and has rows`);
    } else if (c.exists && !c.has_rows) {
      fail(`/api/schema/check — ${c.name} has rows`, `Table/view "${c.name}" exists but is empty. Seed it before Launchpad and Ops Tracker can show real data.`);
    } else {
      fail(`/api/schema/check — ${c.name} exists`, `Table/view "${c.name}" does not exist in the public schema. Run the S-003 schema setup SQL to create it.`);
    }
  }

  if (body.data?.all_ok === true) pass("/api/schema/check — all_ok:true (all tables present and populated)");
  else console.log("  ⚠  schema/check: one or more tables missing or empty (see failures above)");
}

// ── 404 fallback behavior ─────────────────────────────────────────────────────
async function testNotFound() {
  console.log("\n── Unknown route → 404 envelope (not HTML)");
  const { status, body } = await GET("/api/this-does-not-exist-s003");

  if (status === 404) pass("Unknown route — status 404");
  else fail("Unknown route — status 404", `Got HTTP ${status}`);

  if (body && typeof body === "object" && "success" in body)
    pass("Unknown route — returns JSON envelope (not HTML)");
  else
    fail("Unknown route — returns JSON envelope (not HTML)", "Response was not a valid envelope object. React should never receive HTML for missing routes.");
}

// ─── Runner ───────────────────────────────────────────────────────────────────
async function run() {
  console.log(`\nGDA Smoke Tests — S-003`);
  console.log(`Target: ${BASE}`);
  console.log("─".repeat(60));

  try {
    await testHealth();
    await testFinancialKpis();
    await testLaunchpadSummary();
    await testTop10();
    await testQualifyDryRun();
    await testSchemaCheck();
    await testNotFound();
  } catch (err) {
    console.error("\n[FATAL] Test runner threw an unexpected error:");
    console.error(err);
    console.error("\nIs the Express server running? Start it with:\n  cd api && npm run dev\n");
    process.exit(1);
  }

  console.log("\n" + "─".repeat(60));
  console.log(`Results: ${passed} passed, ${failed} failed`);

  if (failed === 0) {
    console.log("\n✅  ALL TESTS PASSED — S-003 API layer is clean.\n");
    process.exit(0);
  } else {
    console.log("\n❌  FAILURES:\n");
    for (const f of failures) {
      console.log(`  • ${f.name}`);
      console.log(`      ${f.reason}`);
    }
    console.log();
    process.exit(1);
  }
}

run();
