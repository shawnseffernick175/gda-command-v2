/**
 * GDA Rebuild — Ops Tracker Page
 * S-003 | Phase 1
 *
 * Read-only opportunity table. Reads from /api/opportunities/top10.
 * Displays: id, title, dept, value, p(win), score, status, due date.
 * Consistent with light Launchpad theme. No charts. No dark mode.
 *
 * Switching to real API: set USE_MOCK = false after confirming Express is live.
 */

import { useState, useEffect } from "react";

// ─── Mock data ────────────────────────────────────────────────────────────────
// Matches the shape returned by /api/opportunities/top10 envelope.data.opportunities
const MOCK_OPPORTUNITIES = [
  { id: "OPP-001", title: "Dept of Army SIGINT Modernization",  dept: "Army",   value: 4200000,  pwin: 72, score: 91, status: "Tracking",    due_date: "2026-06-15" },
  { id: "OPP-002", title: "AFRL Advanced ISR Platform Study",   dept: "Air Force", value: 1850000, pwin: 58, score: 84, status: "Tracking",  due_date: "2026-05-30" },
  { id: "OPP-003", title: "DHS Border Surveillance Tech",       dept: "DHS",    value: 3100000,  pwin: 45, score: 79, status: "Tracking",    due_date: "2026-07-01" },
  { id: "OPP-004", title: "Navy C2 Comms Upgrade Phase II",     dept: "Navy",   value: 7400000,  pwin: 61, score: 78, status: "Tracking",    due_date: "2026-08-20" },
  { id: "OPP-005", title: "SOCOM Tactical Edge Computing",      dept: "SOCOM",  value: 2250000,  pwin: 55, score: 74, status: "Tracking",    due_date: "2026-06-05" },
  { id: "OPP-006", title: "NRO Ground Station Refresh",         dept: "NRO",    value: 5600000,  pwin: 40, score: 71, status: "Identifying", due_date: "2026-09-10" },
  { id: "OPP-007", title: "DISA Zero Trust Architecture BPA",   dept: "DISA",   value: 890000,   pwin: 68, score: 69, status: "Tracking",    due_date: "2026-05-22" },
  { id: "OPP-008", title: "Army Cyber Range Infrastructure",    dept: "Army",   value: 3350000,  pwin: 38, score: 65, status: "Identifying", due_date: "2026-10-01" },
  { id: "OPP-009", title: "NSA Analytics Modernization IDIQ",   dept: "NSA",    value: 12000000, pwin: 25, score: 62, status: "Identifying", due_date: "2026-11-15" },
  { id: "OPP-010", title: "USMC Logistics Automation Pilot",    dept: "USMC",   value: 640000,   pwin: 52, score: 58, status: "Tracking",    due_date: "2026-06-28" },
];

const MOCK_SUMMARY = {
  total_opportunities: 10,
  avg_score: 73,
  avg_pwin: 51,
  total_value: 41280000,
};

// ─── Config ───────────────────────────────────────────────────────────────────
const USE_MOCK = true; // set false once Express + DB are confirmed live

// ─── Helpers ─────────────────────────────────────────────────────────────────
function fmtDollars(n) {
  if (n == null) return "—";
  if (n >= 1_000_000) return `$${(n / 1_000_000).toFixed(1)}M`;
  if (n >= 1_000)     return `$${(n / 1_000).toFixed(0)}K`;
  return `$${n}`;
}

function fmtDate(d) {
  if (!d) return "—";
  try { return new Date(d).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" }); }
  catch { return d; }
}

function PwinBadge({ pwin }) {
  const v = Number(pwin) || 0;
  let bg = "#e5e7eb"; // gray
  if (v >= 65)      bg = "#dcfce7"; // green
  else if (v >= 45) bg = "#fef9c3"; // yellow
  else              bg = "#fee2e2"; // red
  return (
    <span style={{
      display: "inline-block",
      padding: "2px 8px",
      borderRadius: 12,
      fontSize: 12,
      fontWeight: 600,
      backgroundColor: bg,
      color: "#1f2937",
      minWidth: 40,
      textAlign: "center",
    }}>
      {v}%
    </span>
  );
}

function ScoreBadge({ score }) {
  const v = Number(score) || 0;
  let color = "#6b7280";
  if (v >= 80)      color = "#15803d";
  else if (v >= 60) color = "#b45309";
  else              color = "#dc2626";
  return <span style={{ fontWeight: 700, color }}>{v}</span>;
}

function StatusPill({ status }) {
  const map = {
    "Pipeline":    { bg: "#dbeafe", color: "#1e40af" },
    "Tracking":    { bg: "#e0f2fe", color: "#0369a1" },
    "Identifying": { bg: "#f3f4f6", color: "#374151" },
    "Pursuing":    { bg: "#fef9c3", color: "#92400e" },
    "Lost":        { bg: "#fee2e2", color: "#991b1b" },
    "No Bid":      { bg: "#f3f4f6", color: "#9ca3af" },
  };
  const s = map[status] || { bg: "#f3f4f6", color: "#374151" };
  return (
    <span style={{
      display: "inline-block",
      padding: "2px 10px",
      borderRadius: 12,
      fontSize: 12,
      fontWeight: 600,
      backgroundColor: s.bg,
      color: s.color,
    }}>
      {status || "—"}
    </span>
  );
}

// ─── Sort / Filter helpers ────────────────────────────────────────────────────
const DEPTS = ["All", "Army", "Air Force", "Navy", "USMC", "SOCOM", "DHS", "DISA", "NRO", "NSA", "Other"];
const STATUSES = ["All", "Tracking", "Identifying", "Pursuing", "Pipeline", "Lost", "No Bid"];

function applyFilters(rows, { dept, status, minPwin, sortKey, sortDir }) {
  let out = [...rows];
  if (dept !== "All")   out = out.filter(r => r.dept === dept);
  if (status !== "All") out = out.filter(r => r.status === status);
  if (minPwin > 0)      out = out.filter(r => (Number(r.pwin) || 0) >= minPwin);
  if (sortKey) {
    out.sort((a, b) => {
      let av = a[sortKey], bv = b[sortKey];
      if (typeof av === "string") av = av.toLowerCase();
      if (typeof bv === "string") bv = bv.toLowerCase();
      if (av < bv) return sortDir === "asc" ? -1 : 1;
      if (av > bv) return sortDir === "asc" ? 1 : -1;
      return 0;
    });
  }
  return out;
}

// ─── Styles (inline, consistent with GDALaunchpad light theme) ───────────────
const STYLES = {
  page: {
    minHeight: "100vh",
    backgroundColor: "#f8fafc",
    fontFamily: "'Inter', 'Segoe UI', system-ui, sans-serif",
    color: "#1f2937",
  },
  // KPI Strip — persistent financial header (same as Launchpad)
  kpiStrip: {
    display: "flex",
    gap: 0,
    backgroundColor: "#1e293b",
    padding: "0 24px",
    overflowX: "auto",
    borderBottom: "3px solid #0ea5e9",
  },
  kpiItem: {
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    padding: "10px 20px",
    minWidth: 110,
    cursor: "pointer",
    borderRight: "1px solid #334155",
    transition: "background 0.15s",
    textDecoration: "none",
  },
  kpiLabel: { fontSize: 10, fontWeight: 600, color: "#94a3b8", letterSpacing: "0.08em", textTransform: "uppercase" },
  kpiValue: { fontSize: 17, fontWeight: 700, color: "#f1f5f9", marginTop: 2 },
  // Page summary strip — tool-specific
  summaryStrip: {
    display: "flex",
    gap: 16,
    backgroundColor: "#ffffff",
    borderBottom: "1px solid #e2e8f0",
    padding: "12px 24px",
    overflowX: "auto",
  },
  summaryCard: {
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    padding: "8px 20px",
    minWidth: 110,
    backgroundColor: "#f8fafc",
    border: "1px solid #e2e8f0",
    borderRadius: 8,
  },
  summaryLabel: { fontSize: 11, color: "#6b7280", fontWeight: 500 },
  summaryValue: { fontSize: 18, fontWeight: 700, color: "#0f172a", marginTop: 2 },
  // Page header
  pageHeader: {
    padding: "20px 24px 8px",
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    flexWrap: "wrap",
    gap: 12,
  },
  pageTitle: { fontSize: 22, fontWeight: 700, color: "#0f172a", margin: 0 },
  pageSubtitle: { fontSize: 13, color: "#64748b", marginTop: 2 },
  // Filter bar
  filterBar: {
    display: "flex",
    gap: 12,
    padding: "10px 24px",
    alignItems: "center",
    flexWrap: "wrap",
    backgroundColor: "#ffffff",
    borderBottom: "1px solid #e2e8f0",
  },
  filterLabel: { fontSize: 12, color: "#6b7280", fontWeight: 500 },
  select: {
    fontSize: 13,
    padding: "5px 10px",
    border: "1px solid #d1d5db",
    borderRadius: 6,
    backgroundColor: "#ffffff",
    color: "#1f2937",
    cursor: "pointer",
  },
  // Table
  tableWrap: { padding: "16px 24px" },
  table: { width: "100%", borderCollapse: "collapse", backgroundColor: "#ffffff", borderRadius: 10, overflow: "hidden", border: "1px solid #e2e8f0" },
  thead: { backgroundColor: "#f1f5f9" },
  th: {
    padding: "10px 14px",
    textAlign: "left",
    fontSize: 11,
    fontWeight: 700,
    color: "#374151",
    textTransform: "uppercase",
    letterSpacing: "0.06em",
    borderBottom: "1px solid #e2e8f0",
    cursor: "pointer",
    userSelect: "none",
    whiteSpace: "nowrap",
  },
  td: {
    padding: "11px 14px",
    fontSize: 13,
    color: "#374151",
    borderBottom: "1px solid #f1f5f9",
    verticalAlign: "middle",
  },
  trHover: { backgroundColor: "#f8fafc" },
  // Misc
  mockBanner: { backgroundColor: "#fef3c7", borderBottom: "1px solid #fcd34d", padding: "6px 24px", fontSize: 12, color: "#92400e" },
  errorBox:   { margin: "24px", padding: "16px", backgroundColor: "#fee2e2", borderRadius: 8, color: "#991b1b", fontSize: 13 },
  emptyRow:   { textAlign: "center", padding: 32, color: "#9ca3af", fontSize: 13 },
};

// ─── KPI Strip data (mock — replace with real /api/financial/kpis) ────────────
const KPI_MOCK = [
  { label: "Orders",        value: "$42.1M" },
  { label: "Sales",         value: "$38.7M" },
  { label: "EBIT",          value: "$5.2M"  },
  { label: "ROS",           value: "13.4%"  },
  { label: "Funded Backlog",value: "$18.9M" },
  { label: "Backlog",       value: "$61.3M" },
  { label: "Gross Profit",  value: "$9.8M"  },
];

// ─── Component ────────────────────────────────────────────────────────────────
export default function GDAOpsTracker() {
  const [opps,    setOpps]    = useState([]);
  const [summary, setSummary] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error,   setError]   = useState(null);
  const [hoveredRow, setHoveredRow] = useState(null);

  // Filters + sort
  const [dept,    setDept]    = useState("All");
  const [status,  setStatus]  = useState("All");
  const [minPwin, setMinPwin] = useState(0);
  const [sortKey, setSortKey] = useState("score");
  const [sortDir, setSortDir] = useState("desc");

  // Load data
  useEffect(() => {
    if (USE_MOCK) {
      setTimeout(() => {
        setOpps(MOCK_OPPORTUNITIES);
        setSummary(MOCK_SUMMARY);
        setLoading(false);
      }, 300);
      return;
    }

    fetch("/api/opportunities/top10")
      .then(r => {
        if (!r.ok) throw new Error(`HTTP ${r.status}`);
        return r.json();
      })
      .then(env => {
        if (!env.success) throw new Error(env.error || "API returned success:false");
        setOpps(env.data?.opportunities || []);
        setSummary(env.data?.summary || null);
        setLoading(false);
      })
      .catch(e => {
        setError(e.message);
        setLoading(false);
      });
  }, []);

  // Sort column toggle
  function handleSort(key) {
    if (sortKey === key) {
      setSortDir(d => d === "asc" ? "desc" : "asc");
    } else {
      setSortKey(key);
      setSortDir("desc");
    }
  }

  function sortIndicator(key) {
    if (sortKey !== key) return " ↕";
    return sortDir === "asc" ? " ↑" : " ↓";
  }

  const visible = applyFilters(opps, { dept, status, minPwin, sortKey, sortDir });

  // Summary numbers (computed from visible set)
  const shownSummary = {
    shown:     visible.length,
    total:     opps.length,
    avg_score: visible.length ? Math.round(visible.reduce((s, r) => s + (Number(r.score) || 0), 0) / visible.length) : "—",
    avg_pwin:  visible.length ? Math.round(visible.reduce((s, r) => s + (Number(r.pwin)  || 0), 0) / visible.length) : "—",
    total_val: visible.reduce((s, r) => s + (Number(r.value) || 0), 0),
  };

  return (
    <div style={STYLES.page}>

      {/* ── Persistent Financial KPI Strip ───────────────────────────────── */}
      <div style={STYLES.kpiStrip}>
        {KPI_MOCK.map(k => (
          <div
            key={k.label}
            style={STYLES.kpiItem}
            title={`View ${k.label} detail`}
            onClick={() => {/* TODO: route to Financial Bible drill-down */}}
          >
            <span style={STYLES.kpiLabel}>{k.label}</span>
            <span style={STYLES.kpiValue}>{k.value}</span>
          </div>
        ))}
      </div>

      {/* ── Page Summary Strip (tool-specific) ───────────────────────────── */}
      <div style={STYLES.summaryStrip}>
        <div style={STYLES.summaryCard}>
          <span style={STYLES.summaryLabel}>Showing</span>
          <span style={STYLES.summaryValue}>{shownSummary.shown}/{shownSummary.total}</span>
        </div>
        <div style={STYLES.summaryCard}>
          <span style={STYLES.summaryLabel}>Avg Score</span>
          <span style={STYLES.summaryValue}>{shownSummary.avg_score}</span>
        </div>
        <div style={STYLES.summaryCard}>
          <span style={STYLES.summaryLabel}>Avg P(Win)</span>
          <span style={STYLES.summaryValue}>{shownSummary.avg_pwin}%</span>
        </div>
        <div style={STYLES.summaryCard}>
          <span style={STYLES.summaryLabel}>Total Value</span>
          <span style={STYLES.summaryValue}>{fmtDollars(shownSummary.total_val)}</span>
        </div>
        {summary?.total_opportunities != null && (
          <div style={{ ...STYLES.summaryCard, marginLeft: "auto", borderColor: "#bfdbfe", backgroundColor: "#eff6ff" }}>
            <span style={{ ...STYLES.summaryLabel, color: "#1e40af" }}>Pipeline Only</span>
            <span style={{ ...STYLES.summaryValue, color: "#1e40af", fontSize: 13 }}>Qualify to Add</span>
          </div>
        )}
      </div>

      {/* ── Mock banner ──────────────────────────────────────────────────── */}
      {USE_MOCK && (
        <div style={STYLES.mockBanner}>
          ⚠ MOCK DATA — set USE_MOCK = false in GDAOpsTracker.jsx after confirming Express API is live
        </div>
      )}

      {/* ── Page header ──────────────────────────────────────────────────── */}
      <div style={STYLES.pageHeader}>
        <div>
          <h1 style={STYLES.pageTitle}>Ops Tracker</h1>
          <div style={STYLES.pageSubtitle}>
            Opportunity discovery and management · Qualify to move to Pipeline
          </div>
        </div>
      </div>

      {/* ── Filter bar ───────────────────────────────────────────────────── */}
      <div style={STYLES.filterBar}>
        <span style={STYLES.filterLabel}>Filter:</span>

        <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
          <label style={STYLES.filterLabel} htmlFor="dept-filter">Dept</label>
          <select
            id="dept-filter"
            style={STYLES.select}
            value={dept}
            onChange={e => setDept(e.target.value)}
          >
            {DEPTS.map(d => <option key={d}>{d}</option>)}
          </select>
        </div>

        <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
          <label style={STYLES.filterLabel} htmlFor="status-filter">Status</label>
          <select
            id="status-filter"
            style={STYLES.select}
            value={status}
            onChange={e => setStatus(e.target.value)}
          >
            {STATUSES.map(s => <option key={s}>{s}</option>)}
          </select>
        </div>

        <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
          <label style={STYLES.filterLabel} htmlFor="pwin-filter">Min P(Win)</label>
          <select
            id="pwin-filter"
            style={STYLES.select}
            value={minPwin}
            onChange={e => setMinPwin(Number(e.target.value))}
          >
            <option value={0}>Any</option>
            <option value={25}>≥ 25%</option>
            <option value={40}>≥ 40%</option>
            <option value={55}>≥ 55%</option>
            <option value={70}>≥ 70%</option>
          </select>
        </div>

        {(dept !== "All" || status !== "All" || minPwin > 0) && (
          <button
            style={{ ...STYLES.select, backgroundColor: "#fee2e2", color: "#dc2626", border: "1px solid #fca5a5", cursor: "pointer" }}
            onClick={() => { setDept("All"); setStatus("All"); setMinPwin(0); }}
          >
            Clear
          </button>
        )}
      </div>

      {/* ── Table ────────────────────────────────────────────────────────── */}
      <div style={STYLES.tableWrap}>

        {loading && (
          <div style={{ padding: 32, textAlign: "center", color: "#64748b" }}>Loading opportunities…</div>
        )}

        {error && (
          <div style={STYLES.errorBox}>
            <strong>Error loading opportunities:</strong> {error}
            <div style={{ marginTop: 8, fontSize: 12 }}>
              Check that the Express API is running on :3001 and DATABASE_URL is set.
            </div>
          </div>
        )}

        {!loading && !error && (
          <table style={STYLES.table}>
            <thead style={STYLES.thead}>
              <tr>
                {[
                  { key: "id",       label: "ID"       },
                  { key: "title",    label: "Title"    },
                  { key: "dept",     label: "Dept"     },
                  { key: "value",    label: "Value"    },
                  { key: "pwin",     label: "P(Win)"   },
                  { key: "score",    label: "Score"    },
                  { key: "status",   label: "Status"   },
                  { key: "due_date", label: "Due Date" },
                ].map(col => (
                  <th
                    key={col.key}
                    style={STYLES.th}
                    onClick={() => handleSort(col.key)}
                    title={`Sort by ${col.label}`}
                  >
                    {col.label}{sortIndicator(col.key)}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {visible.length === 0 && (
                <tr>
                  <td colSpan={8} style={STYLES.emptyRow}>
                    No opportunities match the current filters.
                  </td>
                </tr>
              )}
              {visible.map(opp => (
                <tr
                  key={opp.id}
                  style={hoveredRow === opp.id ? { ...STYLES.trHover } : {}}
                  onMouseEnter={() => setHoveredRow(opp.id)}
                  onMouseLeave={() => setHoveredRow(null)}
                >
                  <td style={{ ...STYLES.td, fontFamily: "monospace", fontSize: 11, color: "#6b7280" }}>{opp.id}</td>
                  <td style={{ ...STYLES.td, fontWeight: 500, maxWidth: 260 }}>{opp.title}</td>
                  <td style={STYLES.td}>{opp.dept || "—"}</td>
                  <td style={{ ...STYLES.td, fontWeight: 600, fontVariantNumeric: "tabular-nums" }}>{fmtDollars(opp.value)}</td>
                  <td style={STYLES.td}><PwinBadge pwin={opp.pwin} /></td>
                  <td style={STYLES.td}><ScoreBadge score={opp.score} /></td>
                  <td style={STYLES.td}><StatusPill status={opp.status} /></td>
                  <td style={{ ...STYLES.td, whiteSpace: "nowrap" }}>{fmtDate(opp.due_date)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}

        {/* Pipeline callout — reinforces the qualify rule */}
        {!loading && !error && (
          <div style={{
            marginTop: 16,
            padding: "10px 16px",
            backgroundColor: "#eff6ff",
            border: "1px solid #bfdbfe",
            borderRadius: 8,
            fontSize: 12,
            color: "#1e40af",
          }}>
            <strong>Pipeline Rule:</strong> An opportunity does not become Pipeline until explicitly qualified.
            Qualify action is available via the API (<code>POST /api/opportunities/:id/qualify</code>).
            The Qualify UI will ship in S-004.
          </div>
        )}
      </div>

    </div>
  );
}
