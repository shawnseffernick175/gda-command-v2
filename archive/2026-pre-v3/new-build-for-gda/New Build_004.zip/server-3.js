/**
 * GDA Rebuild — Express API Server
 * S-003 | Phase 1
 *
 * Mounts the standard /api/... route layer.
 * React never calls n8n or Postgres directly — all calls route here first.
 *
 * Architecture rules enforced:
 * - Every endpoint returns the standard JSON envelope
 * - No secrets in the browser — DATABASE_URL stays server-side only
 * - Write-capable endpoints require dryRun:true before live execution
 * - Frozen workflow IDs are not referenced here
 *
 * S-003 changes vs S-002:
 * - Added GET /api/schema/check to route list in startup log
 * - No other server.js changes required; schema/check is in gda-api-routes.js
 *
 * Start (dev):   npm run dev    (requires nodemon)
 * Start (prod):  NODE_ENV=production node server.js
 *
 * Required env vars (see .env.example):
 *   DATABASE_URL   — Postgres connection string
 *   PORT           — optional, defaults to 3001
 *   ALLOWED_ORIGIN — optional, defaults to http://localhost:5173 (Vite dev)
 */

"use strict";

const express    = require("express");
const cors       = require("cors");
const helmet     = require("helmet");
const morgan     = require("morgan");
const gdaApi     = require("./gda-api-routes");

// ─── Env ──────────────────────────────────────────────────────────────────────
require("dotenv").config();

const PORT           = parseInt(process.env.PORT || "3001", 10);
const ALLOWED_ORIGIN = process.env.ALLOWED_ORIGIN || "http://localhost:5173";
const IS_PROD        = process.env.NODE_ENV === "production";

if (!process.env.DATABASE_URL) {
  console.error("\n[GDA] FATAL: DATABASE_URL is not set. Check your .env file.\n");
  process.exit(1);
}

// ─── App ──────────────────────────────────────────────────────────────────────
const app = express();

// Security headers — relaxed in dev, stricter in prod
app.use(helmet({
  contentSecurityPolicy:    IS_PROD,
  crossOriginEmbedderPolicy: IS_PROD,
}));

// CORS — React dev server or production origin only
app.use(cors({
  origin:         IS_PROD ? ALLOWED_ORIGIN : true,
  methods:        ["GET", "POST"],
  allowedHeaders: ["Content-Type", "Authorization"],
}));

// Body parsing
app.use(express.json({ limit: "256kb" }));
app.use(express.urlencoded({ extended: false }));

// Request logging
app.use(morgan(IS_PROD ? "combined" : "dev"));

// ─── API Routes ───────────────────────────────────────────────────────────────
// All React-facing routes are under /api/...
// gda-api-routes.js contains the full route registry.
app.use("/api", gdaApi);

// ─── Root + fallback ─────────────────────────────────────────────────────────
app.get("/", (req, res) => {
  res.json({
    success:  true,
    workflow: "server",
    action:   "root",
    dryRun:   false,
    data:     { service: "GDA Rebuild API", version: "S-003", status: "online" },
    meta:     { ts: new Date().toISOString(), env: IS_PROD ? "production" : "development" },
    error:    null,
  });
});

// 404 — unknown routes return a proper envelope, not an HTML error page
app.use((req, res) => {
  res.status(404).json({
    success:  false,
    workflow: "server",
    action:   "not_found",
    dryRun:   false,
    data:     null,
    meta:     { path: req.path },
    error:    `Route not found: ${req.method} ${req.path}`,
  });
});

// 500 — uncaught errors return a proper envelope
// eslint-disable-next-line no-unused-vars
app.use((err, req, res, _next) => {
  console.error("[GDA] Unhandled error:", err);
  res.status(500).json({
    success:  false,
    workflow: "server",
    action:   "internal_error",
    dryRun:   false,
    data:     null,
    meta:     { path: req.path },
    error:    IS_PROD ? "Internal server error" : err.message,
  });
});

// ─── Start ────────────────────────────────────────────────────────────────────
app.listen(PORT, () => {
  console.log(`\n[GDA] API server running on port ${PORT}`);
  console.log(`[GDA] ENV:     ${IS_PROD ? "production" : "development"}`);
  console.log(`[GDA] CORS:    ${IS_PROD ? ALLOWED_ORIGIN : "open (dev mode)"}`);
  console.log(`[GDA] Routes:`);
  console.log(`[GDA]   GET  /api/health`);
  console.log(`[GDA]   GET  /api/financial/kpis`);
  console.log(`[GDA]   GET  /api/financial/:kpi`);
  console.log(`[GDA]   GET  /api/launchpad/summary`);
  console.log(`[GDA]   GET  /api/opportunities/top10`);
  console.log(`[GDA]   GET  /api/opportunities/:id`);
  console.log(`[GDA]   POST /api/opportunities/:id/qualify  (dryRun:true required)`);
  console.log(`[GDA]   GET  /api/schema/check               (debug only)`);
  console.log();
});

module.exports = app; // for testing
