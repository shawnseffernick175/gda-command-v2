# S-185 SESSION KICKOFF
**GDA Command Platform | EIS / GDA OU3 | Shawn Seffernick**
**Generated: 2026-05-01 (S-184 Close)**

---

## MANDATORY FIRST ACTION
```
tool_search("n8n")   ← load MCP before ANY other action
```

---

## CARRY-FORWARD STATUS
- R-SR-09 artifacts from S-184: COMPLETE (Session Delta DOCX, DevOps Report DOCX, Master Build XLSX v4.184, this Kickoff MD)
- DEBT-JWT RESOLVED: N8N_API_KEY in /opt/gda-api-gateway-v1/.env replaced with valid no-exp JWT (New Key_0430'26, DB row oLzHLHvhX7AzK9m1). /api/failures/latest → HTTP 200.
- SSH Workflow IcD4K740vpWSIuaZ: authentication=headerAuth, cred 1pNPY36DDz49OtKL — CLEAN.
- Roadmap assessed: 7/10 stability criteria met (~78% stable). NOW phase ~85%, NEXT ~40%, LATER ~10%.

---

## S-185 PRIORITY QUEUE (Execute in Order)

| Rank | ID | Priority | Description |
|------|----|----------|-------------|
| 1 | **C-3** | 🔴 HIGH | Wire QACenterPage.jsx to gateway `/api/qa/health`. Currently calls `/api/gda-platform-health` etc. directly via n8n proxy — reroute through the gateway unified endpoint. Done when: QA Center health tab shows single normalized result. |
| 2 | **C-4/C-5** | 🟡 MEDIUM | Run agent-runner `{action:inventory_workflows}` and `{action:test_react_used_workflows}` — baseline all 156 workflows |
| 3 | **D-\*** | 🟡 MEDIUM | Rescue Map 6-workflow live audit: weekly-comp-scan, morning-briefing-v1, nightly-fy-revenue-calc, data-retention, e2e-gemini-report, dept-opp-sweep |
| 4 | **Source Control** | 🟡 MEDIUM | Put React source `/opt/gda-command/src` into reliable git repo — Stability Criterion 7 |
| 5 | **Phase B Expand** | 🟢 LOW | Add capture-plan preview + deep-research preview dry-run paths to gateway |
| 6 | **Approval Queue UI** | 🟢 LOW | Human-in-the-loop action center in React for sends, deploys, paid calls |

---

## PLATFORM SNAPSHOT (entering S-185)

| Component | Status |
|-----------|--------|
| n8n | OPERATIONAL (2.49.0) |
| Frontend (gda.csr-llc.tech) | OPERATIONAL — S-183 build |
| API Gateway (gda-gateway) | OPERATIONAL — 0.0.0.0:8788 |
| /api/failures/latest | ✅ FIXED S-184 — HTTP 200 |
| /api/qa/health | ⚠️ C-3 PENDING — not yet wired from React |
| QA Center React page | LIVE in source + dist |
| fix-runner (aAVitXXjGWaP7bb2) | ACTIVE — dry-run |
| agent-runner (TxcPdvx2Ld9rE9er) | ACTIVE |
| Postgres | OPERATIONAL |
| Traefik | OPERATIONAL — rate limiting active |
| SSH Exec (IcD4K740vpWSIuaZ) | OPERATIONAL — headerAuth, cred 1pNPY36DDz49OtKL |
| Gist-update (PoOofuf0OgaYJCBN) | OPERATIONAL |
| N8N_API_KEY (gateway .env) | VALID — oLzHLHvhX7AzK9m1 (New Key_0430'26, no-exp) |
| MCP Server | ✅ OPERATIONAL — 2027 key active |
| React source control | ❌ NOT IN GIT — Criterion 7 open |

---

## CANONICAL KEYS (post S-178/S-181 rotation)

```
x-gda-key:          gda-api-2027-AWqjhbxDYNcyV1mr
deploy-key:         gda-deploy-2027-a4zslQ79hn9A9UIi
GDA Webhook Auth cred ID:  1pNPY36DDz49OtKL
GitHub Gist PAT cred ID:   sKJFLNzetK86JnvO
VPS SSH Key cred ID:       NKOxLo5F81sRNPua   ← CANONICAL (ed25519)
Postgres cred ID:          HwronxMmGY5XDGEt
N8N_API_KEY (gateway .env): oLzHLHvhX7AzK9m1 DB row JWT (New Key_0430'26)
```

---

## GATEWAY CONFIG (post S-184)

```
Service:       gda-gateway (systemd, enabled)
Listens:       0.0.0.0:8788
WorkingDir:    /opt/gda-api-gateway-v1/
EnvFile:       /opt/gda-api-gateway-v1/.env
N8N_BASE_URL:  https://n8n.csr-llc.tech
N8N_API_BASE:  https://n8n.csr-llc.tech/api/v1
N8N_API_KEY:   ✅ VALID — oLzHLHvhX7AzK9m1 JWT (New Key_0430'26)
nginx bridge:  172.18.0.1 (corrected S-183)
```

---

## KEY IDs (quick reference)
```
Dashboard-Mega:    UYGJPu7N5YZblvEU
SSH Exec:          IcD4K740vpWSIuaZ
Deploy:            8GnGxnBL9TJjj1i2
Gist-update:       PoOofuf0OgaYJCBN
Morning Briefing:  YIvCdrOgF1LGmFNL
Briefing API:      0zVPgmYsvcqhyyo6
Capture-Plan:      QgperN6cuOpfnb09
agent-runner:      TxcPdvx2Ld9rE9er
fix-runner:        aAVitXXjGWaP7bb2
GDA Webhook Cred:  1pNPY36DDz49OtKL
GitHub Gist PAT:   sKJFLNzetK86JnvO
VPS SSH Key:       NKOxLo5F81sRNPua
Postgres:          HwronxMmGY5XDGEt
MCP Proxy:         8r0ss5z6X3i0yuqi
```

---

## STANDING HARD RULES (never break)
- **Switch node** → broken platform-wide → use IF or Code nodes
- **LangChain cred `d92MU0tRK7bEGV83`** → permanently broken → use HTTP + `$env.ANTHROPIC_API_KEY`
- **Postgres typeVersion 2.5/2.6** → inline `{{ $json.field }}` in SQL only
- **App.jsx / GDALaunchpad.jsx source** → canonical at /opt/gda-command/src/ → edit source, vite build, cp dist
- **n8n container restart** → never `docker compose up -d n8n` from within n8n
- **N8N_ENCRYPTION_KEY** → must persist in `/root/n8n-envision/.env`
- **MCP test trigger** → does NOT pass x-gda-key → use temporary auth bypass pattern if needed
- **RR-38, RR-28** → RESOLVED — do not reference as frozen
- **nginx.conf** → mounted volume at /root/gda-frontend/nginx.conf → edit on host, restart container
- **N8N_API_KEY for gateway** → use no-exp JWT from user_api_keys DB table, NOT SHA-256 hash

---

## SESSION PROTOCOL REMINDER
- Do not interrogate. Do not run in circles. Do not contradict prior sessions.
- If Shawn says "continue" / "go" / anything ambiguous → execute top item from queue above.
- Close every session with R-SR-09 (4 artifacts).
- AUTONOMY RULE: Claude executes everything via MCP. Never ask Shawn to manually edit files.

---
*S-185 Kickoff | GDA Command Platform | EIS / GDA OU3 | CONFIDENTIAL*
