# GDA Command Platform — S-206 Kickoff
**Platform Version:** v205 → v206  
**Date:** Next session after 2026-05-05  
**Platform Manager:** Shawn Seffernick, President EIS/OU3  

---

## Canonical Baseline at S-205 Close

| Component | ID | Status |
|---|---|---|
| Frontend | n8n-envision-gda-frontend-1 | UP — gda.csr-llc.tech LIVE |
| GDA.api.launchpad | GrbSQxeJs7ag6zXx | ACTIVE — 103 PURSUE / 70 EVAL / ~$2.3B |
| GDA.api.pipeline | f4PLgyzEu0tj3R5Y | ACTIVE — 100-row table |
| GDA.util.gist-update | t2209zk3c9x0OS9S | ACTIVE (NEW S-205) |
| GDA.dev.deploy | 8GnGxnBL9TJjj1i2 | ACTIVE — versionCounter 939, SSH expr fixed |
| GDA.cron.learning-engine | fZpqchmmPnqAmiMq | ACTIVE — 12 weights calibrated |
| gda_feedback | — | 8 rows |
| gda_learned_weights | — | 12 rows, calibrated 2026-05-05 02:48:36 UTC |

---

## S-206 Priority Queue

### P1 — Deploy Live Test (HP-DEPLOY carry-forward)
**Debt:** SSH expression fix was patched but a live test deploy was not fired.  
**Required:**  
- POST to `https://n8n.csr-llc.tech/webhook/gda-deploy` with `mode: build_only` and valid auth header `x-gda-auth: gda-deploy-2027-AWqjhbxDYNcyV1mr`  
- Confirm SSH Write Files and SSH Build both return non-empty stdout in execution log  
- Confirm `DEPLOY_COMPLETE_<epoch>` marker appears  
- Confirm Notify Gist fires to `t2209zk3c9x0OS9S` and Gist `dd562918f676affd62153a5f06e7d7d9` is updated  
- Confirm frontend routes /, /pipeline, /fast-track all 200 post-deploy  
**Success:** Full end-to-end deploy with visible logs, DEPLOY_COMPLETE, and Gist updated.

### P2 — Retool KPI Binding (S-164-01 carry-forward)
**Debt:** gdacommand.retool.com Launchpad KPIs show $0.  
**Required:** In Retool Launchpad app, bind numeric KPI component to `kpis.weighted_pipeline_raw` and formatted display to `kpis.weighted_pipeline`.  
**Note:** Cannot be executed via MCP — requires Retool editor browser access.  
**Success:** Retool shows non-zero pipeline value matching Launchpad API.

### P3 — Gist Credential Verification
**Debt:** `GDA.util.gist-update` (t2209zk3c9x0OS9S) uses credential `sKJFLNzetK86JnvO` typed as `githubApi`. Verify the PATCH Gist node (`n8n-nodes-base.httpRequest` typeVersion 4.2) is wired with a correct Bearer token Authorization header, or confirm the credential type resolves correctly.  
**Required:**  
- Fire a test POST to `gda-gist-update-v2` webhook (use RR-44 pattern)  
- Confirm Gist PATCH returns 200 and gist-state.md is updated  
**Success:** Gist updated with session state on demand.

### P4 — HP-6: Webhook Key Rotation (carry-forward from prior queue)
**Debt:** `gda-api-2026-secure` and `gda-deploy-2026-secure` need rotation to 2027 variants.  
**Note:** Auth Guard in deploy already uses `gda-deploy-2027-AWqjhbxDYNcyV1mr` — confirm all callers are updated.  
**Required:** Update n8n credential `fTrhOzBkjS1s67bm` and patch App.jsx API calls if any reference old key.

---

## Hard Rules — Must Be Followed Every Session

- **Do not touch:** canonical ingest `MJapg8dGkvEzLn0K`, frozen `1G4gw4N7DFtVZKF7`, frozen `NQmaj5nu4TBQxBgD`  
- **Switch nodes BROKEN** platform-wide — use IF or Code nodes  
- **Postgres typeVersion 2.5/2.6:** inline `{{ $json.field }}` only — no `queryValues`, no `queryReplacement`  
- **LangChain cred `d92MU0tRK7bEGV83` DEAD** — use HTTP Request with `$env.ANTHROPIC_API_KEY`  
- **No `docker compose up -d n8n` from within n8n** — self-referential restart loop  
- **N8N_ENCRYPTION_KEY must persist** in `/root/n8n-envision/.env` — recover before any restart  
- **App.jsx writes must be UTF-8** — canonical backup at `/opt/gda-command/src/App.jsx.bak-s158-kpi`  
- **RR-38 and RR-28 are RESOLVED/CLOSED** — do not reference as frozen  

---

## Session Protocol

1. First action: `tool_search("n8n")` to load MCP  
2. Check for new priority items before defaulting to queue above  
3. Execute top queue item autonomously — do not ask Shawn what to work on  
4. Close with R-SR-09: Session Delta DOCX, DevOps Report DOCX, Master Build XLSX (versioned), next-session Kickoff MD  

---

## Key IDs Reference

| Resource | ID/Value |
|---|---|
| Deploy webhook path | `gda-deploy` |
| Deploy auth header | `x-gda-auth: gda-deploy-2027-AWqjhbxDYNcyV1mr` |
| Gist update webhook path | `gda-gist-update-v2` |
| Gist ID | `dd562918f676affd62153a5f06e7d7d9` |
| GitHub Gist PAT credential | `sKJFLNzetK86JnvO` |
| GDA Webhook Auth credential | `1pNPY36DDz49OtKL` |
| VPS Root SSH credential | `VqYFb1aRGJa8UfBc` |
| SSH workflow | `IcD4K740vpWSIuaZ` |
| Telegram chat_id (Shawn) | `8631035943` |
| GDA Postgres credential | `HwronxMmGY5XDGEt` |
