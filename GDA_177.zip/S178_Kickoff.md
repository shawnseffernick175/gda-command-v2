# S-178 SESSION KICKOFF
**GDA Command Platform | EIS / GDA OU3 | Shawn Seffernick**
**Generated: 2026-05-01 (S-177 Close)**

---

## MANDATORY FIRST ACTION
```
tool_search("n8n")   ← load MCP before ANY other action
```

---

## CARRY-FORWARD STATUS
- R-SR-09 artifacts from S-176/S-177 carry: **COMPLETE** (generated S-177 open)
- 4 artifacts delivered: Session Delta DOCX, DevOps Report DOCX, Master Build XLSX (v4.177), this Kickoff MD
- No outstanding artifact debt entering S-178

---

## S-178 PRIORITY QUEUE (Execute in Order)

| Rank | ID | Priority | Description |
|------|----|----------|-------------|
| 1 | **HP-6** | 🔴 HIGH | Webhook key rotation: `gda-api-2026-secure` + `gda-deploy-2026-secure`. Update n8n cred `fTrhOzBkjS1s67bm`, patch App.jsx. |
| 2 | **HP-7** | 🔴 HIGH | nginx rate limiting via SSH to VPS (187.77.206.105) |
| 3 | **GIST-RBL** | 🟡 MED | Rebuild Gist update workflow (`t85atQIzsTajgUre` no longer exists) |
| 4 | **S-164-01** | 🟡 MED | Retool Launchpad KPI binding mismatch ($0 display) — frontend fix |
| 5 | **AN-1** | 🟡 MED | Incumbent analysis + win themes seeded into AI agent |

---

## PLATFORM SNAPSHOT (entering S-178)

| Component | Status |
|-----------|--------|
| n8n | OPERATIONAL |
| Frontend (gda.csr-llc.tech) | OPERATIONAL |
| Postgres | OPERATIONAL |
| getMegaDash | LIVE ($2.3B+ pipeline) |
| Telegram Bot | ACTIVE |
| Retool Launchpad | PARTIAL (S-164-01 open) |

---

## STANDING HARD RULES (never break)
- **Switch node** → broken platform-wide → use IF or Code nodes
- **LangChain cred `d92MU0tRK7bEGV83`** → permanently broken → use HTTP + `$env.ANTHROPIC_API_KEY`
- **Postgres typeVersion 2.5/2.6** → inline `{{ $json.field }}` in SQL only. No `queryValues`. No `queryReplacement`.
- **App.jsx** → UTF-8 only. Large patches via base64 Python script.
- **n8n container restart** → never `docker compose up -d n8n` from within n8n (loop).
- **N8N_ENCRYPTION_KEY** → must persist in `/root/n8n-envision/.env`.
- **Webhook auth test** → temporarily patch to `none` → fire → restore `headerAuth` (RR-44 pattern).
- **RR-38, RR-28** → FROZEN. Do not reference as open.

---

## KEY IDs (quick reference)
```
Dashboard-Mega:    UYGJPu7N5YZblvEU
SSH Exec:          IcD4K740vpWSIuaZ   (x-gda-key: gda-api-2026-secure)
Deploy:            8GnGxnBL9TJjj1i2
Morning Briefing:  YIvCdrOgF1LGmFNL
Briefing API:      0zVPgmYsvcqhyyo6
Capture-Plan:      QgperN6cuOpfnb09
GDA Webhook Cred:  fTrhOzBkjS1s67bm
GitHub Gist PAT:   sKJFLNzetK86JnvO
VPS Root SSH:      VqYFb1aRGJa8UfBc
Telegram user_id:  8626724926
Telegram chat_id:  8631035943
```

---

## SESSION PROTOCOL REMINDER
- Do not interrogate. Do not run in circles. Do not contradict prior sessions.
- If Shawn says "continue" / "go" / anything ambiguous → execute top item from queue above.
- Close every session with R-SR-09 (4 artifacts). If tool limit hit, carry to next session open.

---
*S-178 Kickoff | GDA Command Platform | EIS / GDA OU3 | CONFIDENTIAL*
