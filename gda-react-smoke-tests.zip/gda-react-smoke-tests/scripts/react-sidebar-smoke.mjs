import { chromium } from "playwright";
import fs from "fs";
import path from "path";

const BASE_URL = process.env.GDA_REACT_URL || "https://gda.csr-llc.tech";
const REPORT_DIR = path.resolve(process.cwd(), "reports");

const navItems = [
  "Launchpad",
  "AI Agent Chat",
  "Daily SITREP",
  "Morning Brief",
  "Intel Feed",
  "Deep Research",
  "Meeting Notes",
  "Competitive Intel",
  "Bid Strategy",
  "OODA Loop",
  "Opportunity Tracker",
  "Pwin Calculator",
  "Capture Plan",
  "Compliance Matrix",
  "Document Hub & PPT",
  "Email Drafter",
  "Proposal Review",
  "Proposal Factory",
  "Risk Register",
  "Financial Bible",
  "Platform Health",
  "Platform Guide",
  "Prompt Architect"
];

function uniqueApiCalls(calls) {
  return [...new Map(calls.map((call) => [`${call.method} ${call.url}`, call])).values()];
}

function isNavigationAbort(requestFailure) {
  return String(requestFailure.errorText || "").includes("ERR_ABORTED");
}

function mdEscape(value) {
  return String(value ?? "").replaceAll("|", "\\|").replaceAll("\n", " ");
}

async function main() {
  fs.mkdirSync(REPORT_DIR, { recursive: true });

  const browser = await chromium.launch({ headless: true });
  const context = await browser.newContext({ viewport: { width: 1440, height: 1000 } });
  const page = await context.newPage();

  const results = [];
  const startUrl = `${BASE_URL}/?v=${Date.now()}#launchpad`;
  await page.goto(startUrl, { waitUntil: "domcontentloaded", timeout: 30000 });
  await page.waitForTimeout(3000);

  for (const label of navItems) {
    const consoleMessages = [];
    const failedRequests = [];
    const requests = [];

    const onConsole = (msg) => {
      if (["error", "warning"].includes(msg.type())) {
        consoleMessages.push({
          type: msg.type(),
          text: msg.text(),
          location: msg.location()
        });
      }
    };

    const onRequest = (req) => {
      const url = req.url();
      if (url.includes("n8n.csr-llc.tech/webhook") || url.includes("gda.csr-llc.tech/api/")) {
        requests.push({ method: req.method(), url });
      }
    };

    const onRequestFailed = (req) => {
      const url = req.url();
      if (url.includes("n8n.csr-llc.tech") || url.includes("gda.csr-llc.tech/api/")) {
        failedRequests.push({
          url,
          errorText: req.failure()?.errorText || ""
        });
      }
    };

    page.on("console", onConsole);
    page.on("request", onRequest);
    page.on("requestfailed", onRequestFailed);

    let clickStatus = "clicked";
    let bodyPreview = "";

    try {
      const locator = page.getByText(label, { exact: true }).first();
      await locator.scrollIntoViewIfNeeded({ timeout: 3000 }).catch(() => {});
      await locator.click({ timeout: 8000 });
      await page.waitForTimeout(2500);
      bodyPreview = (await page.locator("body").innerText({ timeout: 3000 }).catch(() => "")).slice(0, 350);
    } catch (error) {
      clickStatus = `failed: ${String(error.message || error).split("\n")[0]}`;
      bodyPreview = (await page.locator("body").innerText({ timeout: 3000 }).catch(() => "")).slice(0, 350);
    }

    page.off("console", onConsole);
    page.off("request", onRequest);
    page.off("requestfailed", onRequestFailed);

    const directCalls = requests.filter((request) => request.url.includes("n8n.csr-llc.tech/webhook"));
    const apiCalls = requests.filter((request) => request.url.includes("gda.csr-llc.tech/api/"));
    const consoleErrors = consoleMessages.filter((message) => message.type === "error");
    const blockingFailedRequests = failedRequests.filter((request) => !isNavigationAbort(request));

    const passed =
      clickStatus === "clicked" &&
      directCalls.length === 0 &&
      consoleErrors.length === 0 &&
      blockingFailedRequests.length === 0;

    results.push({
      label,
      passed,
      clickStatus,
      url: page.url(),
      directCallCount: directCalls.length,
      directCalls,
      apiCallCount: uniqueApiCalls(apiCalls).length,
      apiCalls: uniqueApiCalls(apiCalls),
      consoleErrorCount: consoleErrors.length,
      consoleWarningCount: consoleMessages.filter((message) => message.type === "warning").length,
      consoleMessages,
      failedRequests,
      blockingFailedRequests,
      bodyPreview
    });
  }

  await browser.close();

  const totals = {
    routesTested: results.length,
    routesPassed: results.filter((result) => result.passed).length,
    routesFailed: results.filter((result) => !result.passed).length,
    directN8nWebhookCalls: results.reduce((sum, result) => sum + result.directCallCount, 0),
    consoleErrors: results.reduce((sum, result) => sum + result.consoleErrorCount, 0),
    blockingFailedRequests: results.reduce((sum, result) => sum + result.blockingFailedRequests.length, 0)
  };

  const report = {
    ok: totals.routesFailed === 0,
    overallStatus: totals.routesFailed === 0 ? "PASS" : "FAIL",
    testedAt: new Date().toISOString(),
    baseUrl: BASE_URL,
    totals,
    results
  };

  const jsonPath = path.join(REPORT_DIR, "react-sidebar-smoke-latest.json");
  const mdPath = path.join(REPORT_DIR, "react-sidebar-smoke-latest.md");
  fs.writeFileSync(jsonPath, JSON.stringify(report, null, 2), "utf8");

  const mdRows = results
    .map((result) => {
      const failed = result.blockingFailedRequests.map((request) => request.url).join("<br>");
      return `| ${mdEscape(result.label)} | ${result.passed ? "PASS" : "FAIL"} | ${result.directCallCount} | ${result.consoleErrorCount} | ${result.blockingFailedRequests.length} | ${mdEscape(result.url)} | ${mdEscape(failed)} |`;
    })
    .join("\n");

  const markdown = `# GDA React Sidebar Smoke Report

Generated: ${report.testedAt}

Overall: **${report.overallStatus}**

| Metric | Value |
|---|---:|
| Routes tested | ${totals.routesTested} |
| Routes passed | ${totals.routesPassed} |
| Routes failed | ${totals.routesFailed} |
| Direct n8n webhook calls | ${totals.directN8nWebhookCalls} |
| Console errors | ${totals.consoleErrors} |
| Blocking failed requests | ${totals.blockingFailedRequests} |

## Route Results

| Route | Status | Direct n8n calls | Console errors | Blocking failed requests | URL | Failed request URLs |
|---|---:|---:|---:|---:|---|---|
${mdRows}
`;

  fs.writeFileSync(mdPath, markdown, "utf8");

  console.log(`Overall: ${report.overallStatus}`);
  console.log(`Routes tested: ${totals.routesTested}`);
  console.log(`Routes passed: ${totals.routesPassed}`);
  console.log(`Routes failed: ${totals.routesFailed}`);
  console.log(`Direct n8n webhook calls: ${totals.directN8nWebhookCalls}`);
  console.log(`Console errors: ${totals.consoleErrors}`);
  console.log(`Blocking failed requests: ${totals.blockingFailedRequests}`);
  console.log(`JSON report: ${jsonPath}`);
  console.log(`Markdown report: ${mdPath}`);

  if (!report.ok) {
    process.exitCode = 1;
  }
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
