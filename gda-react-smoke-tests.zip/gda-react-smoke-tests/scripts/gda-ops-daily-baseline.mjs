import { spawnSync } from "child_process";
import fs from "fs";
import path from "path";

const REPORT_DIR = path.resolve(process.cwd(), "reports");
const QA_AGENT_WEBHOOK_URL = process.env.GDA_QA_AGENT_WEBHOOK_URL || "";
const QA_AGENT_KEY = process.env.GDA_QA_AGENT_KEY || "";

const qaActions = [
  { name: "QA agent health", action: "health" },
  { name: "n8n React-used workflow smoke", action: "test_react_used_workflows" },
  { name: "n8n Retool-used workflow smoke", action: "test_retool_used_workflows" },
  { name: "Latest failed n8n workflows", action: "return_latest_failed_workflows", body: { limit: 25 }, reviewOnly: true }
];

function mdEscape(value) {
  return String(value ?? "").replaceAll("|", "\\|").replaceAll("\n", " ");
}

function readJson(fileName) {
  const fullPath = path.join(REPORT_DIR, fileName);
  if (!fs.existsSync(fullPath)) return null;
  return JSON.parse(fs.readFileSync(fullPath, "utf8"));
}

function runReactBaseline() {
  console.log("\n=== React Daily Baseline ===");
  const result = spawnSync("npm", ["run", "baseline", "--silent"], {
    cwd: process.cwd(),
    stdio: "inherit",
    shell: process.platform === "win32"
  });
  const report = readJson("gda-react-daily-baseline-latest.json");
  const exitCode = typeof result.status === "number" ? result.status : 1;
  return {
    name: "React daily baseline",
    type: "react",
    status: exitCode === 0 && report?.ok ? "PASS" : "FAIL",
    ok: Boolean(exitCode === 0 && report?.ok),
    exitCode,
    reportFile: "gda-react-daily-baseline-latest.json",
    totals: report?.totals || {},
    error: report ? "" : "React baseline report was not written."
  };
}

async function callQaAgent(actionDef) {
  if (!QA_AGENT_WEBHOOK_URL || !QA_AGENT_KEY) {
    return {
      name: actionDef.name,
      type: "n8n",
      status: "SKIPPED",
      ok: true,
      skipped: true,
      reviewOnly: Boolean(actionDef.reviewOnly),
      error: "Set GDA_QA_AGENT_WEBHOOK_URL and GDA_QA_AGENT_KEY to enable this check."
    };
  }

  const startedAt = Date.now();
  const body = {
    action: actionDef.action,
    ...(actionDef.body || {})
  };

  try {
    const response = await fetch(QA_AGENT_WEBHOOK_URL, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        "x-gda-qa-key": QA_AGENT_KEY
      },
      body: JSON.stringify(body)
    });
    const text = await response.text();
    let parsed = null;
    try {
      parsed = text ? JSON.parse(text) : null;
    } catch {
      parsed = { rawText: text.slice(0, 2000) };
    }

    const status = classifyQaResult(actionDef, response.status, response.ok, parsed);
    return {
      name: actionDef.name,
      type: "n8n",
      action: actionDef.action,
      status: status.status,
      ok: status.ok,
      reviewOnly: Boolean(actionDef.reviewOnly),
      httpStatus: response.status,
      durationMs: Date.now() - startedAt,
      summary: status.summary,
      responsePreview: summarizeResponse(actionDef, parsed)
    };
  } catch (error) {
    return {
      name: actionDef.name,
      type: "n8n",
      action: actionDef.action,
      status: "FAIL",
      ok: false,
      reviewOnly: Boolean(actionDef.reviewOnly),
      durationMs: Date.now() - startedAt,
      error: String(error.message || error)
    };
  }
}

function classifyQaResult(actionDef, httpStatus, httpOk, parsed) {
  if (!httpOk) {
    return { status: "FAIL", ok: false, summary: `HTTP ${httpStatus}` };
  }
  if (!parsed || parsed.ok === false) {
    return { status: "FAIL", ok: false, summary: parsed?.error || "QA agent returned ok=false or empty response." };
  }

  if (actionDef.action === "test_react_used_workflows" || actionDef.action === "test_retool_used_workflows") {
    const failed = Number(parsed.failed || 0);
    const passed = Number(parsed.passed || 0);
    const total = Number(parsed.total || 0);
    return {
      status: failed === 0 ? "PASS" : "FAIL",
      ok: failed === 0,
      summary: `${passed}/${total} passed; ${failed} failed`
    };
  }

  if (actionDef.action === "return_latest_failed_workflows") {
    const data = parsed.executions?.data || parsed.executions || [];
    const count = Array.isArray(data) ? data.length : 0;
    return {
      status: count > 0 ? "NEEDS_REVIEW" : "PASS",
      ok: true,
      summary: `${count} recent failed execution record(s) returned`
    };
  }

  return { status: "PASS", ok: true, summary: "ok" };
}

function summarizeResponse(actionDef, parsed) {
  if (!parsed) return null;
  if (actionDef.action === "health") {
    return {
      agent: parsed.agent,
      mode: parsed.mode,
      n8nBaseConfigured: parsed.n8nBaseConfigured,
      n8nApiKeyConfigured: parsed.n8nApiKeyConfigured,
      webhookHeaderConfigured: parsed.webhookHeaderConfigured
    };
  }
  if (actionDef.action === "test_react_used_workflows" || actionDef.action === "test_retool_used_workflows") {
    return {
      group: parsed.group,
      total: parsed.total,
      passed: parsed.passed,
      failed: parsed.failed
    };
  }
  if (actionDef.action === "return_latest_failed_workflows") {
    const data = parsed.executions?.data || parsed.executions || [];
    return Array.isArray(data)
      ? data.slice(0, 10).map((item) => ({
          id: item.id,
          workflowId: item.workflowId,
          workflowName: item.workflowName,
          status: item.status,
          startedAt: item.startedAt
        }))
      : parsed;
  }
  return parsed;
}

function summarizeReactTotals(result) {
  const totals = result.totals || {};
  return {
    routes: `${totals.routesPassed || 0}/${totals.routesTested || 0}`,
    functional: `${totals.functionalChecksPassed || 0}/${totals.functionalChecksTested || 0}`,
    api: `${totals.apiEndpointsPassed || 0}/${totals.apiEndpointsTested || 0}`,
    directN8nWebhookCalls: totals.directN8nWebhookCalls || 0,
    consoleErrors: totals.consoleErrors || 0,
    blockingFailedRequests: totals.blockingFailedRequests || 0,
    apiAuthFailures: totals.apiAuthFailures || 0
  };
}

function writeReports(results) {
  fs.mkdirSync(REPORT_DIR, { recursive: true });
  const hardFailures = results.filter((result) => !result.ok && result.status !== "NEEDS_REVIEW");
  const needsReview = results.filter((result) => result.status === "NEEDS_REVIEW");
  const skipped = results.filter((result) => result.status === "SKIPPED");
  const ok = hardFailures.length === 0;
  const overallStatus = hardFailures.length > 0 ? "FAIL" : needsReview.length > 0 || skipped.length > 0 ? "NEEDS_REVIEW" : "PASS";

  const report = {
    ok,
    overallStatus,
    testedAt: new Date().toISOString(),
    results,
    summary: {
      hardFailures: hardFailures.length,
      needsReview: needsReview.length,
      skipped: skipped.length,
      react: summarizeReactTotals(results.find((result) => result.type === "react") || {})
    }
  };

  const jsonPath = path.join(REPORT_DIR, "gda-ops-daily-baseline-latest.json");
  const mdPath = path.join(REPORT_DIR, "gda-ops-daily-baseline-latest.md");
  fs.writeFileSync(jsonPath, JSON.stringify(report, null, 2), "utf8");

  const rows = results.map((result) => {
    const summary = result.summary || result.error || (result.skipped ? "Skipped" : "");
    return `| ${mdEscape(result.name)} | ${mdEscape(result.status)} | ${mdEscape(summary)} |`;
  }).join("\n");

  const markdown = `# GDA Ops Daily Baseline Report

Generated: ${report.testedAt}

Overall: **${report.overallStatus}**

| Metric | Value |
|---|---:|
| Hard failures | ${report.summary.hardFailures} |
| Needs review | ${report.summary.needsReview} |
| Skipped checks | ${report.summary.skipped} |
| React sidebar routes | ${report.summary.react.routes} |
| React functional checks | ${report.summary.react.functional} |
| React API endpoints | ${report.summary.react.api} |
| Direct n8n webhook calls | ${report.summary.react.directN8nWebhookCalls} |
| Browser console errors | ${report.summary.react.consoleErrors} |
| Blocking failed requests | ${report.summary.react.blockingFailedRequests} |
| API auth failures | ${report.summary.react.apiAuthFailures} |

## Check Results

| Check | Status | Summary |
|---|---:|---|
${rows}

## Notes

This command is read-only. It does not change n8n workflows, Postgres data, deployed React code, opportunities, risks, action items, or external integrations.

If n8n checks are skipped, set \`GDA_QA_AGENT_WEBHOOK_URL\` and \`GDA_QA_AGENT_KEY\` in PowerShell before running, or use \`.\\run-ops-baseline-windows.ps1\` and enter them when prompted.
`;

  fs.writeFileSync(mdPath, markdown, "utf8");
  return { report, jsonPath, mdPath };
}

const results = [runReactBaseline()];
for (const actionDef of qaActions) {
  console.log(`\n=== ${actionDef.name} ===`);
  const result = await callQaAgent(actionDef);
  console.log(`${result.status}: ${result.summary || result.error || "done"}`);
  results.push(result);
}

const { report, jsonPath, mdPath } = writeReports(results);

console.log("\n=== Ops Daily Baseline Summary ===");
console.log(`Overall: ${report.overallStatus}`);
console.log(`Hard failures: ${report.summary.hardFailures}`);
console.log(`Needs review: ${report.summary.needsReview}`);
console.log(`Skipped checks: ${report.summary.skipped}`);
console.log(`React routes: ${report.summary.react.routes}`);
console.log(`React functional checks: ${report.summary.react.functional}`);
console.log(`React API endpoints: ${report.summary.react.api}`);
console.log(`JSON report: ${jsonPath}`);
console.log(`Markdown report: ${mdPath}`);

if (report.summary.hardFailures > 0) {
  process.exitCode = 1;
}
