import { spawnSync } from "child_process";
import fs from "fs";
import path from "path";

const REPORT_DIR = path.resolve(process.cwd(), "reports");

const checks = [
  {
    name: "Sidebar route smoke",
    command: ["npm", ["run", "smoke", "--silent"]],
    jsonReport: "react-sidebar-smoke-latest.json",
    markdownReport: "react-sidebar-smoke-latest.md"
  },
  {
    name: "Functional smoke",
    command: ["npm", ["run", "functional", "--silent"]],
    jsonReport: "react-functional-smoke-latest.json",
    markdownReport: "react-functional-smoke-latest.md"
  },
  {
    name: "API proxy smoke",
    command: ["npm", ["run", "api", "--silent"]],
    jsonReport: "react-api-proxy-smoke-latest.json",
    markdownReport: "react-api-proxy-smoke-latest.md"
  }
];

function readJsonReport(fileName) {
  const fullPath = path.join(REPORT_DIR, fileName);
  if (!fs.existsSync(fullPath)) {
    return { ok: false, overallStatus: "MISSING", error: `Missing report: ${fileName}`, totals: {} };
  }
  return JSON.parse(fs.readFileSync(fullPath, "utf8"));
}

function mdEscape(value) {
  return String(value ?? "").replaceAll("|", "\\|").replaceAll("\n", " ");
}

function runCheck(check) {
  const [command, args] = check.command;
  console.log(`\n=== ${check.name} ===`);
  const result = spawnSync(command, args, {
    cwd: process.cwd(),
    stdio: "inherit",
    shell: process.platform === "win32"
  });

  const report = readJsonReport(check.jsonReport);
  const exitCode = typeof result.status === "number" ? result.status : 1;

  return {
    name: check.name,
    ok: Boolean(exitCode === 0 && report.ok),
    exitCode,
    status: exitCode === 0 && report.ok ? "PASS" : "FAIL",
    reportFile: check.jsonReport,
    markdownReport: check.markdownReport,
    testedAt: report.testedAt || null,
    totals: report.totals || {},
    error: report.error || ""
  };
}

function summarizeTotals(results) {
  const sidebar = results.find((result) => result.name === "Sidebar route smoke")?.totals || {};
  const functional = results.find((result) => result.name === "Functional smoke")?.totals || {};
  const api = results.find((result) => result.name === "API proxy smoke")?.totals || {};

  return {
    routesTested: sidebar.routesTested || 0,
    routesPassed: sidebar.routesPassed || 0,
    routesFailed: sidebar.routesFailed || 0,
    functionalChecksTested: functional.checksTested || 0,
    functionalChecksPassed: functional.checksPassed || 0,
    functionalChecksFailed: functional.checksFailed || 0,
    apiEndpointsTested: api.endpointsTested || 0,
    apiEndpointsPassed: api.endpointsPassed || 0,
    apiEndpointsFailed: api.endpointsFailed || 0,
    directN8nWebhookCalls: (sidebar.directN8nWebhookCalls || 0) + (functional.directN8nWebhookCalls || 0),
    consoleErrors: (sidebar.consoleErrors || 0) + (functional.consoleErrors || 0),
    blockingFailedRequests: (sidebar.blockingFailedRequests || 0) + (functional.blockingFailedRequests || 0),
    apiAuthFailures: api.authFailures || 0,
    apiEmptyResponses: api.emptyResponses || 0,
    apiHtmlResponses: api.htmlResponses || 0
  };
}

function writeReports(results) {
  fs.mkdirSync(REPORT_DIR, { recursive: true });

  const totals = summarizeTotals(results);
  const ok = results.every((result) => result.ok);
  const report = {
    ok,
    overallStatus: ok ? "PASS" : "FAIL",
    testedAt: new Date().toISOString(),
    totals,
    results
  };

  const jsonPath = path.join(REPORT_DIR, "gda-react-daily-baseline-latest.json");
  const mdPath = path.join(REPORT_DIR, "gda-react-daily-baseline-latest.md");
  fs.writeFileSync(jsonPath, JSON.stringify(report, null, 2), "utf8");

  const rows = results
    .map((result) => `| ${mdEscape(result.name)} | ${result.status} | ${result.exitCode} | ${mdEscape(result.reportFile)} |`)
    .join("\n");

  const markdown = `# GDA React Daily Baseline Report

Generated: ${report.testedAt}

Overall: **${report.overallStatus}**

| Metric | Value |
|---|---:|
| Sidebar routes tested | ${totals.routesTested} |
| Sidebar routes passed | ${totals.routesPassed} |
| Sidebar routes failed | ${totals.routesFailed} |
| Functional checks tested | ${totals.functionalChecksTested} |
| Functional checks passed | ${totals.functionalChecksPassed} |
| Functional checks failed | ${totals.functionalChecksFailed} |
| API endpoints tested | ${totals.apiEndpointsTested} |
| API endpoints passed | ${totals.apiEndpointsPassed} |
| API endpoints failed | ${totals.apiEndpointsFailed} |
| Direct n8n webhook calls | ${totals.directN8nWebhookCalls} |
| Browser console errors | ${totals.consoleErrors} |
| Blocking failed requests | ${totals.blockingFailedRequests} |
| API auth failures | ${totals.apiAuthFailures} |
| API empty responses | ${totals.apiEmptyResponses} |
| API HTML responses | ${totals.apiHtmlResponses} |

## Check Results

| Check | Status | Exit code | Detail report |
|---|---:|---:|---|
${rows}

## Interpretation

This baseline is safe and read-only. It does not change n8n, Postgres, opportunities, risks, action items, or deployed React code.

Passing means the live React app loaded its tested sidebar routes, key pages showed expected UI, and React-critical server-side proxy endpoints responded without auth failures.
`;

  fs.writeFileSync(mdPath, markdown, "utf8");
  return { report, jsonPath, mdPath };
}

const results = checks.map(runCheck);
const { report, jsonPath, mdPath } = writeReports(results);

console.log("\n=== Daily Baseline Summary ===");
console.log(`Overall: ${report.overallStatus}`);
console.log(`Sidebar routes: ${report.totals.routesPassed}/${report.totals.routesTested}`);
console.log(`Functional checks: ${report.totals.functionalChecksPassed}/${report.totals.functionalChecksTested}`);
console.log(`API endpoints: ${report.totals.apiEndpointsPassed}/${report.totals.apiEndpointsTested}`);
console.log(`Direct n8n webhook calls: ${report.totals.directN8nWebhookCalls}`);
console.log(`Browser console errors: ${report.totals.consoleErrors}`);
console.log(`Blocking failed requests: ${report.totals.blockingFailedRequests}`);
console.log(`API auth failures: ${report.totals.apiAuthFailures}`);
console.log(`JSON report: ${jsonPath}`);
console.log(`Markdown report: ${mdPath}`);

if (!report.ok) {
  process.exitCode = 1;
}
