import { chromium } from "playwright";
import fs from "fs";
import path from "path";

const BASE_URL = process.env.GDA_REACT_URL || "https://gda.csr-llc.tech";
const REPORT_DIR = path.resolve(process.cwd(), "reports");

const checks = [
  {
    name: "Launchpad dashboard basics",
    hash: "#launchpad",
    expectedText: [
      "Command Center",
      "ACTIVE OPPORTUNITIES",
      "OPPORTUNITY VALUE",
      "Top 10 Opportunities",
      "Market Analysis"
    ],
    forbiddenText: [
      "Failed to load funnel"
    ]
  },
  {
    name: "Opportunity Tracker basics",
    hash: "#opp-tracker",
    expectedText: [
      "Opportunity",
      "GDA",
      "Score"
    ],
    forbiddenText: [
      "Authorization data is wrong",
      "Unauthorized"
    ]
  },
  {
    name: "Platform Health basics",
    hash: "#platform-health",
    expectedText: [
      "Platform",
      "Health"
    ],
    forbiddenText: [
      "Authorization data is wrong",
      "Unauthorized"
    ]
  },
  {
    name: "Deep Research basics",
    hash: "#deep-research",
    expectedText: [
      "Deep",
      "Research"
    ],
    forbiddenText: [
      "Authorization data is wrong",
      "Unauthorized"
    ]
  },
  {
    name: "Proposal Factory basics",
    hash: "#proposal-factory",
    expectedText: [
      "Proposal",
      "Factory"
    ],
    forbiddenText: [
      "Authorization data is wrong",
      "Unauthorized"
    ]
  },
  {
    name: "Financial Bible basics",
    hash: "#aop-tracker",
    expectedText: [
      "Financial",
      "Bible"
    ],
    forbiddenText: [
      "Authorization data is wrong",
      "Unauthorized"
    ]
  },
  {
    name: "Risk Register basics",
    hash: "#risk",
    expectedText: [
      "Risk"
    ],
    forbiddenText: [
      "Authorization data is wrong",
      "Unauthorized"
    ]
  },
  {
    name: "Morning Brief basics",
    hash: "#daily-brief",
    expectedText: [
      "Morning",
      "Brief"
    ],
    forbiddenText: [
      "Authorization data is wrong",
      "Unauthorized"
    ]
  }
];

function uniqueApiCalls(calls) {
  return [...new Map(calls.map((call) => [`${call.method} ${call.url}`, call])).values()];
}

function isNavigationAbort(requestFailure) {
  return String(requestFailure.errorText || "").includes("ERR_ABORTED");
}

function mdEscape(value) {
  return String(value ?? "").replaceAll("|", "\\|").replaceAll("\n", " ");
}

async function runCheck(browser, check) {
  const context = await browser.newContext({ viewport: { width: 1440, height: 1000 } });
  const page = await context.newPage();
  const consoleMessages = [];
  const failedRequests = [];
  const requests = [];

  page.on("console", (msg) => {
    if (["error", "warning"].includes(msg.type())) {
      consoleMessages.push({
        type: msg.type(),
        text: msg.text(),
        location: msg.location()
      });
    }
  });

  page.on("request", (req) => {
    const url = req.url();
    if (url.includes("n8n.csr-llc.tech/webhook") || url.includes("gda.csr-llc.tech/api/")) {
      requests.push({ method: req.method(), url });
    }
  });

  page.on("requestfailed", (req) => {
    const url = req.url();
    if (url.includes("n8n.csr-llc.tech") || url.includes("gda.csr-llc.tech/api/")) {
      failedRequests.push({
        url,
        errorText: req.failure()?.errorText || ""
      });
    }
  });

  let status = "loaded";
  let bodyText = "";
  let title = "";

  try {
    await page.goto(`${BASE_URL}/?v=${Date.now()}${check.hash}`, { waitUntil: "domcontentloaded", timeout: 30000 });
    await page.waitForLoadState("networkidle", { timeout: 15000 }).catch(() => {});
    await page.waitForTimeout(2500);
    title = await page.title();
    bodyText = await page.locator("body").innerText({ timeout: 5000 });
  } catch (error) {
    status = `failed: ${String(error.message || error).split("\n")[0]}`;
    bodyText = await page.locator("body").innerText({ timeout: 3000 }).catch(() => "");
  }

  await context.close();

  const missingExpectedText = check.expectedText.filter((text) => !bodyText.toLowerCase().includes(text.toLowerCase()));
  const foundForbiddenText = check.forbiddenText.filter((text) => bodyText.toLowerCase().includes(text.toLowerCase()));
  const directCalls = requests.filter((request) => request.url.includes("n8n.csr-llc.tech/webhook"));
  const apiCalls = requests.filter((request) => request.url.includes("gda.csr-llc.tech/api/"));
  const consoleErrors = consoleMessages.filter((message) => message.type === "error");
  const blockingFailedRequests = failedRequests.filter((request) => !isNavigationAbort(request));

  const passed =
    status === "loaded" &&
    missingExpectedText.length === 0 &&
    foundForbiddenText.length === 0 &&
    directCalls.length === 0 &&
    consoleErrors.length === 0 &&
    blockingFailedRequests.length === 0;

  return {
    name: check.name,
    hash: check.hash,
    passed,
    status,
    title,
    missingExpectedText,
    foundForbiddenText,
    directCallCount: directCalls.length,
    directCalls,
    apiCallCount: uniqueApiCalls(apiCalls).length,
    apiCalls: uniqueApiCalls(apiCalls),
    consoleErrorCount: consoleErrors.length,
    consoleWarningCount: consoleMessages.filter((message) => message.type === "warning").length,
    consoleMessages,
    failedRequests,
    blockingFailedRequests,
    bodyPreview: bodyText.slice(0, 500)
  };
}

async function main() {
  fs.mkdirSync(REPORT_DIR, { recursive: true });

  const browser = await chromium.launch({ headless: true });
  const results = [];

  for (const check of checks) {
    results.push(await runCheck(browser, check));
  }

  await browser.close();

  const totals = {
    checksTested: results.length,
    checksPassed: results.filter((result) => result.passed).length,
    checksFailed: results.filter((result) => !result.passed).length,
    missingExpectedText: results.reduce((sum, result) => sum + result.missingExpectedText.length, 0),
    foundForbiddenText: results.reduce((sum, result) => sum + result.foundForbiddenText.length, 0),
    directN8nWebhookCalls: results.reduce((sum, result) => sum + result.directCallCount, 0),
    consoleErrors: results.reduce((sum, result) => sum + result.consoleErrorCount, 0),
    blockingFailedRequests: results.reduce((sum, result) => sum + result.blockingFailedRequests.length, 0)
  };

  const report = {
    ok: totals.checksFailed === 0,
    overallStatus: totals.checksFailed === 0 ? "PASS" : "FAIL",
    testedAt: new Date().toISOString(),
    baseUrl: BASE_URL,
    totals,
    results
  };

  const jsonPath = path.join(REPORT_DIR, "react-functional-smoke-latest.json");
  const mdPath = path.join(REPORT_DIR, "react-functional-smoke-latest.md");
  fs.writeFileSync(jsonPath, JSON.stringify(report, null, 2), "utf8");

  const mdRows = results
    .map((result) => {
      return `| ${mdEscape(result.name)} | ${result.passed ? "PASS" : "FAIL"} | ${mdEscape(result.hash)} | ${mdEscape(result.missingExpectedText.join(", "))} | ${mdEscape(result.foundForbiddenText.join(", "))} | ${result.directCallCount} | ${result.consoleErrorCount} | ${result.blockingFailedRequests.length} |`;
    })
    .join("\n");

  const markdown = `# GDA React Functional Smoke Report

Generated: ${report.testedAt}

Overall: **${report.overallStatus}**

| Metric | Value |
|---|---:|
| Checks tested | ${totals.checksTested} |
| Checks passed | ${totals.checksPassed} |
| Checks failed | ${totals.checksFailed} |
| Missing expected text items | ${totals.missingExpectedText} |
| Forbidden text matches | ${totals.foundForbiddenText} |
| Direct n8n webhook calls | ${totals.directN8nWebhookCalls} |
| Console errors | ${totals.consoleErrors} |
| Blocking failed requests | ${totals.blockingFailedRequests} |

## Check Results

| Check | Status | Hash | Missing expected text | Forbidden text found | Direct n8n calls | Console errors | Blocking failed requests |
|---|---:|---|---|---|---:|---:|---:|
${mdRows}
`;

  fs.writeFileSync(mdPath, markdown, "utf8");

  console.log(`Overall: ${report.overallStatus}`);
  console.log(`Checks tested: ${totals.checksTested}`);
  console.log(`Checks passed: ${totals.checksPassed}`);
  console.log(`Checks failed: ${totals.checksFailed}`);
  console.log(`Direct n8n webhook calls: ${totals.directN8nWebhookCalls}`);
  console.log(`Console errors: ${totals.consoleErrors}`);
  console.log(`Blocking failed requests: ${totals.blockingFailedRequests}`);
  console.log(`JSON report: ${jsonPath}`);
  console.log(`Markdown report: ${mdPath}`);

  if (!report.ok) {
    process.exitCode = 1;
  }
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
