import fs from "fs";
import path from "path";

const BASE_URL = process.env.GDA_REACT_URL || "https://gda.csr-llc.tech";
const REPORT_DIR = path.resolve(process.cwd(), "reports");

const endpoints = [
  {
    name: "dashboard mega",
    method: "POST",
    path: "/api/gda-dashboard-mega",
    body: { source: "gda-react-smoke-tests", mode: "smoke" }
  },
  {
    name: "trends",
    method: "POST",
    path: "/api/gda-trends",
    body: { source: "gda-react-smoke-tests", mode: "smoke" }
  },
  {
    name: "daily actions",
    method: "POST",
    path: "/api/gda-daily-actions",
    body: { source: "gda-react-smoke-tests", mode: "smoke" }
  },
  {
    name: "opportunity tracker",
    method: "POST",
    path: "/api/gda-opp-tracker",
    body: { source: "gda-react-smoke-tests", mode: "list", limit: 5 }
  },
  {
    name: "launchpad funnel",
    method: "POST",
    path: "/api/gda-launchpad-funnel",
    body: { source: "gda-react-smoke-tests", mode: "smoke" }
  },
  {
    name: "deep research history",
    method: "POST",
    path: "/api/gda-deep-research-history",
    body: { source: "gda-react-smoke-tests", mode: "history", limit: 5 }
  },
  {
    name: "capture plan list",
    method: "POST",
    path: "/api/gda-capture-plan",
    body: { source: "gda-react-smoke-tests", action: "list", limit: 5 }
  },
  {
    name: "risk register",
    method: "POST",
    path: "/api/gda-risk",
    body: { source: "gda-react-smoke-tests", mode: "list", limit: 5 }
  },
  {
    name: "platform health",
    method: "POST",
    path: "/api/gda-platform-health",
    body: { source: "gda-react-smoke-tests", mode: "smoke" }
  },
  {
    name: "morning briefing",
    method: "GET",
    path: "/api/gda-morning-briefing",
    body: null
  }
];

function looksLikeAuthFailure(text) {
  const lower = text.toLowerCase();
  return (
    lower.includes("authorization data is wrong") ||
    lower.includes("unauthorized") ||
    lower.includes("forbidden") ||
    lower.includes("missing or invalid")
  );
}

function mdEscape(value) {
  return String(value ?? "").replaceAll("|", "\\|").replaceAll("\n", " ");
}

async function callEndpoint(endpoint) {
  const startedAt = Date.now();
  const url = `${BASE_URL}${endpoint.path}`;
  const headers = {
    Accept: "application/json",
    "Content-Type": "application/json"
  };

  let status = 0;
  let ok = false;
  let responseText = "";
  let contentType = "";
  let error = "";

  try {
    const response = await fetch(url, {
      method: endpoint.method,
      headers,
      body: endpoint.method === "GET" ? undefined : JSON.stringify(endpoint.body || {})
    });
    status = response.status;
    ok = response.ok;
    contentType = response.headers.get("content-type") || "";
    responseText = await response.text();
  } catch (err) {
    error = String(err.message || err);
  }

  let parsed = null;
  if (responseText) {
    try {
      parsed = JSON.parse(responseText);
    } catch {
      parsed = null;
    }
  }

  const authFailure = looksLikeAuthFailure(responseText || error);
  const emptyResponse = !responseText || responseText.trim().length === 0;
  const htmlResponse = responseText.trim().toLowerCase().startsWith("<!doctype") || responseText.trim().toLowerCase().startsWith("<html");
  const passed = Boolean(ok && !authFailure && !emptyResponse && !htmlResponse);

  return {
    name: endpoint.name,
    method: endpoint.method,
    path: endpoint.path,
    url,
    passed,
    httpStatus: status,
    ok,
    durationMs: Date.now() - startedAt,
    contentType,
    authFailure,
    emptyResponse,
    htmlResponse,
    error,
    responsePreview: parsed ?? responseText.slice(0, 1000)
  };
}

async function main() {
  fs.mkdirSync(REPORT_DIR, { recursive: true });

  const results = [];
  for (const endpoint of endpoints) {
    results.push(await callEndpoint(endpoint));
  }

  const totals = {
    endpointsTested: results.length,
    endpointsPassed: results.filter((result) => result.passed).length,
    endpointsFailed: results.filter((result) => !result.passed).length,
    authFailures: results.filter((result) => result.authFailure).length,
    emptyResponses: results.filter((result) => result.emptyResponse).length,
    htmlResponses: results.filter((result) => result.htmlResponse).length
  };

  const report = {
    ok: totals.endpointsFailed === 0,
    overallStatus: totals.endpointsFailed === 0 ? "PASS" : "FAIL",
    testedAt: new Date().toISOString(),
    baseUrl: BASE_URL,
    totals,
    results
  };

  const jsonPath = path.join(REPORT_DIR, "react-api-proxy-smoke-latest.json");
  const mdPath = path.join(REPORT_DIR, "react-api-proxy-smoke-latest.md");
  fs.writeFileSync(jsonPath, JSON.stringify(report, null, 2), "utf8");

  const mdRows = results
    .map((result) => {
      const flags = [
        result.authFailure ? "auth failure" : "",
        result.emptyResponse ? "empty response" : "",
        result.htmlResponse ? "html response" : "",
        result.error ? result.error : ""
      ].filter(Boolean).join("; ");
      return `| ${mdEscape(result.name)} | ${result.passed ? "PASS" : "FAIL"} | ${result.httpStatus} | ${result.durationMs} | ${mdEscape(result.path)} | ${mdEscape(flags)} |`;
    })
    .join("\n");

  const markdown = `# GDA React API Proxy Smoke Report

Generated: ${report.testedAt}

Overall: **${report.overallStatus}**

| Metric | Value |
|---|---:|
| Endpoints tested | ${totals.endpointsTested} |
| Endpoints passed | ${totals.endpointsPassed} |
| Endpoints failed | ${totals.endpointsFailed} |
| Auth failures | ${totals.authFailures} |
| Empty responses | ${totals.emptyResponses} |
| HTML responses | ${totals.htmlResponses} |

## Endpoint Results

| Endpoint | Status | HTTP | Duration ms | Path | Flags |
|---|---:|---:|---:|---|---|
${mdRows}
`;

  fs.writeFileSync(mdPath, markdown, "utf8");

  console.log(`Overall: ${report.overallStatus}`);
  console.log(`Endpoints tested: ${totals.endpointsTested}`);
  console.log(`Endpoints passed: ${totals.endpointsPassed}`);
  console.log(`Endpoints failed: ${totals.endpointsFailed}`);
  console.log(`Auth failures: ${totals.authFailures}`);
  console.log(`Empty responses: ${totals.emptyResponses}`);
  console.log(`HTML responses: ${totals.htmlResponses}`);
  console.log(`JSON report: ${jsonPath}`);
  console.log(`Markdown report: ${mdPath}`);

  if (!report.ok) {
    process.exitCode = 1;
  }
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
