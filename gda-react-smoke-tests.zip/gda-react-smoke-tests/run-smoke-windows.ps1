$ErrorActionPreference = "Stop"

Write-Host ""
Write-Host "Running GDA React daily baseline..." -ForegroundColor Cyan
Write-Host ""

npm run baseline

Write-Host ""
Write-Host "Done. Reports are in the reports folder." -ForegroundColor Green
