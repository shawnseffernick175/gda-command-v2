$ErrorActionPreference = "Stop"

Write-Host ""
Write-Host "Running GDA Ops Daily Baseline..." -ForegroundColor Cyan
Write-Host ""

if (-not $env:GDA_QA_AGENT_WEBHOOK_URL) {
  $enteredUrl = Read-Host "Enter GDA_QA_AGENT_WEBHOOK_URL, or press Enter to skip n8n QA checks"
  if ($enteredUrl) {
    $env:GDA_QA_AGENT_WEBHOOK_URL = $enteredUrl
  }
}

if ($env:GDA_QA_AGENT_WEBHOOK_URL -and -not $env:GDA_QA_AGENT_KEY) {
  $secureKey = Read-Host "Enter GDA_QA_AGENT_KEY" -AsSecureString
  $bstr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secureKey)
  try {
    $env:GDA_QA_AGENT_KEY = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($bstr)
  }
  finally {
    [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($bstr)
  }
}

npm run ops

Write-Host ""
Write-Host "Done. Reports are in the reports folder." -ForegroundColor Green
