$ErrorActionPreference = "Stop"

Write-Host ""
Write-Host "GDA QA Agent Local Setup" -ForegroundColor Cyan
Write-Host ""
Write-Host "This stores your QA agent webhook URL and QA agent key in your Windows user environment."
Write-Host "It does not store your n8n API key or your GDA webhook key."
Write-Host ""

$currentUrl = [Environment]::GetEnvironmentVariable("GDA_QA_AGENT_WEBHOOK_URL", "User")
$currentKey = [Environment]::GetEnvironmentVariable("GDA_QA_AGENT_KEY", "User")

if ($currentUrl) {
  Write-Host "Existing GDA_QA_AGENT_WEBHOOK_URL found." -ForegroundColor Yellow
  $replaceUrl = Read-Host "Replace it? Type Y to replace, or press Enter to keep"
  if ($replaceUrl -match "^[Yy]$") {
    $currentUrl = $null
  }
}

if (-not $currentUrl) {
  $currentUrl = Read-Host "Paste your QA agent webhook URL"
}

if ($currentKey) {
  Write-Host "Existing GDA_QA_AGENT_KEY found." -ForegroundColor Yellow
  $replaceKey = Read-Host "Replace it? Type Y to replace, or press Enter to keep"
  if ($replaceKey -match "^[Yy]$") {
    $currentKey = $null
  }
}

if (-not $currentKey) {
  $secureKey = Read-Host "Paste your QA agent key" -AsSecureString
  $bstr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secureKey)
  try {
    $currentKey = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($bstr)
  }
  finally {
    [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($bstr)
  }
}

if (-not $currentUrl) {
  throw "Missing QA agent webhook URL."
}

if (-not $currentKey) {
  throw "Missing QA agent key."
}

[Environment]::SetEnvironmentVariable("GDA_QA_AGENT_WEBHOOK_URL", $currentUrl, "User")
[Environment]::SetEnvironmentVariable("GDA_QA_AGENT_KEY", $currentKey, "User")

$env:GDA_QA_AGENT_WEBHOOK_URL = $currentUrl
$env:GDA_QA_AGENT_KEY = $currentKey

Write-Host ""
Write-Host "Saved." -ForegroundColor Green
Write-Host ""
Write-Host "Testing QA agent health..." -ForegroundColor Cyan

$response = Invoke-RestMethod `
  -Uri $env:GDA_QA_AGENT_WEBHOOK_URL `
  -Method POST `
  -Headers @{
    "Content-Type" = "application/json"
    "x-gda-qa-key" = $env:GDA_QA_AGENT_KEY
  } `
  -Body '{"action":"health"}'

$response | ConvertTo-Json -Depth 20

if ($response.ok -ne $true) {
  throw "QA agent health check did not return ok=true."
}

Write-Host ""
Write-Host "QA agent setup is working." -ForegroundColor Green
Write-Host "Close and reopen PowerShell if future shells do not see the new environment variables."
