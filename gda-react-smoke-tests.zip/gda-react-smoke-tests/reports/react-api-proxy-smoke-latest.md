# GDA React API Proxy Smoke Report

Generated: 2026-04-27T17:17:01.898Z

Overall: **PASS**

| Metric | Value |
|---|---:|
| Endpoints tested | 10 |
| Endpoints passed | 10 |
| Endpoints failed | 0 |
| Auth failures | 0 |
| Empty responses | 0 |
| HTML responses | 0 |

## Endpoint Results

| Endpoint | Status | HTTP | Duration ms | Path | Flags |
|---|---:|---:|---:|---|---|
| dashboard mega | PASS | 200 | 402 | /api/gda-dashboard-mega |  |
| trends | PASS | 200 | 124 | /api/gda-trends |  |
| daily actions | PASS | 200 | 18128 | /api/gda-daily-actions |  |
| opportunity tracker | PASS | 200 | 322 | /api/gda-opp-tracker |  |
| launchpad funnel | PASS | 200 | 203 | /api/gda-launchpad-funnel |  |
| deep research history | PASS | 200 | 106 | /api/gda-deep-research-history |  |
| capture plan list | PASS | 200 | 278 | /api/gda-capture-plan |  |
| risk register | PASS | 200 | 222 | /api/gda-risk |  |
| platform health | PASS | 200 | 140 | /api/gda-platform-health |  |
| morning briefing | PASS | 200 | 387 | /api/gda-morning-briefing |  |
