# GDA React Sidebar Smoke Report

Generated: 2026-04-27T17:14:14.461Z

Overall: **PASS**

| Metric | Value |
|---|---:|
| Routes tested | 23 |
| Routes passed | 23 |
| Routes failed | 0 |
| Direct n8n webhook calls | 0 |
| Console errors | 0 |
| Blocking failed requests | 0 |

## Route Results

| Route | Status | Direct n8n calls | Console errors | Blocking failed requests | URL | Failed request URLs |
|---|---:|---:|---:|---:|---|---|
| Launchpad | PASS | 0 | 0 | 0 | https://gda.csr-llc.tech/?v=1777309990491#launchpad |  |
| AI Agent Chat | PASS | 0 | 0 | 0 | https://gda.csr-llc.tech/?v=1777309990491#ai-agent |  |
| Daily SITREP | PASS | 0 | 0 | 0 | https://gda.csr-llc.tech/?v=1777309990491#sitrep |  |
| Morning Brief | PASS | 0 | 0 | 0 | https://gda.csr-llc.tech/?v=1777309990491#daily-brief |  |
| Intel Feed | PASS | 0 | 0 | 0 | https://gda.csr-llc.tech/?v=1777309990491#intel-feed |  |
| Deep Research | PASS | 0 | 0 | 0 | https://gda.csr-llc.tech/?v=1777309990491#deep-research |  |
| Meeting Notes | PASS | 0 | 0 | 0 | https://gda.csr-llc.tech/?v=1777309990491#meeting-notes |  |
| Competitive Intel | PASS | 0 | 0 | 0 | https://gda.csr-llc.tech/?v=1777309990491#comp-intel |  |
| Bid Strategy | PASS | 0 | 0 | 0 | https://gda.csr-llc.tech/?v=1777309990491#bid-strategy |  |
| OODA Loop | PASS | 0 | 0 | 0 | https://gda.csr-llc.tech/?v=1777309990491#ooda |  |
| Opportunity Tracker | PASS | 0 | 0 | 0 | https://gda.csr-llc.tech/?v=1777309990491#opp-tracker |  |
| Pwin Calculator | PASS | 0 | 0 | 0 | https://gda.csr-llc.tech/?v=1777309990491#pwin-calculator |  |
| Capture Plan | PASS | 0 | 0 | 0 | https://gda.csr-llc.tech/?v=1777309990491#capture-plan |  |
| Compliance Matrix | PASS | 0 | 0 | 0 | https://gda.csr-llc.tech/?v=1777309990491#compliance-matrix |  |
| Document Hub & PPT | PASS | 0 | 0 | 0 | https://gda.csr-llc.tech/?v=1777309990491#doc-hub |  |
| Email Drafter | PASS | 0 | 0 | 0 | https://gda.csr-llc.tech/?v=1777309990491#email |  |
| Proposal Review | PASS | 0 | 0 | 0 | https://gda.csr-llc.tech/?v=1777309990491#red-team |  |
| Proposal Factory | PASS | 0 | 0 | 0 | https://gda.csr-llc.tech/?v=1777309990491#proposal-factory |  |
| Risk Register | PASS | 0 | 0 | 0 | https://gda.csr-llc.tech/?v=1777309990491#risk |  |
| Financial Bible | PASS | 0 | 0 | 0 | https://gda.csr-llc.tech/?v=1777309990491#aop-tracker |  |
| Platform Health | PASS | 0 | 0 | 0 | https://gda.csr-llc.tech/?v=1777309990491#platform-health |  |
| Platform Guide | PASS | 0 | 0 | 0 | https://gda.csr-llc.tech/?v=1777309990491#directions |  |
| Prompt Architect | PASS | 0 | 0 | 0 | https://gda.csr-llc.tech/?v=1777309990491#prompt-architect |  |
