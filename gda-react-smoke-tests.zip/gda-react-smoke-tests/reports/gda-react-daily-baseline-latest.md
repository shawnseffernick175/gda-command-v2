# GDA React Daily Baseline Report

Generated: 2026-04-27T17:17:01.963Z

Overall: **PASS**

| Metric | Value |
|---|---:|
| Sidebar routes tested | 23 |
| Sidebar routes passed | 23 |
| Sidebar routes failed | 0 |
| Functional checks tested | 8 |
| Functional checks passed | 8 |
| Functional checks failed | 0 |
| API endpoints tested | 10 |
| API endpoints passed | 10 |
| API endpoints failed | 0 |
| Direct n8n webhook calls | 0 |
| Browser console errors | 0 |
| Blocking failed requests | 0 |
| API auth failures | 0 |
| API empty responses | 0 |
| API HTML responses | 0 |

## Check Results

| Check | Status | Exit code | Detail report |
|---|---:|---:|---|
| Sidebar route smoke | PASS | 0 | react-sidebar-smoke-latest.json |
| Functional smoke | PASS | 0 | react-functional-smoke-latest.json |
| API proxy smoke | PASS | 0 | react-api-proxy-smoke-latest.json |

## Interpretation

This baseline is safe and read-only. It does not change n8n, Postgres, opportunities, risks, action items, or deployed React code.

Passing means the live React app loaded its tested sidebar routes, key pages showed expected UI, and React-critical server-side proxy endpoints responded without auth failures.
