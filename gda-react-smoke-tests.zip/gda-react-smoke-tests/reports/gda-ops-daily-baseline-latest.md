# GDA Ops Daily Baseline Report

Generated: 2026-04-27T17:17:01.979Z

Overall: **NEEDS_REVIEW**

| Metric | Value |
|---|---:|
| Hard failures | 0 |
| Needs review | 0 |
| Skipped checks | 4 |
| React sidebar routes | 23/23 |
| React functional checks | 8/8 |
| React API endpoints | 10/10 |
| Direct n8n webhook calls | 0 |
| Browser console errors | 0 |
| Blocking failed requests | 0 |
| API auth failures | 0 |

## Check Results

| Check | Status | Summary |
|---|---:|---|
| React daily baseline | PASS |  |
| QA agent health | SKIPPED | Set GDA_QA_AGENT_WEBHOOK_URL and GDA_QA_AGENT_KEY to enable this check. |
| n8n React-used workflow smoke | SKIPPED | Set GDA_QA_AGENT_WEBHOOK_URL and GDA_QA_AGENT_KEY to enable this check. |
| n8n Retool-used workflow smoke | SKIPPED | Set GDA_QA_AGENT_WEBHOOK_URL and GDA_QA_AGENT_KEY to enable this check. |
| Latest failed n8n workflows | SKIPPED | Set GDA_QA_AGENT_WEBHOOK_URL and GDA_QA_AGENT_KEY to enable this check. |

## Notes

This command is read-only. It does not change n8n workflows, Postgres data, deployed React code, opportunities, risks, action items, or external integrations.

If n8n checks are skipped, set `GDA_QA_AGENT_WEBHOOK_URL` and `GDA_QA_AGENT_KEY` in PowerShell before running, or use `.\run-ops-baseline-windows.ps1` and enter them when prompted.
