# GDA React Functional Smoke Report

Generated: 2026-04-27T17:16:41.425Z

Overall: **PASS**

| Metric | Value |
|---|---:|
| Checks tested | 8 |
| Checks passed | 8 |
| Checks failed | 0 |
| Missing expected text items | 0 |
| Forbidden text matches | 0 |
| Direct n8n webhook calls | 0 |
| Console errors | 0 |
| Blocking failed requests | 0 |

## Check Results

| Check | Status | Hash | Missing expected text | Forbidden text found | Direct n8n calls | Console errors | Blocking failed requests |
|---|---:|---|---|---|---:|---:|---:|
| Launchpad dashboard basics | PASS | #launchpad |  |  | 0 | 0 | 0 |
| Opportunity Tracker basics | PASS | #opp-tracker |  |  | 0 | 0 | 0 |
| Platform Health basics | PASS | #platform-health |  |  | 0 | 0 | 0 |
| Deep Research basics | PASS | #deep-research |  |  | 0 | 0 | 0 |
| Proposal Factory basics | PASS | #proposal-factory |  |  | 0 | 0 | 0 |
| Financial Bible basics | PASS | #aop-tracker |  |  | 0 | 0 | 0 |
| Risk Register basics | PASS | #risk |  |  | 0 | 0 | 0 |
| Morning Brief basics | PASS | #daily-brief |  |  | 0 | 0 | 0 |
