# GDA React Smoke Tests

This is a safe, read-only test kit for the live GDA React Command Center.

It opens the React app in a browser, clicks through the sidebar pages, and fails if it sees:

- direct browser calls to `n8n.csr-llc.tech/webhook`
- browser console errors
- failed GDA API requests, except navigation-aborted requests
- sidebar pages that cannot be clicked

## What it does not do

- It does not change n8n.
- It does not need your n8n API key.
- It does not use your webhook key.
- It does not write to Postgres.
- It does not deploy anything.

## First-time setup

Open PowerShell in this folder and run:

```powershell
npm run setup
```

## Run the smoke test

```powershell
npm run smoke
```

## Run functional smoke checks

These checks verify high-value pages show expected business UI text and do not show obvious auth failures.

```powershell
npm run functional
```

## Run API proxy smoke checks

These checks call selected React-critical `/api/...` proxy endpoints directly and fail on auth errors, empty responses, HTML responses, or non-2xx responses.

```powershell
npm run api
```

## Run everything

```powershell
npm run all
```

## Run the daily baseline

This is the recommended command. It runs the sidebar route smoke test, the functional smoke checks, and the API proxy checks, then writes one combined report.

```powershell
npm run baseline
```

You can also double-click/use the helper from PowerShell:

```powershell
.\run-smoke-windows.ps1
```

## Run the ops daily baseline

This runs the React daily baseline first. If you provide your secured n8n QA agent URL and key, it also checks QA agent health, the React-used workflow smoke group, the Retool-used workflow smoke group, and latest failed n8n workflows.

It is read-only. It does not change n8n or Postgres.

```powershell
npm run ops
```

Or use the PowerShell helper, which prompts for the QA agent details if they are not already set:

```powershell
.\run-ops-baseline-windows.ps1
```

Optional environment variables:

```powershell
$env:GDA_QA_AGENT_WEBHOOK_URL = "https://n8n.csr-llc.tech/webhook/YOUR-QA-AGENT-PATH"
$env:GDA_QA_AGENT_KEY = "YOUR-QA-AGENT-KEY"
npm run ops
```

## Save QA-agent settings on Windows

Run this once from PowerShell in the smoke-test folder:

```powershell
.\setup-qa-agent-windows.ps1
```

It prompts for:

- `GDA_QA_AGENT_WEBHOOK_URL`
- `GDA_QA_AGENT_KEY`

Then it saves them to your Windows user environment and tests QA-agent health.

After that, your normal daily command is:

```powershell
npm run ops
```

## Output

The test writes two files:

- `reports/react-sidebar-smoke-latest.json`
- `reports/react-sidebar-smoke-latest.md`
- `reports/react-functional-smoke-latest.json`
- `reports/react-functional-smoke-latest.md`
- `reports/react-api-proxy-smoke-latest.json`
- `reports/react-api-proxy-smoke-latest.md`
- `reports/gda-react-daily-baseline-latest.json`
- `reports/gda-react-daily-baseline-latest.md`
- `reports/gda-ops-daily-baseline-latest.json`
- `reports/gda-ops-daily-baseline-latest.md`

If everything is healthy, the terminal summary should show:

```text
Overall: PASS
Routes tested: 23
Direct n8n webhook calls: 0
Console errors: 0
Blocking failed requests: 0
```

## Recommended use

Run this after every React deploy and before trusting the app for daily work.
