# S-191 Kickoff — GDA Command Platform
**Date:** Next session after May 2, 2026
**Operator:** Claude (Anthropic)
**Platform:** GDA OU3 / Envision Innovative Solutions

---

## Session Open Protocol (MANDATORY)
1. `tool_search("n8n")` — load MCP context
2. Read this file
3. Execute top item from queue below without interrogating

---

## Platform State at S-190 Close
| Component | State |
|---|---|
| VPS 187.77.206.105 | ONLINE |
| n8n.csr-llc.tech | ACTIVE — 160+ workflows |
| gda.csr-llc.tech | LIVE — React SPA, ops loading via gateway |
| API Gateway | ACTIVE — gda-gateway.service systemd, :8788, n8n proxy route live |
| QA test suite | **10/10 PASS** (was 6/10 at S-190 open) |
| Reboot survival | **ALL SERVICES** — 7/7 Docker containers restart=always, systemd services enabled |
| nginx | Rate limiting active — 30r/s /api/, 60r/s general |

---

## S-191 Priority Queue

### **RANK 1 — HP-4: saveDataSuccessExecution Audit**
High-volume workflows (opp-refresh, data-sync, broad-opp-search, etc.) may be set to save ALL successful executions, filling the n8n DB fast.

```
SSH cmd: python3 -c "
import urllib.request, json
api_key = open('/root/n8n-envision/.env').read().split('N8N_API_KEY=')[1].split()[0]
req = urllib.request.Request('http://localhost:5678/api/v1/workflows?limit=200', headers={'X-N8N-API-KEY': api_key})
with urllib.request.urlopen(req) as r:
    wfs = json.loads(r.read())['data']
    for w in wfs:
        s = w.get('settings', {})
        if s.get('saveDataSuccessExecution') == 'all':
            print(w['id'], w['name'])
"
```
Set `saveDataSuccessExecution: none` on any high-frequency cron workflows returning > 50 rows/run.

### **RANK 2 — Block F: OODA Auto-Trigger**
When a new opp enters `PURSUE` stage, auto-trigger opp-tracker OODA analysis. Wire: opp-tracker stage-change webhook → IF stage=PURSUE → call gda-ooda with opp context → Telegram result to Shawn.

### **RANK 3 — Block F: Pwin Loop**
Daily: pull all PURSUE opps with no pwin score → batch call gda-pwin-calculator → update gda_opportunity_tracker.gda_score → Telegram summary of changes.

### **RANK 4 — Block F: Recompete Alert**
GDA.cron.recompete-early-warning (MtcQwAgm1zHYXNfB) — verify it's running and Telegram is wired. If not, wire it.

### **RANK 5 — Block F: Capture AI Assist**
When a capture plan is created, auto-trigger incumbent analysis + recommended teaming partners → append to plan_data in gda_capture_plans.

### **RANK 6 — AN-1: Incumbent Analysis Win Themes**
Pull all WON entries from gda_win_loss_db → extract agency patterns, teaming patterns, NAICS patterns → seed gda_learned_weights → Telegram summary.

---

## Key Credentials (S-190 canonical)
```
x-gda-key:                gda-api-2027-AWqjhbxDYNcyV1mr
GDA Webhook Auth cred:    fTrhOzBkjS1s67bm  (headerAuth on all webhooks)
GDA Webhook Auth cred:    1pNPY36DDz49OtKL  (alternate — some older workflows)
VPS SSH Key cred:         NKOxLo5F81sRNPua
QA Agent key:             qa-agent-test-2026-adlkjfn7987-srkigio-99-eatshit
```

## Key Workflow IDs
```
SSH Exec:             IcD4K740vpWSIuaZ
Deploy:               8GnGxnBL9TJjj1i2
Dashboard-mega:       UYGJPu7N5YZblvEU
opp-tracker 2:        SEJLE89wZa1yfQyB  (CANONICAL)
ooda-loop 2:          pkPpMhiz8IdRy7To  (CANONICAL)
agent-runner:         TxcPdvx2Ld9rE9er
Morning briefing:     YIvCdrOgF1LGmFNL
Capture-plan:         QgperN6cuOpfnb09
platform-health:      UBgoJGxZro834RbT
daily-actions:        C7Bh7KcAl1IgSTRr
action-history:       1OPkoA5e8DYVQKm1
recompete-warning:    MtcQwAgm1zHYXNfB
error-handler:        2Swf6LP9AzFjHFYU
```

## Hard Rules (S-190 additions + all prior)
- Switch node → broken → use IF or Code nodes
- LangChain cred d92MU0tRK7bEGV83 → permanently broken → HTTP + $env.ANTHROPIC_API_KEY
- Postgres typeVersion 2.5/2.6 → inline `{{ $json.field }}` in SQL; no queryValues; use dollar-quoting ($tag$...$tag$) for JSON strings
- App.jsx writes → UTF-8 only; backup at /opt/gda-command/src/App.jsx.bak-s158-kpi
- Deploy sequence: vite build → cp -r dist/. /root/gda-frontend/dist/ → docker exec nginx -s reload
- N8N_ENCRYPTION_KEY → must persist in /root/n8n-envision/.env
- nginx config: bind-mounted from /root/gda-frontend/nginx.conf; reload via docker exec nginx -s reload
- Gateway: /opt/gda-command/gateway/src/server.js; running as gda-gateway.service; PORT=8788
- Gateway restart: python3 /tmp/restart_gw.py (script persists in /tmp; recreate if gone)
- SSH Guard allows: bash -c, python3 (any), cat, grep, sed, tee, tail, find, ls — NOT nohup/pkill/cd directly
- MCP prefix: fuck-this-shit: exclusively for live ops. n8n: may timeout.
- errorWorkflow: 2Swf6LP9AzFjHFYU now set on 25 additional workflows (S-190)
- Canonical active pipeline: stage NOT IN ('No-Bid','Cancelled','No-Go','Lost','Won')
- Canonical opp table: gda_opportunity_tracker (not 'opportunities')
- RR-38 and RR-28 are RESOLVED.
- Never mention Retool.

---

## North Star Gap (post S-190)
| Remaining | Effort |
|---|---|
| HP-4: saveDataSuccessExecution | S-191 Rank 1 — quick audit |
| Block F: Autonomous BD ops layer (OODA auto, pwin loop, recompete, capture AI) | S-191–S-193 |
| AN-1: Incumbent analysis win themes | S-191 |

Platform is ~85% of North Star vision. Block F is the autonomous BD ops layer — the original end goal.

---
*Generated by R-SR-09 close protocol at end of S-190 — May 2, 2026*
