# GDA Command Platform — S-161 Kickoff
**Prepared:** S-160 close | April 22, 2026
**Next operator:** Shawn Seffernick, EIS/GDA OU3

---

## Pre-Flight (Every Chat)
1. `tool_search("n8n")` — load MCP
2. Read this file
3. RR-38 and RR-28 are **CLOSED** (resolved S-159)

---

## FIRST ACTION NEXT CHAT

Ask Shawn if new items exist before defaulting to queue below.

**S-161 Priority Queue:**
1. **HP-8** (Low) — queryReplacement final sweep — 8 nodes confirmed, patch all now
2. **HP-6** (Med) — Webhook key rotation — coordinated App.jsx + n8n cred + all webhook callers
3. **HP-7** (Med) — nginx/proxy rate limiting — locate proxy config via SSH, then apply `limit_req_zone`

---

## HP-8 Patch List (queryReplacement → inline expressions)

All 8 nodes need `options.queryReplacement` removed and queries rewritten with `{{ $json.field }}` inline expressions:

| Workflow | ID | Node | Params |
|---|---|---|---|
| recompete-early-warning | MtcQwAgm1zHYXNfB | Create Missing Opp Stubs | 6 |
| recompete-early-warning | MtcQwAgm1zHYXNfB | Log to Intelligence | 2 |
| win-rate-weekly-digest | ZuQkz1HrMONclkFm | Save Digest to DB | 5 |
| idiq-task-order-alert | DeSN1t1swXX14xTc | Create TO Opp Stubs | 7 |
| idiq-task-order-alert | DeSN1t1swXX14xTc | Log TO to Intel | 2 |
| capture-opp-sync | 0E3lCtWt2rdJlMPY | Promote Opp Stage | 3 |
| capture-milestone-alerts | Kk7O8Bw2FOe41M9l | Log Milestone Alert | 3 |

**Note on win-rate Save Digest to DB:** insight field is Claude output — contains apostrophes/quotes — HIGH failure risk with queryReplacement.

---

## Platform State

| Item | Status |
|---|---|
| Active workflows | ~155 |
| Frontend (gda.csr-llc.tech) | LIVE |
| GDA.util.ssh-read-file | HARDENED — headerAuth + Guard allowlist active |
| All cron workflows | errorWorkflow → 2Swf6LP9AzFjHFYU ✅ |
| morning-briefing, dashboard-mega, opp-tracker 2, capture-plan | saveDataSuccessExecution: none ✅ |
| Hardening Items 1–5 | COMPLETE |
| Hardening Items 6–8 | QUEUED |

---

## Open Debt

| ID | Sev | Summary |
|---|---|---|
| HP-6 | Med | Webhook key rotation — gda-api-2026-secure + gda-deploy-2026-secure |
| HP-7 | Med | nginx/proxy rate limiting — proxy config location TBD |
| HP-8 | Low | queryReplacement sweep — 8 nodes across 4 workflows |
| RR-36 | Med | Chrome MCP cross-origin — workaround in place |
| RR-43 | Low | Bot dual-routing — fix when telegram-chat next touched |
| RR-44 | Low | n8n_test_workflow 403 on headerAuth — workaround documented |

---

## Key Workflow IDs

| Workflow | ID |
|---|---|
| GDA.util.ssh-read-file | IcD4K740vpWSIuaZ |
| GDA.dev.deploy | 8GnGxnBL9TJjj1i2 |
| GDA.bot.telegram-chat | 1ItrrFxGI3L43Pdv |
| GDA.intel.morning-briefing-v1 | YIvCdrOgF1LGmFNL |
| GDA.api.capture-plan | QgperN6cuOpfnb09 |
| GDA.api.dashboard-mega | UYGJPu7N5YZblvEU |
| GDA.cron.recompete-early-warning | MtcQwAgm1zHYXNfB |
| GDA.cron.win-rate-weekly-digest | ZuQkz1HrMONclkFm |
| GDA.cron.idiq-task-order-alert | DeSN1t1swXX14xTc |
| GDA.cron.capture-opp-sync | 0E3lCtWt2rdJlMPY |
| GDA.cron.learning-engine | fZpqchmmPnqAmiMq |
| GDA.cron.capture-milestone-alerts | Kk7O8Bw2FOe41M9l |
| Error handler | 2Swf6LP9AzFjHFYU |

---

## Infrastructure

| Resource | Detail |
|---|---|
| Frontend source | /opt/gda-command/src/App.jsx |
| Deploy webhook | POST https://n8n.csr-llc.tech/webhook/gda-deploy |
| Deploy auth | Header: x-gda-auth: gda-deploy-2026-secure |
| SSH webhook (read) | POST https://n8n.csr-llc.tech/webhook/ssh-read-file |
| SSH auth (read) | Header: x-gda-key: gda-api-2026-secure (RR-44: temp set to none → fire → restore) |
| API auth | Header: x-gda-key: gda-api-2026-secure |
| Postgres cred | HwronxMmGY5XDGEt |
| VPS | 187.77.206.105 |
| n8n | https://n8n.csr-llc.tech |
| MCP | https://mcp.csr-llc.tech/mcp |

---

## Critical Rules

- Claude executes everything via MCP. Never tell Shawn to manually do things.
- All Postgres nodes at typeVersion 2.5/2.6: use inline `{{ $json.field }}` expressions — NEVER queryValues arrays or queryReplacement strings.
- Switch node is broken — use IF or Code nodes.
- LangChain cred d92MU0tRK7bEGV83 is BROKEN — all Anthropic calls via direct HTTP with $env.ANTHROPIC_API_KEY.
- Webhook test pattern (RR-44): temp set auth to none → fire → restore headerAuth.
- SSH Guard allowlist: cat, ls, wc, echo, find /opt/gda-command, python3 /tmp/gda_* — do NOT add /etc paths permanently.

---

## Schema (Canonical)

- `gda_intelligence_log` time column: **timestamp only** — created_at DROPPED S-159
- Allocation revenue: `gda_capture_plans.plan_data->>'allocated_revenue'` (JSONB, dollars)
- `opp-tracker 2` and `ooda-loop 2` are LIVE CANONICAL — do not delete
- `gda_mega_cache` — id=1 singleton, 60min TTL
- capture-plan Postgres nodes use inline `{{ }}` expressions — queryReplacement fully removed S-158 Chat 2

---

*— GDA S-161 Kickoff | Prepared at S-160 close | April 22, 2026 —*
